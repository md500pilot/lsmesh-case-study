bool electShouldTakeOver(uint32_t nowMs){
#ifdef LSM_LISTEN_ONLY
  // A passive witness may observe candidate state for diagnostics, but it must
  // never become an authority. LSM_TX is a no-op on this build, so allowing a
  // logical takeover would create a silent keeper that freezes its partition.
  return false;
#endif
  // A quarantined radio remains a normal member but can neither cold-elect nor
  // use a stale successor nomination.  Every keeper applies the same mask when
  // naming its successor, so this does not strand the fast-failover chain.
  if (!keeperEligibleId((uint8_t)NODE_ID)) return false;
  if (!g_radioElectionReady) {
    g_coldCommitSinceMs = 0;
    g_electBootMs = 0;
    g_electJitterMs = 0;
    return false;
  }
  // v7.29.43: election deadlines are unique provisioned-id ranks. This removes
  // the modulo collisions and gives the preceding rank a full second to publish.
  if (g_electBootMs==0){ g_electBootMs=nowMs; g_electJitterMs = electSeparatorMs(); }   // v7.28.36: drawn once per cycle so the threshold holds steady for the cycle
  // Vacuum: we have never heard any TK and the boot grace has elapsed. Nobody
  // is in charge, so form the mesh by taking authority. Other nodes in the same
  // vacuum resolve to one winner via the score compare below once they hear us.
  // v6.1: vacuum election is STAGGERED by NODE_ID so two members losing the
  // TK in the same instant do not both self-elect (bench 2026-07-04: pulled 07,
  // both 08 and 09 went TK). The lowest id fires first; each higher rank waits
  // 400 ms more and hears the new TK's first beacon before its own timer fires.
  // v7.18.0: re-centered on the command post id. The old ((id>=7)?id-7:id)
  // formula was a leftover from when 07 was the command post; after the move
  // to 05 it mapped 05 and 12 to the SAME 2000ms mark, so the one pair that
  // most needs separation (command post vs its hop-1 spine) had none. Offset
  // from CMD id over the 8-id ring is collision-free and puts 05 first.
  uint32_t stag = g_electJitterMs;   // v7.28.36: per-cycle SEPARATOR slice (electSeparatorMs), drawn once when the election clock arms; every board is eligible the instant its cold listen elapses, and slices are disjoint by construction
  if (g_successor == (uint8_t)NODE_ID) stag = 0;   // v6.6: named successor jumps the queue for fast failover
  // v7.19.2: sphere-full LOCKOUT -> SPILL, not on-channel spawn. The v6.6 body
  // here returned true, self-electing a rival TK ON the channel that just
  // flagged full; its own comment admitted it only existed to prove the
  // control path on the single-channel rig. The cap-4 bench woke it for the
  // first time and produced three co-resident TKs on 924 (2026-07-28 live
  // bench, root-caused same day). Now: request a deferred spill. The main
  // loop retunes to the backhaul and re-walks the ladder exactly like a cold
  // boot (spillWalkLadder), joining the first rung with room or spawning on
  // the first empty rung. The walk blocks ~3.5 s, so it runs at a loop-level
  // safe point, never inside this predicate. Uniform across all boards: no
  // command-post carve-out. The v7.12.28 board-05 +30000 bias was removed from
  // this tree, so every board reaches this branch on merit.
  if (g_sphereFull && g_role==0) {
    if (g_fullBlockedSinceMs==0) g_fullBlockedSinceMs=nowMs;
    else if (nowMs - g_fullBlockedSinceMs > SPHERE_FULL_HOLD_MS + stag) {
      g_spillReq = true; g_spillFromFull = true;   // v7.28.8: full-lockout spill excludes the current (full) rung
      g_fullBlockedSinceMs = 0;
      return false;
    }
  } else g_fullBlockedSinceMs=0;
  if (g_lastTkHeardMs==0) {
    // v7.29.46: a cold/late starter may miss the keeper schedule while still
    // hearing authenticated members that are following it. Treat two or more
    // advancing frame witnesses as a short authority lease. The lease uses the
    // keeper frame sequence as its clock, not local wall-clock agreement.
    // Once advances stop, the lease expires and the original unique rank is
    // applied from the expiry boundary, so disconnected partitions still form
    // one keeper instead of freezing indefinitely.
    uint32_t leaseHold = tkSuccessorPeerMs();
    if (g_meshLease.advancedAt != 0 &&
        (uint32_t)(nowMs - g_meshLease.advancedAt) <= leaseHold) {
      g_coldCommitSinceMs = 0;
      return false;
    }
    if (g_meshLease.advancedAt != 0) {
      uint32_t expiredAt = g_meshLease.advancedAt + leaseHold;
      if ((int32_t)(nowMs - expiredAt) > (int32_t)stag) {
        if (g_coldCommitSinceMs == 0) {
          g_coldCommitSinceMs = nowMs;
          logRec(4 /*LOG_STATE*/, NODE_ID, g_role, 0xF7, 1, 0, coldCommitGuardMs());
          return false;
        }
        if ((uint32_t)(nowMs - g_coldCommitSinceMs) >= coldCommitGuardMs()) return true;
      }
      return false;
    }
    if (nowMs - g_electBootMs > TK_COLD_LISTEN_MS + stag) {
      if (g_coldCommitSinceMs == 0) {
        g_coldCommitSinceMs = nowMs;
        logRec(4 /*LOG_STATE*/, NODE_ID, g_role, 0xF7, 0, 0, coldCommitGuardMs());
        return false;
      }
      if ((uint32_t)(nowMs - g_coldCommitSinceMs) >= coldCommitGuardMs()) return true;
    }
  }
  // TK went silent long enough to be considered gone.
  // v7.28.22: was (nowMs - g_lastTkHeardMs > TK_FAILOVER_MS + stag), which any
  // relayed copy of a dead keeper's cached beacon reset. Now the age of the last
  // SEQ ADVANCE. g_lastTkHeardMs stays in the predicate as the have-we-ever-heard
  // -a-keeper term; the cold branch above still owns the never-heard case.
  // v7.29.38 WARM SUCCESSOR. Only the keeper-named backup may use the fast
  // path. It stays on the working channel, preserves the last published roster,
  // and advances the authority epoch. Every other member remains behind the
  // conservative quorum/vacuum logic, so one missing keeper produces one replacement.
  uint32_t warmAdvanceMs = warmLastAdvanceMs();
  bool warmUsingPeer = g_peerSeqAdvMs != 0 && g_peerSeqTk == g_tkId;
  uint32_t warmMissMs = warmUsingPeer ? tkSuccessorPeerMs() : tkSuccessorMs();
  bool warmSuccessor = (g_role == 1) && (g_successor == (uint8_t)NODE_ID)
                    && (g_lastTkHeardMs != 0) && (warmAdvanceMs != 0)
                    && ((uint32_t)(nowMs - warmAdvanceMs) > warmMissMs);
  if (warmSuccessor) {
    // warmAdvanceMs already includes authenticated advancing peer evidence,
    // and warmMissMs gives that evidence the full ten-second fade hold. A
    // second gate on any merely-recent (but no longer advancing) keepalive
    // extended a real failover by another peer-fresh window: the nine-board
    // v7.29.40 test measured 18.3 s. Once the advancing-sequence hold expires,
    // stale scheduled reports must not postpone the named successor again.
    g_warmTakeoverPending = true;
    return true;
  }
  if(ordinaryPeerProgressHolds(nowMs)){g_coldCommitSinceMs=0;return false;}
  bool tkDead = (g_lastTkHeardMs!=0) && (g_seqAdvMs!=0) && (nowMs - g_seqAdvMs > tkStallMs() + stag);
  if (tkDead) {
    // v7.28.8: a LISTEN board whose TK went silent must NOT self-elect in place
    // on the same rung. At a mass resignation every board does exactly that at
    // once and re-collides (bench 2026-08-30: ten co-booted boards, 53 rival-
    // outranked resignations, four minutes to converge). Re-walk the ladder
    // instead, so the board resyncs frame timing and either JOINS a keeper that
    // has come up on any rung or spawns cleanly on an empty one. Jittered per
    // attempt from esp_random (an independent draw per board, unlike the
    // unseeded Arduino random() used elsewhere) so co-resigned boards do not
    // re-walk in lockstep. A board that is NOT in LISTEN here (a member whose TK
    // died) keeps the old behavior and fills the vacuum in place.
    // v7.29.6 CANDIDATE STRANDING FIX. A candidate was taking the in-place branch
    // below, which returns without ever reaching the re-walk. Candidate is only
    // ever entered after true isolation (no schedule for aloneGraceMs), so by
    // definition there is no beacon on this rung to hear and the only exit was
    // winning the election outright. Blocked by a rival, the dwell guard or the
    // peer quorum, the board sat deaf forever. Stand the candidate down to LISTEN
    // here so it falls into the ladder re-walk like any isolated listener, and let
    // the existing RELISTEN_MAX_ATTEMPTS counter decide when to spawn. Never spawn
    // straight off a silent rung: the walk has to come up empty first.
    if (g_role == 2) {
      uint32_t candDwell = g_candSinceMs ? nowMs - g_candSinceMs : 0;
      // v7.29.45 CASCADING FALLBACK. The warm path normally names the next
      // live successor every frame. If several keepers are removed faster than
      // that nomination can propagate, all surviving members reach CANDIDATE
      // together. The old code made every candidate see peer quorum and stand
      // down, so the healthy survivors deadlocked indefinitely. Elect exactly
      // one survivor: a candidate may proceed only when no lower-id
      // authenticated keepalive is still fresh. Higher ids stand down and hear
      // its first schedule. A short settle lets simultaneous candidates enter
      // the same comparison before the lowest live id commits.
      uint32_t candWin = quorumWinMs();
      bool lowerLive = false;
      for (uint8_t id = 1; id < (uint8_t)NODE_ID; id++) {
        if (!keeperEligibleId(id)) continue;
        if (g_kaSeenMs[id] && (uint32_t)(nowMs - g_kaSeenMs[id]) <= candWin) {
          lowerLive = true;
          break;
        }
      }
      if (!lowerLive && candDwell >= 500UL) {
        logRec(4 /*LOG_STATE*/, NODE_ID, g_role, 0xE5,
               (int16_t)quorumFresh(nowMs), 0, candDwell);
        return true;
      }
      g_role = 0;
      g_candSinceMs = 0;
      // Fresh grace on stand-down. Without it the anchored isolation check
      // (g_role 0 or 1 past aloneGraceMs, no schedule since the keeper died)
      // re-enters CANDIDATE on the very next loop pass and this branch stands it
      // down again, flipping every pass with two log records each, the
      // ring-flood failure class of v7.28.67/68. The re-walk jitter
      // (RELISTEN_JITTER_MIN_MS + SPAN, 1.5 to 7.5 s) fires well inside the
      // ~28 s grace, so the board walks before it can re-enter candidate.
      // tkDead keys on g_seqAdvMs, not g_lastSchedMs, so this does not hide
      // the dead keeper from the re-walk path below.
      g_lastSchedMs = nowMs;
      logRec(4 /*LOG_STATE*/, NODE_ID, g_role, 0xE3, (int16_t)quorumFresh(nowMs), 0, candDwell);   // aux 0xE3 = candidate stood down to LISTEN for re-walk (dead keeper); data = ms in CANDIDATE. 0xE7 is the election roster-rung witness, do not reuse
    }
    if (g_role != 0) {
      // v7.28.60: a member (or candidate) whose keeper stalled fills the vacuum in place ONLY if its peers
      // have gone quiet too. Two or more peers still keepalive-fresh means the keeper is alive and this board
      // is the one that lost it (deaf, shadowed, or an LR1121 that cannot decode the keeper): go LISTEN,
      // mark the rung occupied so the walk below never spawns back onto this channel, and re-walk.
      uint8_t q = quorumFresh(nowMs);
      if (q < QUORUM_PEERS) {
        // v7.29.5 VACUUM LOCK. Isolated (no fresh peers) but the adopted schedule advanced
        // within VACUUM_LOCK_MS: this board just lost the mesh, the mesh did not lose its
        // keeper. Stay a member in place and keep listening so a grace carry can bring the
        // uplink home; never spawn a one-board island. Node 04, 2026-09-24 walk. When the
        // lock ages out the pre-existing in-place fill runs exactly as before.
        if (nowMs - g_seqAdvMs < VACUUM_LOCK_MS) { vacuumLockWitness(q, nowMs); return false; }
        return true;
      }
      g_role = 0; g_quorumBlocked = true; g_relistenAttempts = 0; g_relistenSinceMs = 0; g_relistenJitterMs = 0;
      logRec(4 /*LOG_STATE*/, NODE_ID, g_role, 0xE8, (int16_t)q, (int16_t)g_framesSilent, nowMs - g_seqAdvMs);   // aux 0xE8 = self-election blocked by peer quorum, e = fresh peers
      return false;
    }
    if (g_relistenAttempts >= RELISTEN_MAX_ATTEMPTS) {
      if (quorumFresh(nowMs) >= QUORUM_PEERS) { g_relistenAttempts = 0; g_quorumBlocked = true; return false; }   // v7.28.60: peers still fresh, keep walking, never spawn here
      if (nowMs - g_seqAdvMs < VACUUM_LOCK_MS) { vacuumLockWitness(quorumFresh(nowMs), nowMs); return false; }   // v7.29.5 VACUUM LOCK, LISTEN branch: same rule, see above
      return true;
    }   // v7.28.10: RELISTEN_MAX_ATTEMPTS empty re-walks; self-elect on the current rung as the last resort, the transitive tiebreak resolves co-electors
    if (g_relistenJitterMs == 0)
      g_relistenJitterMs = RELISTEN_JITTER_MIN_MS + (uint32_t)(esp_random() % RELISTEN_JITTER_SPAN_MS);
    if (g_relistenSinceMs == 0) g_relistenSinceMs = nowMs;
    if (nowMs - g_relistenSinceMs > g_relistenJitterMs) {
      g_spillReq = true;             // main loop retunes to backhaul and re-walks (spillWalkLadder)
      if (g_quorumBlocked) { g_quorumBlocked = false; }   // v7.28.60: a quorum-blocked walk excludes the current rung, same exclusion the full-lockout spill uses
      g_relistenAttempts++;          // v7.28.10: count this empty re-walk toward RELISTEN_MAX_ATTEMPTS
      g_relistenSinceMs  = 0;
      g_relistenJitterMs = 0;        // re-draw next attempt
    }
    return false;                    // never self-elect in place on a dead-TK rung
  }
  // v7.29.19: only an admitted member may challenge a live keeper. LISTEN is
  // deliberately outside the keeper's roster/trust boundary; allowing it into
  // the score handoff let a deep, still-joining board hear the healthy keeper
  // continuously and nevertheless self-elect after TK_HANDOFF_HOLD_MS.
  if (g_role != 1) { g_betterSinceMs = 0; return false; }
#if !LSM_LIVE_MERIT_HANDOFF
  // v7.29.52: the old score path promoted the challenger before the serving
  // keeper had transferred authority. On both matched nine-board runs the
  // weighted node 01 joined a healthy keeper, held its score advantage for
  // exactly six seconds, then created a second epoch and split the followers
  // until merge evidence propagated. Keep score telemetry, but do not turn it
  // into authority without a future explicit offer/accept/commit handshake.
  // Failure paths above remain unchanged and already have a named successor,
  // advancing epoch and deterministic fallback.
  g_betterSinceMs = 0;
  return false;
#endif
  // live TK present: apply the full hysteresis
  if (nowMs - g_tkSinceMs < TK_MIN_DWELL_MS) return false;   // dwell guard
  if (g_myScore < g_tkScore + TK_HANDOFF_MARGIN) { g_betterSinceMs=0; return false; }
  if (g_betterSinceMs==0) g_betterSinceMs=nowMs;             // start the hold clock
  if (nowMs - g_betterSinceMs < TK_HANDOFF_HOLD_MS) return false;  // sustained?
  return true;
}

