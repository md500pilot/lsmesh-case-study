static bool scheduleRelayMustDefer(uint32_t offUs){
#if LSM_RELAY_TIMING_V2
  if(!g_anchorValid || g_relaySchedLen<BEACON_WIRE_FIXED_B)return false;
  const auto *s=(const SchedBeacon*)g_relaySchedRaw;
  if(!lsmgeometry::relayTierAllowed(s->schedHops,g_schedTiers))return false;
  const uint64_t end=tkSlotUsLive(s->nSlots)+(uint64_t)s->schedHops*relaySchedTierUsLive(s->nSlots);
  if(offUs>=end)return false;
  // Do not interrupt an already-started reception to send a competing copy.
  // radioPoll will validate it and apply the existing same-tier suppression.
  const uint32_t irq=lsmIrqRead();
  return schedulerelay::receiveInProgress(irq,
      RADIOLIB_SX126X_IRQ_PREAMBLE_DETECTED|RADIOLIB_SX126X_IRQ_HEADER_VALID,
      RADIOLIB_SX126X_IRQ_RX_DONE|RADIOLIB_SX126X_IRQ_HEADER_ERR|RADIOLIB_SX126X_IRQ_TIMEOUT);
#else
  (void)offUs;return false;
#endif
}
static void relaySchedTx(){
#ifdef LSM_LISTEN_ONLY
  return; // The passive witness must never count a shim return as an RF transmission.
#else
  g_schedRelayStats.calls++;
  RadioFlashGuard flashGuard;
  if(!flashGuard.ok()){g_schedRelayStats.flashBlocked++;logRec(LOG_TRIM,NODE_ID,g_role,0xEF,14,0,(uint32_t)(g_frameAnchorUs/1000));return;}

  const SchedBeacon* s=(const SchedBeacon*)g_relaySchedRaw;
  const uint64_t now=(uint64_t)esp_timer_get_time();
  const bool current=g_anchorValid&&g_frameAnchorUs&&g_frameUs&&now>=g_frameAnchorUs&&now-g_frameAnchorUs<g_frameUs&&
    g_relaySchedLen>=BEACON_WIRE_FIXED_B&&g_relaySchedLen==beaconWireB(s->nSlots)&&
    s->tkId==g_tkId&&s->sphere==g_tkEpoch&&s->seq==g_curSchedSeq&&s->nSlots==g_frameGeometrySlots&&
    s->schedHops==g_schedFloodOutHop&&lsmgeometry::relayTierAllowed(s->schedHops,g_schedTiers);
  if(!current){g_schedRelayStats.geometryBlocked++;logRec(LOG_TRIM,NODE_ID,g_role,0xEF,8,(int16_t)g_schedFloodOutHop,(uint32_t)(g_frameAnchorUs/1000));return;}
  const uint64_t tierStart=g_frameAnchorUs+tkSlotUsLive(s->nSlots)+(uint64_t)(s->schedHops-1)*relaySchedTierUsLive(s->nSlots);
  const uint64_t tierEnd=tierStart+relaySchedTierUsLive(s->nSlots);
  if(tierEnd>g_frameAnchorUs+(uint64_t)g_frameUs){g_schedRelayStats.geometryBlocked++;logRec(LOG_TRIM,NODE_ID,g_role,0xEF,8,(int16_t)g_schedFloodOutHop,(uint32_t)(g_frameAnchorUs/1000));return;}

  const uint32_t air=(uint32_t)radio.getTimeOnAir(g_relaySchedLen+MESH_SEC_OVERHEAD);
  const uint32_t rx=g_rxArmUs+100U>SLOT_GUARD_US?g_rxArmUs+100U:SLOT_GUARD_US;
  if(now<tierStart||ownedslot::fits(true,now,tierEnd,air,g_txLatUs,rx)!=ownedslot::FIT){
    g_schedRelayStats.budgetBlocked++;
    const int64_t spare=(int64_t)tierEnd-(int64_t)now-(int64_t)air-g_txLatUs-rx-(int64_t)ownedslot::UNCERTAINTY_US;
    logRec(LOG_TRIM,NODE_ID,g_role,0xEF,9,(int16_t)(spare < -32768 ? -32768 : spare > 32767 ? 32767 : spare),(uint32_t)(g_frameAnchorUs/1000));return;
  }
  const uint64_t call=(uint64_t)esp_timer_get_time();
  femTx();const int16_t status=LSM_TX(g_relaySchedRaw,g_relaySchedLen);
  const uint64_t txEnd=(uint64_t)esp_timer_get_time();rxArmAfterTx();
  const uint64_t finish=(uint64_t)esp_timer_get_time();
  g_schedRelayTiming.lastTxUs=(uint32_t)(txEnd-call);g_schedRelayTiming.lastRxUs=(uint32_t)(finish-txEnd);
  g_schedRelayTiming.lastAirUs=air;g_schedRelayTiming.lastPredictedEngageUs=g_txLatUs;
  const uint32_t excessTx=g_schedRelayTiming.lastTxUs>air?g_schedRelayTiming.lastTxUs-air:0;
  if(excessTx>g_schedRelayTiming.maxTxOverAirUs)g_schedRelayTiming.maxTxOverAirUs=excessTx;
  if(g_schedRelayTiming.lastRxUs>g_schedRelayTiming.maxRxUs)g_schedRelayTiming.maxRxUs=g_schedRelayTiming.lastRxUs;

  if(status==RADIOLIB_ERR_NONE)g_schedRelayStats.success++;else g_schedRelayStats.failed++;
  if(finish>tierEnd){
    g_schedRelayStats.overruns++;const uint32_t excess=(uint32_t)(finish-tierEnd);
    if(excess>g_schedRelayStats.maxOverrunUs)g_schedRelayStats.maxOverrunUs=excess;
    logRec(LOG_TRIM,NODE_ID,g_role,0xEF,10,(int16_t)(excess>32767?32767:excess),(uint32_t)(g_frameAnchorUs/1000));
    logRec(LOG_TRIM,NODE_ID,g_role,0xEF,11,(int16_t)(excessTx>32767?32767:excessTx),(uint32_t)(g_frameAnchorUs/1000));
    logRec(LOG_TRIM,NODE_ID,g_role,0xEF,12,(int16_t)(g_schedRelayTiming.lastRxUs>32767?32767:g_schedRelayTiming.lastRxUs),(uint32_t)(g_frameAnchorUs/1000));
    logRec(LOG_TRIM,NODE_ID,g_role,0xEF,13,(int16_t)(call-now>32767?32767:call-now),(uint32_t)(g_frameAnchorUs/1000));

  }
  // Preserve the legacy call witnesses; counters above distinguish actual driver outcome.
  logRec(LOG_RSYNC,NODE_ID,g_role,s->tkId,0,0,g_schedFloodOutHop);
  logRec(LOG_TX,NODE_ID,g_role,0xFA,(int16_t)g_relayArmNeed,(int16_t)g_relayArmProbe,g_schedFloodOutHop);
#endif
}