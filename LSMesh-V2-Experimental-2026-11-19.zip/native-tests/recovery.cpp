#include <cassert>
#include <cstdint>
#include <cstdio>
#include <initializer_list>
#include "../src/core/authority_progress.h"
#include "../src/core/mesh_recovery.h"
#include "../src/core/frame_geometry.h"
#include "../src/core/owned_slot_gate.h"
#include "../src/core/schedule_relay_budget.h"

#define NODE_ID 4
#define LSM_LIVE_MERIT_HANDOFF 0
#define TK_COLD_LISTEN_MS 12000U
#define TK_MIN_DWELL_MS 5000U
#define TK_HANDOFF_MARGIN 750
#define TK_HANDOFF_HOLD_MS 6000U
#define QUORUM_PEERS 2U
#define VACUUM_LOCK_MS 180000UL
#define RELISTEN_MAX_ATTEMPTS 3U
#define RELISTEN_JITTER_MIN_MS 1500U
#define RELISTEN_JITTER_SPAN_MS 6000U
#define SPHERE_FULL_HOLD_MS 3000U
#define CAND_STRAND_MS 45000U

uint8_t g_role=1,g_successor=5,g_tkId=3,g_tkEpoch=3,g_peerSeqTk=0;
uint8_t g_relistenAttempts=0;
bool g_radioElectionReady=true,g_sphereFull=false,g_spillReq=false;
bool g_spillFromFull=false,g_quorumBlocked=false,g_warmTakeoverPending=false;
uint32_t g_coldCommitSinceMs=0,g_electBootMs=1,g_electJitterMs=4355;
uint32_t g_fullBlockedSinceMs=0,g_seqAdvMs=265782,g_peerSeqAdvMs=0;
uint32_t g_lastTkHeardMs=265782,g_lastSchedMs=265783,g_framesSilent=17;
uint32_t g_candSinceMs=0,g_relistenSinceMs=0,g_relistenJitterMs=0;
uint32_t g_kaSeenMs[32]{},g_tkSinceMs=1,g_betterSinceMs=0,g_frameUs=1000000;
int32_t g_myScore=0,g_tkScore=0;
uint8_t freshPeers=3;
AuthorityProgress g_meshLease{};

bool keeperEligibleId(uint8_t id){return id!=1;}
uint32_t electSeparatorMs(){return 4355;}
uint32_t esp_random(){return 17;}
uint8_t quorumFresh(uint32_t){return freshPeers;}
uint32_t quorumWinMs(){return 10000;}
uint32_t tkStallMs(){const auto v=g_frameUs/1000*15;return v>15000?v:15000;}
uint32_t tkSuccessorMs(){const auto v=g_frameUs/1000*3;return v>10000?v:10000;}
uint32_t tkSuccessorPeerMs(){return tkSuccessorMs();}
uint32_t coldCommitGuardMs(){const auto v=tkSuccessorPeerMs()+2*g_frameUs/1000;return v<16000?16000:v>32000?32000:v;}
uint32_t aloneGraceMs(){const auto v=g_frameUs/1000*20;return v>30000?v:30000;}
uint32_t warmLastAdvanceMs(){return g_peerSeqAdvMs>g_seqAdvMs?g_peerSeqAdvMs:g_seqAdvMs;}
template<class... T>void logRec(T...){}
void vacuumLockWitness(uint8_t,uint32_t){}
static uint32_t g_progressHoldWitnessMs=0;
#include "candidate-hold.inc"
#include "candidate-election.inc"
#define g_meshLeaseAdvMs g_meshLease.advancedAt
#include "baseline-election.inc"
#undef g_meshLeaseAdvMs
#include "airtime.inc"

static void reset(){
  g_role=1;g_successor=5;g_tkId=3;g_tkEpoch=3;g_peerSeqTk=0;g_peerSeqAdvMs=0;
  g_seqAdvMs=265782;g_lastTkHeardMs=265782;g_lastSchedMs=265783;
  g_electBootMs=1;g_electJitterMs=4355;g_coldCommitSinceMs=0;
  g_spillFromFull=false;g_quorumBlocked=false;g_spillReq=false;
  g_warmTakeoverPending=false;g_radioElectionReady=true;g_sphereFull=false;
  g_relistenAttempts=0;g_relistenSinceMs=0;g_relistenJitterMs=0;g_candSinceMs=0;
  freshPeers=3;g_meshLease={};g_frameUs=1000000;
  for(auto &time:g_kaSeenMs)time=0;
}

static void capturedFade(){
  reset();
  g_meshLease={3,3,32,2,265782,0};
  // Captured peer progression and the same E8 timeout witness.
  const uint32_t times[]={267049,268831,274100,275726,277085,281465,285761,289597,291474};
  const uint8_t seqs[]={33,34,37,38,39,42,45,47,49};
  for(unsigned i=0;i<6;i++)assert(g_meshLease.observe(3,3,seqs[i],7,times[i],4));
  assert(!baselineElectShouldTakeOver(285138));
  assert(g_role==0&&g_quorumBlocked); // Reproduce the actual bad state transition.
  g_role=1;g_quorumBlocked=false;
  assert(!electShouldTakeOver(285138));
  assert(g_role==1&&!g_spillReq&&!g_quorumBlocked);
  for(unsigned i=6;i<9;i++){
    assert(g_meshLease.observe(3,3,seqs[i],7,times[i],4));
    assert(!electShouldTakeOver(times[i]));
    assert(g_role==1&&!g_spillReq);
  }
  assert(!electShouldTakeOver(291988));
  assert(g_role==1&&!g_spillReq);
  const auto cap=authorityrecovery::holdCap(tkStallMs(),coldCommitGuardMs(),aloneGraceMs(),CAND_STRAND_MS);
  assert(!g_meshLease.holds(3,3,g_seqAdvMs,g_seqAdvMs+cap,10000,cap));
}

static void progressionTrust(){
  AuthorityProgress p{};
  assert(!p.observe(3,3,254,7,1000,4));
  assert(!p.observe(3,3,255,7,2000,4));
  assert(p.observe(3,3,0,7,3000,4)); // Modular wrap is a real advance.
  assert(p.holds(3,3,1000,4000,10000,31000));
  const auto old=p.advancedAt;
  for(unsigned i=0;i<200;i++)assert(!p.observe(3,3,0,7,4000+i,4));
  assert(p.advancedAt==old&&!p.observe(3,3,127,7,6000,4));
  assert(!p.holds(3,4,1000,4000,10000,31000));
  assert(!p.observe(9,3,1,8,4000,4)); // Conflicting keeper at equal generation.
  assert(!p.observe(3,2,1,8,4000,4)); // Old authority.
  assert(!p.observe(4,4,1,8,5000,4)); // New generation starts a new baseline.
  assert(!p.holds(3,3,1000,5000,10000,31000));
  assert(!p.observe(4,4,2,8,6000,4));
  assert(p.observe(4,4,3,8,7000,4));
  assert(p.holds(4,4,5000,7000,10000,31000));
  assert(!p.holds(4,4,5000,17001,10000,31000));
  p={3,3,3,2,0xfffffff0U,128};
  assert(p.holds(3,3,0xffffff00U,200,10000,31000));
}

static void realFailuresAndRejoin(){
  reset();g_successor=4;g_electJitterMs=0;g_seqAdvMs=1000;g_lastTkHeardMs=1000;
  assert(!electShouldTakeOver(11000));
  assert(electShouldTakeOver(11001)&&g_warmTakeoverPending);
  reset();g_meshLease={3,3,33,2,266000,128};
  assert(!g_meshLease.holds(3,3,g_seqAdvMs,276001,10000,31000));
  assert(!electShouldTakeOver(285138)&&g_role==0); // Dead peer lease cannot delay E8.
  g_relistenSinceMs=285138;g_relistenJitterMs=1500;
  assert(!electShouldTakeOver(286639));
  assert(g_spillReq&&!g_spillFromFull); // Recovery revisits the working channel.
  reset();g_sphereFull=true;g_role=0;g_fullBlockedSinceMs=1;
  assert(!electShouldTakeOver(10000)&&g_spillFromFull); // Real capacity exclusion retained.
  reset();g_radioElectionReady=false;
  assert(!electShouldTakeOver(500000));
  MeshRecovery join{};
  assert(!join.observe(3,10,400000,1410));
  assert(!join.observe(3,10,401410,1410));
  assert(join.observe(3,11,401410,1410));
  assert(!join.observe(4,12,402820,1410));
}

static void relayGeometry(){
  assert(ownedslot::UNCERTAINTY_US==6000);
  unsigned geometries=0;
  for(uint8_t sf=5;sf<=7;sf++)for(unsigned slots=0;slots<=64;slots++)
  for(uint8_t tiers=1;tiers<=7;tiers++){
    const auto air=lsmLoraAirUs(63+slots+32,sf);
    const auto tier=schedulerelay::tier(air,12000,true);
    uint64_t previous=1000000+air+20000;
    const uint64_t members=previous+(uint64_t)tiers*tier+100000;
    for(uint8_t hop=1;hop<=tiers;hop++){
      assert(lsmgeometry::relayTierAllowed(hop,tiers));
      const uint64_t begin=1000000+air+20000+(uint64_t)(hop-1)*tier;
      const uint64_t end=begin+tier;
      assert(begin>=previous&&end<members);
      assert(ownedslot::fits(true,begin+12000+8000,end,air,3000,1200)==ownedslot::FIT);
      assert(ownedslot::fits(true,begin+12000+12000,end,air,3000,1200)==ownedslot::BUDGET);
      assert(ownedslot::fits(false,begin,end,air,3000,1200)==ownedslot::STALE);
      assert(ownedslot::fits(true,end,end,air,3000,1200)==ownedslot::EXPIRED);
      assert(ownedslot::fits(true,end-air,end,air,3000,1200)==ownedslot::BUDGET);
      previous=end;
    }
    // Exercise the full-frame capacity calculation with conservative tails.
    unsigned capacity=slots;
    auto need=[&](unsigned count){
      const auto scheduleAir=lsmLoraAirUs(63+count+32,sf);
      return schedulerelay::frameNeed(scheduleAir+20000,tiers,
        schedulerelay::tier(scheduleAir,12000,true),100000,count,72736,100000,250000);
    };
    while(capacity>0 && need(capacity)>10000000ULL)capacity--;
    assert(need(capacity)<=10000000ULL);
    if(capacity<slots)assert(need(capacity+1)>10000000ULL);
    geometries++;
  }
  for(auto deficit:{2278,12016}){
    const uint64_t air=100000,now=1000000,engage=3000,rx=1000;
    const uint64_t legacyEnd=now+air+engage+rx+ownedslot::UNCERTAINTY_US-deficit;
    assert(ownedslot::fits(true,now,legacyEnd,air,engage,rx)==ownedslot::BUDGET);
    assert(ownedslot::fits(true,now,legacyEnd+membercapacity::GAP_US,air,engage,rx)==ownedslot::FIT);
  }
  std::printf("PASS %u SF/slot/tier geometries; 3/4-hop reservations, captured refusals, stale and late guards\n",geometries);
}

int main(){
  capturedFade();progressionTrust();realFailuresAndRejoin();relayGeometry();
  std::puts("PASS actual firmware election baseline regression, bounded peer recovery, replay/epoch/wrap, failure and rejoin");
}
