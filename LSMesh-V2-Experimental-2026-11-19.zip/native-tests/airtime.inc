static constexpr uint32_t lsmCeilDiv(int32_t a, int32_t b){ return (uint32_t)((a + b - 1)/b); }
static constexpr uint32_t lsmTsymUs(uint8_t SF, uint32_t BW){ return (uint32_t)(((uint64_t)(1u<<SF) * 1000000ULL) / BW); }
static constexpr uint8_t  lsmLowDataOpt(uint8_t SF, uint32_t BW){ return (SF>=11 && BW==125000u) ? 1 : 0; }
// v7.28.1: single source of the SX126x preamble rule. The datasheet REQUIRES at
// least 12 preamble symbols at SF5/SF6; 8 is fine at SF7 and up. Both the hardware
// preamble (LORA_PREAMBLE_SYMS, all three radio config sites) and the airtime
// formula below draw from THIS function, so the modem and the arithmetic cannot
// disagree. The 2026-08-28 SF5 bench failure was exactly that disagreement: TX at
// 8 preamble symbols left every SF5 receiver effectively deaf (0 to 6 receptions
// in 15 minutes against thousands in the SF7 runs), ten boards each self-elected
// TK, and the mesh never formed.
// v7.28.34: PREAMBLE TEST, and the rule is now DERIVED rather than a per-SF
// literal. LSM_PRE_MS is the wanted preamble DURATION in milliseconds; the
// symbol count falls out of the symbol time at whatever SF and BW are in
// force, so moving SF, moving BW, or moving to another modulation family
// later carries the same detector energy instead of inheriting a number that
// only made sense at one SF. Clamped to the SX126x legal range: the datasheet
// floor is 12 symbols at SF5/SF6 and 8 at SF7+, the register ceiling is 255.
// v7.28.35: ROLLED BACK. v7.28.34 shipped 16 ms (63 symbols at SF5) and
// delivery collapsed from 0.874 to 0.004, every witnessed failure a header
// error (IRQ 0x20) at saturation RSSI. Preamble length is eliminated as the
// lever. The duration RULE stays because it is correct and travels with the
// modulation; only the VALUE returns. 3 ms lands exactly on the v7.28.33
// numbers at every SF: 12 symbols at SF5 and SF6 (the datasheet floor binds),
// 8 at SF7 and SF8. Bit-for-bit what v7.28.33 flew.
static constexpr uint32_t LSM_PRE_MS = 3u;    // wanted preamble duration, ms
static constexpr uint16_t lsmPreFloor(uint8_t SF){ return (SF<=6) ? 12u : 8u; }
static constexpr uint16_t lsmPreSyms(uint8_t SF, uint32_t BW=125000u){
  const uint32_t Ts = lsmTsymUs(SF, BW);
  const uint32_t want = Ts ? ((LSM_PRE_MS * 1000u) + Ts - 1u) / Ts : 0u;
  const uint32_t floorS = lsmPreFloor(SF);
  const uint32_t n = want < floorS ? floorS : want;
  return (uint16_t)(n > 255u ? 255u : n);
}
static constexpr uint32_t lsmLoraAirUs(uint32_t PL, uint8_t SF, uint32_t BW=125000u,
                                       uint8_t CR=1, uint8_t CRC=1, uint8_t IH=0, uint8_t npre=0){
  const uint32_t Ts  = lsmTsymUs(SF, BW);
  // v7.28.1: npre=0 means auto, the per-SF minimum from lsmPreSyms. Callers that
  // pass an explicit count (none today) still get exactly what they ask for.
  const uint32_t np  = npre ? npre : lsmPreSyms(SF, BW);   // v7.28.34: BW matters now that the count is derived from duration
  const uint32_t preQ = (SF<=6) ? 25u : 17u;   // v7.27.0: SX126x SF5/SF6 use 6.25 sym preamble offset (25 quarter-sym) vs 4.25 (17) for SF>=7
  const uint32_t pre = ((4u*np + preQ) * Ts) / 4u;
  const int32_t  num = (int32_t)(8u*PL) - 4*SF + 28 + 16*CRC - 20*IH;
  const int32_t  den = 4*(SF - 2*lsmLowDataOpt(SF,BW));
  const uint32_t ps  = 8u + lsmCeilDiv(num, den) * (uint32_t)(CR+4);
  return pre + ps*Ts;
}
