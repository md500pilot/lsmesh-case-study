static bool ordinaryPeerProgressHolds(uint32_t nowMs){
  if((g_role!=0 && g_role!=1) || g_successor==(uint8_t)NODE_ID)return false;
  const uint32_t cap=authorityrecovery::holdCap(tkStallMs(),coldCommitGuardMs(),
                                               aloneGraceMs(),CAND_STRAND_MS);
  const bool hold=g_meshLease.holds(g_tkId,g_tkEpoch,g_seqAdvMs,nowMs,
                                    tkSuccessorPeerMs(),cap);
  if(hold && (uint32_t)(nowMs-g_progressHoldWitnessMs)>=5000UL){
    g_progressHoldWitnessMs=nowMs;
    logRec(4 /*LOG_STATE*/,NODE_ID,g_role,0xF8,(int16_t)g_meshLease.keeper,
           (int16_t)(nowMs-g_meshLease.advancedAt),nowMs-g_seqAdvMs);
  }
  return hold;
}
