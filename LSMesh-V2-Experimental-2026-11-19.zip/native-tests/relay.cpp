#include <cassert>
#include <cstdint>
#include <cstdio>
#include "../src/core/owned_slot_gate.h"
#include "../src/core/frame_geometry.h"
#include "../src/core/schedule_relay_budget.h"
#define NODE_ID 5
#define RADIOLIB_ERR_NONE 0
#define LOG_TRIM 12
#define LOG_RSYNC 14
#define LOG_TX 2
#define BEACON_WIRE_FIXED_B 63
#define MESH_SEC_OVERHEAD 32
#define LSM_RELAY_TIMING_V2 1
#define RADIOLIB_SX126X_IRQ_PREAMBLE_DETECTED 4
#define RADIOLIB_SX126X_IRQ_HEADER_VALID 16
#define RADIOLIB_SX126X_IRQ_RX_DONE 2
#define RADIOLIB_SX126X_IRQ_HEADER_ERR 32
#define RADIOLIB_SX126X_IRQ_TIMEOUT 512

struct SchedBeacon {uint8_t tkId=3,sphere=3,seq=42,nSlots=9,schedHops=1;};
alignas(SchedBeacon) uint8_t g_relaySchedRaw[127]{};
uint8_t g_relaySchedLen=72,g_role=1,g_tkId=3,g_tkEpoch=3,g_curSchedSeq=42;
uint8_t g_frameGeometrySlots=9,g_schedFloodOutHop=1,g_schedTiers=4;
uint8_t g_relayArmNeed=1,g_relayArmProbe=0;
bool g_anchorValid=true,flashAvailable=true,extended=true;
uint64_t g_frameAnchorUs=1000000,nowUs=0;
uint32_t g_frameUs=2000000,g_rxArmUs=1000,g_txLatUs=3000;
uint32_t SLOT_GUARD_US=800;
uint32_t txSwitches=0,driverCalls=0;
uint32_t irqWord=0;
uint32_t lsmIrqRead(){return irqWord;}
uint32_t beaconWireB(uint8_t slots){return 63+slots;}
uint32_t tkSlotUsLive(uint8_t){return 120000;}
uint32_t relaySchedTierUsLive(uint8_t){return schedulerelay::tier(100000,12000,extended);}
uint64_t esp_timer_get_time(){return nowUs;}
struct Radio {uint32_t getTimeOnAir(uint32_t){return 100000;}} radio;
struct RadioFlashGuard {bool ok(){return flashAvailable;}};
struct Stats {
 uint32_t calls=0,flashBlocked=0,geometryBlocked=0,budgetBlocked=0,success=0,failed=0;
 uint32_t overruns=0,maxOverrunUs=0;
} g_schedRelayStats;
struct Timing {uint32_t lastTxUs=0,lastRxUs=0,lastAirUs=0,lastPredictedEngageUs=0;
 uint32_t maxTxOverAirUs=0,maxRxUs=0;
} g_schedRelayTiming;
template<class... T>void logRec(T...){}
void femTx(){txSwitches++;}
int16_t LSM_TX(uint8_t*,uint8_t){driverCalls++;nowUs+=103000;return 0;}
void rxArmAfterTx(){nowUs+=1000;}
#include "relay-transmit.inc"

void prepare(uint8_t hop){
 auto *s=reinterpret_cast<SchedBeacon*>(g_relaySchedRaw);
 *s={3,3,42,9,hop};
 g_schedFloodOutHop=hop;
 nowUs=g_frameAnchorUs+tkSlotUsLive(9)+(hop-1)*relaySchedTierUsLive(9)+12000;
}
int main(){
 for(uint8_t hop=1;hop<=4;hop++){
  prepare(hop);relaySchedTx();
  assert(g_schedRelayStats.success==hop&&g_schedRelayStats.overruns==0);
 }
 const auto sent=driverCalls;
 prepare(2);reinterpret_cast<SchedBeacon*>(g_relaySchedRaw)->sphere=2;
 relaySchedTx();assert(driverCalls==sent);
 prepare(2);reinterpret_cast<SchedBeacon*>(g_relaySchedRaw)->tkId=9;
 relaySchedTx();assert(driverCalls==sent);
 prepare(2);reinterpret_cast<SchedBeacon*>(g_relaySchedRaw)->seq=41;
 relaySchedTx();assert(driverCalls==sent);
 prepare(2);g_frameGeometrySlots=8;
 relaySchedTx();assert(driverCalls==sent);g_frameGeometrySlots=9;
 prepare(5);relaySchedTx();assert(driverCalls==sent);
 prepare(1);nowUs+=2000000;relaySchedTx();assert(driverCalls==sent);
 prepare(1);flashAvailable=false;relaySchedTx();assert(driverCalls==sent);flashAvailable=true;
 prepare(1);nowUs+=100000;relaySchedTx();assert(driverCalls==sent);
 // The legacy width cannot carry its full jitter plus actual predictive reserve.
 extended=false;prepare(1);relaySchedTx();assert(driverCalls==sent);
 assert(txSwitches==driverCalls);
 extended=true;prepare(1);
 irqWord=RADIOLIB_SX126X_IRQ_HEADER_VALID;
 assert(scheduleRelayMustDefer((uint32_t)(nowUs-g_frameAnchorUs)));
 irqWord|=RADIOLIB_SX126X_IRQ_RX_DONE;
 assert(!scheduleRelayMustDefer((uint32_t)(nowUs-g_frameAnchorUs)));
 irqWord=RADIOLIB_SX126X_IRQ_PREAMBLE_DETECTED|RADIOLIB_SX126X_IRQ_TIMEOUT;
 assert(!scheduleRelayMustDefer((uint32_t)(nowUs-g_frameAnchorUs)));
 irqWord=RADIOLIB_SX126X_IRQ_HEADER_VALID;
 assert(!scheduleRelayMustDefer(tkSlotUsLive(9)+relaySchedTierUsLive(9)));
 std::puts("PASS actual relaySchedTx: 4-hop driver calls, authority/epoch/sequence/geometry/flash/deadline gates");
}
