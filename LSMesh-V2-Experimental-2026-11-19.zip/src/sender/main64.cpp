// v7.29.40 V2 secure witness extension plus v39 warm-backup repair. See docs/RELEASE.md.
// LSMESH badge firmware for Heltec Wireless Tracker V2 (ESP32-S3 + UC6580 GNSS).
// Hosts the LSMESH GATT service that LSMESH_Command.html connects to with the
// "Connect badge" button, and feeds it live position and diagnostics over BLE.
//
// What it does:
//   - Powers the GNSS (VEXT high), reads NMEA on UART, parses with TinyGPSPlus.
//   - On the first fix it sets a local origin. Position is reported as an
//     east/north offset in centimeters from that origin, which is exactly the
//     relative metric frame the dashboard expects on the badge path.
//   - Notifies position once per second and diagnostics once per second.
//   - The USER button: tap sends a manual evidence mark at the current
//     position, hold 3 s soft powers the badge off, hold 1.5 s wakes it.
//
// Frame note (important for a single board):
//   The badge protocol carries relative mesh coordinates, not absolute lat/lon.
//   The dashboard draws each badge at operator_GPS + (badge offset). So power
//   this board on next to the operator/phone. It will then track correctly as
//   it moves away. The board does not advertise itself as the frame origin, so
//   it shows real motion instead of sitting on the operator.
//
// v4.8 (whole fleet): RF readout full time. TFT line 3 always shows T and R
// counters (mod 1000) and the last RSSI as a magnitude, 102 on the glass
// means -102 dBm, the log keeps the sign. Line 2 drops the TK label and
// gains the hop count to command, LK12 07 P3 H2, H- when no path known.
// The GPS offset readout is off the screen for now, position still flows
// to the dashboard and the log. Wire format unchanged at version 3.
//
// v4.7 (whole fleet): soft power off. Hold USER 3 s to shut down: the badge
// logs a LOG_PWR record, flushes it to flash, drops BLE, sleeps the SX1262,
// cuts the FEM rail, VEXT, and backlight, then enters ESP32-S3 deep sleep.
// Hold USER 1.5 s to power back on. A tap still sends a mark, now fired on
// release. The hold at boot log wipe is unchanged and runs on cold boot
// only, never on a wake from off. Wire format unchanged at version 3.
//
// v4.5 (whole fleet): flash log record grows 16 to 24 bytes, locked for the
// x, y, z position pipeline: every record carries the badge's floor and
// altitude, and RX and DRIFT records carry per packet RSSI and SNR. Old
// logs are auto erased at boot. Wire format unchanged at version 3.
//
// v4.4 (whole fleet): drives the KCT8103L RF front end that every prior
// version left shut down, sets the TCXO reference to 1.8 V, applies the
// 0x8B5 RX sensitivity patch, and drops the SX1262 drive to 2 dBm because
// the FEM now supplies real gain. Wire format is unchanged at version 3.
//
// Build and flash: see README.md. The byte layout in this file is verified by
// tools/verify_packets.py against the dashboard decode.

#include <Arduino.h>
#include <atomic>
#include "freertos/semphr.h"
static std::atomic<bool> g_telemetryUsbPrefixBusy{false},g_telemetryReplayRequested{false};
static std::atomic<bool> g_exportBleConnected{false},g_exportBleSubscribed{false};
static std::atomic<uint32_t> g_exportBleGeneration{0};
static StaticSemaphore_t g_exportSerialMutexStorage;
static SemaphoreHandle_t g_exportSerialMutex=nullptr;
#include "telemetry_wire.h"
struct SchedBeacon;
static bool telemetryTxOwn();
static bool telemetryReceive(const uint8_t*,int);
static bool telemetryReceiveAggregate(const uint8_t*,int);
static bool telemetryAggregateTx(uint32_t,bool);
static bool legacyPeerNotifyChecked(const uint8_t*,size_t);
static void telemetryAdopt(uint8_t,uint8_t,uint8_t,uint8_t,uint8_t,uint8_t);
static void telemetryRelayQueue(const telemetry::Snapshot&);
static bool telemetryRelayTransmit(const uint8_t*,uint32_t);
static void telemetrySchedule(SchedBeacon&);
static void telemetryKeeperTail();
static void telemetryHostService();
static bool uiTailLogDeferred(); // V41 local UI/log quiet-tail arbitration.

#include "esp_timer.h"   // v4.15: 64 bit microsecond clock, ISR safe
#include "esp_cpu.h"     // v7: cycle counter feeds the entropy scheduler
#include "esp_system.h"  // v7.11.11: esp_reset_reason, distinguishes a clean boot from a fault
#include "esp_log.h"     // v7.20.22: esp_log_level_set, to mute the IDF during a serial dump
#include <NimBLEDevice.h>
#include <TinyGPSPlus.h>
#include <math.h>
#include <SPI.h>
#include <Wire.h>
#include "dual_phy_profile.h"
#ifdef LSM_BOARD_LILYGO
// v7.28.47: LilyGO T-Display-S3-Pro LR1121 target. Display is the vendor's
// Arduino_GFX ST7796 path (T-Display-S3-Pro-MVSRLora examples/GFX), which
// carries the same Adafruit-shaped print API the ST7735 code uses, so the
// tft call sites below are untouched; only the object behind the name and
// the six color constants change.
#include <Arduino_GFX_Library.h>
#define ST77XX_BLACK  RGB565_BLACK
#define ST77XX_WHITE  RGB565_WHITE
#define ST77XX_RED    RGB565_RED
#define ST77XX_GREEN  RGB565_GREEN
#define ST77XX_CYAN   RGB565_CYAN
#define ST77XX_YELLOW RGB565_YELLOW
#elif defined(LSM_BOARD_V4)
// v7.28.84: V4 board SSD1306 OLED I2C display (128x64)
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#define ST77XX_BLACK  SSD1306_BLACK
#define ST77XX_WHITE  SSD1306_WHITE
#define ST77XX_RED    SSD1306_WHITE
#define ST77XX_GREEN  SSD1306_WHITE
#define ST77XX_CYAN   SSD1306_WHITE
#define ST77XX_YELLOW SSD1306_WHITE
#else
#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#endif
#include <RadioLib.h>
#include "vol_hardening.h"
#include "mesh_recovery.h"
#include "secure_mesh.h"
#include "frame_geometry.h"
#include "owned_slot_gate.h"
#include "member_capacity.h"
#include "authority_progress.h"
#include "schedule_relay_budget.h"
#ifndef LSM_RELAY_TIMING_V2
#define LSM_RELAY_TIMING_V2 0
#endif
static uint8_t g_frameGeometrySlots = 0; // USB witness: actual published/adopted count
#include "local_window_protocol.h"
#include "local_window_state.h"
static MeshRecovery meshRecovery;
#include <FS.h>
#include <LittleFS.h>
// v7.21.0: the token layer is MANDATORY. The blind build wrote the departure
// integrity value into attToken, which this patch makes wrong, and a compile
// path nobody builds is exactly what silently compiled itself out on boards 09
// through 12 and cost a version to find. It is removed rather than fixed, and
// its absence is now loud instead of silent.
#ifndef CRYSTAL_TOKEN
#error "CRYSTAL_TOKEN is required from v7.21.0. The blind build is gone: it wrote departAttest into attToken, which now carries the crystal tag only. Add -D CRYSTAL_TOKEN to every env in platformio.ini."
#endif
#ifdef CRYSTAL_TOKEN
#include "pair_token.h"
static bool ctokTkVerify(const uint8_t* raw, int len);   // v7.28.59: returns false when the packet must be dropped
static void handleCtok(const uint8_t* raw, int len);
static void ctokService(uint32_t nowMs);
static void ctokTailSend(uint8_t kind);                  // v7.28.59: the tail-slot transmit; the unscheduled announce/request pair is gone
// v7.28.59 identity gate and tail token slot, defined with the token block
static bool    ksDenied(uint8_t id);
static bool    ksAllowed(uint8_t id);
static bool    ksIdAdmissible(uint8_t id);
static void    ksRosterInit(int idx);
static void    tkRosterDrop(int idx);
struct SchedBeacon;
static uint8_t ksTokGrantDecide(uint8_t nSlots, SchedBeacon& s);
static void    ksTailRelayNote(const uint8_t* raw, int len);
static void    ksSerialClearDeny();
static void    ksTailTxMember(uint32_t offUs);
static void    ksTailRelayTx(uint32_t offUs);
static void    ksTailTxKeeper();
static void    ksSerialRevoke();
static void    ksSerialStatus();
static uint8_t ksSideReq();
static void    ksBegin();
static int     ksRevokeAccept(const uint8_t* raw, int len, uint8_t via);
static uint32_t ctokMintOr(uint16_t src, uint8_t seq, int16_t depoff);
#endif
#include "esp_sleep.h"
#include "driver/rtc_io.h"
#include "driver/gpio.h"
#include "esp_intr_alloc.h"
#include "irq_policy.h"
#if CONFIG_ARDUINO_ISR_IRAM != 1
#error "Controlled IRQ build requires rebuilt Arduino GPIO core with CONFIG_ARDUINO_ISR_IRAM=1"
#endif
static esp_err_t g_irqPolicyInstall = ESP_FAIL;
static bool g_irqPolicyVerified = false;
static void irqPolicyPrint();
static void uiStatusPrint();
static void irqPolicySerialOnly();

// ----------------------- board pins (Heltec Wireless Tracker) -----------------------
// Confirmed from the Heltec board support package. If your V2 differs, change here.
#ifdef LSM_BOARD_LILYGO
static const int PIN_VEXT     = -1;   // v7.28.47: no VEXT rail on the LilyGO; the RT9080 LDO (GPIO 42) powers the radio, see femInit
static const int PIN_GNSS_RX  = -1;   // v7.28.47: no GNSS on the T-Display-S3-Pro. GPIO 33/34 are octal PSRAM lines on this board, never drive them
static const int PIN_GNSS_TX  = -1;
#elif defined(LSM_BOARD_V4)
static const int PIN_VEXT     = 36;   // v7.28.86: VEXT GPIO36 is active LOW and powers the SSD1306 OLED. Was -1, which left the OLED rail unpowered and the display dark.
static const int PIN_GNSS_RX  = -1;
static const int PIN_GNSS_TX  = -1;
#else
static const int PIN_VEXT     = 3;    // drive HIGH to power GNSS and TFT
static const int PIN_GNSS_RX  = 33;   // MCU RX, wired to GNSS TX
static const int PIN_GNSS_TX  = 34;   // MCU TX, wired to GNSS RX
#endif
static const int PIN_USER_BTN = 0;    // USER button, pressed = LOW
static const uint32_t GNSS_BAUD = 115200; // if no NMEA appears, try 9600
// v7.11.9: UC6580 positioning/output rate, bumped 1Hz to 10Hz, the chip's
// own documented max (UC6580 datasheet Table 1-2, Update Rate 10 Hz max).
// FUSION_PULL_MS matches it so posFusionUpdate actually uses the faster
// fixes instead of still only pulling once a second.
#define FUSION_PULL_MS 100U

// ----------------------- TFT pins (Heltec Wireless Tracker, ST7735 160x80) -----------------------
// From the Heltec board support package. VEXT (GPIO 3) also powers the TFT,
// and setup() drives it HIGH before the display init runs.
#ifdef LSM_BOARD_LILYGO
// v7.28.47: LilyGO T-Display-S3-Pro pins, from the vendor pin_config.h
// (T-Display-S3-Pro-MVSRLora/libraries/private_library/pin_config.h). The
// ST7796 LCD and the LR1121 share one FSPI bus (SCLK 18, MOSI 17, MISO 8)
// with separate chip selects.
static const int PIN_TFT_CS   = 39;  // LCD_CS
static const int PIN_TFT_RST  = 47;  // LCD_RST
static const int PIN_TFT_DC   = 9;   // LCD_DC
static const int PIN_TFT_SCLK = 18;  // LCD_SCLK, shared with the radio
static const int PIN_TFT_MOSI = 17;  // LCD_MOSI, shared
static const int PIN_TFT_MISO = 8;   // LCD_MISO, shared
static const int PIN_TFT_BL   = 48;  // LCD_BL, HIGH = on
#define TFT_INVERT 0

// ----------------------- LoRa LR1121 pins (LilyGO T-Display-S3-Pro) -----------------------
static const int PIN_LORA_NSS  = 7;   // LR1121_CS
static const int PIN_LORA_SCK  = 18;  // LR1121_SCLK
static const int PIN_LORA_MOSI = 17;  // LR1121_MOSI
static const int PIN_LORA_MISO = 8;   // LR1121_MISO
static const int PIN_LORA_RST  = 10;  // LR1121_RST
static const int PIN_LORA_BUSY = 46;  // LR1121_BUSY
static const int PIN_LORA_DIO1 = 40;  // LR1121_INT (the IRQ line; RadioLib calls it irq)
static const int PIN_RT9080_EN = 42;  // RT9080 LDO enable, radio rail, HIGH before radio.begin
#elif defined(LSM_BOARD_V4)
// v7.28.84: V4 board SSD1306 OLED I2C pins
static const int PIN_OLED_SDA = 17;  // I2C SDA
static const int PIN_OLED_SCL = 18;  // I2C SCL
static const int PIN_OLED_RST = 21;  // OLED RST
static const int PIN_TFT_BL   = -1;  // no backlight on OLED
#define TFT_INVERT 0

// ----------------------- LoRa SX1262 pins (V4 board) -----------------------
static const int PIN_LORA_NSS  = 8;
static const int PIN_LORA_SCK  = 9;
static const int PIN_LORA_MOSI = 10;
static const int PIN_LORA_MISO = 11;
static const int PIN_LORA_RST  = 12;
static const int PIN_LORA_BUSY = 13;
static const int PIN_LORA_DIO1 = 14;
#else
static const int PIN_TFT_CS   = 38;
static const int PIN_TFT_RST  = 39;
static const int PIN_TFT_DC   = 40;
static const int PIN_TFT_SCLK = 41;
static const int PIN_TFT_MOSI = 42;
static const int PIN_TFT_BL   = 21;  // backlight, HIGH = on
#define TFT_INVERT 0                 // this board's panel batch renders inverted with 1,
                                     // bench confirmed 2026-07-03: white background at 1, black at 0

// ----------------------- LoRa SX1262 pins (Heltec ESP32-S3 series) -----------------------
static const int PIN_LORA_NSS  = 8;
static const int PIN_LORA_SCK  = 9;
static const int PIN_LORA_MOSI = 10;
static const int PIN_LORA_MISO = 11;
static const int PIN_LORA_RST  = 12;
static const int PIN_LORA_BUSY = 13;
static const int PIN_LORA_DIO1 = 14;
#endif

// ----------------------- 915 MHz mesh parameters -----------------------
#ifndef LSM_BUILD_FREQ_MHZ
#define LSM_BUILD_FREQ_MHZ 924.0f
#endif
static const float   LORA_FREQ_MHZ = LSM_BUILD_FREQ_MHZ;  // field default 924 MHz; bench profile can isolate narrowband interference.
static const float    BACKHAUL_FREQ_MHZ = 927.5;   // v7.12.14: backhaul discovery channel, TK-only, cold-boot listen
static const uint32_t BACKHAUL_LISTEN_MS = 5000;   // v7.19.2: was 1500, HALF of BACKHAUL_ADV_PERIOD_MS (3000), so a booting or spilling board had coin-flip odds of catching an advert and a miss failed toward rejoining channel A. Now just over one full advert period: an active TK's advert is guaranteed to land inside the window. Costs ~2 s on the dead-TK re-walk and the full-lockout spill; since v7.28.26 this is the floor under backhaulListenMs(), which derives the window from the advert cadence and the frame length.
static const uint32_t BACKHAUL_FRAME_CEIL_MS = 10000;   // v7.28.98: was 2550, which was not a policy
// number at all, it was the uint8 frameMs10 field ceiling (255 * 10 ms) wearing a constant name. With
// the field widened to uint16 the real limit is policy again. 10 s covers the widest simulated
// geometry (SF7, 7 tiers, 64 slots = 6914 ms) with headroom. NOTE: AIR_TIMEOUT_MS is 90 s, so a 10 s
// frame is only 9 frames of eviction margin. That interacts with the rotation guarantee, which is
// deliberately NOT in this cut.
static const uint32_t BACKHAUL_ADV_PERIOD_MS = 3000; // backhaul advertise v1: primary TK advertises its working channel on 927.5 this often, light-touch visit under the design-spec duty budget
#ifndef LSM_LEGACY_SUBGHZ_BACKHAUL
#define LSM_LEGACY_SUBGHZ_BACKHAUL 0
#endif
#ifndef LSM_BUILD_BW_HZ
#define LSM_BUILD_BW_HZ 125000
#endif
static_assert(LSM_BUILD_BW_HZ == 125000 || LSM_BUILD_BW_HZ == 250000 || LSM_BUILD_BW_HZ == 500000,
              "working bandwidth must be 125, 250, or 500 kHz");
static constexpr uint32_t LSM_ACTIVE_BW = (uint32_t)LSM_BUILD_BW_HZ;
static const float   LORA_BW_KHZ   = (float)LSM_ACTIVE_BW / 1000.0f;
#ifndef LSM_BUILD_SF
#define LSM_BUILD_SF 6
#endif
static_assert(LSM_BUILD_SF == 5 || LSM_BUILD_SF == 6 || LSM_BUILD_SF == 7,
              "working spreading factor must be SF5, SF6, or SF7");
static const uint8_t LORA_SF       = LSM_BUILD_SF; // v7.30.0: one build flag drives radio and all derived geometry.
static uint8_t g_workingProfileId  = lsm_dual_phy::idFor(LORA_SF, LSM_ACTIVE_BW);
static uint8_t g_workingSf         = LORA_SF;
static uint32_t g_workingBw        = LSM_ACTIVE_BW;
                                             // v7.28.57: SF7 -> SF5 per Stuart 2026-09-13, production cut. Preamble re-derives to the SF5 minimum (12 symbols) through lsmPreSyms.      // v7.28.46: SF5 -> SF7 for the 3-hop mile range test 2026-09-13. Geometry re-derives via LSM_ACTIVE_SF alias.      // v7.27.0: SF5. Drives BOTH the radio and the derived geometry (LSM_ACTIVE_SF aliases this). Was 7.
#ifndef LSM_BUILD_CR
#define LSM_BUILD_CR 5
#endif
static const uint8_t LORA_CR       = LSM_BUILD_CR;      // 5=4/5 field default; bench profiles may test stronger FEC.
static const uint8_t LORA_SYNC     = 0x4B;   // private sync word, K for Kairoshield
// v7.28.86: LISTEN-ONLY WITNESS GATE. This board never keys the LoRa PA;
// every mesh transmit becomes a no-op so it passively logs the whole
// network from one vantage without perturbing it. BLE is untouched, so a
// phone can still pair to it and read the map. Radio silence is the whole
// point of a witness, so it is enforced at the transmit primitive, not per site.
static int16_t secureTransmit(const uint8_t*, size_t);
static void radioFaultNote(uint8_t, int16_t);
#ifndef LSM_BENCH_LINK_MASK
#define LSM_BENCH_LINK_MASK 0xFFFE
#endif
static uint16_t g_benchLinkMask = LSM_BENCH_LINK_MASK; // payload tests may compile an isolated topology; field default is all IDs
static bool g_benchDropSched = false;     // v7.29.39: volatile proof fixture; Y enables schedule-only drop, y disables, reset disables
static int16_t secureRead(uint8_t*, size_t);
// Immediate physical sender proven by the last successful AES-GCM envelope.
// Packet handlers bind their mutable hop fields to this value; otherwise a
// valid fleet member could claim that another badge transmitted the packet.
static uint8_t g_secureRxSender = 0;
static uint32_t g_senderBindReject = 0;
static size_t securePacketLength();
static uint32_t secureAirTime(size_t);
#ifdef LSM_LISTEN_ONLY
#define LSM_TX(buf,len) (RADIOLIB_ERR_NONE)
#else
#define LSM_TX(buf,len) secureTransmit((const uint8_t*)(buf),(len))
#endif
#ifndef LSM_BUILD_DBM
#define LSM_BUILD_DBM 1
#endif
#ifndef LSM_RX_BOOSTED
#define LSM_RX_BOOSTED 0
#endif
#ifndef LSM_RX_LNA_BYPASS
#define LSM_RX_LNA_BYPASS 0
#endif
static const int8_t  LORA_DBM      = LSM_BUILD_DBM;    // v7.28.46 field default remains 1 dBm. LSM_BUILD_DBM is a bench-only override used to isolate near-field FEM saturation.
                                             // The FEM adds roughly 13 dB of TX gain, so 2 here
                                             // radiates about 15 dBm. The old value of 14 pushed
                                             // into a shut down FEM and radiated almost nothing.

// ----------------------- one second superframe, v7 dynamic MAC -----------------------
// The timekeeper (command 07) is the SOLE slot authority. Each frame it sends a
// schedule beacon in slot 0 naming which roster member owns each member slot
// THIS frame. A grant is valid only for the frame it was heard in. Miss the
// schedule and you stay a silent member: no contention, no stale slot reuse.
// New nodes listen only until admitted through the join window, and the TK
// admits at a non-deterministic frame driven by the CPU cycle-counter jitter.
static const uint32_t FRAME_MS  = 1000;
static const uint64_t FRAME_US  = 1000000ULL;   // legacy fixed frame, still the fallback
// v11: dynamic superframe. The TK sizes the frame to the live roster and
// advertises it in the beacon (frameMs10, units of 10 ms). Members anchor
// their frame period to the advertised value. Slots are assignment only; the
// clock rides in the data, so a variable frame length does not move the
// election timers, which are all wall-clock. See RIG_DYNAMIC_SUPERFRAME_NOTE.
static uint32_t g_frameUs = 1000000UL;   // current frame length in us, TK computes, members adopt
// v7.16.0: the "joiner airtime(36ms)" this used to claim was the stale
// AIRTIME8_US 8-byte-payload figure, which made it a THIRD stale airtime
// consumer alongside the two v7.15.0 corrected and V7_HARD_CAP_SLOTS corrected
// this release. The real MemberPkt airtime is 56576 us and the real JoinPkt
// airtime is 30976 us; 36 ms was never either of them.
// THE VALUE IS DELIBERATELY LEFT AT 40000. This is an end of frame tail, NOT
// the join reservation. The join reservation now lives in g_joinResUs, sits
// ahead of member slot 0, and is computed and published by the TK. Re-sizing
// this tail honestly would move a SECOND frame term in the same release that
// moves the reservation, and a bench regression would then be ambiguous about
// which of the two caused it. It gets its own release and its own bench pass.
// v7.26.0 PHY-DERIVED AIRTIME. Integer constexpr LoRa airtime, no float. Replaces the
// frozen 118016 and 56576 magic airtimes with the formula that PRODUCES them, so the
// geometry can follow the modulation instead of a hand-typed number. Pinned at
// LSM_ACTIVE_SF 7 it evaluates bit-identical to v7.25.0; the static_asserts by the
// airtime block enforce that at compile time and reject the build if it ever drifts.
// FLAT step only: TK_SLOT_US and MEMBER_SLOT_US stay literal, slot count stays 22, the
// beacon stays a fixed 62B on air. Letting nSlots and the beacon length move is a later
// version with a wire bump. Flip LSM_ACTIVE_SF to 6 or 5 to move the geometry.
// ceil(a/b) for a>=0,b>0 is (a+b-1)/b. Tsym_us = (2^SF * 1e6)/BW, exact for our BW.
static constexpr uint32_t lsmCeilDiv(int32_t a, int32_t b){ return (uint32_t)((a + b - 1)/b); }
static constexpr uint32_t lsmTsymUs(uint8_t SF, uint32_t BW){ return (uint32_t)(((uint64_t)(1u<<SF) * 1000000ULL) / BW); }
static constexpr uint8_t  lsmLowDataOpt(uint8_t SF, uint32_t BW){ return (SF>=11 && BW==125000u) ? 1 : 0; }
// v7.28.1: single source of the SX126x preamble rule. The datasheet REQUIRES at
// least 12 preamble symbols at SF5/SF6; 8 is fine at SF7 and up. Both the hardware
// preamble (LORA_PREAMBLE_SYMS, all three radio config sites) and the airtime
// formula below draw from THIS function, so the modem and the arithmetic cannot
// disagree. The 2026-08-28 SF5 bench failure was exactly that disagreement: TX at
// 8 preamble symbols left every SF5 receiver effectively deaf (0 to 6 receptions
// in 15 minutes against thousands in the SF7 runs), ten boards each self-elected
// TK, and the mesh never formed.
// v7.28.34: PREAMBLE TEST, and the rule is now DERIVED rather than a per-SF
// literal. LSM_PRE_MS is the wanted preamble DURATION in milliseconds; the
// symbol count falls out of the symbol time at whatever SF and BW are in
// force, so moving SF, moving BW, or moving to another modulation family
// later carries the same detector energy instead of inheriting a number that
// only made sense at one SF. Clamped to the SX126x legal range: the datasheet
// floor is 12 symbols at SF5/SF6 and 8 at SF7+, the register ceiling is 255.
// v7.28.35: ROLLED BACK. v7.28.34 shipped 16 ms (63 symbols at SF5) and
// delivery collapsed from 0.874 to 0.004, every witnessed failure a header
// error (IRQ 0x20) at saturation RSSI. Preamble length is eliminated as the
// lever. The duration RULE stays because it is correct and travels with the
// modulation; only the VALUE returns. 3 ms lands exactly on the v7.28.33
// numbers at every SF: 12 symbols at SF5 and SF6 (the datasheet floor binds),
// 8 at SF7 and SF8. Bit-for-bit what v7.28.33 flew.
static constexpr uint32_t LSM_PRE_MS = 3u;    // wanted preamble duration, ms
static constexpr uint16_t lsmPreFloor(uint8_t SF){ return (SF<=6) ? 12u : 8u; }
static constexpr uint16_t lsmPreSyms(uint8_t SF, uint32_t BW=125000u){
  const uint32_t Ts = lsmTsymUs(SF, BW);
  const uint32_t want = Ts ? ((LSM_PRE_MS * 1000u) + Ts - 1u) / Ts : 0u;
  const uint32_t floorS = lsmPreFloor(SF);
  const uint32_t n = want < floorS ? floorS : want;
  return (uint16_t)(n > 255u ? 255u : n);
}
static constexpr uint32_t lsmLoraAirUs(uint32_t PL, uint8_t SF, uint32_t BW=125000u,
                                       uint8_t CR=1, uint8_t CRC=1, uint8_t IH=0, uint8_t npre=0){
  const uint32_t Ts  = lsmTsymUs(SF, BW);
  // v7.28.1: npre=0 means auto, the per-SF minimum from lsmPreSyms. Callers that
  // pass an explicit count (none today) still get exactly what they ask for.
  const uint32_t np  = npre ? npre : lsmPreSyms(SF, BW);   // v7.28.34: BW matters now that the count is derived from duration
  const uint32_t preQ = (SF<=6) ? 25u : 17u;   // v7.27.0: SX126x SF5/SF6 use 6.25 sym preamble offset (25 quarter-sym) vs 4.25 (17) for SF>=7
  const uint32_t pre = ((4u*np + preQ) * Ts) / 4u;
  const int32_t  num = (int32_t)(8u*PL) - 4*SF + 28 + 16*CRC - 20*IH;
  const int32_t  den = 4*(SF - 2*lsmLowDataOpt(SF,BW));
  const uint32_t ps  = 8u + lsmCeilDiv(num, den) * (uint32_t)(CR+4);
  return pre + ps*Ts;
}
static constexpr uint8_t  LSM_ACTIVE_SF       = LORA_SF;   // v7.26.2: aliased to the radio's own SF constant (was a separate literal 7). One knob now drives BOTH the modem and the derived geometry, so an SF change cannot leave them mismatched. Flip LORA_SF at its definition to move everything together.
static constexpr uint32_t BEACON_WIRE_FIXED_B = 63u;   // v7.30.9: + keeper absolute lat/lon/altitude and confidence.
// heardMask[3]->[8] (+5). Max beacon is now 48 + 64 = 112 bytes against the 128-byte RX buffer, so the
// margin narrows from 22 bytes to 16. Any further wire growth has to come out of a restructure, not a
// wider field: see the node-id note in BUILD-NOTES.
                                                       // NOT the packet-loss root cause; at SF7/npre 8 both 62 and 64 give 118016 us so the
                                                       // frozen assert could not catch it. At SF5/npre 12 the real 64B beacon is 41280 us
                                                       // against 40000 modelled: a 1280 us per-frame under-count, now corrected.
static const uint16_t LORA_PREAMBLE_SYMS = lsmPreSyms(LORA_SF, LSM_ACTIVE_BW);   // v7.28.34: hardware preamble, the SAME derived rule the airtime formula uses. LSM_PRE_MS worth of symbols at the active SF and BW, floored at the SX126x per-SF minimum.

// v7.28.72-symbvalid: RECEIVER PREAMBLE VALIDATION. The SX126x command
// SetLoRaSymbNumTimeout (0xA0) sets how many LoRa symbols the modem must see
// before it commits to a reception. Its reset value is 0, which the Semtech
// driver documents as "validate the reception as soon as a LoRa symbol has
// been detected". RadioLib 6.6.0 and 7.1.2 never issue that command (grep of
// SX126x.cpp: only the opcode define exists), so every arm in this firmware
// has run at the single-symbol setting since day one. At SF7 a symbol is 128
// chips and a single-symbol false detection is rare. At SF5 a symbol is 32
// chips; the 2026-09-16 ten-board outdoor capture graded a flat one-in-three
// uplink loss that is memoryless, independent of slot index, occupancy,
// timing, range and power, 52 to 73 percent of it silent at the keeper, with
// header aborts firing in quiet air at 0.5 to 0.9 per second. That is a
// detector being captured by junk and being blind when the real preamble
// arrives. This rule asks for LSM_RX_SYMB_VALID symbols, capped four short of
// the transmitted preamble so the modem still has margin to lock on a real
// packet whose first symbols it missed. At SF5 (12 symbol preamble) that is 8.
// Bench A/B: build with -D LSM_RX_SYMB_VALID=0 to restore the reset setting
// and grade the two builds against each other; nothing else changes.
#ifndef LSM_RX_SYMB_VALID
#define LSM_RX_SYMB_VALID 2
#endif
static constexpr uint8_t lsmRxSymbValid(uint8_t SF, uint32_t BW=125000u){
  const uint32_t pre = lsmPreSyms(SF, BW);
  const uint32_t cap = (pre > 4u) ? (pre - 4u) : 0u;
  const uint32_t want = (uint32_t)LSM_RX_SYMB_VALID;
  return (uint8_t)(want < cap ? want : cap);
}
static const uint8_t LORA_RX_SYMB_VALID = lsmRxSymbValid(LORA_SF, LSM_ACTIVE_BW);
#if LSM_RX_SYMB_VALID != 0
static_assert(lsmRxSymbValid(5, 125000u) == 2u, "v7.28.73: SF5 receiver validation must come out at 2 symbols; 8 was graded totally deaf on hardware 2026-09-16");
#endif
static_assert(lsmRxSymbValid(LORA_SF, LSM_ACTIVE_BW) + 4u <= lsmPreSyms(LORA_SF, LSM_ACTIVE_BW), "v7.28.72: receiver validation must leave at least 4 preamble symbols of margin");
static constexpr uint32_t MEMBER_WIRE_B       = 35u;   // v7.29.57: must equal sizeof(MemberPkt). v7.29.38 added hiddenRivalEpoch but left this at 34; airtime-neutral at SF5/SF7, but SF6 was under-budgeted by 2560 us.

// ---------------- v7.28.37 VARIABLE-LENGTH BEACON GEOMETRY ----------------
// The slot array is the tail of SchedBeacon and the beacon now goes out at the
// length its live slot count needs, not at a fixed 22-entry width. Two numbers
// come out of that: the WIRE length and the AIRTIME, and every consumer of
// either must ask for the count rather than assume one.
//
// V7_SLOTS_MAX is the ceiling the wire format allows, NOT today's roster size.
// 64 chosen deliberately: at SF5 a 64-slot beacon is 63040 us of airtime, which
// still fits a frame, and the hard ceiling from the 128-byte RX buffer is 86.
// V7_SLOTS_PER_FRAME stays as the CURRENT geometry (the packer's working size);
// it no longer sizes the wire.
static constexpr uint8_t V7_SLOTS_MAX = 64u;

// Wire length of a beacon carrying n slot entries.
static constexpr uint32_t beaconWireB(uint32_t nSlots){
  return BEACON_WIRE_FIXED_B + nSlots;
}

#define DYN_JOIN_TAIL_US     60000UL     // v7.30.0: covers one measured replay-reservation NVS write with margin.
#define MAINT_TAIL_US       200000UL     // v7.30.0 long service tail, published periodically.
#define MAINT_TAIL_PERIOD        4U       // three replay reservations per tail sustain a full active roster
#define DYN_FRAME_FLOOR_US  (MEMBER_SLOTS_BASE_US + RELAY_REPLY_SLOT_US + DYN_JOIN_TAIL_US + 2*MEMBER_SLOT_US)  // v7.10.7: derived, not hardcoded, so it never goes stale when these constants change; v7.11.10 adds the reply-relay window
// v5.3: guard cut 16ms to 1ms. The scheduler places grants by each node's
// MEASURED delay (which contains ToF, both ways, relay hops, and processing),
// so the guard only carries the frame-to-frame change: engage variance, ISR
// stamp noise, and crystal drift across missed frames (25 ppm over the 7
// frame grace worst case is 175 us). ToF is 5.37 us per mile one way, 107 us
// round trip at 10 miles, inside the measurement. Sim: 3000 frames, 08 at 10
// miles going dark 7 of every 40 frames, zero collisions at 1 ms with the
// convergence quarantine below. Bench cyc data will set the final number.
// 22 member slots end at 914 ms; the join window [914, 930) keys the 8 byte
// join fully on air by 966 ms with 34 ms of guard before the next schedule.
// Join geometry lesson from board 08: the join must FIT its own airtime.
static const uint32_t AIRTIME8_US    = 36000;
#define V7_SLOTS_PER_FRAME 22
// v7.10.7: the join window is FIXED, not adaptive. It used to sit after
// the last placed member slot, so its position moved every time the
// roster changed size, and a cold joiner whose own frame estimate had
// not converged yet could compute the wrong spot and miss it entirely.
// Board 5's bench log showed exactly this: the first joiner in landed
// inside a second, every joiner after that stalled while the frame kept
// resizing under it. Now the join window sits right after the TK's own
// slot, at MEMBER_SLOTS_BASE_US, a fixed offset that never depends on
// roster size. Member data slots start after it instead of before it.
// The TK still scales overall frame length with roster count same as
// before, only the join window's POSITION is no longer part of that math.
static const uint32_t JOIN_KEYWIN_US = 24000;  // v7.10.6: was 16000, widened for cold-start slack
// v7.16.0: RETIRED from the frame geometry. This was one of the two local
// constants that added up to the old 25000 us join reservation, against a join
// packet whose airtime was 56576 us. Its job is now done by SLOT_GUARD_US
// inside the TK published g_joinResUs, stated once instead of twice. Kept
// declared rather than deleted so that anyone searching for it lands on this
// note instead of on nothing.
static const uint32_t JOIN_ALLOW_US  = 1000;   // RETIRED v7.16.0, see the note above
// v7.10.7: fixed offset where member data slots begin, right after the TK's
// own slot and the fixed join window. This never moves with roster size,
// see the join window note above.
// MEMBER_SLOTS_BASE_US moved below BEACON_AIR_US, v7.11.10: it now needs
// RELAY_SCHED_SLOT_US, which needs BEACON_AIR_US, not declared yet here.
// v7.10.1: deterministic join turn, replaces the old coin flip on both ends.
// A candidate only keys in when (schedule seq + its own NODE_ID) falls on
// this modulus, so distinct node IDs (mod this value) never contend for the
// same schedule's join window. Both ends read this from the same
// TK-published seq, so every node agrees on whose turn it is without any
// extra wire field.
//
// v7.10.8: the modulus itself is no longer one fixed number. A small fleet
// waiting up to 16 frames for a turn is needlessly slow, and a fleet near
// capacity needs more spacing than a small one does to keep simultaneous
// candidates from landing on the same remainder. nodeCount is already in
// every beacon (v6.6), so both the joiner and anyone else computing this
// read the identical value with no new wire field needed. Thresholds are
// Stu's own call, easy to retune:
//   under 30 nodes  -> modulus 4  (small fleet, frequent turns)
//   30 to 79 nodes  -> modulus 8
//   80 and up       -> modulus 16 (matches the old fixed ceiling)
// On top of that, if a board overhears heavy join-request traffic from
// OTHER candidates recently, real contention beyond what the base modulus
// was sized for, it backs off further on its own, same idea as WiFi's own
// congestion backoff, and decays back down once things quiet. See
// joinModBase() and joinModEffective() further down.
#define JOIN_SLOT_MOD_MAX 64U          // ceiling so backoff can never fully starve a joiner
// v7.19.0 brick1: JOIN-superframe demand trigger. When the overheard join backlog
// (g_recentJoinReqCount, already live since v7.10.8) crosses this, the TK announces
// a JOIN frame via the v7.17.0 typed-superframe countdown. Whole JOIN frame = admission
// turns; relays keep slots (leaf-yield only). Threshold 8 = the span-derived join floor.
#define JOIN_FRAME_DEMAND 8U
// v7.28.5: birth-frame swarm join. A funnel node that has buffered distant
// joiners it cannot admit through the modulus signals the TK with a MemberPkt of
// type MEMBER_TYPE_SWARM_REQ. The TK grants exactly ONE birth frame in response,
// then a mandatory member (DATA) frame, and will not re-arm until the cooldown
// clears. All enforcement is at the TK so a stuck or spoofed signal can never
// hold the sphere in birth mode and starve members. Byte-identical wire.
#define MEMBER_TYPE_SWARM_REQ 7U    // v7.28.5: funnel-to-TK swarm-join request. conf64 (flags_conf[5..0]) carries the count of joiner windows requested, capped 63.
#define MEMBER_TYPE_RELAY_PLEA 8U   // v7.29.1: a SEATED board that the keeper cannot hear directly and that no beacon names a relay FOR, pleads for a leg. It sends type 8 hops=0 in its own member slot; ANY capable seated board forwards it ONCE (hop limit 1, deduped on src+seq), stamping relayerId with its own id. The keeper's existing relayed-packet learn block (g_role==3 && hops>0 && relayerId!=0) then latches relayerId as this pleader's relay parent, so the very next beacon names the leg. This closes the bootstrap: before this a member needed a relayed copy to get a relayer, and a relayer to get a relayed copy. No wire-layout change; a pre-v7.29.1 board simply ignores the type. Gated on LSM_RELAY_PLEA.
#define MEMBER_TYPE_AGG_DEMAND 9U   // v7.30.0: relay asks the keeper for one compact subtree-update tail.
#define PLEA_UNNAMED_FRAMES 6U      // v7.29.1: frames a seated board may go both unheard-by-keeper AND un-named-as-relay before it begins pleading
#define PLEA_WAIT1_FRAMES   4U      // v7.29.1: frames after the first plea before the second (~6 s at a 1.4 s frame)
#define PLEA_WAIT2_FRAMES   8U      // v7.29.1: cadence after the second plea; a board that hears NOTHING is handled by the cold-listen / re-walk path, not here, so the plea does not drop to LISTEN on its own
#define BIRTH_COOLDOWN_FRAMES 1U    // v7.28.5: minimum DATA frames served between two birth frames. 1 = strict one-on-one-off.
#define BIRTH_RIVAL_CLEAR_FRAMES 3U   // v7.28.15: proactive birth frames stay in rotation until this many consecutive frames have passed with no rival keeper heard (direct or member-relayed). Frames, not seconds: frame length scales with the roster, so the debounce stays proportionate as the sphere grows.
#define BIRTH_EMPTY_RUNS_MAX 3U       // v7.28.15: after the rival debounce clears, this many consecutive proactive birth frames that admit nobody end the standing offer. Reset whenever a rival is heard, so the count only runs once the storm is over.
#define BIRTH_TAPER_COOLDOWN 2U       // v7.28.15: DATA frames between proactive birth frames once the roster holds at least half the schedulable slots (one-on-two-off). Below half it is BIRTH_COOLDOWN_FRAMES (one-on-one-off). The offer thins as there is member traffic to protect.
#define BIRTH_MAINT_DATA_FRAMES 3U    // v7.29.51: live nine-board recovery needed two offers and held node 01 in LISTEN about 45 s. Open maintenance birth after three DATA frames while capacity remains, bounding a missed-first-attempt retry near 18 s at the measured ~3 s field frame. One JOIN in four frames is about 25% admission overhead only while unused roster capacity remains.
#define BIRTH_W_MIN 4U    // v7.28.102: floor for BOTH demand and proactive birth W. One window puts every direct joiner in the same slot.
#define BIRTH_W_MAX 16U   // v7.28.102: ceiling for both. A large W buys nothing for a tree-admitted joiner and only lengthens every JOIN frame.
#define COLD_BIRTH_WINDOWS 7U   // v7.28.104: window count for the FIRST birth of a fresh TK tenure, forced regardless of demand or roster. 7 matches RELAY_TIERS_MAX so a cold TK opens one direct-join window per reachable relay tier. NOTE: multi-hop joiners climb via the aggregate tree and do NOT consume a W window (see the v7.28.102 note above), so this widens DIRECT admission on cold start; it does not by itself produce depth on a flat bench.
#define BIRTH_ANNOUNCE_CD 0U        // v7.28.5: frames of warning before a birth frame. 0 = flip at the next boundary. Every beacon already carries the live frame type and a joiner picks its window off the birth beacon itself, so no warning is needed. Raise it to add a warning frame at the cost of one extra DATA frame per birth.
#define JOIN_BACKOFF_DECAY_MS 5000U    // how often the overheard-join counter decays a step
#define RESIGN_SWARM_MAX_TRIES 25U   // v7.28.7: at the hoisted once-per-frame cadence this spans the ~10s failover window; Part B self-admit clears the flag on the first request that reaches a live TK, so the cap only bites under sustained deafness
// v7.16.0: this was subtracting AIRTIME8_US, the 8-byte-payload figure, making
// it a FOURTH stale airtime consumer alongside the two v7.15.0 corrected and
// the DYN_JOIN_TAIL_US comment. Understating the join reservation here
// OVERSTATES the cap, so the packer was allowed to place more member slots than
// physically fit in the frame. Sized now on the same generous fallback
// reservation as MEMBER_SLOTS_BASE_US. Macro, so it expands at its use site and
// the ordering of MEMBER_AIR_US below is not a problem.
// v7.28.102 CHUNK 3 ITEM 1: derived from the LIVE frame equation under the 10 s
// BACKHAUL_FRAME_CEIL_MS, not from the legacy 1 s FRAME_US. v7.28.98 lifted the
// ceiling from 2550 to 10000 ms and this cap never moved: it still divided the
// 1-second constant and came out at 10, so a birth frame published ten windows and
// fifty joiners needed five births with a mandatory data frame between each. The
// old value was not even self-consistent: a ten-window birth frame is 1425 ms at
// two tiers, already past the FRAME_US it was derived from.
// The equation is the two-tier birth-frame layout from tkBuildAndSend: keeper slot,
// two schedule-relay tiers sized for a full beacon, the fixed join reservation, two
// reply tiers, and the join tail. That gives roughly 121 at SF7. It is a MACRO and
// expands at the two use sites, where every constant it names is in scope.
// Both use sites still clamp to V7_SLOTS_MAX (64), and 64 is the honest number for
// this cut: the beacon slot array is slot[V7_SLOTS_MAX], and 48 + 64 = 112 bytes is
// what fits the read buffer. Reaching 121 needs slot[] widened, WIRE_VER 34, an
// 8-byte heardMask grown to 16, and a 169-byte beacon that the 256-byte buffer of
// item 4 can hold. That is a separate cut and must not be backed into.
#define V7_HARD_CAP_SLOTS ((uint32_t)(( (uint64_t)BACKHAUL_FRAME_CEIL_MS * 1000ULL \
                                        - TK_SLOT_US \
                                        - 2ULL * relaySchedTierUs((uint32_t)V7_SLOTS_MAX) \
                                        - JOIN_KEYWIN_US - MEMBER_AIR_US - SLOT_GUARD_US \
                                        - 2ULL * RELAY_MEMBER_TIER_US \
                                        - DYN_JOIN_TAIL_US ) / MEMBER_SLOT_US))
static const uint32_t TX_ENGAGE_US = 0;         // v7.28.25: was 300, the pre-measurement guess. g_txLatUs is the lead now; this is a residual knob only.
// v7.28.37: airtime of a beacon carrying n slot entries, at the ACTIVE PHY.
// This replaces the single fixed BEACON_AIR_US constant. Every consumer that used
// to read that constant must now say which count it means:
//   keeper  -> the count it is about to send
//   member  -> the count carried in the beacon it just heard
static constexpr uint32_t beaconAirUs(uint32_t nSlots){
  return lsmLoraAirUs(beaconWireB(nSlots)+MESH_SEC_OVERHEAD, LSM_ACTIVE_SF, LSM_ACTIVE_BW, (uint8_t)(LORA_CR - 4));
}
static inline uint32_t beaconAirUsLive(uint32_t nSlots){
  return lsmLoraAirUs(beaconWireB(nSlots)+MESH_SEC_OVERHEAD, g_workingSf, g_workingBw, (uint8_t)(LORA_CR - 4));
}
// Retained name = the CURRENT geometry's beacon airtime, for the boot-time and
// cold-start paths that have not heard a beacon yet and hold no count.
static const uint32_t BEACON_AIR_US = beaconAirUs((uint32_t)V7_SLOTS_PER_FRAME);   // v7.26.2: CR from LORA_CR   // v7.26.0: derived, was 118016. v7.15.2 COMMENT CORRECTION, value unchanged and correct. This is the real 62B SchedBeacon airtime at SF7/125k/CR4-5, explicit header, CRC on, 8-sym preamble: 103 payload symbols, 115.25 symbols total, 1024 us per symbol, 118016 us. The comment read 51B until now, left behind when v7.15.0 grew the beacon 54B to 62B and moved this value 102656 to 118016. The VALUE was right, the prose was not, and this same line already narrated an earlier staleness, so it had gone stale twice. History kept: was 77100, a stale 36B assumption that undersized the relay-schedule region and landed the member frame anchor about 25.6 ms early every frame. sizeof(SchedBeacon) is now pinned by a static_assert so this cannot silently drift again. Same struct and PHY as the LilyGO, so the same number. Feeds RELAY_SCHED_HOP_US, MEMBER_SLOTS_BASE_US, and the g_frameAnchorUs anchor.
static const uint32_t TK_TX_OVERHEAD_US = 20000;
static const uint32_t MEMBER_AIR_US = lsmLoraAirUs(MEMBER_WIRE_B+MESH_SEC_OVERHEAD, LSM_ACTIVE_SF, LSM_ACTIVE_BW, (uint8_t)(LORA_CR - 4));   // v7.26.2: CR from LORA_CR   // v7.26.0: derived, was 56576
#ifndef LSM_SLOT_GUARD_US
#define LSM_SLOT_GUARD_US 800UL
#endif
static const uint32_t SLOT_GUARD_US = LSM_SLOT_GUARD_US;
// v7.27.0: slot widths DERIVE from the real airtime so they shrink to fit the active
// SF with no dead air. TK_SLOT_US was literal 138016, MEMBER_SLOT_US was literal 57376;
// both are now airtime + their overhead, identical at SF7, smaller at SF5/SF6. The
// relationship asserts below stay tight because both sides move together.
// v7.28.37 OPTION B: the keeper slot is sized PER FRAME from the real slot count.
// tkSlotUs(n) is the live value; TK_SLOT_US is kept as the cold-start value at the
// current geometry, used only before any count is known (boot, cold listen, ceilings).
static constexpr uint32_t tkSlotUs(uint32_t nSlots){ return beaconAirUs(nSlots) + TK_TX_OVERHEAD_US; }
static inline uint32_t tkSlotUsLive(uint32_t nSlots){ return beaconAirUsLive(nSlots) + TK_TX_OVERHEAD_US; }
static const uint32_t TK_SLOT_US     = tkSlotUs((uint32_t)V7_SLOTS_PER_FRAME);
static const uint32_t MEMBER_SLOT_US = membercapacity::slotUs(MEMBER_AIR_US);
static_assert(membercapacity::wireFits(MEMBER_SLOT_US),"Member width must be exactly representable");
static uint32_t g_memberAirUsLive = MEMBER_AIR_US;
static uint32_t g_slotUsLive = MEMBER_SLOT_US;
static_assert(MEMBER_SLOT_US == membercapacity::slotUs(MEMBER_AIR_US),
  "MEMBER_SLOT_US must equal the real 22B MemberPkt airtime plus SLOT_GUARD_US. "
  "If MemberPkt size or PHY changes, recompute MEMBER_AIR_US and move both together.");  // v7.12.33: TX engage+teardown padding over airtime for slot 0, unified fleet value sized for the slower LR1121.
static_assert(TK_SLOT_US == beaconAirUs((uint32_t)V7_SLOTS_PER_FRAME) + TK_TX_OVERHEAD_US,
  "v7.28.37: TK_SLOT_US must be the cold-start beacon airtime at the current geometry plus TK_TX_OVERHEAD_US.");
// v7.28.37 REFERENCE GEOMETRY PIN, per Stuart 2026-09-05. The fixed sizeof(SchedBeacon)==64
// assert is retired with the variable-length beacon, so the LENGTH FUNCTION itself is pinned
// instead: it must reproduce the known SF7 / 22-slot geometry exactly, or the build fails
// before flash. This is what stops the formula drifting silently now that nothing else
// nails the beacon width down.
static_assert(BEACON_WIRE_FIXED_B + 22u == 85u,
  "v7.30.0 reference geometry: 52 fixed + 22 slots must be the 74-byte beacon");
static_assert(lsmLoraAirUs(64u, 7, 125000u, 1u, 1, 0, 8) == 118016u,
  "v7.28.98: formula proof, pinned to the 64-BYTE historical payload so it survives a wire change");
static_assert(beaconWireB(V7_SLOTS_MAX) <= 127u,
  "v7.30.9: max beacon 63 + 64 = 127 bytes; radioPoll read buffer remains 256 bytes");
// v7.26.0 FLAT-BUILD PROOF: derived airtimes must reproduce the frozen v7.25.0 values
// exactly at the pinned SF7/22 geometry, and the untouched slot literals must still
// match them. Any drift fails the build before flash. TK_SLOT_US and MEMBER_SLOT_US
// remain literal this release; these asserts are what make that safe.
// v7.27.0 FORMULA PROOF, SF-independent. Validates lsmLoraAirUs at the known SF7
// reference so a formula regression fails the build even though the ACTIVE SF is 5.
// v7.28.34: the two frozen references now pass npre EXPLICITLY (8, the old SF7
// literal). They exist to prove the PAYLOAD arithmetic has not regressed, and
// with a derived preamble the auto value at SF7 is no longer 8, so pinning the
// preamble here keeps the proof about the part it was written to protect.
static_assert(lsmLoraAirUs(64u, 7, 125000u, 1u, 1, 0, 8) == 118016u, "v7.27.0: CR4/5 formula no longer gives frozen 118016 at the SF7 reference (npre pinned 8)");
static_assert(lsmLoraAirUs(MEMBER_WIRE_B, 7, 125000u, 1u, 1, 0, 8) == 77056u, "v7.29.57: CR4/5 SF7 reference is 77056 us for the 35-byte MemberPkt");
// v7.28.34: and a NEW assert on the derived rule itself, so the preamble cannot
// silently fall below the SX126x floor or above the register ceiling at any SF.
static_assert(lsmPreSyms(5, 125000u) >= 12u && lsmPreSyms(5, 125000u) <= 255u, "v7.28.34: SF5 preamble outside the SX126x legal range");
static_assert(lsmPreSyms(7, 125000u) >= 8u  && lsmPreSyms(7, 125000u) <= 255u, "v7.28.34: SF7 preamble outside the SX126x legal range");
// tight slot relationship, holds at ANY active SF because both sides derive:
static_assert(MEMBER_SLOT_US == membercapacity::slotUs(MEMBER_AIR_US), "v7.27.0: MEMBER_SLOT_US must equal derived MEMBER_AIR_US + guard");
// the member hears RxDone at the END of this, the TK anchors at the START, so the
// member subtracts it to share the TK's slot-0 reference (fixes DRIFT rail, log 25)

// v7.11.10: real multi-hop flood relay, sizing. RELAY_MAX_HOPS is a real,
// tunable ceiling, not the LoRa datasheet's 7. It exists only to bound how
// wide the contention windows below have to be; raising it costs frame time
// linearly, nothing else. schedHops and MemberPkt.hops are each a full
// byte, so 255 is the hard technical ceiling, this cap is a deliberate,
// cheaper choice, currently comfortably past 7 and moved up by changing one
// constant if that is not enough. See the relay state block further down,
// after the packet structs, for the actual tracking logic and why this
// lives here instead of there: MEMBER_SLOTS_BASE_US needs it, and that has
// to exist before the packet structs are even declared.
#define RELAY_MAX_HOPS 8
// v7.13.0: TIER COUNT != HOP CEILING. The relay guard is strict:
//   if (outHop < RELAY_MAX_HOPS)
// so the deepest relay transmission ever produced is outHop = RELAY_MAX_HOPS-1,
// i.e. only RELAY_MAX_HOPS-1 tiers are ever occupied. The windows below used to
// multiply by RELAY_MAX_HOPS, reserving one whole tier in each window that no
// node can ever transmit in: 117656 us in the schedule window plus 50000 us in
// the reply window = 167656 us of dead air EVERY frame, ~8.7% of the floor,
// constant regardless of the hop setting. Sizing on tiers instead costs zero
// reachable depth. Nodes at depth RELAY_MAX_HOPS are still reached; they are
// simply leaves that cannot relay onward, which is what the guard already said.
#define RELAY_TIERS_MAX (RELAY_MAX_HOPS - 1)
static const uint32_t RELAY_SCHED_HOP_US  = BEACON_AIR_US + schedulerelay::overhead(LSM_RELAY_TIMING_V2);   // one schedule-relay hop, airtime + guard
static const uint32_t RELAY_MEMBER_HOP_US = MEMBER_AIR_US + 2000UL;    // one data-relay hop, airtime + guard
static const uint32_t RELAY_JITTER_MAX_US = 12000UL;                  // contention jitter ceiling, per hop tier
static const uint32_t RELAY_PROBE_MOD      = 8UL;     // v7.28.16: a board with no downstream evidence relays the schedule only on its probe turn, (seq + NODE_ID) % RELAY_PROBE_MOD == 0
static const uint32_t RELAY_NEED_DWELL_MS  = 3000UL; 
static const uint32_t JOIN_DIRECT_WINDOW_MS = 3000UL;  // v7.28.19: a direct schedule heard this recently means the keeper can hear us, so join direct
 // v7.28.16: how long downstream evidence keeps the every-frame relay armed after the last piece of it was heard; millis, not frames, because g_frame advances only on the keeper
// Full contention window width: RELAY_MAX_HOPS tiers, each wide enough for
// one real hop's airtime plus its own jitter budget. This is the real,
// honest cost of true depth: window width grows linearly with the hop
// ceiling, not with roster size, and is paid every frame whether or not a
// packet actually needs that many hops this cycle.
static const uint32_t RELAY_SCHED_TIER_US = RELAY_SCHED_HOP_US  + RELAY_JITTER_MAX_US;   // v7.13.0: one schedule tier
static const uint32_t RELAY_MEMBER_TIER_US = RELAY_MEMBER_HOP_US + RELAY_JITTER_MAX_US;   // v7.13.0: one reply tier
#define RELAY_LEG2_JITTER_US 11000UL   // v7.28.104 GUARD 1: the second named leg forwards 11 ms after the first, inside the existing 12 ms band. Leg 1 stays at the tier start.
static_assert(RELAY_LEG2_JITTER_US < RELAY_JITTER_MAX_US, "v7.28.104: leg-2 jitter must stay under the 12 ms relay jitter band");
static_assert(RELAY_LEG2_JITTER_US + MEMBER_AIR_US <= RELAY_MEMBER_TIER_US, "v7.28.104: a leg-2 forward must end inside its reply tier");
static const uint32_t RELAY_SCHED_SLOT_US = (uint32_t)RELAY_TIERS_MAX * RELAY_SCHED_TIER_US;   // v7.13.0: tiers, not hops (see RELAY_TIERS_MAX)
static const uint32_t RELAY_REPLY_SLOT_US = (uint32_t)RELAY_TIERS_MAX * RELAY_MEMBER_TIER_US;  // v7.13.0: tiers, not hops
// v7.28.37 OPTION B, per-frame relay-schedule geometry. A relayed beacon is a copy
// of the keeper's, so its airtime is beaconAirUs(nSlots) at THIS frame's slot count.
// One schedule-relay hop and one tier therefore scale with the frame, exactly like
// tkSlotUs. The fixed RELAY_SCHED_HOP_US / RELAY_SCHED_TIER_US above stay as the
// cold-start reference (V7_SLOTS_PER_FRAME) for paths that hold no count yet.
static constexpr uint32_t relaySchedHopUs(uint32_t nSlots){ return beaconAirUs(nSlots) + schedulerelay::overhead(LSM_RELAY_TIMING_V2); }
static constexpr uint32_t relaySchedTierUs(uint32_t nSlots){ return relaySchedHopUs(nSlots) + RELAY_JITTER_MAX_US; }
static inline uint32_t relaySchedTierUsLive(uint32_t nSlots){ return schedulerelay::tier(beaconAirUsLive(nSlots),RELAY_JITTER_MAX_US,LSM_RELAY_TIMING_V2); }
#define RELAY_NO_DEADLINE 0xFFFFFFFFUL
// v7.10.7: fixed offset where member data slots begin, right after the TK's
// own slot and the fixed join window. v7.11.10 inserts the schedule-relay
// contention window between the TK's own slot and the join window, so the
// join window and everything after it shifts later by RELAY_SCHED_SLOT_US.
// v7.16.0: compile time FALLBACK only. The live value is g_memberBaseUs, which
// applyTiers() derives from the TK published reservation g_joinResUs. This
// constant is deliberately sized on the FULL MemberPkt airtime rather than the
// much smaller JoinPkt airtime, so that any path which somehow still reaches it
// reserves too MUCH room and lengthens the frame, never too little and collides.
// JOIN_ALLOW_US leaves the geometry here: SLOT_GUARD_US now states that idea
// once, in the same units, in the same place as every other guard.
static const uint32_t MEMBER_SLOTS_BASE_US = TK_SLOT_US + RELAY_SCHED_SLOT_US + JOIN_KEYWIN_US + MEMBER_AIR_US + SLOT_GUARD_US;

// ---------- v7.13.0: RUNTIME tier geometry ----------
// The relay windows, and therefore the member-slot anchor, are the only parts
// of the frame whose width depends on network DEPTH rather than roster size.
// These runtime mirrors let the TK size them to the depth actually observed
// instead of always paying for the full ceiling. They are PINNED to
// RELAY_TIERS_MAX unless LSM_DYNAMIC_DEPTH is defined, so a default build
// computes byte-identical values to the static constants above.
//
// SAFETY: g_memberBaseUs is the structural anchor for EVERY member slot on
// both the TK and the member. TK and member must always agree on it exactly.
// That agreement is why schedTiers rides in the beacon: a member never infers
// the tier count, it is told, every frame.
static uint8_t  g_schedTiers       = RELAY_TIERS_MAX;   // tier count in force RIGHT NOW
// v7.19.0 brick6: compile tripwire. The runtime tier-admission clamp (below, at the
// three relay-transmission depth gates) is now in place, so a relay can no longer
// transmit past a shrunk dynamic-depth window into the join/member region. That clamp
// has NOT been bench-proven yet. This #error forces a conscious removal before any
// dynamic-depth build can ship: prove the clamp on hardware, THEN delete this block.
// v7.20.0: tripwire RETIRED, deliberately, for the clamp bench itself. The
// #error that stood here forced a conscious arming of LSM_DYNAMIC_DEPTH; it
// is armed NOW, fleet-wide, for the four-board hop-3 refusal proof (05 TK,
// 06 hop1, 07 hop2, 08 pushed to hop3, LSM_BENCH_FORCE_TIERS=2). PASS is the
// hop-3 board REFUSED at the admission gates, silent past the window, nothing
// landing in the join/member region. Until that log exists the bench define
// pins the window and bypasses grow/shrink so the ONLY thing under test is
// the clamp.
static uint32_t g_relaySchedSlotUs = RELAY_SCHED_SLOT_US;
static uint32_t g_relayReplySlotUs = RELAY_REPLY_SLOT_US;
static uint32_t g_relayMemberTierUsLive = RELAY_MEMBER_TIER_US;
static uint32_t g_memberBaseUs     = MEMBER_SLOTS_BASE_US;
static uint32_t g_dynFloorUs       = DYN_FRAME_FLOOR_US;
// v7.16.0: join reservation, the single value that decides where member slots
// begin. g_joinAirUs is THIS node's own join packet airtime, measured from the
// radio at boot rather than carried as a constant. g_joinResUs is the total
// reservation: on the TK it is computed and published, on a member it is
// adopted from the beacon and never inferred locally.
// The initial value here is a deliberately GENEROUS fail-safe, sized on the
// full MemberPkt airtime rather than the JoinPkt airtime, so that if the
// measurement or the beacon field were ever missing the reservation comes out
// too LONG (a slightly longer frame) instead of too SHORT (the 2026-07-28
// collision defect). It is overwritten before the first join in both roles.
static uint32_t g_joinAirUs        = 0;
static uint32_t g_joinResUs        = JOIN_KEYWIN_US + g_memberAirUsLive + SLOT_GUARD_US;
static uint8_t  g_joinMod          = 8;   // TK published; 0 = join closed

static inline void applyTiers(uint8_t t, uint32_t nSlots = V7_SLOTS_PER_FRAME){
  if (t > RELAY_TIERS_MAX) t = RELAY_TIERS_MAX;
  g_schedTiers       = t;
  // v7.28.37 OPTION B: the schedule-relay region scales with the beacon actually
  // in force this frame, and the keeper's own slot does too. nSlots defaults to the
  // cold-start reference geometry for callers with no live count yet. The reply
  // region carries member packets, whose airtime is fixed, so it stays on the fixed
  // member tier.
  g_relaySchedSlotUs = (uint32_t)t * relaySchedTierUsLive(nSlots);
  g_relayReplySlotUs = (uint32_t)t * g_relayMemberTierUsLive;
  // v7.16.0: ONE published reservation, not two local constants. On the TK
  // g_joinResUs is computed from the measured JoinPkt airtime; on a member it
  // is adopted from the beacon. This is the exact line the 2026-07-28 join
  // defect lived on: it reserved 25000 us ahead of member slot 0 for a packet
  // whose airtime was 56576 us, so every join overran slot 0 by 31576 us.
  g_memberBaseUs     = tkSlotUsLive(nSlots) + g_relaySchedSlotUs + g_joinResUs;
  g_dynFloorUs       = g_memberBaseUs + g_relayReplySlotUs + DYN_JOIN_TAIL_US + 2*g_slotUsLive;
}

// ---------- v7.13.0: committed-depth hold + resize countdown ----------
// Growth is INSTANT: a deep node's relay must have a tier waiting before it
// needs one, or it drops. Shrink is deliberately slow, because the failure
// mode is a collapse spiral: shrink the window -> a deep node's relay no
// longer fits -> that node drops -> observed depth falls -> shrink again.
// So shrink is gated on a WALL CLOCK hold (not a frame count, which is the
// v7.9-v7.10.2 frame-count-as-time trap) and steps down ONE tier at a time,
// re-arming the hold on each step.
#define DEPTH_HOLD_MS         6000UL   // v7.30.0: brief anti-flap hold; seated depth still prevents collapse below a live route.
#define RESIZE_COUNTDOWN_MS   5000UL   // human-facing pre-announce, converted to frames at arm time
#define RESIZE_CD_MIN            3U
#define RESIZE_CD_MAX           60U
#define RESIZE_NONE           0xFFU    // sentinel, mirrors FREQ_SWITCH_NONE
#ifndef LSM_MIN_DISCOVERY_TIERS
#define LSM_MIN_DISCOVERY_TIERS 0U     // v7.30.0: direct spheres need no relay tier; periodic probes discover a deeper frontier.
#endif
#define LSM_DISCOVERY_PROBE_FRAMES 8U  // v7.30.0: one brief deeper probe every eight frames; no permanent six-tier tax.
static_assert(LSM_MIN_DISCOVERY_TIERS <= RELAY_TIERS_MAX,
              "LSM_MIN_DISCOVERY_TIERS must fit the reserved relay geometry");
static uint8_t  g_pendTiers      = 0;
static uint8_t  g_resizeCountdown = RESIZE_NONE;
static uint32_t g_depthHoldUntilMs = 0;
static uint8_t  g_obsDepth        = 0;   // deepest MemberPkt.hops seen this frame
static uint8_t  g_obsDepthWin     = 0;   // v7.28.98: max observed depth across the CURRENT hold window

#define V7_MAX_ROSTER 200
static const uint32_t AIR_TIMEOUT_FR   = 40;    // legacy frame count, kept for the relative sort only
static const uint32_t AIR_TIMEOUT_MS   = 90000;  // v7.11.6: settled at 90s (1.5 min) per Stu, a real operating value now, not a test number. Long enough to clear a steel-building fade or a brief dual-TK confusion without a full rejoin, short enough that a genuinely gone node still clears in reasonable time.
static const uint32_t RESURFACE_MS     = 7000;   // v11.3: real-time resurface-quarantine window (was 7 frames)
static const uint32_t ALONE_GRACE_FRAMES = 20;  // v7.12.16: restored the v7.11.14 frame-scaled grace that regressed out at v7.12.0. N=20 confirmed by Stu. A fixed 8000ms grace only covered about 4 or 5 frames once the v7.11.10 relay windows stretched the frame to about 1.77s, so members self-elected on a brief line-of-sight blockage. Scaling to a fixed frame count fixes that.
static const uint32_t ALONE_GRACE_FLOOR_MS = 30000UL; // v7.30.0: true dynamic frames can be under 500 ms; twenty such frames made an ordinary listener cold-elect in under ten seconds while the named successor was already recovering the sphere.
static inline uint32_t aloneGraceMs(){
  uint32_t scaled = (g_frameUs/1000UL) * ALONE_GRACE_FRAMES;
  return scaled > ALONE_GRACE_FLOOR_MS ? scaled : ALONE_GRACE_FLOOR_MS;
}  // preserve frame scaling for long/deep spheres, but never let a short adaptive frame turn a routine schedule gap into a cold election
static const uint32_t PEER_SEED_FRESH_MS = 90000; // v7.11.6: widened 5s to 90s, matched to AIR_TIMEOUT_MS, so any board a TK would still consider live is also fresh enough to seed instantly on election
                                                  // from a peer heard this recently, same
                                                  // freshness window peerCount() already uses
static const uint32_t ROSTER_KEEP_MS = 30000;    // v7.10.4: a board that stood down from
                                                  // TK and re-elects itself within this
                                                  // window keeps its own roster rather than
                                                  // being treated as a fresh, unknown TK
// ----------------------- v7 sync note -----------------------
// Time sync rides the schedule beacon itself: its ISR arrival instant anchors
// slot 0 of the frame on every member, microsecond precision, the proven v4.15
// mechanism. The v4 relayed-time machinery is superseded by the TK schedule.
static const uint32_t AIR_US = 77100;  // 36B schedule beacon time on air at SF7
// ----------------------- identity and reported state -----------------------
// v7.29.12: NODE_ID comes ONLY from platformio.ini (-D NODE_ID=N, plain decimal).
// The source constant is gone so all thirteen boards carry a byte-identical main64.cpp.
// Before this, the source said static const NODE_ID = N and the ini ALSO said
// -D NODE_ID=0N; the macro rewrote the constant into "static const uint16_t 02 = 2;",
// and every #if NODE_ID test (phantom carrier, keeper budget) saw 0 whenever the
// macro was absent, so those blocks were silently compiled out.
#ifndef NODE_ID
#error "NODE_ID is not set: add -D NODE_ID=N to build_flags in this board's platformio.ini"
#endif
#define LSM_STR2_(x) #x
#define LSM_STR_(x) LSM_STR2_(x)
static_assert(LSM_STR_(NODE_ID)[0] != '0', "NODE_ID has a leading zero: C reads 010 as 8 and 08 fails, write plain decimal");
static_assert(NODE_ID >= 1 && NODE_ID <= 65535, "NODE_ID out of range 1..65535");
// Wire protocol version for the ctok sub-GHz sphere. Carried by BOTH
// SchedBeacon.ver and JoinPkt.ver, which move in lockstep by design. Every
// build site and every receive gate reads this one constant, so a wire bump
// now moves exactly one line. This retires the scattered-literal defect class
// that let the JoinPkt transmit build sit at 21 while the other four sites
// were at 22, silently dropping every join request at the TK gate (found on
// the first v7.17.0 hardware flash log, board 06 never admitted). Still
// incompatible with the ver 17 main fleet by design.
static const uint8_t  WIRE_VER   = LSM_RELAY_TIMING_V2 ? 41 : 40;   // v7.30.9 keeper position/confidence beacon; coordinated fleet reflash required.
// Both move the beacon layout, so 32 and 33 cannot interoperate. Fixed part 42 -> 48 bytes.
static const uint8_t  FW_MAJOR   = 7;
// v7.10.1: FW_MINOR now actually matches the v7.10 wire-12 release name,
// it had stayed at 9 through the v7.10 token field work even though that
// was already a distinct, wire-bumped release from the v7.9.x line.
static const uint8_t  FW_MINOR   = 30;
// v7.29.16: authenticated, deduplicated reports refresh roster liveness even when relay delay makes them stale for timing. Timing calibration remains same-frame only. No wire change. WIRE_VER stays 36.
static const uint8_t FW_PATCH = 153;
static_assert(FW_PATCH == 153, "Uphill candidate");
// v7.28.104: four changes on top of 103, heltec v2 only. (1) GLASS: the H field paints hops to the TK from
// g_anchorHops, 0 on the keeper, a dash with no live schedule inside aloneGraceMs; g_hopsToCmd stays compiled,
// reserved, read only by the election score, never painted. (2) COLD BIRTH: the first JOIN beacon of a fresh keeper
// tenure opens COLD_BIRTH_WINDOWS (7) windows even with an empty roster. (3) TWO NAMED LEGS: relayForId2/relayById2
// on the beacon, same frame, named by the keeper, never a volunteer; WIRE_VER 34, fixed head 50. (4) THREE GUARDS on
// the forward: leg 2 jitter 11 ms inside the 12 ms band, decreasing hop before arm (sender depth rides volunteerFor on
// relayed copies), per-frame dedup on (src_id, hop). New witness LOG_STATE 0xAD = second pair named. v4 and lilygo
// untouched at 100, WIRE_VER 33.
// v7.28.103: two cuts on top of 102, neither ever flashed.
// CUT 1 fixes a real hole in the 102 build note's own safety claim: aggBufAdd
// latched g_admitId on any fresh insert, and aggReaggregate (secondhand, from a
// magic-B receive) also calls aggBufAdd, so an honest relay's first re-aggregation
// of a never-before-cached joiner looked first-hand to the dedup check and set the
// latch exactly as a genuine direct hearing would. memberSendSwarmReq then
// hardcoded hops=0 regardless of provenance, so the keeper's hop-0 check could not
// tell the difference. Not an attack path, ordinary traffic. Fixed by threading an
// explicit firstHand bool through aggBufAdd: true only from the type-2/hops==0
// receipt, false from both aggReaggregate call sites.
// CUT 2 lets an admit climb more than one hop. memberSendSwarmReq no longer
// hardcodes hops=0; it reports this board's own real g_anchorHops+1 when an admit
// is riding, the same way every relay leg already reports its own depth honestly
// elsewhere in this file. The keeper's honor check drops the hop-0 requirement for
// the volunteerFor branch (Part B's own hop-0 self-admit two lines above is
// unchanged) and replaces a broken depth bound from the first draft of Chunk 4,
// p->hops <= g_anchorHops + 1 evaluated AT THE KEEPER, which is always <= 1
// because g_anchorHops is a single scalar per board and the keeper's own reads 0
// the moment it wins election. There is no per-claimant depth stored anywhere the
// keeper could read instead, so the bound is RELAY_MAX_HOPS, the same ceiling
// aggReaggregate already trusts on the other admission path.
// Untouched: magic-B receive, the reply-window flush, depth-strict / one-shot,
// WIRE_VER, tkOnJoinReq as the sole admission door, srcIdx >= 0 chain of custody.

// v7.28.102 CHUNK 4, added after the initial 102 cut above: parallel local admission,
// folded into the existing type-7 swarm-ask rather than a new packet. A board that
// hears an unseated joiner first-hand (type-2, hops==0, the ONE call site allowed
// to set g_admitId) rides that joiner's id on volunteerFor on its next swarm-ask,
// transmitted from its own existing member slot. The keeper, on a type-7 with hops
// 0 and a nonzero volunteerFor, admits and names the sender as parent in one step,
// aux 0xEC with a 0xA7 marker. Requires the sender itself be a currently-seated
// roster member (tkRosterFind(src) >= 0) before honoring the claim; this check was
// missing from the first draft of this cut and was the entire chain-of-custody
// property, not a redundant one. Even fixed, the check proves the claimant is
// trusted, not that it actually heard the joiner; that remains the accepted v1
// limit. aggReaggregate, the magic-B receive path, the reply-window flush and
// WIRE_VER are all untouched by this item. No new packet type, no wire-layout
// change, no new receive-side transmission.
 // v7.29.0: THE HAIL MARY, per Stuart. v2 boards only, cut on the proven v7.28.105 source.
 // Every new subsystem behind its own compile flag, all flags on for the first flight, so a bad
 // walk is bisected by flipping a flag rather than rebuilding. WIRE_VER stays 34, no wire change,
 // air-compatible with v7.28.105.
 //  (1) PHANTOM CARRIER, node 12 only (RIG_PHANTOM_CARRIER in node_12 platformio.ini, double-gated
 //      on NODE_ID==12 in source). Node 12 carries 16 phantom joiners that present as unseated
 //      joiners it proxies, raising the birth flag on their behalf, to exercise the birth frame at
 //      the most distant node. Compiled out on every other board; node 01 stays clean as keeper.
 //  (2) ROTATION GUARANTEE (LSM_ROTATE_GUARANTEE, default 1). In the keeper slot shuffle, any member
 //      whose wall-clock last-heard age has passed HALF the eviction window (AIR_TIMEOUT_MS/2 = 45 s)
 //      is pulled to the front in stable order and NAMED a slot before anyone fresher, so a
 //      near-eviction node is never starved by two bad shuffles in a row. Everyone else keeps the
 //      staleness order and the Fisher-Yates. With the flag off it is byte-for-byte the v7.22.0
 //      shuffle. Wall-clock basis because the old sort key g_lastAirFr is a frame count and does not
 //      track age when the superframe length varies.
 //  (3) COMMAND-CENTER CASCADE (LSM_CMDCTR_CASCADE, default OFF, SOURCE ONLY). NODE_ID 200..203
 //      (C1..C4) carry a descending election weight 10000/9000/8000/7000 so a designated command
 //      board wins keeper. Undefined on the 01..13 fleet, so it does NOT run this flight and does
 //      not perturb the DAISY_ROOT_ID=1 TK lock; 01 stays the only weighted board. One flag later.
 //  (4) CENTRALITY RENAME finished: the election rung macro TIE_CENTRAL is renamed TIE_ROSTER (this
 //      rung weighs rosterCount, not centrality), value unchanged. The centrality score term has
 //      been held at zero since v7.28.9 (CENTRAL_ENABLED false) and the function rename landed in
 //      v101, so nothing else was needed. The word centrality is reserved for a real UWB ranging
 //      input. See DESIGN-NOTE-centrality.txt.
 //  ALREADY IN THE TREE, not rebuilt: hop depth is surfaced in the RX record (incoming hops in data
 //      bits 24..31, member and schedule beacons, v7.28.86) and on the glass (hops to TK from
 //      g_anchorHops, v7.28.104); the tier floor (v7.28.105) and frame-length ceiling (v7.28.98)
 //      hold; the birth frame / join tree (v7.28.102) is present. SF_TYPE_FLAG stays unused.
 //  NOT COMPILED in this environment; run pio on the fleet toolchain before flashing. Flash all
 //      thirteen v2 boards together. v4 and lilygo are not in this tree and stay on their own line.
 //  The dashboard map plotting fix is a separate web file, shipped on its own, not in this firmware.
 // v7.28.105: TIER-COLLAPSE FIX plus MEMBER RELAY WITNESS, per Stuart. Cut against the v7.28.104 relay-walk grade. (1) TIER FLOOR. Root cause proven on two continuous logs, the keeper and node02: g_schedTiers walked 7 down to 1 over the run and stuck at 1 for about ten minutes, because the shrink side sized the tier count from the deepest LIVE uplink the keeper heard, which never passed hop 1 once boards fell past the shrunk edge. Sizing reach from what the keeper currently hears is self-blinding: once it shrinks past a node, that node loses the relayed downlink schedule, its uplink is refused at the relay gate, and it can never report back to grow the count. FIX: new parallel roster array g_seatDepth, the high-water relay-hop depth of each seated node, 0 at seat, RAISED (never lowered) whenever a seated node reports a deeper MemberPkt.hops, carried through the eviction compaction and released on evict. The governor computes seatFloorTiers = deepest seated depth + 1 (clamped RELAY_TIERS_MAX) and the one-tier shrink can fall TO the floor but never below. Growth unchanged, still immediate off g_obsDepth + 1. Empty roster floors at 1, the pre-105 behaviour. Refresh-up-not-down is deliberate per Stuart: a node admitted at hop 1 that later only arrives at hop 3 raises its entry to 3, or the same self-blind shrink happens to a board already owned. (2) MEMBER RELAY-NAMING WITNESS. LOG_STATE 0xDB (pair 1) and 0xDC (pair 2), both distinct from the keeper-side 0xEB/0xAD. Emitted where a member writes g_relayAssignedFor/g_relayAssignedFor2 from an adopted beacon, one per adopt, e = relayForId, n = relayById, data = seq, mirroring 0xEB from the receive side so the grader lines a member's adoption up with the keeper's naming by seq. Keeper excluded, it already emits 0xEB/0xAD. Closes the gap that left node04's 27 data relays (0xFC) untraceable on the 104 walk. (3) SF_TYPE_FLAG. Left INTENTIONALLY UNUSED this cut and marked so at its define, so nobody implements a dead enum. g_frameTypeTarget is only ever set to DATA or JOIN. The tier hold needs no flag frame: the held tier count already rides every beacon in s.schedTiers, so a held-depth sphere is already marked on the wire. Enabling it is a design task (what a FLAG frame carries and how members react), not this cut. (4) FRAME-LENGTH CEILING. Already lifted at v7.28.98: frameMs10 is uint16 and BACKHAUL_FRAME_CEIL_MS is 10000 ms, nothing left to widen. The field is NOT retouched. The stale v7.13.0 comment at the frame clamp that still called frameMs10 uint8 (255 = 2550 ms) is corrected to historical. BENCH CHECK, since the floor can now hold tiers high while the roster is full, which the pre-105 collapse never allowed: the worst case is nSlots = V7_SLOTS_MAX 64 held at RELAY_TIERS_MAX 7 tiers. 64 member slots at g_slotUsLive 72736 = 4655 ms dominate; 7 sched-relay tiers add about 1600 ms, 7 reply tiers about 600 ms, keeper slot plus join plus 40 ms tail about 350 ms, so about 7.2 s, under the 10000 ms ceiling with roughly 2.8 s to spare. If a future geometry ever exceeds it, the existing 0xF2 short-clamp witnesses the overflow rather than losing slots silently. NOTE for a later cut: V7_HARD_CAP_SLOTS is derived assuming only 2 sched tiers of overhead, so held-high tiers eat headroom; the 64/7 corner still fits. (5) SAT GATE. MIN_SATS_TX made a compile flag, default RELAXED 3 -> 1 so a position walk can grade with a weak fix (both 104 walks ran sats=0 and graded no position). gps.location.isValid() still gates origin, seed burst, wire, BLE and fusion, so no-lock is still refused. Compile -D MIN_SATS_TX=3 to restore strict, =0 to trust isValid alone. CROSS-CUTS. NO WIRE CHANGE: g_seatDepth is keeper-local and 0xDB/0xDC are log records, so WIRE_VER stays 34, compatible on the air with 104. WIRE_VER 34 is v2 only; the v4 and lilygo boards stay at 33 until bumped and are not in this tree. Flash all thirteen v2 boards together. NOT COMPILED in the build environment; run pio on the fleet toolchain before flashing. Prior: v7.28.102 CHUNK 3, the join tree, cut against the working list in order. (1) V7_HARD_CAP_SLOTS re-derived from the live two-tier frame equation under the 10 s BACKHAUL_FRAME_CEIL_MS, not the legacy 1 s FRAME_US; it was 10 and is now 126 clamped to V7_SLOTS_MAX 64 (the beacon slot array and the 112-byte beacon are the honest ceiling; 121 needs a wire change and is a separate cut); proactive birth W split from demand W and clamped 4..16 so a standing offer can no longer publish every window and burn a 5-second empty frame three times over. (2) aggFlush gated on offUs and moved into the REPLY WINDOW of a JOIN frame, which carries no member relay and was empty; it used to fire ungated on the tail of the schedule flood. g_schedFloodRelayed is no longer a prerequisite: any JOINED board with an adopted schedule and cached joiners flushes, which is the tree. (3) One record per flush (AGG_FLUSH_MAX_REC), slot AGG_SLOT_US derived from real airtime plus guard (about 44 ms at SF7), N slots from the live reply window or -D AGG_FLUSH_SLOTS; RELAY_JITTER_MAX_US (12 ms) cannot hold an aggregate and is not reused. The v7.28.101 funnel ask moved off that same ungated site and now rides the board's own member slot as a type-7 in place of the report. (4) radioPoll read buffer 128 to 256: any aggregate over 24 records was dropped with no witness. (5) Aggregate magic 'B' adds the sender byte; the keeper seats AND names the sender as parent in one step. 'A' still accepted, seats without naming. No WIRE_VER bump. (6) Discovery-to-exclusive boundary: aggBufAdd refuses seated ids, aggBufPurgeSeated drops them after every adopted beacon; the seat is the one event that flips an id. (7) One-shot equal-depth latch g_aggEqOnce keyed on the joiner id, set on first equal-depth re-aggregate, refused on the second, cleared on seat; replaces the v7.28.101 strict refusal that could strand a joiner with only equal-depth neighbours. (8) Asymmetric parent hold: adopt a fresh volunteer immediately if the latched parent has been silent PARENT_SWITCH_SILENT_FRAMES (3) frames, abandon still at relayParentHoldMs. New witnesses: LOG_STATE 0xAB flush slot (e pick, n N, data cached), 0xAC equal-depth one-shot taken, 0xEC data hi byte 0xB0 = named via 'B' aggregate. heltec_v4 and lilygo untouched at 100. Prior: v7.28.101: CHUNK 1 mechanical cut on top of the hardware-proven v7.28.100. (1) both deprecated volatile increments (g_fsWritten in fsWriterTask, g_fsQueued in logFlush) moved to read-add-write. (2) ESP_RST_USB added to the clean-boot erase set, so a reflash no longer leaves a stale log to mix builds in the next dump. (3) electCentral renamed electRosterCount and every centrality comment in the election path corrected to rosterCount; the function has carried roster size since v7.28.60 and the word centrality is now reserved for a real UWB ranging input, see DESIGN-NOTE-centrality.txt. (4) LOG_STATE aux 0xEC split: 0xEC is volunteer-accepted only, keeper resignation moved to 0xEE. (5) the join-relay comment corrected, TWICE. Type 2 has been in the dispatch gate since v7.18.0 and does reach memberFloodNote, but reaching it is not relaying it: memberFloodNote forwards only when iAmRelay, and that keys on relayForId, which the keeper assigns as g_roster[i], a ROSTERED member always. An unseated joiner is never in the roster, so no beacon ever names a relay for it and an individual type-2 join is deduped and dropped, never forwarded. The aggregate path plus the sized swarm request is a distant joiner's only route up. Related: exactly one relayForId/relayById pair exists per beacon, so MemberPkt.hops cannot reach 2 under exclusive-grant; 1 is the ceiling, not a shortfall. (6) LSM_NMEA_ECHO serial-only raw NMEA passthrough, default 0. CHUNK 2 makes the EXISTING v7.28.5 birth frame reachable; it does not build a second one. Source audit found the birth frame, the SF_TYPE_JOIN all-slots-are-join-windows schedule, the MEMBER_TYPE_SWARM_REQ wire type with its conf64 window count, and the entire keeper-side rate limit (BIRTH_COOLDOWN_FRAMES, BIRTH_TAPER_COOLDOWN, BIRTH_EMPTY_RUNS_MAX, rival debounce) already present and already firing: the v7.28.100 seven-board walk shows nine birth frames armed on node 01. (7) FUNNEL ASK. memberSendSwarmReq took no argument and hardcoded conf64=1, and its only caller was the v7.28.6 resigned-keeper failover, so g_swarmReqCount never exceeded 1 and a demand-armed birth frame opened exactly ONE window no matter how many joiners were queued behind a relay. It now takes a window count, and a relaying member emits it once per frame sized to its real g_aggN cache, beside the aggFlush drain that already passes the same gate. Every limit stays on the TK, so a stuck or spoofed funnel still cannot hold the sphere in birth mode. The failover caller is explicitly passed 1 and is behaviourally unchanged. (8) DEPTH-STRICT PROXY. The aggregate re-aggregation gate tested only a ceiling (inHops+1 <= g_schedTiers), which says nothing about direction, so two peers at EQUAL depth each re-aggregated the other's joiner records and the same ids ping-ponged sideways forever instead of climbing toward the keeper. Now also requires inHops > g_anchorHops+1, i.e. the sender must be STRICTLY deeper than this node; equal depth is refused, and a node with no adopted schedule does not re-aggregate at all. (9) PEEL BIRTH GRACE. PEEL_BIRTH_GRACE_MS 30000: a board admitted in a birth frame has almost no home RSSI samples, so one strong foreign beacon could peel it straight back off the roster it just joined, which is worst-case for exactly the edge burst the birth frame exists to admit. g_admittedMs latches the unslotted-to-slotted edge and the gate sits AFTER target selection so the averages keep accumulating per-keeper and only the ACTION is suppressed; stage 10 witnesses a held-off knock. Delays a peel, never prevents one. (10) LOG_MESH 30, the dedicated relay measurement record, its own type rather than overloaded onto LOG_TOPO: aux = deepest hops seen this second, e = relayForId, n = relayById, data = orphan count | cached joiners << 8 | windows asked << 16 | own depth << 24. g_orphanSeen is counted on volPick's existing slot walk at no extra cost and its round-robin pick is unchanged. No wire change, WIRE_VER stays 33. PREVIOUSLY v7.28.94: LILYGO BUILD BREAK plus V4 RADIO -2 FIX, both from one mangled conditional introduced by the v7.28.92 V4 restore. The board-pin chain had the LilyGO LoRa block (PIN_LORA_NSS 7, SCK 18, MOSI 17, MISO 8, RST 10, BUSY 46, DIO1 40, PIN_RT9080_EN 42) trapped inside the FIRST #elif defined(LSM_BOARD_V4) branch, with a SECOND, unreachable #elif defined(LSM_BOARD_V4) holding the real V4 SX1262 pins. Consequences: a LilyGO build never compiled its own LoRa pins so PIN_LORA_NSS and friends were undeclared and the whole LilyGO variant failed to build (it was frozen on old firmware); and a V4 build silently took the first V4 branch and drove its SX1262 on the LilyGO LR1121 pins, so SPI addressed the wrong GPIOs and the radio never answered, which is the SX1262 begin -2 observed on board 21. FIX: re-sorted the chain into three complete branches (LilyGO TFT plus LR1121 plus RT9080; V4 OLED plus V4 SX1262; v2 TFT plus v2 SX1262) and removed the now-needless #undef PIN_RT9080_EN. SOURCE PIN MAP ONLY, no wire change, no logic change, WIRE_VER 31. Verified with the C preprocessor for all three -D variants: every LoRa pin resolves exactly once with the correct value and no duplicate symbols; LilyGO LR1121 pins and RT9080 EN 42 cross-checked against the LilyGO T-Display-S3-Pro-MVSRLora vendor README. Folder scheme moved to folder-number-equals-NODE_ID per Stuart: v2 node_01 to node_13, v4 node_21 to node_29, lilygo node_31 and node_32; role suffixes dropped so the folder name carries the ID and nothing else. Retained unchanged: v7.28.93 fleet ID blocks, v7.28.92 V4 display restore, v7.28.91 RX arm witness, listen-only gate and relay flood clear. // v7.28.93: FLEET ID RENUMBER per Stuart 2026-09-19. Node IDs are now allocated in fixed per-hardware blocks so the number tells you the hardware and each variant has room to grow: heltec v2 owns 1 to 20 (13 boards in use, 1 to 13, node 01 weighted keeper), heltec v4 owns 21 to 30 (9 boards in use, 21 to 29), lilygo owns 31 to 40 (2 boards in use, 31 and 32). Previously v4 sat at 17 to 25 and lilygo at 15 and 16, which interleaved the variants and left no growth room above the v2 block. SOURCE CONSTANT CHANGE ONLY: NODE_ID per board. No wire change, no logic change, WIRE_VER 31, and the V4 display restore from v7.28.92 plus the v7.28.91 RX arm witness, listen only gate and relay flood clear are all retained unchanged. NOTE: the wire still truncates node id to 8 bits, so these blocks are valid only below 256; the 16 bit widening for the 14,000 node target is a separate future cut. // v7.28.92: V4 DISPLAY RESTORE - the nine Heltec V4 boards lost their entire display and radio support in the v7.28.86 listen-only witness lineage, which stripped the #elif defined(LSM_BOARD_V4) branches when it removed the bench guards; v7.28.87 through 91 all shipped with V4 dark (no OLED power rail, no I2C pins, wrong LoRa pins - the boards would not power up a screen). Restored verbatim from proven v7.28.87 source: the SSD1306/GFX includes and ST77XX colour aliases, VEXT on GPIO36 (active-low OLED rail), the OLED I2C pins 17/18 with reset 21, the V4 SX1262 pin set, the buffered SSD1306 display object with its 50ms-timeout init and 128x64 brand/version/badge splash, the tft.display() flush after every repaint, and the #ifndef LSM_BOARD_V4 guard that skips the shared ST7735 splash on V4. No wire change and no functional change to v2 or lilygo. Every v7.28.91 change retained unchanged: the LOG_RXARM RX-arm latency witness, the listen-only LSM_TX gate, and the relay flood suppression clear. WIRE_VER 31. // v7.28.91: RX ARM LATENCY WITNESS (LOG_RXARM 28). Measures the tx->rx turnaround dead window (standby to armed) and the bare startReceive command cost, emitted 1-in-16 on the txDoneWitness gate like LOG_TXLAT. MEASURE-ONLY, no delay added or grown (the settle-delay theory was graded FAIL in v7.28.40/41). Purpose: see whether RX_ARM_SETTLE_US 100us is realistic and how much receive dead time exists after each transmit. // v7.28.90: build fix only - removed an orphan #endif left in the source when the v7.28.86 witness variant stripped the LSM_BENCH_FORCE_TIERS bench guards; no functional change from v7.28.89, which never compiled. v7.28.89: relay flood suppression reset - g_schedFloodRelayed cleared on a new beacon seq so suppression fires again on every sequence (was 116 relays of one beacon in the v7.28.88 walk). // v7.28.87: V4 SSD1306 buffered-display fix - flush after every repaint plus a 128x64 brand/version/badge splash; only the nine V4 boards changed functionally, v2 and lilygo carry the version bump only. Full description in the build note. // v7.28.78-sf7: SF7 RECEIVE LEVER plus the free three-stage detection witness, per Stuart 2026-09-17. TWO source changes, no fire-path touch. (1) LORA_SF 5 -> 7. The four-board v7.28.77 stay-on-listen flight graded 37.1 percent keeper member-slot loss over 1342 frames (node 2 36.7, node 3 37.5, witness node 12 38.9), no improvement on the 28 percent three-board baseline, and the two receivers still miss independently (neither 23 percent observed vs 14 to 15 predicted). The re-arm removal did execute (aux 19 e nonzero, 3487 clean no-rearm services on the keeper) and the after-clean vs after-empty slot-loss gap collapsed from the bench 34 vs 27 to 33.5 vs 31.6, which proves the demodulator restart it removed was NOT the cost. The loss that remains is the memoryless per-packet floor a short preamble and no processing gain would produce. SF7 gives an 8.19 ms floored preamble against 3.07 ms at SF5 and about 15 dB more effective sensitivity from spreading gain. All geometry, airtime and the 8-symbol preamble floor re-derive through LSM_ACTIVE_SF; member airtime is 71936 us, beacon(22) 118016 us; the SF7 reference static_asserts pass unchanged. symbvalid stays 0 (build flag), safe at SF7. (2) PREAMBLE_DETECTED added to the LATCHED IRQ flag mask in lsmRxArm, DIO1 mask untouched, so preamble-seen and header-valid now ride in the irqW word the aux 10 (read fail) and aux 11 (header abort) witnesses already log, at zero timing cost. Every serviced slot now names the stage it reached: preamble, header, CRC. A clean receive (LOG_RX) is a three-stage pass by definition. NOT DONE, by decision with Stuart: a fully silent slot (no DIO event) is still not attributed, because witnessing it needs a per-slot IRQ register poll on the receive path, which would perturb the very timing this build measures (flash-stall guardrail); held as a separate edge-to-polled receive build only if SF7 disappoints. Exact IRQ-overrun count is held for the same reason; the possible-overrun window (IRQ-to-service latency over one slot) remains available from the RF8 latency instrument. Real per-packet rssi and quarter-dB snrRaw are UNCHANGED: the v7.13.3 triple-read race-retry path already captures them on every clean receive; the sub-metre -35 dBm readings are a loud bench, not a clamp (int8 field floors at -128). Per-member CRC attribution is done in the grader from the frame offset the aux 10 witness already stamps, no firmware change. WIRE_VER 31, wire format, slot guard, LSM_RX_STAY 1, encryption, the 30 s watchdog and NODE_ID per board all unchanged from v7.28.77. Numbers to beat, four-board same geometry with node 12 as witness: 37.1 percent keeper loss, 38.9 percent witness loss; target 5 to 10 percent. Grade LOG_RF aux 19 FIRST to confirm the receive path is live, then the three-stage bits on aux 10 and aux 11. Previously v7.28.77-stayonlisten: STAY ON LISTEN per Stuart 2026-09-17, one variable. After a clean receive radioPoll no longer issues startReceive; it clears the IRQ register (DIO1 needs the flag down) and leaves the chip in the continuous receive it was already armed into, gated by LSM_RX_STAY (default 1, 0 compiles the v7.28.75 trailing re-arm back). The header abort re-arm is also OFF again (-D LSM_ABORT_REARM removed) so an abort clears the IRQ only, the v7.28.72 path; that path executed zero times in the v72/v73 deaf flights so it is unimplicated in that regression, and the v74 revert was a precaution not a finding. Why: the v7.28.76 eleven-board sub-metre bench with node 12 as raw-air witness graded 38.6 percent keeper loss and 43.3 percent witness loss over 14,690 member slots, memoryless, statistically independent between the two receivers (neither 16.3 percent observed vs 16.7 predicted), growing with member count (28 percent at three boards). Every architectural theory is dead. The source shows each slot is airtime plus SLOT_GUARD_US 800 with a 12 symbol 3.1 ms SF5 preamble, and a full startReceive restarting the demodulator after every packet and every abort; the witness shows the slot after a clean packet lost 34 percent against 27 percent after an empty slot, the restart cost. Main-loop stalls were checked and REFUTED from the capture: seconds with the longest loop passes hear as many packets as quiet seconds and the loss has no run structure. Instrumentation defect on record, not fixed here: g_irqOverrun cannot count a second packet while the first flag is unserviced, since DIO1 is level-held and RadioLib attaches a rising edge. New witness LOG_RF aux 19 once per second: e = clean receives serviced without a re-arm this second, n = header aborts serviced without a re-arm this second, data = cumulative clean no-rearm count; if aux 19 e sits at zero the new path did not execute and the build must not be graded as if it had. The 30 s receiver watchdog in houseTick is unchanged and remains the safety net. Preamble length (LSM_PRE_MS 3), slot pitch, WIRE_VER 31, wire format and NODE_ID per board unchanged from v7.28.75. Previously v7.28.75-rawposition: RAW POSITION per Stuart 2026-09-16, the dots did not track the ground. Root cause: posFusionUpdate re-centered the origin toward every fix (alpha 0.52 to 1.0 at 10 Hz) and reported the residual, so motion was absorbed into the origin the dashboard never sees while the offset it does see stayed near zero; the dashboard plots seed plus offset and the seed only refreshed every SEED_RESEND_MS (2.5 min), so a moving node sat at its old seed and jumped on the next burst. Fix: origin is HELD once locked, offset = raw fix minus the held origin at every 100 ms pull, velocity EMA replaced by raw fix-to-fix velocity (alpha 1). The origin re-centers only when the offset exceeds RECENTER_CM (25000 cm, 250 m, inside the int16 cm field limit of 327 m), and a re-center immediately queues a BLE seed and re-arms the over-air seed burst so every listener learns the new origin. Second fix, same cut: the connected board queues its OWN seed over BLE at lock, at re-center and every BLE_SELF_SEED_MS (10 s) from houseTick, for ANY role. Before, the only self-seed path lived inside the member slot block (g_role==1), so a timekeeper never sent its own seed and the dashboard showed it as on mesh no fix (node 01 keeper, v43 outdoor). SPHERE_CAP opened from 5 to 200 on all boards for the twelve-board spoke test (FULL_LINE 4 -> 160). WIRE_VER 31, wire format and slot geometry unchanged. Previously v7.28.74-symbvalid-off: SetLoRaSymbNumTimeout DISABLED (-D LSM_RX_SYMB_VALID=0) and header abort re-arm RESTORED (-D LSM_ABORT_REARM), returning the receive path to the proven v7.28.71 behavior. Cut after grading the v7.28.72 (8 symbols) and v7.28.73 (2 symbols) hardware flights from the raw dumps: LOG_RX ZERO on all four boards both flights, TX healthy and spanning the full run, LOG_RF aux 18 cumulative timeouts climbing monotonically the whole run (v73 23/65/116/351, v72 1973/2059/2165/3668), aux 18 no-rearm-abort field ZERO in every record, ZERO LOG_RF aux 11 header-abort witnesses on all eight dumps. The removed-re-arm path (change 3) executed zero times so it is not the cause, and a timeout count climbing all run proves the receiver was alive and re-arming, not parked. The only change common to both deaf builds and absent from proven-good v7.28.71 is that SetLoRaSymbNumTimeout is issued at all; the count value 8 vs 2 is not the discriminator since both went deaf. Does NOT address the original SF5 one-in-three uplink loss, a separate older problem. Feature ON at 2 with re-arm still reverted is held for v7.28.75 as the isolated confirmation flight, one flag delta from this build. WIRE_VER 31, slot geometry, wire format and NODE_ID per board unchanged from v7.28.73. Previously v7.28.73-symbvalid2: LSM_RX_SYMB_VALID DEFAULT 8 -> 2 per Stuart 2026-09-16, after the first hardware flight of v7.28.72 graded TOTAL RECEIVE DEAFNESS on all four boards: staggered bring-up into a sphere with a live keeper, every board self-elected timekeeper, four one-board networks. Capture evidence: LOG_RF aux 17 shows the command applied cleanly on all four (symbols=8, status=0, cmd byte 0x08, reg 0x0706 written 0x20), and LOG_RX record count is ZERO on all four across the full run, with aux 18 cumulative timeouts climbing at about 3 per second and no-rearm aborts at 0. The modem armed, waited for 8 symbols that never resolved, and timed out, every time. Reading: the receiver is armed at slot boundaries and therefore mid-preamble, so it cannot be promised 8 of the 12 transmitted symbols; the preamble-minus-4 cap is necessary but not sufficient. 2 keeps rejection of single-symbol noise latches while leaving 10 symbols of arming margin. NOT YET PROVEN: whether the original SF5 uplink loss was in fact caused by the reset value 0 - the v7.28.72 flight produced no receptions at all, so it neither confirmed nor refuted that root cause. The A/B bench (0 versus 2) is still the test that settles it. Nothing on the wire moves, WIRE_VER stays 31, slot geometry untouched. Previously v7.28.72-symbvalid: RECEIVER PREAMBLE VALIDATION, the uplink loss cut. SetLoRaSymbNumTimeout issued in radioConfig at LSM_RX_SYMB_VALID (8 at SF5, derived from the preamble rule, cap preamble minus 4); RadioLib 6.6.0 and 7.1.2 never issue it so every arm ran at the chip reset value 0, single-symbol validation. Header abort no longer does a full startReceive (IRQ clear only, LSM_ABORT_REARM restores). TIMEOUT routed to DIO1 and serviced with a re-arm. New witnesses: LOG_RF aux 17 at config (e symbols, n status, data SF | cmd byte << 8 | reg 0x0706 << 16), aux 18 per second (e timeouts, n no-rearm aborts, data cumulative timeouts). Bench A/B is -D LSM_RX_SYMB_VALID=0 versus the default; nothing on the wire moves, WIRE_VER stays 31, slot geometry untouched. Root cause file: 2026-09-16 ten-board outdoor capture, flat memoryless one-in-three uplink loss at SF5, 52 to 73 percent silent at the keeper, independent of slot, occupancy, timing, range, power and keeper load, header aborts at 0.5 to 0.9 per second in quiet air. Previously v7.28.71-asyncflush: the blocking LittleFS write moved off the mesh loop to a writer task on core 0, sized from the 2026-09-16 beach capture where a 60 ms median flush (233 to 313 ms at p95 and max) did not fit the 40 ms tail of a 390 ms four-board frame and overran into the next frame's member slots on 37 to 39 percent of flushes. Pool of 3 buffers, drops counted in g_fsDropped not silent, write frequency and flash wear unchanged, LSM_ASYNC_FLUSH 0 compiles back to the proven synchronous path. RESIDUAL, not fixed here: an internal flash sector erase disables the instruction cache across BOTH cores, so a badly timed erase can still stall the flash-resident RadioLib transmit path on core 1; full immunity needs the fire path plus RadioLib and the SPI driver in IRAM, rejected on this rig as a two-library fork for a chip not shipping. See the flash-stall guardrail. Previously v7.28.70-absposbranch: FW_PATCH bumped off 69 so a board stops reporting V7.28.69 while it is actually running the branch (WIRE_VER 31, TXLAT and RXABS records present); the stale string cost real time reading the 2026-09-16 beach capture. Previously v7.28.69-satgate-noflood: removed the per-loop LOG_GPS debug line (v7.28.67-gps-debug) that wrote a flash record every loop pass and flooded the log ring, forcing mid-frame flushes; 1/sec LOG_GPS at the tick remains. Sat gate unchanged. Previously v7.28.68-sat-gate: MIN_SATS_TX 3 gate on GPS ingest, position packet, seed burst, BLE raw feed, and receive-side fusion per Stuart 2026-09-15. Previously v7.28.67-gps-debug: PRODUCTION NODE_ID SCALED TO 14,000+ per Stuart 2026-09-15. NODE_ID changed from uint32_t to uint16_t (0-65535), supporting 14,000+ nodes in production. C1 command center weighted (NODE_ID 200). WIRE_VER stays 30. Previously v7.28.66: POSITION LOGGING + SNAPPY FUSION + SPHERE 200 per Stuart 2026-09-15.
// v7.28.59 tail token slot geometry and enforcement switch
#ifndef CTOK_ENFORCE
#define CTOK_ENFORCE 1          // 1: a FAIL verdict refuses the packet and repeated failures evict. 0: observe and log only. Set in platformio.ini.
#endif
static const uint32_t TOK_WIRE_MAX_B = 75u;   // KsRevokeWire, the largest tail-slot packet (CtokWire is 37); asserted against sizeof below
static const uint32_t TOK_SLOT_US = lsmLoraAirUs(TOK_WIRE_MAX_B+MESH_SEC_OVERHEAD, LSM_ACTIVE_SF, LSM_ACTIVE_BW, (uint8_t)(LORA_CR - 4)) + 2u*SLOT_GUARD_US;
static uint32_t g_tokSlotUsLive = TOK_SLOT_US;
  // Removed the v7.10.9 random join-backoff window and its any-roster-growth
  // reset (g_joinBackoffUntil, g_seenJoinThisCycle). That reset fired on ANY
  // node joining anywhere, not just a collision near this node's own turn, so
  // during sustained roster churn (a mass reboot/reflash, or repeated
  // evictions and rejoins) a stuck node's window could be cancelled and
  // rearmed indefinitely. Confirmed on the bench: two independent flash logs
  // showed a node hearing the TK's beacon every frame the whole time yet
  // stuck in LISTEN for 157 seconds and, in a worse case, over 11 minutes.
  // New behavior: every eligible frame, if the deterministic modulus says
  // it is this node's turn, just attempt the join, exactly like a node
  // would on the very first beacon it ever hears. The modulus already
  // prevents simultaneous joiners from colliding, and joinModEffective's
  // adaptive widening already spreads out heavy overheard join traffic
  // mesh-wide; neither of those needed a second, separate backoff layer on
  // top. After JOIN_MAX_ATTEMPTS consecutive failed attempts at its own
  // turn, the node gives up on whatever got it this far and resets its
  // attempt counter, so the next eligible frame is tried exactly like a
  // fresh cold boot, no special state carried forward (g_tkId is already
  // refreshed from every heard beacon regardless of role, so there is
  // nothing else to clear). No wire change (15).
static const uint8_t  BATTERY_PCT = 100; // placeholder. Real Vbat read is a TODO
                                         // (ADC on GPIO1, divider enable on GPIO37).
static const int8_t   FLOOR_LEVEL = 0;   // ground
// v7.28.9 election tuning.
static const bool     CENTRAL_ENABLED = false;  // positional centrality held at zero (needs UWB/MEMS); computation kept, flip to re-enable
static const uint8_t  BATT_LOW_PCT    = 25;     // battery penalty floor; nothing above this level
static const int32_t  BATT_W          = 2;      // points per percent below the floor, light so battery only breaks ties
volatile uint8_t      g_battPctSmooth = 100;    // slow-averaged battery percent the election reads (init full; updated 1/s by battService)
// v7.28.70 daisy hop/relay depth test: the node id weighted to WIN keeper and
// root the relay ladder, so the chain has a fixed anchor to build back toward.
// Bench test aid, keyed to a node id, NOT a command-center role. Set DAISY_ROOT_ID
// to 0 to disable and return to a pure merit election. The weight dominates every
// other election term (RSSI health tops near +240, hop penalty is 25/hop, the
// handoff margin is 750), so the root wins from cold boot and never yields.
// Field builds use the normal deterministic election. A nonzero value is only
// for an explicitly controlled daisy-chain bench fixture.
#ifndef LSM_DAISY_ROOT_ID
#define LSM_DAISY_ROOT_ID 0
#endif
static const uint16_t DAISY_ROOT_ID     = LSM_DAISY_ROOT_ID;
static const int32_t  DAISY_ROOT_WEIGHT = 10000;
// v7.29.0 COMMAND-CENTER CASCADE, SOURCE ONLY, default OFF. Enable per board with
// -D LSM_CMDCTR_CASCADE. When defined, NODE_ID 200..203 (C1..C4) carry a descending election
// weight so a designated command board wins keeper: C1 200 -> +10000, C2 201 -> +9000,
// C3 202 -> +8000, C4 203 -> +7000. Left undefined on the 01..13 field fleet so it never
// perturbs the DAISY_ROOT_ID=1 TK lock this fleet elects on; 01 stays the only weighted board.
static const int32_t  CMDCTR_WEIGHT_C1   = 10000;   // C1 (NODE_ID 200) election bonus
static const int32_t  CMDCTR_WEIGHT_STEP = 1000;    // each lower rank C2..C4 drops one step
static const uint16_t CMDCTR_ID_BASE     = 200;     // C1..C4 = 200..203
static const uint16_t CMDCTR_ID_TOP      = 203;
// v7.29.0 ROTATION GUARANTEE flag, ON for the first flight. -D LSM_ROTATE_GUARANTEE=0 compiles it out.
#ifndef LSM_ROTATE_GUARANTEE
#define LSM_ROTATE_GUARANTEE 1
#endif
#ifndef LSM_RELAY_PLEA
#define LSM_RELAY_PLEA 1        // v7.29.3: source default, same shape as rotate. 1: relay plea compiled in. 0: compiled out. Before this the flag lived only in platformio.ini and every guard was #ifdef, so a board built without the -D line silently lost the plea, and -D LSM_RELAY_PLEA=0 did NOT compile it out (a macro defined to 0 is still defined). All seven guards are now #if, so the default and the off switch are both real.
#endif
#ifndef LSM_PLEA_MINT
#define LSM_PLEA_MINT 0         // v7.29.3: 0 (default): a plea frame skips the crystal-tag mint and the departure attestation. ctokTkVerify returns true for any type but 0 and 6, so the keeper never reads them for type 8 and minting was dead compute. The fields are part of the shared MemberPkt shape, so the packet is the same size either way. 1: restore the v7.29.1 minting for an A/B; gated on its own so a bisect can tell this change apart from the rest of 29.3.
#endif
static char           BADGE_NUM[4] = "00"; // large print badge number on the TFT; filled from NODE_ID in setup() (ctok 2026-07-21 identity fix)
#define IS_COMMAND_CENTER 1   // v6.0: all nodes carry gateway+TK code; role is runtime                  // this badge relays peer positions to the dashboard

// ----------------------- LSMESH GATT UUIDs (must match the dashboard) -----------------------
static const char* SVC_UUID  = "4b410001-5253-4849-454c-440000000000";
static const char* CPOS_UUID = "4b410002-5253-4849-454c-440000000000"; // position notify
static const char* CMRK_UUID = "4b410003-5253-4849-454c-440000000000"; // mark notify
static const char* CINF_UUID = "4b410006-5253-4849-454c-440000000000"; // info read
static const char* CDIA_UUID = "4b410007-5253-4849-454c-440000000000"; // diagnostics notify
static const char* CLOG_UUID = "4b410008-5253-4849-454c-440000000000"; // flash log control and dump
static const char* CSEED_UUID = "4b410009-5253-4849-454c-440000000000"; // v7.2: absolute seed notify, self and assembled peers

// CINF returns this badge node id so the dashboard pins it as the frame origin.
// this board to the operator as the frame origin (see frame note above).
static const uint16_t SELF_ID = NODE_ID;  // v5.6: report real id so the dashboard pins this badge as the frame origin

// ----------------------- little-endian packers -----------------------
static inline void put_u32(uint8_t* p, uint32_t v) { p[0]=v; p[1]=v>>8; p[2]=v>>16; p[3]=v>>24; }
static inline void put_u16(uint8_t* p, uint16_t v) { p[0]=v; p[1]=v>>8; }
static inline void put_i16(uint8_t* p, int16_t v)  { uint16_t u=(uint16_t)v; p[0]=u; p[1]=u>>8; }

// ----------------------- globals -----------------------
TinyGPSPlus gps;
HardwareSerial GNSS(1);

// ------------- v7.20.23: NMEA sentence health tally -------------
// The GPS is a free running UART source and the loop already drains it into
// TinyGPS one byte at a time, but nothing ever graded those bytes. A board
// reporting sats=0 with a climbing character counter was therefore ambiguous
// between three completely different faults: a wiring or baud error mangling
// the bytes, a module that is simply cold and has no almanac yet, and an
// antenna with no view of the sky. Every drained byte now also passes through
// a sentence state machine that frames on the dollar sign, accumulates the
// NMEA checksum across the body, and closes on the star plus two hex digits.
// Counters are kept, not stored text: one corrupt sentence proves nothing,
// while a pass to fail ratio over a one second window is a trend and answers
// the question. The counters reset every window in gpsTallyTake().
#define NMEA_MAX 84          // 82 characters per NMEA 0183, plus a terminator
static char     g_nmBuf[NMEA_MAX];
static uint8_t  g_nmLen   = 0;
static uint8_t  g_nmXor   = 0;
static uint8_t  g_nmState = 0;   // 0 idle, 1 body, 2 want hex1, 3 want hex2, 4 graded
static uint8_t  g_nmCk    = 0;
static uint16_t g_nmPass = 0, g_nmFail = 0, g_nmTrunc = 0, g_nmBytes = 0;
static uint8_t  g_nmTypes = 0;
static char     g_nmLastBad[NMEA_MAX];   // one slot only, the most recent failure
static bool     g_nmHaveBad = false;
static uint16_t g_nmShowPass = 0, g_nmShowFail = 0, g_nmShowTrunc = 0;  // last window, for the serial line

static inline int nmHex(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  return -1;
}

// One bit per sentence type, so a single byte records which of the usual set
// appeared in the window. A module emitting only GSV and no GGA is searching;
// one emitting nothing recognisable is not speaking NMEA at this baud.
static inline uint8_t nmTypeBit(const char* s, uint8_t len) {
  if (len < 6) return 0;      // dollar sign plus five identifier characters
  const char* t = s + 3;      // skip the dollar sign and the two char talker id
  if (!memcmp(t, "GGA", 3)) return 0x01;
  if (!memcmp(t, "RMC", 3)) return 0x02;
  if (!memcmp(t, "GSA", 3)) return 0x04;
  if (!memcmp(t, "GSV", 3)) return 0x08;
  if (!memcmp(t, "VTG", 3)) return 0x10;
  if (!memcmp(t, "GLL", 3)) return 0x20;
  if (!memcmp(t, "ZDA", 3)) return 0x40;
  return 0x80;                // anything else, TXT included
}

static inline void nmReset() { g_nmLen = 0; g_nmXor = 0; g_nmState = 0; g_nmCk = 0; }

// Fed exactly one byte per drained character. Never blocks, never allocates,
// touches no mesh or timing state. Runs in loop() context only, same as the
// drain itself, so no critical section is needed around the counters.
static void nmeaTally(uint8_t c) {
  if (g_nmBytes < 0xFFFF) g_nmBytes++;
  if (c == '$') {
    // A fresh sentence opening while one is still in flight means the
    // previous one was cut off. That is a distinct fault from a bad
    // checksum, so it is counted separately rather than as a failure.
    if (g_nmState != 0 && g_nmState != 4) { if (g_nmTrunc < 0xFFFF) g_nmTrunc++; }
    nmReset();
    g_nmState = 1;
    g_nmBuf[g_nmLen++] = (char)c;
    return;
  }
  if (g_nmState == 0) return;   // stray byte outside any sentence, counted in bytes only
  if (c == '\r' || c == '\n') {
    if (g_nmState != 4) { if (g_nmTrunc < 0xFFFF) g_nmTrunc++; }
    nmReset();
    return;
  }
  if (g_nmLen >= NMEA_MAX - 1) { if (g_nmTrunc < 0xFFFF) g_nmTrunc++; nmReset(); return; }
  g_nmBuf[g_nmLen++] = (char)c;
  if (g_nmState == 1) {
    if (c == '*') { g_nmState = 2; return; }   // the star is excluded from the checksum
    g_nmXor ^= c;
    return;
  }
  if (g_nmState == 2) {
    int h = nmHex((char)c);
    if (h < 0) { if (g_nmTrunc < 0xFFFF) g_nmTrunc++; nmReset(); return; }
    g_nmCk = (uint8_t)(h << 4);
    g_nmState = 3;
    return;
  }
  if (g_nmState == 3) {
    int h = nmHex((char)c);
    if (h < 0) { if (g_nmTrunc < 0xFFFF) g_nmTrunc++; nmReset(); return; }
    g_nmCk = (uint8_t)(g_nmCk | (uint8_t)h);
    g_nmTypes = (uint8_t)(g_nmTypes | nmTypeBit(g_nmBuf, g_nmLen));
    if (g_nmCk == g_nmXor) {
      if (g_nmPass < 0xFFFF) g_nmPass++;
    } else {
      if (g_nmFail < 0xFFFF) g_nmFail++;
      uint8_t n = g_nmLen;
      if (n > NMEA_MAX - 1) n = NMEA_MAX - 1;
      memcpy(g_nmLastBad, g_nmBuf, n);
      g_nmLastBad[n] = 0;
      g_nmHaveBad = true;
    }
    g_nmState = 4;
    return;
  }
  // state 4: graded already, ignore trailing bytes until the terminator
}

// Reads and clears the window. Called once per second from the tick.
static void gpsTallyTake(uint16_t& pass, uint16_t& fail, uint16_t& trunc,
                         uint16_t& bytes, uint8_t& types) {
  pass = g_nmPass; fail = g_nmFail; trunc = g_nmTrunc; bytes = g_nmBytes; types = g_nmTypes;
  g_nmPass = 0; g_nmFail = 0; g_nmTrunc = 0; g_nmBytes = 0; g_nmTypes = 0;
}

NimBLECharacteristic* chPos = nullptr;
NimBLECharacteristic* chSeed = nullptr;   // v7.2: absolute seed notify
NimBLECharacteristic* chMrk = nullptr;
NimBLECharacteristic* chDia = nullptr;

volatile bool g_connected = false;

bool   originSet = false;
double lat0 = 0, lon0 = 0;     // local origin, set on first fix
bool     altOriginSet = false;   // v7.12.6: Z (altitude) origin baseline, separate flag since altitude fix can lag lat/lon
int32_t  alt0 = 0;               // v7.12.6: altitude origin in cm, set alongside lat0/lon0 when available
uint32_t fixSinceMs = 0;       // millis when we first locked a fix

// ---------------------- v6.7 GPS-only fusion ----------------------
#define POS_STALE_MS   2500U
// v7.28.64: fix quality gate. Until this patch any parsed lat/lon locked the
// origin at conf 63, so a three satellite cold sentence became ground truth
// and was seeded to the fleet. A REAL fix needs FIX_SATS_HIGH satellites and
// HDOP at or under FIX_HDOP_HIGH (hundredths; ignored when the receiver has
// not reported HDOP). Weaker parsed fixes are RAW: reported, never trusted.
#define FIX_SATS_HIGH   0U  // v7.28.67-fixed: temporarily lowered to 0 for testing without sat count. GPS driver not reporting satellites correctly. Engineering note in binder.
#define FIX_HDOP_HIGH   250U
// v7.28.101: LSM_NMEA_ECHO, serial-only raw NMEA echo for the GPS gate question.
// Every board in the v7.28.100 walk reported sats=0 on node 06 and the witness while
// nodes 02, 04 and 05 held full-confidence fixes, so the open question is whether the
// module is emitting no GGA at all, emitting GGA with a zero sat count, or emitting
// sentences the parser is rejecting. Only the raw bytes answer that.
// DEFAULT 0 DELIBERATELY: the fleet capture tool reads this same serial console, and a
// 10 Hz raw NMEA stream would drown the fleetlog. Build ONE board with -D LSM_NMEA_ECHO=1
// and monitor it directly; never arm it on a board whose serial log is being captured.
#ifndef LSM_NMEA_ECHO
#define LSM_NMEA_ECHO 0
#endif
#ifndef MIN_SATS_TX
#define MIN_SATS_TX     3U   // v7.29.6: back to 3 per Stuart. This is now an ACQUISITION gate, not a transmit gate: a fresh fix must report at least this many satellites to be adopted as ground truth (posFusionUpdate haveFix, seed burst, BLE, wire fusion). It no longer stops transmit, because v7.29.6 holds the last known position and keeps sending it every granted slot with confidence decaying by age once a board has ever had a real fix, so tightening the gate makes fixes REFRESH less often but never silences a board that already has one. The v7.28.105 relaxation to 1 (so a weak-fix walk could grade position) is superseded now that LOG_POSABS plus hold-last-known give a gradeable walk without it. Compile -D MIN_SATS_TX=1 for the old relaxed gate, or -D MIN_SATS_TX=0 to trust isValid() alone.
#endif
#define POS_CONF_RAW_MAX 3U      // raw conf64 range is 1..3; 4..63 stays real (4 is the existing decay floor)
static bool     g_rawOrigin = false;   // v7.28.64: origin is provisional (set from a raw fix), not real
static uint8_t  g_posState = 0;        // v7.28.64: LOG_POS state, 0 none 1 raw 2 real 3 held
static uint8_t  g_posLogJumpM = 0;     // v7.28.64: reseed jump in metres, reported once then cleared
static inline uint8_t rawConfFrom(uint32_t sats){ return (uint8_t)(sats >= 5U ? 3U : (sats >= 4U ? 2U : 1U)); }
static double   g_posLat = 0, g_posLon = 0;
static float    g_fusE = 0, g_fusN = 0;
static bool     g_posValid = false;
static bool     g_haveRealFix = false;
static uint8_t  g_posConf = 0;
static uint32_t g_satsNow = 0;   // v7.28.68: satellites used from the latest GGA, sampled once per loop
static uint32_t g_posLastGpsMs = 0;

// ----------------------- v7 mesh state -----------------------
volatile uint8_t g_role = 0;   // 0 LISTEN, 1 JOINED, 2 CANDIDATE, 3 TK; all elect
static uint32_t g_candSinceMs = 0;   // v7.29.6: when this board entered CANDIDATE; 0 when not a candidate
static volatile uint8_t g_missedGrants = 0;  // v6.2: schedules heard without our grant
volatile uint8_t g_tkId = 0;
volatile uint8_t g_mySlot = 0xFF;        // slot granted THIS frame, cleared each frame
static uint8_t g_mySlotLastFrame = 0xFF;  // v7.29.4: slot granted in the most recent adopted beacon, never consumed
static uint8_t g_mySlotPrevFrame = 0xFF;  // v7.29.4: the slot BEFORE that, the one this beacon's heardMask is indexed by
volatile uint8_t g_peersHeard = 0;       // distinct peers heard in the last 5 s
uint8_t  g_screenIdx = 0;                // v7.12.12: 0=status,1=info,2=freq, cycles every 5s across 4 screens

// ---- v7.12.26 cold-boot self-tuning slot trim (per-node departure lead) ----
// Each granted-slot TX measures devUs = actual air departure minus scheduled
// slot start. That residual feeds a bounded ring; once a full window of clean
// samples is in, the average is folded into g_trimAdjUs, which shifts the TX
// engage lead so the next departures land on the slot boundary. g_trimAdjUs is
// persisted in /st.bin and reloaded on cold boot, so the badge self-tunes across
// power cycles and tracks slow silicon drift. Wire format is unchanged.
static const int32_t  TRIM_REJECT_US = 300;   // v7.12.28: widened 290 to 300. The cold-boot offset cluster ran to a min near -291, past the old 290 edge, so the board was rejecting some of its own legitimate cold-boot departures right when it needed them to measure the offset. 300 admits that tail and the deeper offsets on worse silicon; post-fold, once corrected toward zero, 300 is still tight enough that only genuine multi-ms spikes fall out. Same band serves the fold average reject and the out-of-window flag.
static const uint16_t TRIM_WINDOW    = 400;   // clean samples per convergence window
static const char*    TRIM_FILE      = "/st.bin";
static const uint32_t TRIM_MAGIC     = 0x53544D31UL;  // 'STM1'
static const uint8_t  TRIM_SLOTS     = 4;     // wear-leveled record slots in /st.bin
int16_t  g_trimAdjUs   = 0;                   // applied lead adj: effective lead = TX_ENGAGE_US + g_trimAdjUs
// v7.28.24: this board's own measured call-to-air transmit latency, the time
// between calling radio.transmit() and the first preamble symbol radiating.
// Measured by bracketing every transmit this board makes, beacon or member
// packet: (return instant - call instant) - airtime. It is learned, never
// assumed, because the v7.12 comment that called it "a small constant
// SPI-load lag" was wrong by a factor of thirty: it is about 8,400 us on this
// radio and it was landing twice in the delay profile. 0 until measured; the
// first transmit after boot is stamped honestly with 0 and radiates late by
// the true latency, the bracket measures that, and the second transmit is
// already corrected. Carried across roles.
static uint32_t g_txLatUs   = 0;
static uint32_t g_txLatSamp = 0;
static uint32_t g_txLatLast = 0;   // v7.28.70-absposbranch: most recent raw engage sample, for LOG_TXLAT
static inline void txLatSample(uint64_t callUs, uint64_t retUs, uint32_t airUs){
  if (retUs <= callUs) return;
  uint64_t blk = retUs - callUs;
  uint32_t lat = blk > (uint64_t)airUs ? (uint32_t)(blk - (uint64_t)airUs) : 0;
  if (lat > 30000U) return;              // a transmit that blocked 30 ms past airtime is an error, not a latency
  g_txLatLast = lat;                      // v7.28.70-absposbranch: raw sample retained for the LOG_TXLAT witness
  if (g_txLatSamp == 0) g_txLatUs = lat;  // first sample sets it outright, latency is stable to ~120 us
  else g_txLatUs = g_txLatUs - (g_txLatUs >> 2) + (lat >> 2);
  if (g_txLatSamp < 0xFFFFFFFF) g_txLatSamp++;
}
int32_t  g_trimRing[TRIM_WINDOW];             // bounded sample ring, no realloc
uint16_t g_trimHead    = 0;                   // ring write pointer
uint16_t g_trimCount   = 0;                   // valid entries, caps at TRIM_WINDOW
int64_t  g_trimSum     = 0;                   // running sum of ring entries
uint32_t g_trimReject  = 0;                   // rejected-sample counter, this session
bool     g_trimLocked  = false;               // convergence fold done this session
volatile uint8_t g_sphereCount = 0;      // v6.6: sphere occupancy from the TK beacon
volatile uint8_t g_sphereFull  = 0;      // v6.6: full flag from the TK beacon
volatile uint8_t g_successor   = 0;      // v6.6: TK-named successor id from the beacon
static uint8_t  g_tkEpoch      = 0;      // v7.29.38: authority generation; incremented on every new keeper tenure
static uint8_t  g_rivalEpoch   = 0;      // v7.29.38: epoch published by the current rival
static bool     g_warmTakeoverPending = false;
static uint8_t  g_standbyRoster[V7_SLOTS_MAX];
static uint8_t  g_standbyRosterN = 0;
static uint16_t  g_missedFrames = 0;     // v6.6: TK own-beacon TX failures, health demote
static uint32_t  g_fullSinceMs  = 0;     // v6.6: TK-side full-flag debounce
static uint32_t  g_belowLineSinceMs = 0; // v7.19.0 brick3: TK-side reopen debounce, wall clock the roster has held UNDER FULL_LINE. Drives the backhaul accepting-returns bit. One authoritative TK clock, not N node clocks.
static bool      g_hardFull = false;     // v7.19.4 tier-2 hard-full latch. Set the INSTANT the roster reaches SPHERE_CAP at any admission site (no debounce, a momentary touch of the cap counts), cleared ONLY when the roster falls back UNDER FULL_LINE. Hysteresis kills flapping at the cap boundary and closes the mass-simultaneous-start window where joiners piled in during the tier-1 debounce. While latched: beacon full bit forced on, joinMod published as 0 (join closed), backhaul full bit forced on, accepting-returns suppressed.
static uint32_t  g_fullBlockedSinceMs = 0; // v6.6: member blocked-by-full spawn timer
static bool      g_spillReq = false;       // v7.19.2: set by electShouldTakeOver on full-lockout expiry, consumed at a loop-level safe point (spillWalkLadder blocks ~3.5 s, never inside the election predicate)
static bool      g_spillFromFull = false;  // v7.28.8: true only when g_spillReq came from the full-lockout arm, so the loop excludes the current (full) rung; the dead-TK re-walk leaves it false and re-lists the current rung
#ifndef SPHERE_CAP
#define SPHERE_CAP 200            // v6.6: roster size at which the TK flags full. Set LOW (e.g. 4) to bench the spawn path.
#endif
#define SPHERE_FULL_HOLD_MS 3000  // v6.6: roster must hold at the cap this long before full is flagged (debounce)

// ---- v7.19.0 brick3: multi-channel spill, channel ladder + full line ----------
// The 3.5 MHz A->backhaul offset was deliberate. The data ladder reuses it: uniform
// 3.5 MHz spacing stepping DOWN from A, so nothing already flashed (A 924.0, backhaul
// 927.5) moves. Guard between adjacent data channels is 3.5 MHz, 28x the 125 kHz
// occupied width. Seven data channels fit the 902-928 band -> 7 spheres x SPHERE_CAP.
// Index 0 is A (the boot/working channel), the rung a node spills FROM toward higher
// index. Backhaul is NOT in this array, it is a separate discovery channel.
static const float LSM_CHAN_LADDER[] = { 924.0f, 920.5f, 917.0f, 913.5f, 910.0f, 906.5f, 903.0f };
#define LSM_CHAN_LADDER_N ((int)(sizeof(LSM_CHAN_LADDER)/sizeof(LSM_CHAN_LADDER[0])))
static_assert(LSM_CHAN_LADDER_N == 7, "channel ladder must be 7 data channels on the 902-928 band");
// FULL_LINE: the TK flags full at roster >= floor(CAP*0.8), a 20 percent cushion, NOT
// at the hard cap. The cushion is what a returning migrant lands in without re-filling
// the sphere, and reopen-line == full-line == FULL_LINE makes migration self-halting.
// 200 -> 160; a cap-4 bench build -> 3.
#define LSM_FULL_LINE ((uint8_t)((SPHERE_CAP * 4) / 5))
static_assert(LSM_FULL_LINE >= 1, "FULL_LINE floored below 1; SPHERE_CAP too small");
volatile bool    g_radioOk    = false;
volatile int16_t g_radioRc    = -999;    // SX1262 init result, shown on failure
volatile uint32_t g_rxCount   = 0;
// ctok 2026-07-21: throughput accounting (all boards), sampled once/second in loop()
static uint32_t g_tputLastMs = 0;
static uint32_t g_tputLastRx = 0;
static uint16_t g_rxPps = 0;      // rx packets/sec over the last 1 s window
static uint32_t g_rxBps = 0;      // rx goodput bytes/sec over the last 1 s window
#ifdef CRYSTAL_TOKEN
// ctok 2026-07-21: token verdict + session counters (token boards only)
static uint32_t g_tokAccept = 0, g_tokReject = 0;
static uint16_t g_tokLastSrc = 0;
static uint8_t  g_tokLastSeq = 0;
static bool     g_tokLastOk  = false;
static bool     g_tokHadVerdict = false;
static bool     g_baseLoggedDone = false;
static uint32_t g_tokMint = 0;   // pairwise tokens minted, member side
#endif

volatile int16_t  g_lastRssi  = 0;
// v7.13.3: RF capture-dropout witness. g_rssiRxTotal counts every accepted
// reception; g_rssiNoCap counts the subset where radio.getRSSI() returned
// exactly 0.0 on BOTH the initial read and the retry. The ratio is the
// dropout rate and is what tells us on the next bench run whether the retry
// actually fixed the capture or merely reduced it.
volatile uint32_t g_rssiRxTotal = 0;
volatile uint32_t g_rssiNoCap   = 0;
volatile uint8_t  g_hopsToCmd = 255;  // v7.28.104: RESERVED for future node-identity / command-hierarchy work. NOT painted on the glass; the glass paints hops to the TK from g_anchorHops. Read ONLY by the election score below, isolated from the display so it cannot confuse a bench grade.
volatile int16_t  g_lastTxErr = 0;
volatile uint64_t g_frameAnchorUs = 0;   // slot-0 instant from the schedule ISR stamp
// v7.21.1 anchor witness state. Written and read by the witness only, never
// by any timing, scheduling or admission path.
static uint64_t g_anchErrandEndUs  = 0;  // esp_timer at the last bhTailErrand() exit
static uint32_t g_anchErrandBlkUs  = 0;  // how long that errand blocked
static uint8_t  g_anchErrandKind   = 0;  // 0 none, 1 transmit piece, 2 listen piece
static uint64_t g_anchPrevAnchorUs = 0;  // previous frame's anchor stamp
static uint32_t g_anchPrevFrameUs  = 0;  // g_frameUs in force at that previous anchor
// v7.21.3 member anchor witness state. Same rule as the block above: written
// and read by the witness only, never by any timing, scheduling or admission
// path. A member stamps its anchor from the schedule beacon it heard, so these
// are the member side counterparts of the three TK fields above.
static uint64_t g_manchPrevAnchorUs = 0;  // previous frame's member anchor stamp
static uint32_t g_manchPrevFrameUs  = 0;  // g_frameUs in force at that previous anchor
static uint32_t g_manchPrevCorrUs   = 0;  // relay correction applied at that previous anchor
static inline int16_t anchClamp(int32_t v){
  if (v >  32767) return  32767;
  if (v < -32768) return -32768;
  return (int16_t)v;
}
volatile bool     g_anchorValid   = false;
volatile bool     g_anchorFresh   = false; // set by handleSched, consumed by frameEngine
volatile bool     g_schedThisFrame = false; // heard THIS frame's schedule, gates the join
volatile uint8_t  g_nSlotsThisFrame = 0;    // v5.4: boundary from the beacon, sets the join window
volatile uint16_t g_lastTxInFrame = 0xFFFF;
static uint8_t  g_parentId = 0;
static uint8_t  g_curSchedSeq = 0;
// v7.23.0 RECEIVE-SIDE SCHEDULE SANITY STATE. The freshness gate needs the
// newest seq this board has seen, tracked apart from g_curSchedSeq (which is
// the seq actually adopted) and g_schedFloodSeq (which is flood dedup). seq is
// the 8-bit frame counter, so every compare against it is wrap-safe signed.
static bool     g_haveSchedSeq  = false; // seeded true on the first schedule reception
static uint8_t  g_schedSeqTk = 0;
static uint8_t  g_maxSchedSeq   = 0;     // newest schedule seq seen, freshness reference
static uint32_t g_schedRejDepth = 0;     // rejected: schedHops above the tier count in force
static uint32_t g_schedRejStale = 0;     // rejected: seq more than one frame behind the newest seen
static uint32_t g_schedRejMag   = 0;     // rejected: anchor correction longer than one frame
static uint32_t g_lastSchedMs = 0;       // wall clock of last schedule heard
static uint64_t g_wrapSampleDueUs = 0;   // v7.28.31: beacon-instant sample due after a wrap, 0 = none
static uint8_t  g_wrapSampleSeq   = 0;   // v7.28.31: last anchored seq at the wrap
static uint32_t g_framesSilent = 0;
static uint32_t g_ent = 0x1234567u ^ ((uint32_t)NODE_ID << 8);  // entropy accumulator
static uint32_t g_seq = 0;
volatile uint32_t g_loraIrqCyc = 0;      // cycle stamp from the radio ISR
// TK arbiter state (compiled everywhere, used by the command center)
static uint8_t  g_roster[V7_MAX_ROSTER];
static const uint8_t TIER_HEADROOM = 0;   // v7.30.0: committed tiers equal observed seated depth; discovery is probed.
static uint8_t  g_seatDepth[V7_MAX_ROSTER];   // v7.28.105: per-entry high-water relay-hop depth of each seated node; floors the tier shrink so the keeper never collapses reach below a node it has already admitted
static uint32_t g_lastAirFr[V7_MAX_ROSTER];
static uint32_t g_lastAirMs[V7_MAX_ROSTER];   // v11.3: wall-clock last-heard, so eviction grace does not shrink under a faster dynamic frame
static uint8_t  g_lastAirSeq[V7_MAX_ROSTER];  // v7.29.17: last source schedule sequence accepted as liveness
static uint8_t  g_lastAirSeqValid[V7_MAX_ROSTER]; // roster-parallel validity; compacted with the entry
static uint8_t  g_missedAirOpp[V7_MAX_ROSTER]; // v7.29.25: consecutive granted DATA slots without authenticated traffic
static uint8_t  g_slotOf[V7_MAX_ROSTER];
// v7.28.21: previous frame's slot map. tkBuildAndSend wipes g_slotOf to 0xFF
// near the top of the frame and does not refill it until the slot builder runs
// much further down, so the relay naming block in between was reading an
// all-0xFF map and skipping every roster entry. The naming block genuinely
// wants the PREVIOUS frame's positions anyway, because g_heardPub is the
// previous frame's heard accumulator indexed by the previous frame's slots.
// Snapshot taken after roster eviction compaction so indices stay aligned.
static uint8_t  g_slotOfPrev[V7_MAX_ROSTER];
static uint8_t  g_lastRelayer[V7_MAX_ROSTER];
static uint32_t g_lastRelayerMs[V7_MAX_ROSTER];
// v7.22.0 RELAY PARENT LATCH, TK side. g_lastRelayer above is overwritten by
// whoever relayed most recently, and the schedule beacon published it raw, so
// the named relay for an unheard member changed as often as the air did.
// Simulated against the v7.21.3 source with three candidates at minus 58,
// minus 60 and minus 75 dBm under 4 dB of per frame fading, the published
// parent changed 53.7 times a minute, and with two near equal candidates 56.8
// times a minute. Every change moves the zero jitter privilege to a different
// board mid stream, which is the boomerang: the member that was about to relay
// stands down, the new one starts from its own jitter, and the copy the TK is
// waiting for arrives a tier later or not at all.
// The latch holds a chosen parent for RELAY_PARENT_HOLD_MS and REFRESHES on
// every copy that arrives through that same parent, so a working path is never
// re-elected while it is working. Sliding rather than fixed expiry on measured
// grounds: fixed expiry still flapped 8.2 times a minute in the same
// simulation because it re-elects on a timer whether or not anything is wrong,
// while the sliding refresh came in at 0.1. A parent that genuinely dies stops
// refreshing and falls out after the hold, which is the only case that should
// cause a change at all.
// v7.28.102 CHUNK 3 ITEM 8: ASYMMETRIC HOLD. The sliding latch above is the ABANDON
// side and it stays long: a parent that has stopped producing falls out only after
// relayParentHoldMs. The ADOPT side is new and short: when a fresh volunteer report
// names a different board for an orphan, and the latched parent has produced no copy
// for PARENT_SWITCH_SILENT_FRAMES frames, switch to the volunteer immediately rather
// than wait out the hold. Cheap to adopt better evidence, expensive to abandon quiet.
// Three frames, not two, on the walk's numbers: at 60 percent per-frame reception
// three consecutive misses on a WORKING link happen about 6 percent of the time, so
// this is the floor below which a good parent gets replaced by chance. The switch
// also needs a live volunteer, which is positive evidence that an alternative exists,
// not mere absence. Under the v7.25.0 exclusive grant the boomerang cost the latch
// note describes is one frame of the new parent starting, not a jitter contest.
#define PARENT_SWITCH_SILENT_FRAMES 3U
#define RELAY_PARENT_HOLD_MS 3000UL   // v7.28.99: now the FLOOR only, not the hold itself.
// v7.28.99: the hold in FRAMES. Two frames is the minimum that covers the real race: a hop-0
// volunteer report lands late in frame N, and the naming walk that consumes it does not run
// until tkBuildAndSend at the start of N+1. One frame is not enough, because seed and name sit
// on opposite ends of the same frame. The 3 s floor exists only so a SHORT frame cannot drop a
// parent in the middle of a burst of copies; it is not a second policy number.
//
// Reads the PUBLISHED frame (g_frameUs, as set by the last beacon compute on the keeper and
// adopted from frameMs10 on a member), so the seeder and the namer see the SAME number. Before
// the first beacon g_frameUs is the 1 s cold default, which yields 2000 ms and the floor takes
// over, so cold start behaves exactly as it did before this cut.
//
// EVERY reader of the hold goes through here. If one site kept the bare 3000UL there would be
// two clocks in the same latch, and 0xEC and 0xEB would disagree about whether a parent was
// (v7.28.101: keeper resignation used to share 0xEC with the volunteer-accepted record, so a
// decoder could not tell a resignation from an admission without reading the n field. 0xEC is
// now volunteer-accepted only; resignation is 0xEE.)
// live at the instant it mattered.
static inline uint32_t relayParentHoldMs(){
  uint32_t twoFrames = (g_frameUs / 1000UL) * 2UL;
  return (twoFrames < RELAY_PARENT_HOLD_MS) ? RELAY_PARENT_HOLD_MS : twoFrames;
}
static uint8_t  g_relayParent[V7_MAX_ROSTER];    // latched relay for this member, 0 = none
static uint32_t g_relayParentMs[V7_MAX_ROSTER];  // millis of last refresh through that parent
static uint8_t  g_relayGrantCursor = 0;          // v7.22.0: rotation cursor, see the beacon builder
static uint8_t  g_heardAccum[8];
static uint8_t  g_heardPub[8];   // v7.28.98: widened with SchedBeacon.heardMask
static uint8_t  g_linkWin = 0;
static uint8_t  g_linkBits = 0;
static uint8_t  g_linkDegraded = 0;
static uint8_t  g_relayAssignedFor = 0;
static uint8_t  g_relayAssignedFor2 = 0;   // v7.28.104: member this board forwards as the SECOND named leg (relayById2 == NODE_ID), 0 = none
#if LSM_RELAY_PLEA
static uint16_t g_pleaSinceHeardFr = 0;    // v7.29.1: frames since an adopted beacon last confirmed us reachable (keeper heard our slot OR a beacon named a relay FOR us). Grows while stranded.
static uint8_t  g_pleaTries        = 0;    // v7.29.1: ladder position, 0 = not pleading, 1 = first plea sent, 2 = second sent (then steady cadence)
static uint16_t g_pleaNextFr       = 0;    // v7.29.1: g_relayFrameCtr value at which the next plea is due
#define PLEA_SEEN_N 64U                    // v7.29.3: was 16. Forward-once dedupe covers only the last PLEA_SEEN_N distinct (src,seq) pairs this board has seen; at 16 a busy forwarder cycled the ring and re-forwarded the same plea. Composite key kept on purpose: seq is a per-sender counter, so keying on seq alone would drop a second pleader that happened to share a seq value and strand it.
static uint8_t  g_pleaSeenSrc[PLEA_SEEN_N]; // v7.29.1: forward-once dedupe ring, pleader ids
static uint8_t  g_pleaSeenSeq[PLEA_SEEN_N]; // v7.29.1: matching seqs
static uint8_t  g_pleaSeenN        = 0;
#endif
static uint8_t  g_relayLastSeq = 0;        // v7.28.104: beacon seq last adopted, advances the dedup frame counter once per frame
static uint32_t g_relayFrameCtr = 0;       // v7.28.104: local frame counter for GUARD 3; direct and relayed copies of one frame share a seq and count once
#define RELAY_FWD_SEEN_N 32   // v7.29.5: 8 -> 32. The volunteer observe step and the grace dedup ask this ring whether a forward of (src, hop) was already made; at 8 it evicted inside a frame with a few volunteers and two stranded nodes, which reads as a collision.
struct RelayFwdSeen { uint32_t frame; uint8_t srcId; uint8_t hop; };
static RelayFwdSeen g_relayFwdSeen[RELAY_FWD_SEEN_N];
static uint8_t g_relayFwdSeenIdx = 0;
// v7.28.104 GUARD 3, per-frame dedup: a board that already armed a forward of (src_id, hop) this frame does not arm it again.
static inline bool relayFwdSeen(uint8_t srcId, uint8_t hop){
  for (int i = 0; i < RELAY_FWD_SEEN_N; i++)
    if (g_relayFwdSeen[i].frame == g_relayFrameCtr && g_relayFwdSeen[i].srcId == srcId && g_relayFwdSeen[i].hop == hop) return true;
  return false;
}
static inline void relayFwdNote(uint8_t srcId, uint8_t hop){
  g_relayFwdSeen[g_relayFwdSeenIdx].frame = g_relayFrameCtr; g_relayFwdSeen[g_relayFwdSeenIdx].srcId = srcId; g_relayFwdSeen[g_relayFwdSeenIdx].hop = hop;
  g_relayFwdSeenIdx = (uint8_t)((g_relayFwdSeenIdx + 1) % RELAY_FWD_SEEN_N);
}

// v7.29.9 VOLUNTEER RELAY PHASE 1 HARDENING
// GATE 2: per-neighbor dedup (srcId, relayerId, hop triplet, 16 slots, oldest-first eviction)
// GATE 3: claim TTL with AND-guard (cooldown AND TTL must both pass, wraparound-safe signed int8)
// HARDENING 1: claim table cap (8 live claims per node, oldest-first eviction)
// HARDENING 2: re-arm cooldown (4 sequences, atomic death+cooldown_expiry recording)
// HARDENING 3: keeper-side fleet budget (soft 32, hard 64 claims, FLUSH_CLAIMS broadcast)

static VolClaim     g_volClaims[VOL_CARRY_N];        // per-node claim table, max 8 live claims
static VolCooldown  g_volCooldowns[VOL_CARRY_N];     // per-node cooldown table, one per potential claim
static VolDedupEntry g_volDedup[VOL_DEDUP_N];       // per-node dedup table, 16 slots for (src, relayer, hop)
static uint8_t      g_volClaimCount = 0;             // live claim count on this node

// Keeper-side only (NODE_ID == 1): fleet-wide claim budget
// v7.29.12: the g_volFleetMetric declaration that sat here named a type (VolFleetMetric)
// that was never written. It only compiled because #if NODE_ID == 1 was always false.
// Removed; the fleet budget is Phase 3. Note for Phase 3: the keeper is ELECTED, so the
// budget must key on g_role, not on NODE_ID == 1.

static uint8_t  g_quar[V7_MAX_ROSTER];      // v5.3: frames of convergence quarantine left
// v7.28.59 per-member crystal token state, parallel to g_roster, compacted by tkRosterDrop
static uint8_t  g_ctFail[V7_MAX_ROSTER];        // consecutive FAIL verdicts
static uint32_t g_ctRefreshFr[V7_MAX_ROSTER];   // frame of the last fingerprint absorbed from this member; 0 = never (UNKNOWN)
static uint32_t g_ctAdmitMs[V7_MAX_ROSTER];     // admission wall clock, prove window
static uint8_t  g_ctSilent[V7_MAX_ROSTER];      // tail grants this member answered with nothing
static uint32_t g_ctNotReadyFr[V7_MAX_ROSTER];  // frame of the last NOT READY reply (baseline still baking), grant backoff
static uint8_t  g_ctSideReq[V7_MAX_ROSTER];     // last side-channel request byte heard from this member on a hop-0 packet
static uint32_t g_ctLastGrantFr[V7_MAX_ROSTER]; // frame of the last tail grant to this member
static uint8_t  g_ctPassed[V7_MAX_ROSTER];      // 1 once a PASS verdict has been seen this tenure
static uint32_t g_ctDirectMs[V7_MAX_ROSTER];    // wall clock of the last hop-0 packet from this member, 0 = never heard direct
// member side of the tail token slot, read in handleSched (declared here because handleSched precedes the token block)
static bool     g_tokGrantMe      = false;   // member: this frame's tail slot is ours
static uint8_t  g_tokNSlots       = 0;       // member: nSlots off the beacon that granted us, sizes the slot start
static uint8_t  g_lastRelayForId  = 0;       // v7.28.101: relayForId from the last named grant, for the LOG_MESH witness
static uint8_t  g_lastRelayById   = 0;       // v7.28.101: relayById from that same grant
static uint8_t  g_meshDeepHops    = 0;       // v7.28.101: deepest MemberPkt.hops seen since the last LOG_MESH emit. Separate from g_obsDepth, which the tier policy consumes and zeroes every frame.
static bool     g_tokRelayMe      = false;   // member: this frame names us relayById and a tail grant exists, so we forward the tail packet we hear
static uint8_t  g_tokRelayRaw[80];           // the copy to forward, hops and relayerId rewritten, crc redone
static uint8_t  g_tokRelayLen     = 0;       // 0 = nothing armed
static uint8_t  g_tokExtSlots     = 0;       // keeper: tail sub-slots this frame, 0 1 or 2
// v5.9: per-node latency PROFILE. The TK learns each node's characteristic
// receipt-to-air latency signature and schedules around it, one directional,
// the node stays dumb. mean is the EWMA of measured delay; spread is the mean
// absolute deviation (the frame to frame wobble); trend is the slow drift of
// the mean, signed, so the TK can lead a node that is steadily creeping. tempC
// is reserved: if bench data shows delay tracks temperature we light it up to
// key the profile by temperature. All in microseconds except tempC and trend.
struct LatProfile {
  int32_t  meanUs;     // v7.28.25: SIGNED characteristic delay, arrival minus stated departure. Was uint32 with a >= gate that threw away every negative sample.
  uint32_t spreadUs;   // mean absolute deviation, the wobble
  int32_t  trendUs;    // signed slow drift of the mean per ~64 frames, x256 fixed
  uint32_t nSamp;      // samples folded in
  int16_t  tempC;      // reserved, node temperature at last sample, 0 = unused
  uint32_t guardUs;    // v7.20.19: the guard the scheduler last APPLIED to this
                       // node, post clamp. Written only where it is computed
                       // (SR-8: one value, one site) and read by the DRIFT
                       // record so the log shows the decision, not just the
                       // inputs. 0 until this node has been slotted once.
  // v7.28.23: departure-deviation statistics. THESE, not meanUs/spreadUs,
  // are what the scheduler guard is built from now. See the GUARD_ block
  // below for why. Both are magnitudes in microseconds; devMeanUs is an
  // EWMA of |departDevUs| and devSpreadUs is an EWMA of the absolute
  // deviation of that magnitude from its own mean, same 1/8 step and same
  // mean-absolute-deviation convention the delay profile uses.
  uint32_t devMeanUs;
  uint32_t devSpreadUs;
  uint32_t devSamp;    // departure-deviation samples folded in, separate
                       // from nSamp because the two measurements gate
                       // differently: the delay needs the 200 ms sanity
                       // clamp, the deviation does not.
};
static LatProfile g_prof[V7_MAX_ROSTER];
// per-node scheduling guard = mean + PROFILE_K * spread, clamped. K in eighths.
#define PROFILE_K        24        // 3.0 sigma-ish (24/8), covers the wobble
#define PROFILE_MIN_US   200       // never pack tighter than this
#define PROFILE_MAX_US   40000     // never claim more than ~one slot of guard
#define PROFILE_DEFAULT_MEAN_US   0        // v7.28.25: was 15000U. Observational profile, so unknown reads as zero. v7.11.1: named, was inlined at both admission sites
#define PROFILE_DEFAULT_SPREAD_US 2000U    // v7.11.1: same value the decay step now pulls stale profiles back toward

// ================= v7.28.23 GUARD, PHYSICAL FLOOR PLUS MEASURED DEVIATION ==========
//
// WHAT CHANGED AND WHY. Until this version the scheduling guard was
// meanUs + PROFILE_K*spreadUs/8, where meanUs is an EWMA of
// (TK reconstructed transmit start) - (member stated departure). That
// difference is physically propagation plus processing, so tens of
// microseconds. It measures about 17,000 us and every member in the fleet
// therefore sits pinned at the PROFILE_MAX_US rail of 40,000 us, which is
// roughly 700x the physically honest figure and costs 274 ms of a 591 ms
// frame in guard alone.
//
// The 17 ms is NOT explained yet. Three candidates were checked against the
// source and eliminated:
//   - airtime not subtracted. It is: the reconstruction at the arrival site
//     backs out memAirUs before taking the frame offset.
//   - the wrong airtime subtracted (the legacy AIRTIME8_US 36000 figure).
//     It is not: the runtime witness reads getTimeOnAir(sizeof(MemberPkt)),
//     the correct struct, and that witness is what the reconstruction uses.
//   - guard feedback, the applied guard leaking into its own measurement.
//     It does not: the scheduler places ARRIVAL at slotStart+guard, but the
//     member transmits at plain slotStart and departDevFrom() measures its
//     deviation from that identical base. No guard term on either side.
// So the disagreement is real and unexplained, and it stays an open defect.
//
// THE POINT OF THIS PATCH is that the guard does not need that measurement
// and never did. What a guard must cover is how far off its slot boundary a
// member actually transmits. That quantity is already on the wire, already
// integrity tagged, and already expressed in the shared baseline:
// departDevUs. It is independent of airtime, independent of the arrival
// reconstruction, and therefore independent of whatever is wrong above.
//
// GUARD_FLOOR_US is a PHYSICAL FLOOR, not a starting guess, and adaptation
// never reaches below it:
//     propagation, 5 statute miles          26.84 us
//     clock error, 20 ppm over a 591 ms frame  11.82 us
//     tick and scheduling slop                ~4 us
//                                          ---------
//                                            ~43 us
// Five miles is the design range; anything beyond that is out of bounds for
// this link and is an operator problem, not a guard problem. At 40 ppm the
// clock term doubles and the floor would want ~54 us, which is inside the
// headroom the measured term supplies. Revisit the floor when the MEMS
// oscillator lands and the clock term can be based on a real part.
#define GUARD_FLOOR_US   43        // physics: 5 mi propagation + 20 ppm clock + tick slop
#define GUARD_DEV_K      24        // coverage of devSpreadUs, in eighths (3.0)
// Runaway rail. This is NOT the operating point and should never be reached:
// it is about 90x the honest floor, so it cannot bind while a member is
// legitimately learning, and it caps a runaway at roughly a fifth of a
// member slot instead of the two-plus slots the old 40,000 rail claimed.
#define GUARD_MAX_US     4000
// A member that has never been measured starts AT THE FLOOR and climbs on
// evidence, rather than starting wide and being talked down. Starting wide
// is what the old PROFILE_DEFAULT_MEAN_US did and it means the real number
// is never learned, only decayed toward.
#define GUARD_DEV_DEFAULT_MEAN_US   0U
#define GUARD_DEV_DEFAULT_SPREAD_US 0U
// SAMPLE CLAMP, and this one is measured, not chosen. Replaying the real
// captured deviations (19425 LOG_TRIM records, cap4 2026-09-03, plus 746
// from cap5) through this exact integer arithmetic shows the deviation
// distribution is not one population but two. The bulk is superb: median
// |dev| is 8 us fleet wide, which is inside the physical floor already.
// The tail is not jitter at all: p95 is about 1550 us and p99 is about
// 24000 us, values that are scheduling faults (a missed tick, a frame
// resize, a slot change under the member) rather than oscillator wobble.
// An unclamped EWMA lets one 32767 us fault push devMeanUs up by 4096 in a
// single step, so the replay sits at the GUARD_MAX_US rail 38.4% of the
// time and the median applied guard is 2525 us.
// The decisive number is that guarding for that tail buys almost nothing.
// Unclamped covers 94.93% of transmissions; clamping the sample at 2000 us
// covers 94.26% and drops the median applied guard to 676 us, never
// touching the rail. Roughly a quarter of the airtime for six tenths of a
// percentage point of coverage. The tail is too big to guard for at any
// affordable width, so it must be FIXED rather than padded around, and
// padding around it hides it.
// 2000 us is about 250x the median and comfortably above the real jitter
// band, so genuine multi-hundred-microsecond wobble is still measured in
// full; only fault-scale samples are truncated. The RAW unclamped value
// still goes to the role 10 witness every sample, so the tail stays
// visible and countable in the log.
#define GUARD_DEV_SAMPLE_CLAMP_US 2000U

// forward decls: these are defined later in the assembled file
static int g_rosterN = 0;   // roster count, used by the election score
static bool tkNoteAlive(uint8_t id, uint8_t seq, uint8_t hops);
// v7.28.59: ONE compaction helper for every eviction site. Until now the timeout
// eviction in tkBuildAndSend compacted g_roster, g_lastAirFr, g_lastAirMs, g_prof,
// g_slotOf and g_quar and left g_lastRelayer, g_relayParent and g_relayParentMs
// behind, so after any eviction those three described the wrong member. They
// are compacted here too, together with the token state.
static void tkRosterDrop(int i){
  if (i < 0 || i >= g_rosterN) return;
  for (int k=i;k<g_rosterN-1;k++){
    g_roster[k]=g_roster[k+1]; g_lastAirFr[k]=g_lastAirFr[k+1]; g_lastAirMs[k]=g_lastAirMs[k+1]; g_lastAirSeq[k]=g_lastAirSeq[k+1]; g_lastAirSeqValid[k]=g_lastAirSeqValid[k+1]; g_missedAirOpp[k]=g_missedAirOpp[k+1]; g_seatDepth[k]=g_seatDepth[k+1];
    g_prof[k]=g_prof[k+1]; g_slotOf[k]=g_slotOf[k+1]; g_quar[k]=g_quar[k+1];
    g_slotOfPrev[k]=g_slotOfPrev[k+1]; g_lastRelayerMs[k]=g_lastRelayerMs[k+1]; g_lastRelayer[k]=g_lastRelayer[k+1]; g_relayParent[k]=g_relayParent[k+1]; g_relayParentMs[k]=g_relayParentMs[k+1];
    g_ctFail[k]=g_ctFail[k+1]; g_ctRefreshFr[k]=g_ctRefreshFr[k+1]; g_ctAdmitMs[k]=g_ctAdmitMs[k+1];
    g_ctSilent[k]=g_ctSilent[k+1]; g_ctNotReadyFr[k]=g_ctNotReadyFr[k+1]; g_ctSideReq[k]=g_ctSideReq[k+1];
    g_ctLastGrantFr[k]=g_ctLastGrantFr[k+1]; g_ctPassed[k]=g_ctPassed[k+1]; g_ctDirectMs[k]=g_ctDirectMs[k+1];
  }
  g_rosterN--;
}
static uint32_t g_lastTkHeardMs = 0;   // last time any TK schedule heard (owns def)
// v7.28.22 KEEPER LIVENESS. g_lastTkHeardMs is refreshed by ANY adopted copy of
// a schedule, relayed at any hop depth included, and it always was. The comment
// at the v7.12.3 yield site asserting it is only ever refreshed by directly
// hearing a beacon over the air is FALSE and was false when it was written.
// Proved on hardware 2026-09-03: node09 was powered off at 16:50:41 and members
// went on relaying its cached beacons for 41 s, every relay resetting every
// listener's failover clock, until the pool of un-adopted seqs drained at
// 16:51:21.8. The election then fired 9.6 s later, TK_FAILOVER_MS plus jitter,
// exactly on time. The failover logic was correct and was fed a lie.
// A relayed copy of seq N proves the keeper was alive when it emitted N. It
// says nothing about now. So liveness is judged on the seq ADVANCING, which a
// dead keeper cannot do however many copies of its last frames are still in
// flight, and which a relay-only member still observes normally while the
// keeper lives. Gating the refresh on schedHops==0 instead would have been the
// smaller edit and is WRONG: it strands a member reachable only through a
// relay, the exact hazard the SR-6 comment in tkOnData documents.
static uint32_t g_seqAdvMs   = 0;   // millis() when the adopted seq last advanced; 0 = never
static uint8_t  g_seqHigh    = 0;   // highest seq adopted for g_seqHighTk
static uint8_t  g_seqHighTk  = 0;   // tkId that g_seqHigh belongs to; 0 = none yet
// v7.29.39 WARM-SUCCESSOR INDIRECT LIVENESS. A rostered peer's authenticated
// type-0/type-6 packet carries the schedule sequence that peer adopted. When
// that sequence advances beyond ours, it proves the current schedule continued
// even if this one receiver missed the beacon. Keep this clock separate from
// g_seqAdvMs: only a schedule may anchor timing, while either signal may prevent
// a false warm takeover. No packet field or airtime changed.
static uint32_t g_peerSeqAdvMs = 0;
static uint8_t  g_peerSeqHigh  = 0;
static uint8_t  g_peerSeqTk    = 0;
// v7.29.46: authority evidence for a board that has not received a schedule
// itself. A first authenticated member packet establishes only a baseline;
// the lease becomes active after the reported schedule sequence advances and
// is refreshed only by further bounded modular advances. Replays, duplicates,
// frozen reports and large fabricated jumps do not extend it.
static AuthorityProgress g_meshLease{};
static inline uint32_t warmLastAdvanceMs(){
  if (g_peerSeqAdvMs == 0) return g_seqAdvMs;
  if (g_seqAdvMs == 0) return g_peerSeqAdvMs;
  return ((int32_t)(g_peerSeqAdvMs - g_seqAdvMs) > 0) ? g_peerSeqAdvMs : g_seqAdvMs;
}
static uint8_t  g_anchorHops    = 255; // v7.18.0: schedHops of the schedule this node last adopted. 0 = heard the TK directly, >0 = only via relay (not in direct range). 255 = never heard one yet. Drives evidence-based join escalation: a node that knows it is relayed starts in flood mode instead of burning 5 doomed direct attempts.
// v7.12.5: TK-directed frequency switch, dashboard-initiated test. Set by the
// BLE write handler (LogCB, opcode 0x03) on whichever board is paired. Only
// takes effect once THIS board is actually TK and calls tkBuildAndSend(); if
// you are paired to a member, the request just sits here until/unless this
// board becomes TK. Pair to the current TK for this to do anything, same as
// you already do for the dashboard generally.
static float   g_freqTargetMHz = 0.0f;
static uint8_t g_freqCountdown = 0xFF;   // FREQ_SWITCH_NONE, defined later in the file, same value
static uint8_t g_frameType          = 0;    // SF_TYPE_DATA. v7.17.0 typed superframe: current live frame type. Macro defined later, literal here, same as g_freqCountdown above.
static uint8_t g_frameTypeTarget    = 0;    // SF_TYPE_DATA. pending target when a type change is announced.
static uint8_t g_frameTypeCountdown = 0xF;  // SF_CD_NONE. frames remaining to the target, 0xF = nothing pending.
static float   g_currentFreqMHz = LORA_FREQ_MHZ;  // v7.12.12: actual frequency the radio is tuned to right now, updated on every executed hop, drives the freq glass screen
// ===================== v6.0 TK ELECTION (production model, ported) =====================
// Ported from the badge production logic (tk_topology_scoring.c). On the rig we
// have no trust layer (that lives on the STM32 badge), so eligibility is simply
// "a joined sphere member". The SCORE and the three-part HYSTERESIS handoff are
// the real production model: authority moves only on a sustained, decisive
// margin, never by a single lucky frame, so there is never a double TK.
//
// No command preference. Every node scores purely on merit: centrality to the
// other nodes it hears, RSSI to peers, and low hop count. A node with a
// dashboard has NO election advantage. v7.20.13: the bench-era command post
// election bias is deleted; elections are merit-only on every board.

// production hysteresis constants (badge_defs.h)
// v6.1: dwell cut 15 s to 5 s per bench call 2026-07-04. The dual-TK anomaly
// gets its own short hold below: two live TKs is an error state, not a normal
// challenge, so it resolves in seconds instead of riding the full hysteresis.
#define TK_HANDOFF_MARGIN     750
#define TK_HANDOFF_HOLD_MS    6000U
#define TK_MIN_DWELL_MS       5000U
#ifndef LSM_LIVE_MERIT_HANDOFF
#define LSM_LIVE_MERIT_HANDOFF 0  // v7.29.52: a member cannot safely promote against a healthy keeper without a negotiated transfer; default off prevents the measured six-second dual-TK overlap
#endif
#ifndef LSM_KEEPER_EXCLUDE_MASK
#define LSM_KEEPER_EXCLUDE_MASK 0x0002u  // field quarantine: physical node 01 fails sustained keeper TX; it remains a full member
#endif
static inline bool keeperEligibleId(uint8_t id) {
  return id > 15 || (LSM_KEEPER_EXCLUDE_MASK & (1u << id)) == 0;
}
// v7.18.0: the old fixed 8000ms takeover threshold was retired. At a ~1.9s
// relay frame it was ~4.4 frames, so a deep node self-elected on routine
// relay loss (board 08: 6 false promotions in 133s on the range log). The
// candidate path was already frame-scaled at v7.12.16; the takeover path was
// missed. Replaced by two WALL-CLOCK ceilings a healthy node never reaches:
#define TK_FAILOVER_MS       10000U    // had a TK, it went silent this long = gone
#define TK_COLD_LISTEN_MS    12000U    // never heard any TK: listen this long before forming a sphere (failover + ~2 frames slack for a relayed beacon to arrive)
#define TK_RIVAL_HOLD_MS      2000U     // v6.1: dual-TK loser yields after this
#define RELISTEN_JITTER_MIN_MS  1500U   // v7.28.8: floor before a LISTEN board with a dead TK re-walks the ladder
#define RELISTEN_JITTER_SPAN_MS 6000U   // v7.28.8: random span (esp_random, independent per board) added to the floor so co-resigned boards do not re-walk in lockstep; min+span (7500) exceeds BACKHAUL_LISTEN_MS (5000) so the first board through can be advertising before a later one begins to listen
#define COLD_ELECT_RANK_STEP_MS 1000U  // v7.29.43: unique V2 rank spacing. The retired hash modulo 12 was not
                                       // a permutation (01/07 and 02/06/12 collided) and its 166 ms slices let
                                       // several boards enter TK before the first schedule was adopted.
#define COLD_ELECT_TIE_MS         50U  // only separates duplicate IDs; never consumes the next node's rank.
#define COLD_COMMIT_GUARD_MIN_MS 16000U // v7.29.48: field evidence measured 12.3 s from cold-guard arm to the legitimate warm successor's first schedule; retain margin above that measured maximum.
#define COLD_COMMIT_GUARD_MAX_MS 32000U // bounded recovery: an isolated partition must still form a keeper instead of waiting indefinitely.
#define STAG_JITTER_MS          2000U   // v7.28.11: per-cycle random election jitter band (esp_random, independent per board), replaces the 28.10 id-serialized stagger so no id is structurally delayed
// v7.28.22: keeper liveness threshold, in FRAMES, converted through the live
// frame length at the point of use, the same shape aloneGraceMs() has used
// since v7.12.16. TK_FAILOVER_MS is retained because TK_COLD_LISTEN_MS is
// documented against it and other paths read it; it no longer gates failover.
// 15 frames against the 664 ms frame measured on the 2026-09-03 eleven board
// capture is 9960 ms, so this reproduces the old ten second budget at current
// geometry and changes only WHAT the trigger measures. There is deliberately
// no wall clock floor under it: a short frame SHOULD shorten the budget, which
// is the whole reason it is counted in frames. g_frameUs holds its 1000000
// default until a schedule is adopted, so a board that has never heard a frame
// length uses 15 s, conservative in the safe direction.
#define TK_STALL_FRAMES           15U
#define TK_STALL_FLOOR_MS      15000U // v7.30.0: ordinary members are the fallback, not the fast successor; short frames must not collapse this guard
#define TK_SUCCESSOR_MISS_FRAMES     3U  // v7.29.38: named warm backup commits after three missing sequence advances
#define TK_SUCCESSOR_DIRECT_HOLD_MS 10000U // v7.30.0: the apparent long blackout was a replay-reservation starvation defect; keep the proven fast successor hold
#define TK_SUCCESSOR_PEER_HOLD_MS 10000U // same bound for advancing authenticated peer evidence
static inline uint32_t tkStallMs(){
  uint32_t frames = (g_frameUs/1000UL) * TK_STALL_FRAMES;
  return frames > TK_STALL_FLOOR_MS ? frames : TK_STALL_FLOOR_MS;
}
static inline uint32_t tkSuccessorMs(){
  uint32_t frames = (g_frameUs/1000UL) * TK_SUCCESSOR_MISS_FRAMES;
  return frames > TK_SUCCESSOR_DIRECT_HOLD_MS ? frames : TK_SUCCESSOR_DIRECT_HOLD_MS;
}
static inline uint32_t tkSuccessorPeerMs(){
  uint32_t frames = tkSuccessorMs();
  return frames > TK_SUCCESSOR_PEER_HOLD_MS ? frames : TK_SUCCESSOR_PEER_HOLD_MS;
}
static inline uint32_t coldCommitGuardMs(){
  // A cold starter and a warm successor use different clocks. Give the named
  // successor its full peer-evidence hold plus two complete schedule chances.
  // Clamp both ends so short startup defaults cannot recreate the v47 race and
  // a very long/corrupt advertised frame cannot freeze an isolated partition.
  uint32_t frameMs = g_frameUs / 1000UL;
  uint32_t guard = tkSuccessorPeerMs() + 2UL * frameMs;
  if (guard < COLD_COMMIT_GUARD_MIN_MS) guard = COLD_COMMIT_GUARD_MIN_MS;
  if (guard > COLD_COMMIT_GUARD_MAX_MS) guard = COLD_COMMIT_GUARD_MAX_MS;
  return guard;
}
#define CAND_STRAND_MS        45000UL  // v7.29.6: longest a board may sit in CANDIDATE before standing down to LISTEN and re-walking the ladder. Longer than the worst observed real recovery (111 s was a keeper-present case that cleared itself; a silent rung never clears), short enough that a walked-out board is looking again inside a minute.
#define RELISTEN_MAX_ATTEMPTS     3U    // v7.28.10: empty dead-TK re-walks before a LISTEN board self-elects on the current rung as a last resort
// v6.1 tie deltas: inside the score margin the tiebreak stack runs in order
// RSSI health, rosterCount, battery, lowest NODE_ID. A field only decides when
// it differs by at least its delta, else it falls through to the next rung,
// so beacon noise can never flip authority. The last rung cannot tie.
#define TIE_RSSI_DB           4
void logRec(uint8_t type, uint8_t nodeId, uint8_t role, uint8_t aux, int16_t e, int16_t n, uint32_t data);   // v7.28.60: forward declaration, the comparator and the takeover predicate write witnesses; defined with the log below
#define QUORUM_PEERS          2U        // v7.28.60: keepalive-fresh peers that block an in-place self-election
#define VACUUM_LOCK_MS        180000UL  // v7.29.5: an isolated board whose adopted schedule advanced this recently may not self-elect. Longer than the 90 s eviction window plus a re-seat, so the grace carry has time to land. Tradeoff on record: a truly dead keeper with a lone isolated survivor waits this long before it fills the vacuum; a survivor with peers is unaffected.
static uint32_t g_vacuumLockLastMs = 0;
static uint32_t g_coldCommitSinceMs = 0; // v7.29.47: cold-election phase two; zero until this rank has won phase one
static void vacuumLockWitness(uint8_t q, uint32_t nowMs){
  if (nowMs - g_vacuumLockLastMs < 5000UL) return;   // once per 5 s, the predicate is polled every loop
  g_vacuumLockLastMs = nowMs;
  logRec(4 /*LOG_STATE*/, NODE_ID, g_role, 0xE2, (int16_t)q, (int16_t)g_framesSilent, nowMs - g_seqAdvMs);   // aux 0xE2 = vacuum lock held self-election
}
#define QUORUM_WIN_FRAMES     5U        // v7.28.60: a peer keepalive this many frames old still counts
#define QUORUM_WIN_FLOOR_MS 10000U      // v7.30.0: compact epochs must not forget a healthy peer after only 2-3 seconds
#define SLOT_MUTE_FRAMES      8U        // v7.28.60: consecutive silent frames after which a member stops using its slot
#define EMPTY_TK_REWALK_MS    120000U   // v7.28.60: a keeper that elected from member and stays empty this long re-walks
#define SPAWN_LISTEN_MS       3000U     // v7.28.60: a re-walk or spill spawn listens this long ON THE LANDED RUNG before the vacuum election may fire; a keeper heard in that window cancels the spawn and the board joins or, if that keeper is full, spills again
static uint32_t g_kaSeenMs[32];                // v7.28.60: last KEEPALIVE-bit packet heard per node id (ids 1..31), the quorum witness
static bool     g_quorumBlocked = false;       // v7.28.60: the quorum refused an in-place self-election; the next walk excludes this rung
static bool     g_slotMuted = false;           // v7.28.60: slot muted on silence, witness state
static inline uint32_t quorumWinMs(){
  uint32_t frames = (g_frameUs / 1000UL) * QUORUM_WIN_FRAMES;
  return frames > QUORUM_WIN_FLOOR_MS ? frames : QUORUM_WIN_FLOOR_MS;
}
static uint32_t g_progressHoldWitnessMs=0;
static bool ordinaryPeerProgressHolds(uint32_t nowMs){
  if((g_role!=0 && g_role!=1) || g_successor==(uint8_t)NODE_ID)return false;
  const uint32_t cap=authorityrecovery::holdCap(tkStallMs(),coldCommitGuardMs(),
                                               aloneGraceMs(),CAND_STRAND_MS);
  const bool hold=g_meshLease.holds(g_tkId,g_tkEpoch,g_seqAdvMs,nowMs,
                                    tkSuccessorPeerMs(),cap);
  if(hold && (uint32_t)(nowMs-g_progressHoldWitnessMs)>=5000UL){
    g_progressHoldWitnessMs=nowMs;
    logRec(4 /*LOG_STATE*/,NODE_ID,g_role,0xF8,(int16_t)g_meshLease.keeper,
           (int16_t)(nowMs-g_meshLease.advancedAt),nowMs-g_seqAdvMs);
  }
  return hold;
}
static uint8_t quorumFresh(uint32_t nowMs){    // v7.28.60: distinct peers keepalive-fresh within QUORUM_WIN_FRAMES
  uint32_t win = quorumWinMs(); uint8_t n = 0;
  for (int i = 1; i < 32; i++) if (i != NODE_ID && g_kaSeenMs[i] && (nowMs - g_kaSeenMs[i]) <= win) n++;
  return n;
}
// v7.29.39: the named successor needs only one authenticated peer to prove
// that its own schedule receiver is the outlier. Every KEEPALIVE-bit packet
// reaching this table has already passed the secure envelope and logical
// packet parsing. Peers stop using their slots after schedule loss, so this
// evidence naturally expires after a real keeper failure. The ten-second hold
// covers the measured 7.95-second packet-loss burst without stretching to 24
// seconds when relay geometry expands the superframe.
static uint8_t warmPeerFresh(uint32_t nowMs){
  uint32_t win = tkSuccessorPeerMs();
  uint8_t n = 0;
  for (int i = 1; i < 32; i++)
    if (i != NODE_ID && g_kaSeenMs[i] && (uint32_t)(nowMs - g_kaSeenMs[i]) <= win) n++;
  return n;
}
#define TIE_ROSTER            2         // v7.29.0: roster tiebreak rung delta (renamed from TIE_CENTRAL; this rung weighs rosterCount, not centrality)
#define TIE_BATT              2         // battery nibble steps, about 12 pct

// live election state
static int32_t  g_myScore = 0;         // this node's current election score
static int32_t  g_tkScore = 0;         // best TK score we have heard
static uint32_t g_tkSinceMs = 0;       // when the current TK took authority
static uint32_t g_betterSinceMs = 0;   // when WE first started beating the TK
static int8_t   g_peerRssiSum = 0;     // rolling avg RSSI to peers (dBm-ish)
static uint8_t  g_peerRssiN = 0;
static int16_t  g_peerRssiAvg = -90;
static uint8_t  g_tkId_rival = 0;
static uint32_t g_rivalSeenMs = 0;
// v7.29.44: distinguish a rival beacon this keeper received itself from a
// hidden-rival tuple repeated by members. The field walk showed keeper 01
// yielding on ONE member's report of keeper 04. Keeper 04's schedule could not
// reach 01's first ring, producing an 80-second schedule blackout even though
// 01-to-roster RF was healthy. A direct authenticated beacon remains decisive;
// an indirect rival is promoted only after distinct roster witnesses establish
// that the replacement authority is actually reachable across the incumbent's
// sphere.
static bool     g_rivalDirect = false;
static uint8_t  g_hiddenRivalTk = 0;
static uint8_t  g_hiddenRivalEpoch = 0;
static uint32_t g_hiddenRivalWitnessMask = 0;
static uint32_t g_hiddenRivalFirstMs = 0;
static uint32_t g_hiddenRivalLastMs = 0;
#define HIDDEN_RIVAL_CONFIRM_MS 12000UL
#define HIDDEN_RIVAL_MIN_WITNESSES 2U
#define HIDDEN_RIVAL_MAX_WITNESSES 4U
static int8_t   g_rivalRssiAvg = -127; // v6.1: rival TK self-reported RSSI health
static uint8_t  g_rivalTie = 0;        // v6.1: rival rosterCount<<4 | battery nibble (v7.28.101 rename)
// v7.11.0: hidden-node dual-TK fix. Two TKs that cannot hear each other never
// trigger the direct rival-yield check above. A MEMBER that hears both can
// relay the second one home in its own data packet instead.
static uint8_t  g_relayRivalTkId = 0;      // a DIFFERENT TK heard while tracking g_tkId, 0 = none
static uint8_t  g_relayRivalEpoch = 0;     // v7.29.38: authority generation of that hidden rival
static uint8_t  g_relayRivalTie = 0;
static int8_t   g_relayRivalRssiAvg = -127;
static int16_t  g_relayRivalScore = 0;      // v7.29.23: complete hidden-rival election tuple
static uint32_t g_relayRivalSeenMs = 0;
// Published tuple of the keeper this member currently follows. These values
// let an authenticated member carry authority evidence through a schedule
// shadow without adding bytes to MemberPkt.
static uint8_t  g_homeTkTie = 0;
static int8_t   g_homeTkRssiAvg = -127;
// v7.10.4: when THIS board last stood down from TK, 0 = never has been TK
// this power cycle. Lets a board that re-elects itself soon after keep its
// own roster instead of being treated like a brand new TK.
static uint32_t g_lastTkStandDownMs = 0;
// v7.10.8: join requests overheard from OTHER nodes recently, drives the
// adaptive backoff in joinModEffective(). Decays in houseTick().
static uint8_t  g_recentJoinReqCount = 0;
static uint8_t  g_birthCooldown      = 0;      // v7.28.5: DATA frames left before another birth frame may arm (TK side)
static bool     g_birthProactive     = false;  // v7.28.15: the live or pending birth frame was armed by the standing offer, not by heard demand; sizes the frame to every window
static bool     g_birthPendingEval   = false;  // v7.28.15: a proactive birth frame just went out; compare the roster at the next tick to see whether it admitted anyone
static uint8_t  g_birthRosterAtOpen  = 0;      // v7.28.15: roster size when the proactive birth beacon went out
static uint8_t  g_birthEmptyRuns     = 0;      // v7.28.15: consecutive proactive birth frames that admitted nobody, counted only while no rival is heard
static uint8_t  g_birthMaintDataAge  = 0;      // v7.29.50: DATA frames since the last maintenance offer or successful fresh admission
static uint8_t  g_framesSinceRival   = 255;    // v7.28.15: frames since a rival keeper was last heard, saturating; 255 = none this tenure
static uint32_t g_birthRivalTickMs   = 0;      // v7.28.15: millis at the previous frame-engine tick; a g_rivalSeenMs at or after it means a rival was heard this frame
static bool     g_swarmReqPending    = false;  // v7.28.5: an explicit swarm-join request is waiting to be served
static uint8_t  g_swarmReqCount      = 0;      // v7.28.5: joiner windows the pending request asked for (capped 63)
static bool     g_coldBirthWindows   = false;  // v7.28.104: a freshly born TK owes one wide first birth. Set on taking the role, forces the first JOIN beacon to COLD_BIRTH_WINDOWS even with an empty roster and no demand, cleared as that beacon is built.
static bool     g_resignSwarmReq    = false;  // v7.28.6: this board owes the winner a type-7 swarm request after a resignation
static uint8_t  g_resignSwarmTarget = 0;      // v7.28.6: the TK id we yielded to
static uint8_t  g_resignSwarmTries  = 0;      // v7.28.6: bounded swarm-request retry count
// v7.28.2: demand counts DISTINCT joiners, not join packets. The aggregate path
// echoes one join through many hearers and re-aggregations, and the counter used
// to rise once per echo per hearer: the 2026-08-29 bench pinned it at the 250
// clamp from 52 real joins and fired hollow JOIN frames every few seconds for
// twenty minutes. One joiner now counts once per DEMAND_DEDUP_MS window, so the
// trigger threshold of 8 means eight actual joiners again.
#define DEMAND_DEDUP_MS 5000UL
// v7.28.3: the 16-entry seen-ring this replaces thrashed under the 100-phantom
// rig. With far more than 16 distinct ids in play every id was evicted from the
// ring long before its 5 s window expired and was recounted on every hearing,
// so demand became a staircase that climbed past the actual joiner population
// (138 counted against 110 possible, bench 2026-08-29 run 2). Exact dedup now:
// one bit per id over the whole 8-bit space, cleared as a whole each
// DEMAND_DEDUP_MS epoch. 32 bytes, no eviction, no thrash, every id counts at
// most once per epoch.
static uint8_t  g_dmdSeenBits[32];
static uint32_t g_dmdEpochMs = 0;
static void demandNote(uint8_t sid){
  if (sid == 0) return;
  uint32_t now = millis();
  if ((uint32_t)(now - g_dmdEpochMs) >= DEMAND_DEDUP_MS){
    memset(g_dmdSeenBits, 0, sizeof(g_dmdSeenBits));
    g_dmdEpochMs = now;
  }
  uint8_t byi = (uint8_t)(sid >> 3), bit = (uint8_t)(1u << (sid & 7));
  if (g_dmdSeenBits[byi] & bit) return;
  g_dmdSeenBits[byi] |= bit;
  if (g_recentJoinReqCount < 250) g_recentJoinReqCount++;
}
// v7.12.1: LISTEN join retry, cold-boot style, replaces the v7.10.9 random
// backoff window and its any-roster-growth reset entirely. See the FW_PATCH
// comment above for the full reasoning. JOIN_MAX_ATTEMPTS caps how many
// times this node will try its own modulus turn before giving up and
// resetting, so a genuinely broken join (corrupted request, full roster,
// dead RF) does not retry forever. JOIN_GIVEUP_SENTINEL tags the STATE
// record logged at that reset so it is unambiguous in a flash log read
// later: role and tk have NOT changed, this is a give-up-and-retry-cold
// event, not a real role transition.
#define JOIN_MAX_ATTEMPTS 5
#define JOIN_FAST_FRAMES 8U          // v7.29.47: bounded recovery after a keeper/roster transition
#define JOIN_FAST_MOD 8U             // v7.30.0: eight identity-separated turns; short adaptive frames keep recovery fast without two collision-locked groups
#define JOIN_FAST_DIRECT_ATTEMPTS 2U // then alternate onto the floodable path instead of waiting five lost directs
static uint8_t g_joinFastFrames = 0;
// v7.18.0: multi-hop join escalation. Set once a node has exhausted its
// direct JoinPkt attempts (TK cannot hear it), so its turn now emits a
// floodable MemberPkt type 2 instead of another direct JoinPkt. Cleared
// when the node leaves LISTEN (admitted, or self-elected).
static bool g_joinFloodMode = false;
static bool g_joinGiveUp    = false;   // v7.28.20: latched only when direct join is exhausted (give-up). The per-turn flood decision is otherwise made fresh, not one-way latched.
// v7.28.0: JOIN-superframe burst window pick. 0xFF = none (not a JOIN frame, or
// no empty slot). Chosen fresh from every JOIN-frame beacon's own slot array.
static uint8_t g_burstSlotPick = 0xFF;
#define JOIN_GIVEUP_SENTINEL 0xC1
// v7.12.11: FREQ_SWITCH_SENTINEL removed, dead code now that the STATE log records the actual Hz value instead of a flat marker.
#define FREQ_SWITCH_NONE      0xFF   // v7.12.5: SchedBeacon.freqCountdown sentinel, no change pending
#define FREQ_SWITCH_COUNTDOWN_FRAMES 5U   // v7.12.5: frames between dashboard request and actual switch
// v7.17.0 typed superframe. The previously unused SchedBeacon.subFrame byte now
// packs [countdown:4][target:2][current:2]. current/target frame type:
// 0 = DATA (default, behaviour-preserving), 1 = JOIN, 2 = FLAG, 3 = reserved.
// countdown 0xF = no pending type change, else frames remaining to the target,
// decremented one per frame on the TK exactly like freqCountdown/resizeCountdown
// and read fresh off any beacon by members, so a missed beacon just means a
// lower number next time. Packing into the existing byte keeps SchedBeacon at
// 64 B, so this is a version-only wire change with zero airtime cost, which is
// the whole point of Decision 6 (typed superframes dissolve the bit-stealing
// problem: a field rides the frame type that needs it, not every beacon).
// TYPE CEILING: 2 bits gives four types; a fifth type is a future wire bump.
#define SF_TYPE_DATA  0
#define SF_TYPE_JOIN  1
#define SF_TYPE_FLAG  2   // v7.28.105: reserved, INTENTIONALLY UNUSED this cut. g_frameTypeTarget is only ever set to DATA or JOIN. The v7.28.105 tier hold needs NO flag frame: the held tier count already rides every beacon in s.schedTiers, so a held-depth sphere is already marked on the wire. Do not wire a trigger for this enum without a design for what a FLAG frame carries and how members react.
#define SF_TYPE_RSVD  3
#define SF_CD_NONE    0xF
#define SF_PACK(cur,tgt,cd) (uint8_t)((((cd)&0xF)<<4)|(((tgt)&0x3)<<2)|((cur)&0x3))
#define SF_CUR(b) ((uint8_t)((b)&0x3))
#define SF_TGT(b) ((uint8_t)(((b)>>2)&0x3))
#define SF_CD(b)  ((uint8_t)(((b)>>4)&0xF))
static uint8_t  g_joinAttemptCount = 0;
static bool     g_joinRadioRecoverReq = false; // v7.29.43: deferred full modem rebuild after silent joins
static bool     g_joinRadioRecovered  = false; // at most once per LISTEN episode unless the driver reports TX error
static int32_t  g_tkEastCm = 0, g_tkNorthCm = 0;

// fold each heard peer's RSSI so a node knows how well connected it is
void electNoteRssi(int16_t rssi){
  if (rssi > -5 || rssi < -140) return;
  g_peerRssiAvg = (int16_t)(g_peerRssiAvg - (g_peerRssiAvg>>3) + (rssi>>3));
}

static inline uint8_t battPct();  // v7.28.9: forward decl; defined with the tiebreak plumbing below, used here for the battery term
// this node's election score, production-shaped: centrality (how many peers it
// hears directly, i.e. how central it is), RSSI health to peers, hop penalty.
int32_t electMyScore(){
  int32_t score = 0;
  // v7.28.70: daisy root weight. Only the board whose NODE_ID matches DAISY_ROOT_ID
  // gets it, so the fleet source stays uniform and one constant picks the root.
  if (DAISY_ROOT_ID != 0 && NODE_ID == DAISY_ROOT_ID) score += DAISY_ROOT_WEIGHT;
#ifdef LSM_CMDCTR_CASCADE
  // v7.29.0 command-center cascade, default OFF (see the weight constants). A designated command
  // board wins keeper by its NODE_ID: C1..C4 at 200..203 carry a descending ladder, all above a
  // plain weighted node. Dormant on 01..13 because the flag is undefined there.
  if ((uint16_t)NODE_ID >= CMDCTR_ID_BASE && (uint16_t)NODE_ID <= CMDCTR_ID_TOP)
    score += CMDCTR_WEIGHT_C1 - (int32_t)((uint16_t)NODE_ID - CMDCTR_ID_BASE) * CMDCTR_WEIGHT_STEP;
#endif
  // centrality: direct peers heard. On the rig, roster size when TK, else the
  // count of distinct peers this node has heard recently.
  // v7.28.8: role-invariant centrality. The old form read roster size when TK
  // and peers-heard when not, so the score JUMPED every time the role flipped;
  // at a mass resignation the whole ranking oscillated because every input to it
  // moved with the roles, and the fleet cycled instead of agreeing on an order
  // (bench 2026-08-30, ten co-booted boards). Now both roles compute the same
  // quantity, distinct peers heard recently, with roster size allowed only to
  // RAISE it as a floor, never to replace it. Roster is kept briefly after a
  // stand-down, so the floor also smooths the very transition that oscillated.
  int32_t central = (int32_t)g_peersHeard;
  if ((int32_t)g_rosterN > central) central = (int32_t)g_rosterN;
  if (central > 12) central = 12;               // cap doorway bias, like production
  if (CENTRAL_ENABLED) score += central * 48;   // v7.28.9: held at zero; positional centrality re-enable point
  // RSSI health to peers
  score += (100 + (int32_t)g_peerRssiAvg) * 6;  // -90 dBm -> +60, -60 dBm -> +240
  // hop penalty: a node far from the cluster is a poor TK
  score -= (int32_t)(g_hopsToCmd==255?8:g_hopsToCmd) * 25;
  // v7.28.9: low-battery handicap on ANY board, floor-triggered. A healthy fleet
  // feels nothing; only a genuinely low pack is nudged off the keeper role, and it
  // is never hard-banned, so a well-placed board still wins on merit when low.
  {
    uint8_t bp = battPct();
    if (bp < BATT_LOW_PCT) score -= (int32_t)(BATT_LOW_PCT - bp) * BATT_W;
  }
  // demote a failing TK so a healthy survivor takes over before it dies.
  if (g_role==3) {
    score -= (int32_t)g_missedFrames * 200;      // own beacons failing = stalling TK
  }
  return score;
}

// ---- v6.1 tiebreak plumbing ----
// v7.28.9: battery read is now live and bench-confirmed (VBAT ADC on PIN_VBAT_ADC,
// divider enable on PIN_VBAT_EN, enable polarity verified on the bench 2026-08-30).
// battPct() returns the slow-averaged percent, so both the comparator rung and
// electMyScore use real battery. The rung stays a light tiebreaker; centrality
// above it is held at zero, so near-equal boards fall through battery to lowest id.
static inline uint8_t battPct(){ return g_battPctSmooth; }  // v7.28.9: real read, slow-averaged
// v7.28.101: RENAMED electCentral -> electRosterCount. The function has not computed
// centrality since v7.28.60; it returns the keeper's ROSTER SIZE and feeds the roster
// tiebreak rung. The name was the only thing wrong, not the math, and it cost real
// reading time in the post-v97 grading. The word "centrality" is now reserved for a
// genuine positional input (UWB ranging) and is used nowhere else in the election path.
// See DESIGN-NOTE-centrality.txt.
static inline uint8_t electRosterCount(){
  // The keeper's ROSTER SIZE, capped 15, so the rival comparator can weigh a sitting
  // roster. Only a keeper has a roster to report; every other role reports 0.
  if (!CENTRAL_ENABLED) return (uint8_t)(g_role == 3 ? (g_rosterN > 15 ? 15 : g_rosterN) : 0);
  int32_t c = (int32_t)g_peersHeard;                  // v7.28.8: role-invariant, matches electMyScore
  if ((int32_t)g_rosterN > c) c = (int32_t)g_rosterN; // roster as a floor only, never a role-flip substitute
  if (c > 15) c = 15;
  return (uint8_t)c;
}
static inline uint8_t electPackTie(){
  uint8_t b = (uint8_t)(battPct() / 7);          // 100 pct packs to nibble 14
  if (b > 15) b = 15;
  return (uint8_t)((electRosterCount() << 4) | b);   // v7.28.101: rosterCount nibble, was misnamed centrality
}
static inline int16_t electPubScore(){
  int32_t s = g_myScore;
  if (s >  32767) s =  32767;
  if (s < -32768) s = -32768;
  return (int16_t)s;
}
// Both TKs run this on each other's beacon and reach the SAME verdict because
// every input is self-reported wire data, never a link-asymmetric measurement.
// Returns true when the rival outranks this node and it must stand down.
bool electRivalOutranks(){
  // v7.29.47: a live dual-keeper merge must be symmetric. Both keepers possess
  // the same authenticated wire tuple, so compare only authority generation and
  // then the provisioned id. The former merit stack included local roster and
  // receiver-health state; concurrent keepers could therefore reach opposite
  // answers and preserve a split. Merit still selects a normal handoff before a
  // rival exists. Once two authorities exist, newer epoch wins and lowest id is
  // the deterministic equal-epoch winner.
  int8_t epochDelta = (int8_t)((uint8_t)g_rivalEpoch - (uint8_t)g_tkEpoch);
  if (epochDelta > 0) return true;
  if (epochDelta < 0) return false;
  return g_tkId_rival < (uint8_t)NODE_ID;        // final rung: lowest id wins
}

// production TK_ShouldHandoff: dwell + margin + sustained hold, all three.
static uint32_t g_electBootMs = 0;
static uint32_t g_electJitterMs = 0;
// v7.30.3: A deaf receiver must never interpret its own silence as an empty
// network. A clean boot radio path or clean received packet opens this gate;
// the first failed radio command closes it and cancels pending cold elections.
static bool g_radioElectionReady = false;
static bool g_radioRecoverRequested = false;
static uint8_t g_radioFirstFaultStage = 0;
static int16_t g_radioFirstFaultStatus = 0;
static void radioElectionGateSet(bool ready, uint32_t nowMs) {
  g_radioElectionReady = ready;
  g_coldCommitSinceMs = 0;
  g_electJitterMs = 0;
  g_electBootMs = ready ? (nowMs ? nowMs : 1U) : 0;
}
// LOG_RF aux 22: e=first failing command stage, n=RadioLib status,
// data bit0=BUSY pin at capture. Preserve the initiating command rather than
// overwriting it with a later watchdog error.
static void radioFaultNote(uint8_t stage, int16_t status) {
  radioElectionGateSet(false, millis());
  g_radioRecoverRequested = true;
  if (g_radioFirstFaultStage == 0) {
    g_radioFirstFaultStage = stage;
    g_radioFirstFaultStatus = status;
    logRec(8 /*LOG_RF*/, NODE_ID, g_role, 22, stage, status,
           digitalRead(PIN_LORA_BUSY) == HIGH ? 1U : 0U);
  }
}
// v7.29.43: collision-free cold-election rank for the V2 id range. The retired
// hash-modulo-12 scheme claimed to be a permutation but was not: ids 01/07 and
// 02/06/12 shared slices, while adjacent slices were only 166 ms apart. The
// field capture showed 04, 03 and 01 all entering TK inside 916 ms. Rank by the
// provisioned id instead. Node 01 publishes first; each later id gets a whole
// second to receive and adopt that authenticated schedule before its deadline.
// Randomness is retained only as a tiny duplicate-id tie break and cannot spill
// into the next valid rank. Warm-successor takeover bypasses this delay below.
static inline uint32_t electSeparatorMs(){
#if LSM_DAISY_ROOT_ID > 0
  // Bench-only anchored-chain test: sequential USB startup and board-specific
  // GNSS/radio scans can differ by many seconds.  Give the selected root a
  // full minute to publish before any non-root cold election is allowed.
  // Production builds leave LSM_DAISY_ROOT_ID at zero and never take this path.
  uint32_t rank = NODE_ID == LSM_DAISY_ROOT_ID ? 0U : (60U + (uint32_t)NODE_ID);
#else
  uint32_t rank = NODE_ID > 0 ? (uint32_t)NODE_ID - 1U : 20U;
#endif
  uint32_t tie = COLD_ELECT_TIE_MS > 1U ?
                 (uint32_t)(esp_random() % COLD_ELECT_TIE_MS) : 0U;
  return rank * COLD_ELECT_RANK_STEP_MS + tie;
}
static uint32_t g_relistenSinceMs  = 0;   // v7.28.8: when a LISTEN board's dead-TK re-walk timer started
static uint32_t g_relistenJitterMs = 0;   // v7.28.8: current per-attempt jitter draw; 0 = draw a fresh one
static uint8_t  g_relistenAttempts = 0;   // v7.28.10: consecutive dead-TK re-walks that found nothing; reset on a real TK heard or on becoming TK, never on the walk's own state-wipe
bool electShouldTakeOver(uint32_t nowMs){
#ifdef LSM_LISTEN_ONLY
  // A passive witness may observe candidate state for diagnostics, but it must
  // never become an authority. LSM_TX is a no-op on this build, so allowing a
  // logical takeover would create a silent keeper that freezes its partition.
  return false;
#endif
  // A quarantined radio remains a normal member but can neither cold-elect nor
  // use a stale successor nomination.  Every keeper applies the same mask when
  // naming its successor, so this does not strand the fast-failover chain.
  if (!keeperEligibleId((uint8_t)NODE_ID)) return false;
  if (!g_radioElectionReady) {
    g_coldCommitSinceMs = 0;
    g_electBootMs = 0;
    g_electJitterMs = 0;
    return false;
  }
  // v7.29.43: election deadlines are unique provisioned-id ranks. This removes
  // the modulo collisions and gives the preceding rank a full second to publish.
  if (g_electBootMs==0){ g_electBootMs=nowMs; g_electJitterMs = electSeparatorMs(); }   // v7.28.36: drawn once per cycle so the threshold holds steady for the cycle
  // Vacuum: we have never heard any TK and the boot grace has elapsed. Nobody
  // is in charge, so form the mesh by taking authority. Other nodes in the same
  // vacuum resolve to one winner via the score compare below once they hear us.
  // v6.1: vacuum election is STAGGERED by NODE_ID so two members losing the
  // TK in the same instant do not both self-elect (bench 2026-07-04: pulled 07,
  // both 08 and 09 went TK). The lowest id fires first; each higher rank waits
  // 400 ms more and hears the new TK's first beacon before its own timer fires.
  // v7.18.0: re-centered on the command post id. The old ((id>=7)?id-7:id)
  // formula was a leftover from when 07 was the command post; after the move
  // to 05 it mapped 05 and 12 to the SAME 2000ms mark, so the one pair that
  // most needs separation (command post vs its hop-1 spine) had none. Offset
  // from CMD id over the 8-id ring is collision-free and puts 05 first.
  uint32_t stag = g_electJitterMs;   // v7.28.36: per-cycle SEPARATOR slice (electSeparatorMs), drawn once when the election clock arms; every board is eligible the instant its cold listen elapses, and slices are disjoint by construction
  if (g_successor == (uint8_t)NODE_ID) stag = 0;   // v6.6: named successor jumps the queue for fast failover
  // v7.19.2: sphere-full LOCKOUT -> SPILL, not on-channel spawn. The v6.6 body
  // here returned true, self-electing a rival TK ON the channel that just
  // flagged full; its own comment admitted it only existed to prove the
  // control path on the single-channel rig. The cap-4 bench woke it for the
  // first time and produced three co-resident TKs on 924 (2026-07-28 live
  // bench, root-caused same day). Now: request a deferred spill. The main
  // loop retunes to the backhaul and re-walks the ladder exactly like a cold
  // boot (spillWalkLadder), joining the first rung with room or spawning on
  // the first empty rung. The walk blocks ~3.5 s, so it runs at a loop-level
  // safe point, never inside this predicate. Uniform across all boards: no
  // command-post carve-out. The v7.12.28 board-05 +30000 bias was removed from
  // this tree, so every board reaches this branch on merit.
  if (g_sphereFull && g_role==0) {
    if (g_fullBlockedSinceMs==0) g_fullBlockedSinceMs=nowMs;
    else if (nowMs - g_fullBlockedSinceMs > SPHERE_FULL_HOLD_MS + stag) {
      g_spillReq = true; g_spillFromFull = true;   // v7.28.8: full-lockout spill excludes the current (full) rung
      g_fullBlockedSinceMs = 0;
      return false;
    }
  } else g_fullBlockedSinceMs=0;
  if (g_lastTkHeardMs==0) {
    // v7.29.46: a cold/late starter may miss the keeper schedule while still
    // hearing authenticated members that are following it. Treat two or more
    // advancing frame witnesses as a short authority lease. The lease uses the
    // keeper frame sequence as its clock, not local wall-clock agreement.
    // Once advances stop, the lease expires and the original unique rank is
    // applied from the expiry boundary, so disconnected partitions still form
    // one keeper instead of freezing indefinitely.
    uint32_t leaseHold = tkSuccessorPeerMs();
    if (g_meshLease.advancedAt != 0 &&
        (uint32_t)(nowMs - g_meshLease.advancedAt) <= leaseHold) {
      g_coldCommitSinceMs = 0;
      return false;
    }
    if (g_meshLease.advancedAt != 0) {
      uint32_t expiredAt = g_meshLease.advancedAt + leaseHold;
      if ((int32_t)(nowMs - expiredAt) > (int32_t)stag) {
        if (g_coldCommitSinceMs == 0) {
          g_coldCommitSinceMs = nowMs;
          logRec(4 /*LOG_STATE*/, NODE_ID, g_role, 0xF7, 1, 0, coldCommitGuardMs());
          return false;
        }
        if ((uint32_t)(nowMs - g_coldCommitSinceMs) >= coldCommitGuardMs()) return true;
      }
      return false;
    }
    if (nowMs - g_electBootMs > TK_COLD_LISTEN_MS + stag) {
      if (g_coldCommitSinceMs == 0) {
        g_coldCommitSinceMs = nowMs;
        logRec(4 /*LOG_STATE*/, NODE_ID, g_role, 0xF7, 0, 0, coldCommitGuardMs());
        return false;
      }
      if ((uint32_t)(nowMs - g_coldCommitSinceMs) >= coldCommitGuardMs()) return true;
    }
  }
  // TK went silent long enough to be considered gone.
  // v7.28.22: was (nowMs - g_lastTkHeardMs > TK_FAILOVER_MS + stag), which any
  // relayed copy of a dead keeper's cached beacon reset. Now the age of the last
  // SEQ ADVANCE. g_lastTkHeardMs stays in the predicate as the have-we-ever-heard
  // -a-keeper term; the cold branch above still owns the never-heard case.
  // v7.29.38 WARM SUCCESSOR. Only the keeper-named backup may use the fast
  // path. It stays on the working channel, preserves the last published roster,
  // and advances the authority epoch. Every other member remains behind the
  // conservative quorum/vacuum logic, so one missing keeper produces one replacement.
  uint32_t warmAdvanceMs = warmLastAdvanceMs();
  bool warmUsingPeer = g_peerSeqAdvMs != 0 && g_peerSeqTk == g_tkId;
  uint32_t warmMissMs = warmUsingPeer ? tkSuccessorPeerMs() : tkSuccessorMs();
  bool warmSuccessor = (g_role == 1) && (g_successor == (uint8_t)NODE_ID)
                    && (g_lastTkHeardMs != 0) && (warmAdvanceMs != 0)
                    && ((uint32_t)(nowMs - warmAdvanceMs) > warmMissMs);
  if (warmSuccessor) {
    // warmAdvanceMs already includes authenticated advancing peer evidence,
    // and warmMissMs gives that evidence the full ten-second fade hold. A
    // second gate on any merely-recent (but no longer advancing) keepalive
    // extended a real failover by another peer-fresh window: the nine-board
    // v7.29.40 test measured 18.3 s. Once the advancing-sequence hold expires,
    // stale scheduled reports must not postpone the named successor again.
    g_warmTakeoverPending = true;
    return true;
  }
  if(ordinaryPeerProgressHolds(nowMs)){g_coldCommitSinceMs=0;return false;}
  bool tkDead = (g_lastTkHeardMs!=0) && (g_seqAdvMs!=0) && (nowMs - g_seqAdvMs > tkStallMs() + stag);
  if (tkDead) {
    // v7.28.8: a LISTEN board whose TK went silent must NOT self-elect in place
    // on the same rung. At a mass resignation every board does exactly that at
    // once and re-collides (bench 2026-08-30: ten co-booted boards, 53 rival-
    // outranked resignations, four minutes to converge). Re-walk the ladder
    // instead, so the board resyncs frame timing and either JOINS a keeper that
    // has come up on any rung or spawns cleanly on an empty one. Jittered per
    // attempt from esp_random (an independent draw per board, unlike the
    // unseeded Arduino random() used elsewhere) so co-resigned boards do not
    // re-walk in lockstep. A board that is NOT in LISTEN here (a member whose TK
    // died) keeps the old behavior and fills the vacuum in place.
    // v7.29.6 CANDIDATE STRANDING FIX. A candidate was taking the in-place branch
    // below, which returns without ever reaching the re-walk. Candidate is only
    // ever entered after true isolation (no schedule for aloneGraceMs), so by
    // definition there is no beacon on this rung to hear and the only exit was
    // winning the election outright. Blocked by a rival, the dwell guard or the
    // peer quorum, the board sat deaf forever. Stand the candidate down to LISTEN
    // here so it falls into the ladder re-walk like any isolated listener, and let
    // the existing RELISTEN_MAX_ATTEMPTS counter decide when to spawn. Never spawn
    // straight off a silent rung: the walk has to come up empty first.
    if (g_role == 2) {
      uint32_t candDwell = g_candSinceMs ? nowMs - g_candSinceMs : 0;
      // v7.29.45 CASCADING FALLBACK. The warm path normally names the next
      // live successor every frame. If several keepers are removed faster than
      // that nomination can propagate, all surviving members reach CANDIDATE
      // together. The old code made every candidate see peer quorum and stand
      // down, so the healthy survivors deadlocked indefinitely. Elect exactly
      // one survivor: a candidate may proceed only when no lower-id
      // authenticated keepalive is still fresh. Higher ids stand down and hear
      // its first schedule. A short settle lets simultaneous candidates enter
      // the same comparison before the lowest live id commits.
      uint32_t candWin = quorumWinMs();
      bool lowerLive = false;
      for (uint8_t id = 1; id < (uint8_t)NODE_ID; id++) {
        if (!keeperEligibleId(id)) continue;
        if (g_kaSeenMs[id] && (uint32_t)(nowMs - g_kaSeenMs[id]) <= candWin) {
          lowerLive = true;
          break;
        }
      }
      if (!lowerLive && candDwell >= 500UL) {
        logRec(4 /*LOG_STATE*/, NODE_ID, g_role, 0xE5,
               (int16_t)quorumFresh(nowMs), 0, candDwell);
        return true;
      }
      g_role = 0;
      g_candSinceMs = 0;
      // Fresh grace on stand-down. Without it the anchored isolation check
      // (g_role 0 or 1 past aloneGraceMs, no schedule since the keeper died)
      // re-enters CANDIDATE on the very next loop pass and this branch stands it
      // down again, flipping every pass with two log records each, the
      // ring-flood failure class of v7.28.67/68. The re-walk jitter
      // (RELISTEN_JITTER_MIN_MS + SPAN, 1.5 to 7.5 s) fires well inside the
      // ~28 s grace, so the board walks before it can re-enter candidate.
      // tkDead keys on g_seqAdvMs, not g_lastSchedMs, so this does not hide
      // the dead keeper from the re-walk path below.
      g_lastSchedMs = nowMs;
      logRec(4 /*LOG_STATE*/, NODE_ID, g_role, 0xE3, (int16_t)quorumFresh(nowMs), 0, candDwell);   // aux 0xE3 = candidate stood down to LISTEN for re-walk (dead keeper); data = ms in CANDIDATE. 0xE7 is the election roster-rung witness, do not reuse
    }
    if (g_role != 0) {
      // v7.28.60: a member (or candidate) whose keeper stalled fills the vacuum in place ONLY if its peers
      // have gone quiet too. Two or more peers still keepalive-fresh means the keeper is alive and this board
      // is the one that lost it (deaf, shadowed, or an LR1121 that cannot decode the keeper): go LISTEN,
      // mark the rung occupied so the walk below never spawns back onto this channel, and re-walk.
      uint8_t q = quorumFresh(nowMs);
      if (q < QUORUM_PEERS) {
        // v7.29.5 VACUUM LOCK. Isolated (no fresh peers) but the adopted schedule advanced
        // within VACUUM_LOCK_MS: this board just lost the mesh, the mesh did not lose its
        // keeper. Stay a member in place and keep listening so a grace carry can bring the
        // uplink home; never spawn a one-board island. Node 04, 2026-09-24 walk. When the
        // lock ages out the pre-existing in-place fill runs exactly as before.
        if (nowMs - g_seqAdvMs < VACUUM_LOCK_MS) { vacuumLockWitness(q, nowMs); return false; }
        return true;
      }
      g_role = 0; g_quorumBlocked = true; g_relistenAttempts = 0; g_relistenSinceMs = 0; g_relistenJitterMs = 0;
      logRec(4 /*LOG_STATE*/, NODE_ID, g_role, 0xE8, (int16_t)q, (int16_t)g_framesSilent, nowMs - g_seqAdvMs);   // aux 0xE8 = self-election blocked by peer quorum, e = fresh peers
      return false;
    }
    if (g_relistenAttempts >= RELISTEN_MAX_ATTEMPTS) {
      if (quorumFresh(nowMs) >= QUORUM_PEERS) { g_relistenAttempts = 0; g_quorumBlocked = true; return false; }   // v7.28.60: peers still fresh, keep walking, never spawn here
      if (nowMs - g_seqAdvMs < VACUUM_LOCK_MS) { vacuumLockWitness(quorumFresh(nowMs), nowMs); return false; }   // v7.29.5 VACUUM LOCK, LISTEN branch: same rule, see above
      return true;
    }   // v7.28.10: RELISTEN_MAX_ATTEMPTS empty re-walks; self-elect on the current rung as the last resort, the transitive tiebreak resolves co-electors
    if (g_relistenJitterMs == 0)
      g_relistenJitterMs = RELISTEN_JITTER_MIN_MS + (uint32_t)(esp_random() % RELISTEN_JITTER_SPAN_MS);
    if (g_relistenSinceMs == 0) g_relistenSinceMs = nowMs;
    if (nowMs - g_relistenSinceMs > g_relistenJitterMs) {
      g_spillReq = true;             // main loop retunes to backhaul and re-walks (spillWalkLadder)
      if (g_quorumBlocked) { g_quorumBlocked = false; }   // v7.28.60: a quorum-blocked walk excludes the current rung, same exclusion the full-lockout spill uses
      g_relistenAttempts++;          // v7.28.10: count this empty re-walk toward RELISTEN_MAX_ATTEMPTS
      g_relistenSinceMs  = 0;
      g_relistenJitterMs = 0;        // re-draw next attempt
    }
    return false;                    // never self-elect in place on a dead-TK rung
  }
  // v7.29.19: only an admitted member may challenge a live keeper. LISTEN is
  // deliberately outside the keeper's roster/trust boundary; allowing it into
  // the score handoff let a deep, still-joining board hear the healthy keeper
  // continuously and nevertheless self-elect after TK_HANDOFF_HOLD_MS.
  if (g_role != 1) { g_betterSinceMs = 0; return false; }
#if !LSM_LIVE_MERIT_HANDOFF
  // v7.29.52: the old score path promoted the challenger before the serving
  // keeper had transferred authority. On both matched nine-board runs the
  // weighted node 01 joined a healthy keeper, held its score advantage for
  // exactly six seconds, then created a second epoch and split the followers
  // until merge evidence propagated. Keep score telemetry, but do not turn it
  // into authority without a future explicit offer/accept/commit handshake.
  // Failure paths above remain unchanged and already have a named successor,
  // advancing epoch and deterministic fallback.
  g_betterSinceMs = 0;
  return false;
#endif
  // live TK present: apply the full hysteresis
  if (nowMs - g_tkSinceMs < TK_MIN_DWELL_MS) return false;   // dwell guard
  if (g_myScore < g_tkScore + TK_HANDOFF_MARGIN) { g_betterSinceMs=0; return false; }
  if (g_betterSinceMs==0) g_betterSinceMs=nowMs;             // start the hold clock
  if (nowMs - g_betterSinceMs < TK_HANDOFF_HOLD_MS) return false;  // sustained?
  return true;
}


static uint32_t g_frame = 0;
static inline uint32_t entMix(uint32_t x){ x^=x<<13; x^=x>>17; x^=x<<5; return x?x:0x9e3779b9u; }
static const char* roleStr() { return g_role == 3 ? "TK" : (g_role == 2 ? "CAND" : (g_role == 1 ? "MEM" : "LSTN")); }
NimBLECharacteristic* chLog = nullptr;
// v7.20.17: negotiated ATT MTU, updated from SrvCB::onMTUChange. 23 is the
// spec floor and the value before any negotiation, which yields the old
// 96 byte frame, so an un-negotiated link behaves exactly as it did.
volatile uint16_t g_bleMtu = 23;
volatile bool g_dumpReq = false, g_eraseReq = false;

int16_t clamp_i16(long v) {
  if (v >  32767) return  32767;
  if (v < -32768) return -32768;
  return (int16_t)v;
}
// Convert current lat/lon to east/north centimeters from the origin.
void offsetCm(double lat, double lon, int16_t& eastCm, int16_t& northCm) {
  double east_m  = (lon - lon0) * 111320.0 * cos(lat0 * M_PI / 180.0);
  double north_m = (lat - lat0) * 111320.0;
  eastCm  = clamp_i16(lround(east_m  * 100.0));
  northCm = clamp_i16(lround(north_m * 100.0));
}

// ----------------------- TFT display -----------------------
// v7.29.13: node 11 display timeout, restored. Present in v7.29.5 and v7.29.6 as node 11
// only source, lost when the fleet went to one byte-identical main64.cpp. Now a role
// flag: -D LSM_DISPLAY_TIMEOUT=1 in node 11's ini only, default 0. Backlight goes off
// after the boot splash; a press of the BOOT button (GPIO0) lights it for 15 s. Only the
// backlight switches, the TFT keeps drawing, so loop timing is unchanged. Measured on
// v7.29.5: 0.695 W with the screen off against 0.81 W, mesh-safe over 46 min.
#ifndef LSM_DISPLAY_TIMEOUT
#define LSM_DISPLAY_TIMEOUT 0
#endif
#if LSM_DISPLAY_TIMEOUT
#define DISPLAY_TIMEOUT_MS 15000UL
static volatile uint32_t g_displayOffAtMs = 0;         // when to turn the backlight off, 0 = already off
static volatile bool g_displayWakeRequested = false;   // ISR sets, loop clears
static void IRAM_ATTR gpio0_isr_handler(void) { g_displayWakeRequested = true; }
static void displayTimeoutTick(uint32_t nowMs) {
  if (g_displayWakeRequested) {
    g_displayWakeRequested = false;
    digitalWrite(PIN_TFT_BL, HIGH);
    g_displayOffAtMs = nowMs + DISPLAY_TIMEOUT_MS;
  }
  if (g_displayOffAtMs > 0 && (int32_t)(nowMs - g_displayOffAtMs) >= 0) {
    digitalWrite(PIN_TFT_BL, LOW);
    g_displayOffAtMs = 0;
  }
}
#endif
#ifdef LSM_BOARD_LILYGO
// v7.28.47: ST7796 222x480 through Arduino_GFX, exactly the vendor GFX example
// (Arduino_HWSPI on the shared FSPI pins, column offset 49, IPS true). The
// 160x80 layout below draws into the top left of the 480x222 landscape canvas
// at the same pixel positions; readable, not redesigned. Rotation 3 matches
// the vendor example orientation.
static Arduino_DataBus *lsmTftBus = new Arduino_HWSPI(PIN_TFT_DC, PIN_TFT_CS, PIN_TFT_SCLK, PIN_TFT_MOSI, PIN_TFT_MISO, &SPI, true);
// v7.28.51: every page in this file is laid out for the 160x80 Heltec glass.
// On the 480x222 LilyGO panel the same layout is scaled 2.5x: cursor
// coordinates and text sizes go through lsmTs(), so 160x80 becomes 400x200
// inside 480x222 and the size 4 badge line becomes size 10 (80 px tall).
// Nothing in the page code changes; the wrapper hides the two setters.
static inline int16_t lsmTs(int16_t v) { return (int16_t)((v * 5) / 2); }
class LsmTft : public Arduino_ST7796 {
public:
  using Arduino_ST7796::Arduino_ST7796;
  void setCursor(int16_t x, int16_t y) { Arduino_ST7796::setCursor(lsmTs(x), lsmTs(y)); }
  void setTextSize(uint8_t s)          { Arduino_ST7796::setTextSize((uint8_t)((s * 5) / 2)); }
};
static LsmTft tft(lsmTftBus, PIN_TFT_RST, 0, true, 222, 480, 49, 0, 0, 0);
static uint32_t g_tftDraws = 0;    // v7.28.51: pages painted since boot, serial witness once a second
static uint32_t g_tftReinits = 0;  // v7.28.51: panel re-inits since boot

// v7.28.51: full panel re-init (reset, init sequence, rotation, clear). The
// ST7796 keeps its frame memory across a controller upset, so a panel that
// has stopped taking commands still shows the last picture: a frozen glass
// with a live radio. Re-init is the recovery. Fires on every USER tap; the
// periodic form is behind LSM_TFT_REINIT_S (seconds, 0 = off) because the
// init sequence holds the bus for well over 100 ms and that is not free for
// a keeper.
static void lsmTftReinit() {
  tft.begin();
  tft.setRotation(3);
  tft.fillScreen(ST77XX_BLACK);
  tft.setTextWrap(false);
  g_tftReinits = g_tftReinits + 1;
}

void setupTFT() {
  // v7.28.51: backlight on the LEDC peripheral, exactly the vendor GFX and
  // Original_Test examples (2 kHz, 8 bit, full duty). Was a plain HIGH.
  ledcAttach(PIN_TFT_BL, 2000, 8);
  ledcWrite(PIN_TFT_BL, 255);
  tft.begin();
  tft.setRotation(3);              // landscape, 480 wide by 222 tall
  tft.fillScreen(ST77XX_BLACK);
  tft.setTextWrap(false);
#elif defined(LSM_BOARD_V4)
// v7.28.84: V4 board SSD1306 OLED I2C display (128x64)
static Adafruit_SSD1306 tft(128, 64, &Wire, -1);
static inline int16_t lsmTs(int16_t v) { return v; }
static volatile bool g_displayOk = false;

static void lsmTftReinit() {
  // no reinit for OLED
}

void setupTFT() {
  g_displayOk = false;
  // power on delay
  delay(100);
  // RST pin control: HIGH -> LOW -> HIGH
  pinMode(PIN_OLED_RST, OUTPUT);
  digitalWrite(PIN_OLED_RST, HIGH);
  delay(10);
  digitalWrite(PIN_OLED_RST, LOW);
  delay(10);
  digitalWrite(PIN_OLED_RST, HIGH);
  // init I2C with explicit pins, 400kHz
  Wire.begin(PIN_OLED_SDA, PIN_OLED_SCL, 400000);
  // init SSD1306 with 50ms timeout
  uint32_t startMs = millis();
  while (!tft.begin(SSD1306_SWITCHCAPVCC, 0x3C) && (millis() - startMs) < 50) {
    delay(10);
  }
  if (tft.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    g_displayOk = true;
    // v7.28.87: full splash on the 128x64 OLED so brand, version and badge id
    // are readable during a fleet reflash. SSD1306 is buffered, flush once.
    tft.clearDisplay();
    tft.setTextColor(SSD1306_WHITE);
    tft.setTextSize(2);
    tft.setCursor(0, 0);
    tft.println("LSMESH");
    tft.setTextSize(1);
    char ver[24];
    snprintf(ver, sizeof(ver), "V%u.%u.%u pv7", (unsigned)FW_MAJOR, (unsigned)FW_MINOR, (unsigned)FW_PATCH);
    tft.setCursor(0, 22);
    tft.println(ver);
    char lab[24];
    snprintf(lab, sizeof(lab), "%s %s", BADGE_NUM, roleStr());
    tft.setCursor(0, 40);
    tft.println(lab);
    tft.display();
    delay(5000);
  }
#else
static SPIClass tftSPI(HSPI);
static Adafruit_ST7735 tft(&tftSPI, PIN_TFT_CS, PIN_TFT_DC, PIN_TFT_RST);
static inline int16_t lsmTs(int16_t v) { return v; }   // v7.28.51: identity on the 160x80 glass

void setupTFT() {
  pinMode(PIN_TFT_BL, OUTPUT);
  digitalWrite(PIN_TFT_BL, HIGH);
  tftSPI.begin(PIN_TFT_SCLK, -1, PIN_TFT_MOSI, PIN_TFT_CS);
  tft.initR(INITR_MINI160x80);
#if TFT_INVERT
  tft.invertDisplay(true);
#endif
  tft.setRotation(1);              // landscape, 160 wide by 80 tall
  tft.fillScreen(ST77XX_BLACK);
  tft.setTextWrap(false);
#endif

#ifndef LSM_BOARD_V4
  // v6.1 splash per Stu 2026-07-04: LSMESH brand large, version under it,
  // badge id on the third line, held 4 seconds so the glass verification is
  // readable during a fleet reflash. 160x80 landscape: size 3 is 18 px per
  // char, LSMESH is 6 chars = 108 px, fits with margin.
  tft.setTextSize(3);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.setCursor(26, 4);
  tft.print("LSMESH");
  char ver[20];
  snprintf(ver, sizeof(ver), "V%u.%u.%u pv7", (unsigned)FW_MAJOR, (unsigned)FW_MINOR, (unsigned)FW_PATCH);
  tft.setTextSize(2);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.setCursor(40, 34);
  tft.print(ver);
  char lab[16];
  snprintf(lab, sizeof(lab), "%s %s", BADGE_NUM, roleStr());
  tft.setTextSize(2);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.setCursor(40, 58);
  tft.print(lab);
  delay(5000);                     // hold 5 s, glass verification per Stu
#if LSM_DISPLAY_TIMEOUT
  digitalWrite(PIN_TFT_BL, LOW);   // v7.29.13: node 11 role flag, backlight off after the splash
  g_displayOffAtMs = 0;
  if(g_irqPolicyVerified)attachInterrupt(PIN_USER_BTN, gpio0_isr_handler, FALLING);   // BOOT wake
#endif
#endif  // shared ST7735 splash, skipped on V4 (V4 draws its own above)
}

// One second refresh. Text is drawn with a background color so each line
// overwrites the last one in place, no full screen clear, no flicker.
// v7.20.4 V2 battery readout (DISPLAY ONLY, NOT wired to the election). Ported
// from the V4 BATT page. Heltec Wireless Tracker V1.1 datasheet: VBAT on GPIO1
// (ADC1_CH0), ADC control on GPIO2, VBAT = Vbat_Read * 4.9. The ADC pin and the
// 4.9 divider are DATASHEET-CONFIRMED; the ENABLE POLARITY is the one remaining
// guess -- flash one board, click to the BATT page, read raw + volts against a
// known-FULL pack. Near 4.20 V = correct. 0/stuck raw = flip VBAT_EN_ACTIVE (or
// wrong pin); plausible raw but wrong volts = adjust VBAT_DIVIDER. battPct() (the
// election stub) is UNCHANGED (still 100), so the mesh election is untouched;
// only the glass shows this live value.
#ifndef PIN_VBAT_ADC
#define PIN_VBAT_ADC     1        // GPIO1, ADC1_CH0 (Wireless Tracker datasheet)
#endif
#ifndef PIN_VBAT_EN
#define PIN_VBAT_EN      2        // GPIO2, ADC Ctrl (Wireless Tracker datasheet)
#endif
#ifndef VBAT_EN_ACTIVE
#define VBAT_EN_ACTIVE   HIGH     // level that switches the divider ON (best guess)
#endif
#ifndef VBAT_DIVIDER
#define VBAT_DIVIDER     4.9f     // VBAT = Vbat_Read * 4.9 (Wireless Tracker datasheet)
#endif
volatile uint16_t g_battRaw  = 0;      // last raw ADC count 0..4095
volatile float    g_battVolt = 0.0f;   // last computed pack voltage
volatile uint8_t  g_battShow = 0;      // last computed percent, glass only
volatile uint16_t g_battMv   = 0;      // v7.20.6: last pack millivolts, for LOG_HEALTH
volatile int16_t  g_dieTempC = 0;      // v7.20.6: ESP32-S3 internal die temp, centi-degrees C, sampled 1/s
static void battService() {            // call once per second from the 1 s tick
#ifdef LSM_BOARD_LILYGO
  // v7.28.47: the LilyGO pack voltage lives behind the SY6970 PMIC on I2C, not
  // on an ADC divider, and GPIO 1/2 are the microphone lines on this board.
  // Report a full pack so the election battery term is neutral; wiring the
  // SY6970 read (vendor Arduino_DriveBus, examples/SY6970) is its own cut.
  g_battRaw = 0; g_battVolt = 4.20f; g_battShow = 100; g_battMv = 4200;
  g_battPctSmooth = 100;
  return;
#endif
  pinMode(PIN_VBAT_EN, OUTPUT);
  digitalWrite(PIN_VBAT_EN, VBAT_EN_ACTIVE);                 // enable divider
  delay(2);                                                  // settle
  uint16_t raw = (uint16_t)analogRead(PIN_VBAT_ADC);         // 0..4095
  uint32_t mv  = analogReadMilliVolts(PIN_VBAT_ADC);         // calibrated mV at pin
  digitalWrite(PIN_VBAT_EN, (VBAT_EN_ACTIVE == HIGH) ? LOW : HIGH); // stop drain
  float v = (mv / 1000.0f) * VBAT_DIVIDER;
  float p = (v - 3.30f) / 0.90f * 100.0f;                    // 3.30 V=0%, 4.20 V=100%
  if (p < 0.0f)   p = 0.0f;
  if (p > 100.0f) p = 100.0f;
  g_battRaw = raw; g_battVolt = v; g_battShow = (uint8_t)(p + 0.5f); g_battMv = (uint16_t)(v * 1000.0f + 0.5f);
  g_battPctSmooth = (uint8_t)(((uint16_t)g_battPctSmooth * 7 + g_battShow) / 8);  // v7.28.9: ~8 s EMA, smooths TX-burst sag
}
void drawStatusBatt() {
  char l1[20]; snprintf(l1, sizeof(l1), "BATT %u%%", (unsigned)g_battShow);
  char l1p[20]; snprintf(l1p, sizeof(l1p), "%-10.10s", l1);
  tft.setTextSize(2);
  tft.setTextColor(g_battShow > 20 ? ST77XX_GREEN : ST77XX_RED, ST77XX_BLACK);
  tft.setCursor(2, 4);
  tft.print(l1p);

  char l2[24]; snprintf(l2, sizeof(l2), "raw %u", (unsigned)g_battRaw);
  char l2p[24]; snprintf(l2p, sizeof(l2p), "%-21.21s", l2);
  tft.setTextSize(1);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.setCursor(2, 32);
  tft.print(l2p);

  char l3[20]; snprintf(l3, sizeof(l3), "%.2f V", g_battVolt);
  char l3p[20]; snprintf(l3p, sizeof(l3p), "%-10.10s", l3);
  tft.setTextSize(2);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.setCursor(2, 48);
  tft.print(l3p);
}

void drawStatus() {
  bool locked = g_haveRealFix && gps.location.isValid();   // v7.28.64

  // line 1: badge ID and live elected role, large print
  char lab[10], labp[10];
  snprintf(lab, sizeof(lab), "%s %s", BADGE_NUM, roleStr());
  snprintf(labp, sizeof(labp), "%-6.6s", lab);
  tft.setTextSize(4);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.setCursor(4, 2);
  tft.print(labp);

  // line 2: lock state, satellite count, battery
  char l2[20];
  if (!g_radioOk) {
    snprintf(l2, sizeof(l2), "RF FAIL %-5d", (int)g_radioRc);
    tft.setTextSize(2);
    tft.setTextColor(ST77XX_RED, ST77XX_BLACK);
    tft.setCursor(2, 38);
    tft.print(l2);
  } else {
    // v7.28.104: glass shows HOPS TO THE TK for this board, and nothing else.
    // 0 = this board is the TK. 1 = hears the TK directly. 2 = one relay behind
    // that. Painted as g_anchorHops + 1 (g_anchorHops is 0 on a direct board).
    // Dash = no live path: no schedule
    // has ever been heard, or the beacon path just dropped, so the glass never
    // shows a hop count from a dead route. g_hopsToCmd (the command scalar) is
    // deliberately NOT read here; it is reserved for later node-identity work.
    // Display path only: election score and join escalation are untouched.
    bool schedLive = (g_lastSchedMs != 0) && (millis() - g_lastSchedMs) <= aloneGraceMs();
    uint8_t hcv = (g_role == 3) ? 0 : ((schedLive && g_anchorHops != 255) ? (uint8_t)(g_anchorHops >= 8 ? 9 : g_anchorHops + 1) : 255);   // links to the TK: g_anchorHops is 0 for a board that hears the TK directly, so +1. Keeper 0, direct 1, one relay 2, cap 9.
    char hc = (hcv == 255) ? '-'
              : (hcv > 9 ? '9' : (char)('0' + hcv));
    snprintf(l2, sizeof(l2), "%s%2lu %02u N%u H%c",
             locked ? "LK" : "AQ",
             (unsigned long)gps.satellites.value(),
             (unsigned)g_tkId, (unsigned)(g_role==3?g_rosterN:g_sphereCount), hc);
    tft.setTextSize(2);
    tft.setTextColor(locked ? ST77XX_GREEN : ST77XX_YELLOW, ST77XX_BLACK);
    tft.setCursor(2, 38);
    tft.print(l2);
  }

  // line 3: RF path, full time as of v4.8. T = beacons sent and R = packets
  // received, both shown mod 1000 so a long run never pushes the RSSI off
  // the 13 character line. RSSI is the last packet heard, shown as a
  // magnitude: 102 on the glass means -102 dBm, the log keeps the sign.
  // A transmit error replaces the RSSI with E and the unsigned code.
  // Yellow until a peer is heard, cyan once the mesh is alive. The GPS
  // offset readout came off this line in v4.8, position still flows to
  // the dashboard and the log unchanged.
  char l3[24];
  char tmp[24];
  if (g_lastTxErr != 0)
    snprintf(tmp, sizeof(tmp), "T%03lu R%03lu E%d",
             (unsigned long)(g_seq % 1000), (unsigned long)(g_rxCount % 1000),
             (int)(g_lastTxErr < 0 ? -g_lastTxErr : g_lastTxErr));
  else
    snprintf(tmp, sizeof(tmp), "T%03lu R%03lu %d",
             (unsigned long)(g_seq % 1000), (unsigned long)(g_rxCount % 1000),
             (int)(g_lastRssi < 0 ? -g_lastRssi : g_lastRssi));
  snprintf(l3, sizeof(l3), "%-13.13s", tmp);
  tft.setTextSize(2);
  tft.setTextColor(g_peersHeard == 0 ? ST77XX_YELLOW : ST77XX_CYAN, ST77XX_BLACK);
  tft.setCursor(2, 60);
  tft.print(l3);
}

// v7.12.6: info screen. Flips in every 5 s alongside drawStatus(), same
// overwrite-in-place style (background color per draw call, no full clear).
// Shows firmware version and the GPS/offset numbers that used to be serial
// only (E/N offset came off the main screen in v4.8, see offsetCm(); Z is
// new this pass, alt0 baseline captured alongside lat0/lon0). Lat/lon get
// their own line at size 1 so full 6 decimal precision fits; version and
// offset stay at size 2 since those are the two things worth reading at a
// glance. Worst-case large offsets can run past the 13-char size-2 budget
// and get clipped by the field width, same known tradeoff as the E/N-only
// version of this screen, now shared by the Z term too.
int16_t altitudeCmNow();   // v7.12.6 fix: forward declare, real definition is further down the file, drawStatusInfo() is called before it otherwise
void drawStatusInfo() {
  char verl[20];
  snprintf(verl, sizeof(verl), "V%u.%u.%u", (unsigned)FW_MAJOR, (unsigned)FW_MINOR, (unsigned)FW_PATCH);
  char verp[20];
  snprintf(verp, sizeof(verp), "%-10.10s", verl);
  tft.setTextSize(2);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.setCursor(2, 4);
  tft.print(verp);

  // v7.12.8: raw location, no fix-valid gate. Stu wants whatever the module
  // currently has, even 0,0 before any fix ever lands, or a stale last-known
  // pair if the fix was lost, since this is the raw-data screen, not the
  // "can I trust this" screen (that judgement stays on the main status
  // screen's LK/AQ indicator).
  char gpsl[24];
  snprintf(gpsl, sizeof(gpsl), "%.6f,%.6f", gps.location.lat(), gps.location.lng());
  char gpsp[24];
  snprintf(gpsp, sizeof(gpsp), "%-22.22s", gpsl);
  tft.setTextSize(1);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.setCursor(2, 32);
  tft.print(gpsp);

  char offl[24];
  if (!gps.location.isValid())
    snprintf(offl, sizeof(offl), "NO FIX");
  else if (!originSet)
    snprintf(offl, sizeof(offl), "NO ORIGIN");
  else {
    int16_t e = 0, n = 0;
    offsetCm(gps.location.lat(), gps.location.lng(), e, n);
    if (altOriginSet)
      snprintf(offl, sizeof(offl), "E%dN%dZ%d", (int)e, (int)n, (int)(altitudeCmNow() - alt0));
    else
      snprintf(offl, sizeof(offl), "E%dN%d", (int)e, (int)n);
  }
  char offp[24];
  snprintf(offp, sizeof(offp), "%-13.13s", offl);
  tft.setTextSize(2);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.setCursor(2, 48);
  tft.print(offp);
}

// v7.12.12: third auto-flip screen, actual tuned radio frequency plus any
// pending hop. g_currentFreqMHz is the real thing (updated only after a
// successful radio.setFrequency), not the pending target, so this always
// reads what the radio is actually sitting on right now, not what it is
// about to move to.
void drawStatusFreq() {
  char fl[20];
  snprintf(fl, sizeof(fl), "%.3f", g_currentFreqMHz);
  char flp[20];
  snprintf(flp, sizeof(flp), "%-10.10s", fl);
  tft.setTextSize(2);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.setCursor(2, 2);
  tft.print(flp);

  // v7.20.4: TX power on the glass. LORA_DBM is a COMPILE-TIME constant, so this
  // is a build-confirmation readout (same spirit as the splash version) -- it
  // never changes at runtime. Its job is to prove at a glance that a board booted
  // at the intended power, especially when stepping 0 -> -3 -> -6 -> -9 on the
  // bench. Frequency (cyan) and power (white) now sit together on the RF page.
  char pw[16];
  snprintf(pw, sizeof(pw), "TX %ddBm", (int)LORA_DBM);
  char pwp[16];
  snprintf(pwp, sizeof(pwp), "%-10.10s", pw);
  tft.setTextSize(2);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.setCursor(2, 24);
  tft.print(pwp);

  char pl[24];
  if (g_freqCountdown != 0xFF)
    snprintf(pl, sizeof(pl), "->%.1f T%u", g_freqTargetMHz, (unsigned)g_freqCountdown);
  else
    snprintf(pl, sizeof(pl), "STABLE");
  char plp[24];
  snprintf(plp, sizeof(plp), "%-10.10s", pl);
  tft.setTextSize(2);
  tft.setTextColor(g_freqCountdown != 0xFF ? ST77XX_YELLOW : ST77XX_GREEN, ST77XX_BLACK);
  tft.setCursor(2, 46);
  tft.print(plp);
}

// v7.12.26 trim screen: fourth page on the USER-tap cycle. Shows the applied
// lead adjustment (green once the session has locked a converged value), the
// live rolling average residual, the clean-sample count, and the reject count.
void drawStatusTrim() {
  int32_t avg = g_trimCount ? (int32_t)(g_trimSum / (int32_t)g_trimCount) : 0;
  char l1[20]; snprintf(l1, sizeof(l1), "TRIM %d", (int)g_trimAdjUs);
  char l1p[20]; snprintf(l1p, sizeof(l1p), "%-11.11s", l1);
  tft.setTextSize(2);
  tft.setTextColor(g_trimLocked ? ST77XX_GREEN : ST77XX_CYAN, ST77XX_BLACK);
  tft.setCursor(2, 4);
  tft.print(l1p);

  char l2[28]; snprintf(l2, sizeof(l2), "adj us  n%u rej%lu", (unsigned)g_trimCount, (unsigned long)g_trimReject);
  char l2p[28]; snprintf(l2p, sizeof(l2p), "%-23.23s", l2);
  tft.setTextSize(1);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.setCursor(2, 32);
  tft.print(l2p);

  char l3[20]; snprintf(l3, sizeof(l3), "avg %d", (int)avg);
  char l3p[20]; snprintf(l3p, sizeof(l3p), "%-11.11s", l3);
  tft.setTextSize(2);
  tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);
  tft.setCursor(2, 48);
  tft.print(l3p);
}

// ----------------------- flash circular log -----------------------
// Every packet, vote, and state transition lands in onboard flash from day one.
// Two 512 KB files alternate as a circular buffer. Records are fixed 16 bytes.
// Readable over USB serial (send D) and over BLE (write 0x01 to the log
// characteristic). Send E over serial or write 0x02 over BLE to erase.

// v7.13.1: passive loop-period accumulators. Reset every 1 s tick.
static uint32_t g_lpMaxUs = 0;
// v7.28.27: loop-stall attribution. Each top-level errand in loop() is
// bracketed; the id of the longest single errand in the 1 s window lands in
// LOG_LOOP aux. Ids: 1 GNSS drain, 2 radioPoll, 3 frameEngine, 4 tailFlush,
// 5 bhTailErrand, 6 one-second tick, 7 dumpService, 8 deferred spill walk.
static uint32_t g_secMaxUs = 0;
static uint8_t  g_secMaxId = 0;
static inline void secNote(uint8_t id, int64_t t0) {
  uint32_t d = (uint32_t)(esp_timer_get_time() - t0);
  if (d > g_secMaxUs) { g_secMaxUs = d; g_secMaxId = id; }
}

static uint64_t g_lpSumUs = 0;
static uint32_t g_lpCnt   = 0;
// v7.13.1: airtime witness. The radio driver computes on-air time from the PHY
// actually programmed into the chip.
// v7.20.20: THIS IS NO LONGER EVIDENCE ONLY and is no longer a removal
// candidate. It now drives the TK's arrival reconstruction in the member data
// path, because the constant it was placed here to check turned out to be wrong
// by 20576 us and had been silently inflating the scheduling profile for the
// whole life of the witness. Frame geometry still runs on the compile time
// constants; the ONE consumer is the RxDone to packet START correction. The
// fixed to dynamic hazard behind the v7.9-v7.10 bug run is respected by keeping
// the fallback equal to the compile time value, so a board that somehow reaches
// this path before radioConfig behaves exactly as it did before.
static uint32_t g_airWitnessUs = 0;   // radio-reported airtime for sizeof(MemberPkt), 0 = not yet read
// v7.28.72-symbvalid: receiver validation state for the aux 17 boot witness and
// the aux 18 per-second witness. Counters are cumulative; the per-second record
// carries the delta.
static int16_t  g_symbValidRc  = -999;   // status of the last SetLoRaSymbNumTimeout, -999 = never issued
static uint8_t  g_symbValidCmd = 0;      // encoded command byte actually sent
static uint8_t  g_symbValidReg = 0;      // encoded 0x0706 byte actually written (SX1262 only)
static uint32_t g_rxSymbTimeout = 0;     // TIMEOUT IRQs serviced with no RX_DONE (a validation that fell through and dropped the chip out of receive)
static uint32_t g_abortNoRearm  = 0;
static uint32_t g_rxNoRearm     = 0;     // v7.28.77: clean receives serviced WITHOUT a startReceive (LSM_RX_STAY path)
#ifndef LSM_RX_STAY
#define LSM_RX_STAY 1                    // v7.28.77: 1 = stay in continuous receive after a clean packet, 0 = v7.28.75 trailing re-arm
#endif     // header aborts serviced WITHOUT a startReceive (v7.28.72 abort path)
static int32_t  g_airWitnessDev = 0;  // witness - AIRTIME8_US, us
#define LOG_BOOT  1
#define LOG_TX    2
#define LOG_RX    3
#define LOG_STATE 4
#define LOG_VOTE  5
#define LOG_LOCK  6
#define LOG_STALL 7   // loop froze, data = stall length in ms
#define LOG_RF    8   // radio api error, aux 0 = tx, aux 1 = reinit, aux 2 = backhaul
                      // freq-hop error, data = code. v7.13.1 adds aux 3 = PASSIVE airtime
                      // witness (NOT an error): e = getTimeOnAir(sizeof(MemberPkt)) minus
                      // AIRTIME8_US in us (clamped), n = sizeof(MemberPkt), data = witness us.
#define LOG_DRIFT 9   // superframe sync: aux = frames spanned, e = drift ms,
                      // n = own TX offset in frame ms (-1 none), data = TK seq
                      // v7.28.63: role 11 = keeper arrival witness. aux = slot,
                      // e = member frame start vs the keeper's slot start in us,
                      // n = 0, data = raw arrivalOffUs. Roles 1 and 10 are
                      // documented at their emit sites in tkOnData. Host side
                      // decoders must not fold role 11 into the role 1 delay.
#define LOG_PWR   10  // soft power event, aux 0 = entering off, 1 = wake from off
#define LOG_RSYNC 11  // relayed anchor adopted: nodeId = relayer, aux = tkId,
                      // e = residual ms vs prior anchor, n = relayer hops,
                      // data = relayer seq, rssi and snr of the relay packet
#define LOG_TRIM  12  // v7.12.25 observe-only slot-time trim. aux = granted slot,
                      // e = devUs = actual air departure minus scheduled slot start
                      // (us, clamped int16), data = dOff = actual departure offset
                      // from the shared frame anchor (us). No wire change.

// 24 byte record, locked for the future x, y, z position pipeline to the
// command center. Every record carries this badge's own floor and altitude
// at the moment of the event, plus per packet RF quality on RX and DRIFT.
// The record grew from 16 bytes, so logs written by older firmware are
// unreadable. logInit auto erases files that are not a multiple of 24, and
// the standing rule still applies: hold the button at power on after every
// reflash to wipe the log.
#define LOG_CTOK  13  // ctok 2026-07-21 token event. aux 1=ACCEPT 2=REJECT 3=baseline 4=announce 5=peer 6=request 7=mint; nodeId=peer/self; e=accept tally clamped; n=reject tally clamped; data=seq or peer id
#define LOG_LOOP  15  // v7.13.1 PASSIVE loop-period instrumentation, 1 s window.
#define LOG_HEALTH 16  // v7.20.6: 1/s baseline. aux=TX dBm; e=die temp centi-deg C; n=batt raw ADC 0..4095; data=pack millivolts
#define LOG_FSOP   17  // v7.20.12: filesystem maintenance witness. aux 1 = inline wrap erase (TK slow path, timed), 2 = pre-erase of the spare half off the hot path, 3 = clean wrap swap (spare was pre-erased), 4 = plain append that blocked over 150 ms (LittleFS GC suspect). e = active half KiB at the event, data = op duration ms. v7.28.33: aux 9 = per-flush witness, e = start offset into frame (100 us, -1 no anchor), n = duration (100 us), data = bytes | caller<<16 | records<<20.
                      // aux = 0; e = max loop period this window (us, clamped int16);
                      // n = mean loop period (us, clamped); data = iteration count.
                      // Pure observation, feeds no control path. Exists to give
                      // sub-500ms visibility that LOG_STALL cannot: STALL only fires
                      // above 500 ms, so a 10-20 ms housekeeping excursion was
                      // previously invisible. CANDIDATE FOR REMOVAL if the bench
                      // shows max loop period is uneventful.
#define LOG_GPS    18  // v7.20.23: 1/s NMEA link health. aux = sentence type bitmask (1 GGA, 2 RMC, 4 GSA, 8 GSV, 0x10 VTG, 0x20 GLL, 0x40 ZDA, 0x80 other); e = sentences passing checksum this window; n = sentences failing checksum; data = bytes in bits 0-15, truncated sentence count in bits 16-23, satellites in view in bits 24-31.
#define LOG_TPUT  14  // ctok 2026-07-21 throughput, 1s window. aux=rx pkts/s; e=rx bytes/s goodput; n=distinct peers heard; data=cumulative rx count
#define LOG_POS   22  // v7.28.64: position source witness. Emitted on every state change and once per second while a position is held. aux = state (0 none, 1 raw provisional, 2 real, 3 real held/decaying on a weak or absent fix), e = conf64 reported, n = HDOP in hundredths clamped (0 if unknown), data = satellites in bits 0-7, x_dm as int8 in bits 8-15, y_dm as int8 in bits 16-23, reseed jump in metres clamped 255 in bits 24-31 (nonzero only on the raw to real transition). Host decoders: a state 1 record means the offset is against a provisional origin and must not be plotted as ground truth.
#define LOG_SEED  24  // v7.28.66: absolute position seed logging. Lat/lon in microdegrees (int32 each), altitude in decimetres (int16), confidence in aux. Emitted whenever position updates. e and n fields carry lat/lon, data carries alt in bits 0-15 and confidence in bits 16-23.
#define LOG_POSABS 31  // v7.29.6: own absolute position witness at FULL microdegree precision, emitted alongside LOG_POS. latI (int32 microdeg) in data, lonI split high/low across e and n int16 fields, sats in aux. About 0.1 m resolution, unlike the coarse ~110 m LOG_RXABS. Exists because LOG_POS carries only clamped int8 decimetre offsets, which pinned at the rail on 97-98 percent of records on the 2026-09-24 walk. conf/state/HDOP are in the sibling LOG_POS at the same ms.
#define LOG_RXABS 27  
#define LOG_MESH  30  // v7.28.101: RELAY MEASUREMENT WITNESS. Once per second from tputService, beside LOG_TOPO.
// This is the record that answers "is the mesh actually relaying, and for whom" without
// cross-referencing four other types. Its own type on purpose: LOG_TOPO already packs three
// reject deltas into its data word and carries the tier geometry, so bolting relay identity
// onto it would make both harder to decode and leave no room to widen either one later.
//   aux  = deepest MemberPkt.hops this board saw in the last second (0 = nothing relayed to it).
//          CEILING IS 1, structurally: a beacon carries exactly one relayForId/relayById
//          pair, so one member gets one relay leg per frame and hops cannot reach 2 under
//          the current exclusive-grant design. Read a 1 as working, not as falling short.
//          This is ALSO not the same number as g_anchorHops in bits 24..31 below, which is
//          SCHEDULE flood depth and does climb past 1. Do not conflate the two when grading.
//   e    = relayForId from the last named grant this board saw (0 = none)
//   n    = relayById from that same grant (0 = none)
//   data = orphan count in bits 0..7   (slots the keeper has NOT heard that THIS board CAN hear)
//        | joiners cached in bits 8..15 (g_aggN, this board's funnel backlog)
//        | windows asked in bits 16..23 (the last swarm request this board sent, 0 = never)
//        | this board's own depth in bits 24..31 (g_anchorHops, 255 = no schedule adopted)
// A board that is relaying shows a nonzero aux; a board that is FUNNELLING shows a nonzero
// cached count and a nonzero windows-asked. Those two together are the birth-frame path
// working end to end, and their absence is the specific thing to look for if it is not.
#define LOG_TOPO  29  // v7.28.96: TOPOLOGY AND REJECT WITNESS. Once per second from tputService, alongside LOG_TPUT.
                      // Carries the state that decides relay depth and the three counters for beacons thrown away, none of
                      // which reached flash before this cut. aux = g_anchorHops (this node's adopted depth to its TK, 255 =
                      // none). e = g_schedTiers in force. n bits 0-7 = g_peersHeard, bit 8 = g_joinFloodMode. data packs the
                      // three reject counters as deltas since the previous record: bits 0-9 depth, bits 10-19 stale,
                      // bits 20-29 worse, each saturating at 1023. Deltas not totals, so a burst is visible in place
                      // rather than having to be differenced across the whole dump.
#define LOG_RXARM 28  // v7.28.91: RX ARM LATENCY WITNESS. Mirrors LOG_TXLAT for the receive turnaround in radioPostTxReset. The settle-delay theory was GRADED FAIL in v7.28.40/41, so this adds and grows NO delay; it only MEASURES the existing tx->rx dead window. aux = 4 if this board has ever sampled, else 0; e = EWMA total turnaround dead window in us (radio.standby() to receiver armed, and it INCLUDES TX_STANDBY_SETTLE_US and RX_ARM_SETTLE_US); n = the bare startReceive() command time from the last sample in us (the chip cost, separate from the fixed no-op settles); data = sample count, saturating. Emitted 1 in 16 transmits on the SAME txDoneWitness gate as LOG_TXLAT, so no extra flash pressure.// v7.28.70-absposbranch: RENUMBERED 25 to 27. 25 was already live as LOG_RELAY_POS (v7.28.67, emitted at the sendPeerPositions site) with a different field layout, so a decoder could not tell the two apart. 26 is TXLAT, so RXABS is 27. RECEIVED peer absolute from a type 0 member packet. Additive; does NOT touch LOG_RX (host decoders expect the offset layout there). aux = conf64; e = latI/100000; n = lonI/100000; data bits 8-15 = (latI/1000)%100, bits 16-23 = (lonI/1000)%100, bits 24-31 = conf. Coarse to ~0.001 deg (~110 m), enough to watch a mile-apart node move on the drive; full precision is in the sender own LOG_SEED and the paired-node BLE feed.
#define LOG_TXLAT 26  // v7.28.70-absposbranch: TX ENGAGE LATENCY WITNESS. CORRECTION 2026-09-16: an earlier draft of this comment said engage latency is the quantity SLOT_GUARD_US guesses at. That was wrong. Engage sizes the transmit LEAD (engLeadS = g_txLatUs + TX_ENGAGE_US + g_trimAdjUs), not the guard: the transmit is started g_txLatUs ahead of the slot so the packet radiates on the boundary. The guard is sized by the residual departure error (departDevUs), a separate quantity. The 2026-09-16 beach capture measured engage at about 7 ms fleet-wide, fully compensated by the lead, median departure error 5 us. g_txLatUs has always existed and led the transmit, but was never logged, so no capture could report it. aux = 4 if this board has ever sampled, 0 if not; e = g_txLatUs (EWMA engage latency, us); n = the last raw sample this frame (us); data = sample count, saturating. Emitted 1 in 16 transmits on the SAME gate as txDoneWitness, deliberately: the v7.28.67 per-loop GPS record flooded the ring and caused the v7.28.68 multi-keeper fracture, so no new record ships ungated.
#define LOG_RELAY_POS 25  // v7.28.67: relay position from peers in the mesh. nodeId = source peer id, aux = peer conf, e and n carry lat/lon, data carries alt in bits 0-15.

// Payload-path A/B instrumentation.  This is deliberately RAM-only and uses
// the production encrypted MemberPkt sequence; it changes no packet bytes.
#ifndef LSM_PAYLOAD_PROBE
#define LSM_PAYLOAD_PROBE 0
#endif
#ifndef LSM_PAYLOAD_TEST_LEAN
#define LSM_PAYLOAD_TEST_LEAN 0
#endif
#ifndef LSM_SF5_RX_LEAN
#define LSM_SF5_RX_LEAN 0
#endif

#if LSM_PAYLOAD_PROBE
static constexpr uint8_t PAYLOAD_PROBE_SOURCES = 24;
struct PayloadProbeSource {
  uint16_t id;
  uint8_t lastSeq;
  bool haveSeq;
  uint32_t unique;
  uint32_t duplicate;
  uint32_t reordered;
  uint32_t gaps;
  uint8_t bitmap[10];                 // 80 production sequence positions
};
static PayloadProbeSource g_payloadProbe[PAYLOAD_PROBE_SOURCES] = {};
static uint32_t g_payloadOriginTx = 0;
static uint32_t g_payloadRelayTx = 0;
static uint32_t g_payloadLogSuppressed = 0;

static PayloadProbeSource* payloadProbeSource(uint16_t id) {
  PayloadProbeSource* freeSlot = nullptr;
  for (uint8_t i=0; i<PAYLOAD_PROBE_SOURCES; ++i) {
    if (g_payloadProbe[i].id == id) return &g_payloadProbe[i];
    if (g_payloadProbe[i].id == 0 && freeSlot == nullptr) freeSlot = &g_payloadProbe[i];
  }
  if (freeSlot != nullptr) freeSlot->id = id;
  return freeSlot;
}

static void payloadProbeRx(uint16_t id, uint8_t seq, bool alreadyProcessed) {
  PayloadProbeSource* s = payloadProbeSource(id);
  if (s == nullptr) return;
  if (alreadyProcessed) { s->duplicate++; return; }
  s->unique++;
  s->bitmap[(seq % 80u) >> 3] |= (uint8_t)(1u << ((seq % 80u) & 7u));
  if (s->haveSeq) {
    uint8_t step = (uint8_t)(seq - s->lastSeq);
    if (step == 0) s->duplicate++;
    else if (step < 128u) {
      if (step > 1u) s->gaps += (uint32_t)(step - 1u);
      s->lastSeq = seq;
    } else {
      s->reordered++;
    }
  } else {
    s->lastSeq = seq;
    s->haveSeq = true;
  }
}

static void payloadProbeReset() {
  memset(g_payloadProbe, 0, sizeof(g_payloadProbe));
  g_payloadOriginTx = 0;
  g_payloadRelayTx = 0;
  g_payloadLogSuppressed = 0;
}
#endif

#define LOG_MANCH 21  // v7.21.3: MEMBER frame anchor witness, diagnostic only, members only.
                      // The exact counterpart of LOG_ANCH(20) at the other end of the same
                      // measurement. LOG_ANCH proved the TK stamps its anchor honestly, which
                      // moved the suspect to the member side and found nothing there to read:
                      // a member derives g_frameAnchorUs from the schedule beacon it heard and
                      // has never recorded that derivation, so when the TK reports six members
                      // simultaneously late by 126 ms the log cannot say whether they moved or
                      // it did. aux 1 fires once per schedule beacon a member anchors on.
                      // e = anchor slip, this anchor minus the previous one minus the frame
                      // length that was in force, in 100 us units clamped, the direct analogue
                      // of the snrRaw slip field on LOG_ANCH. n = the gap from the RxDone ISR
                      // stamp to the instant the beacon was processed, 100 us units clamped:
                      // this does NOT corrupt the anchor, which is derived from the ISR stamp
                      // and not from processing time, so it is here to PROVE that rather than
                      // to measure it, and a large n beside a flat e is the evidence that loop
                      // blocking is innocent. data = the relay correction actually subtracted,
                      // in us, 0 when the beacon came direct from the TK. rssi = schedHops on
                      // that beacon. snr = the relaying node's own jitter stamp in 100 us units,
                      // 0 to 127, or -1 meaning the RxDone stamp was missing or older than 500 ms
                      // and the code fell back to using the current instant, which IS an anchor
                      // corrupting path and has never been witnessed. snrRaw = this frame's
                      // correction minus the previous frame's, 100 us units clamped, so a member
                      // switching between a direct and a relayed beacon shows the jump in one
                      // field instead of needing two records differenced.
                      // WHY THE CORRECTION FIELD IS THE ONE TO WATCH: a member that anchors on a
                      // relayed beacon subtracts TK_SLOT_US plus a tier term plus the relay's
                      // jitter, and TK_SLOT_US alone is 138016 us. The two fleet wide events on
                      // record are a TK to member disagreement of about 126 ms and about 79 ms.
                      // Those sit inside the range this one correction spans, so a member that
                      // applies it when it should not, or fails to when it should, moves its
                      // anchor by exactly the observed magnitude. That is a hypothesis and not a
                      // finding; this record is what tests it.
                      // ANY HOST SIDE DECODER MUST LEARN TYPE 21 or it will count these as
                      // invalid records.
#define LOG_ANCH  20  // v7.21.1: TK frame anchor witness, diagnostic only. The TK stamps
                      // g_frameAnchorUs immediately before radio.transmit() returns and every
                      // arrival offset it measures is relative to that instant, but the instant
                      // itself has never been recorded, so a common mode error in it is
                      // indistinguishable in the log from every member genuinely arriving late.
                      // On the 2026-08-26 seven board run that ambiguity is the whole open
                      // question: at 407.0 s four members and at 472.6 s six members each took a
                      // SINGLE latency sample of 95400 and 141100 us against a 15100 us baseline,
                      // five of the six agreeing within 140 us, and the member that was checked
                      // had departed its own slot within 273 us, so the two ends disagree about
                      // where the frame starts and nothing says which end moved. aux 1 is the
                      // per beacon record: data = microseconds radio.transmit() actually blocked,
                      // e = that block minus BEACON_AIR_US in us (clamped, and this is the field
                      // that matters, since the raw block is dominated by the 118016 us airtime),
                      // n = 100 us units from the last backhaul errand exit to the anchor stamp
                      // (-1 if no errand since the previous beacon), snrRaw = anchor to anchor
                      // interval minus the frame length the TK had scheduled, in 100 us units,
                      // clamped, rssi = which errand piece last ran (0 none, 1 transmit, 2
                      // listen), snr = microseconds from femTx() to the anchor stamp, clamped to
                      // 127. aux 2 is the errand record: data = microseconds bhTailErrand()
                      // blocked, e = piece. Both are TK only, about one each per frame against
                      // the existing fourteen records per second. Nothing feeds back into any
                      // timing, scheduling or admission decision.
#define LOG_SKIP  19  // v7.20.24: silent-skip witness on the TK latency measurement path. Four branches could discard a member measurement writing nothing at all, which is how node 10 held a live nine member roster for 48 minutes on 2026-08-26 emitting zero DRIFT with no record naming which gate closed. aux = branch: 1 departure attestation mismatch, 2 arrival offset reconstructs BEFORE the member's own departure offset, 3 delay over the 200 ms sanity clamp, 4 member is in the roster but held no granted slot this frame. nodeId = the member the discarded measurement was about. e = arrival minus departure in us, signed, clamped to the int16 range. n = occurrences suppressed by the throttle since the last record of this branch. data = arrival offset in bits 0 to 15 and reconstructed departure offset in bits 16 to 31, both in 64 us units, 0xFFFF in the high half meaning no departure offset was reconstructed. snrRaw = bitmask of which member ids hit this branch during the suppressed window, bit 0 = node 1. Throttled to one record per branch per second so a latched branch cannot outrun the log. ANY HOST SIDE DECODER MUST LEARN TYPE 19 or it will count these as invalid records.
struct __attribute__((packed)) LogRec {
  uint32_t ms;         // millis at the event
  uint8_t  type;       // LOG_* above
  uint8_t  nodeId;     // subject node (self for TX and STATE, peer for RX)
  uint8_t  role;       // subject role at the event
  uint8_t  aux;        // type specific: tkId for STATE and VOTE, sats for LOCK
  int16_t  e;          // east cm at the event
  int16_t  n;          // north cm at the event
  int8_t   floorLevel; // this badge's floor at the event, computed on the badge
  uint8_t  lq;         // link quality 0 to 100, reserved, written as 0 for now
  int16_t  altitudeCm; // this badge's altitude in centimeters, 0 when unknown
  int8_t   rssi;       // dBm of the received packet, 0 on non RX records
  int8_t   snr;        // dB rounded to whole numbers, 0 on non RX records
  int16_t  snrRaw;     // SNR in quarter dB steps exactly as the SX1262 reports
  uint32_t data;       // type specific: beacon seq for TX and RX
};

static const char*  LOG_FA   = "/la.bin";
static const char*  LOG_FB   = "/lb.bin";
// v7.20.22: THE SERIAL SINK HAS NO FRAMING. The BLE sink carries a four byte
// header per frame (half, seq lo, seq hi, len) so an interleaved print cannot
// corrupt it, but the serial sink is a declared byte count followed by raw
// bytes, so anything else written to the UART mid dump lands INSIDE the
// payload and shifts every record after it. Measured 2026-08-26 on the first
// staggered fleet pull: a single 41 byte "acquiring fix" line spliced into
// node 06's dump at offset 11776, and because 41 is not a multiple of the 24
// byte record it dropped valid record decode from 100 to 35.8 percent, with
// node 05 at 51.9 and node 07 at 70.7. Every file was recoverable by excising
// the text host side, but recovery must not be load bearing. While a SERIAL
// dump is in flight the UART belongs to the dump. Two sources had to be shut
// off, not one: our own recurring prints, guarded at each site below, and the
// IDF log layer, which printed a vfs_api error from inside LittleFS.open()
// when the absent second half was opened and which no Serial guard of ours
// could ever have caught.
static volatile bool g_serQuiet   = false;
static uint32_t      g_serDropped = 0;
static inline bool serQuiet() { if (g_serQuiet||g_telemetryUsbPrefixBusy.load(std::memory_order_acquire)) { g_serDropped++; return true; } return false; }
// Only known cross-core diagnostic writers share this nonblocking UART gate.
// The main mesh loop never waits for another task's diagnostic output.
static bool serialAsyncBegin(){
  if(!g_exportSerialMutex||xSemaphoreTakeRecursive(g_exportSerialMutex,0)!=pdTRUE)return false;
  if(serQuiet()){xSemaphoreGiveRecursive(g_exportSerialMutex);return false;}return true;
}
static void serialAsyncEnd(){xSemaphoreGiveRecursive(g_exportSerialMutex);}
struct SerialOutputTry {
  bool held;
  SerialOutputTry():held(g_exportSerialMutex&&xSemaphoreTakeRecursive(g_exportSerialMutex,0)==pdTRUE){}
  ~SerialOutputTry(){if(held)xSemaphoreGiveRecursive(g_exportSerialMutex);}
};

static const size_t LOG_CAP  = 1792 * 1024; // v7.20.13: grown with the no-OTA partition (LittleFS 4.94 MB); two halves 3.5 MB, 1.44 MB (29 percent) kept deliberately free, the append stall follows the partition free margin
static const char*  g_logActive = LOG_FA;
static const uint8_t LOG_BUF_N = 128;   // v7.28.57: was 64; tailFlush gets 64 records of headroom before the mid-frame forced flush can fire

// ---------------------------------------------------------------------------
// v7.28.71: ASYNC FLASH WRITER. Heltec V2 / ESP32-S3 rig only, see the note on
// production below.
//
// THE DEFECT, measured on the 2026-09-16 four-board beach capture:
//   Frame period at a four-board roster is about 390 ms (measured from the
//   tail-flush cadence, two nodes agreeing at 390 and 402; NOT the ~1.2 s that
//   a twelve-board roster gives, which is why this bit hardest on a small
//   fleet). A single logFlush blocks 60 ms median, 233 to 313 ms at p95 and
//   max when LittleFS garbage collects. DYN_JOIN_TAIL_US is 40 ms. A 60 ms
//   write does not fit in a 40 ms tail, so on 37 to 39 percent of flushes the
//   write ran past the end of the frame and through the NEXT frame's member
//   slot region. That is the late-departure tail: about 8 percent of member
//   transmits departing more than SLOT_GUARD_US late, about 2 percent more
//   than a full airtime late, p99 about 28 ms.
//
// ELIMINATED FIRST, so this is not re-litigated later:
//   - the guard. Median departure error is 5 us, 90 percent inside 100 us.
//     SLOT_GUARD_US 800 is correct and generous. The tail cannot be fixed by
//     widening it: p99 is 28 ms and nobody reserves 28 ms of guard.
//   - engage latency. About 7 ms fleet-wide, already compensated by the
//     transmit lead. See the LOG_TXLAT comment.
//   - the buffer-full path (g_flushWhy 2). It fired ZERO times across the
//     whole capture. Every flush was tail-caller.
//   - tailFlush itself. It correctly refuses to run outside the tail window.
//     The bug is not when it fires, it is that the write cannot finish inside
//     a short dynamic frame.
//   - receive load. RX within 120 ms of a transmit was enriched 1.9x on late
//     departures, but that is a symptom, not the cause: more traffic means
//     more records means more flush pressure. radioPoll is never the slowest
//     loop section; tailFlush is, in 77 to 80 percent of one-second windows.
//
// WHY A SECOND CORE AND NOT A SMALLER FLUSH:
//   The worst pauses are LittleFS garbage collection, which is not
//   proportional to bytes written, so bounding the drain lowers the median and
//   leaves the tail intact. Logging less loses the evidence the capture exists
//   to collect. Moving the blocking write to core 0 is the only option that
//   keeps full instrumentation AND takes flash off the frame critical path.
//   It also breaks the reflexive trap that the logging switched on to measure
//   slot timing is itself corrupting slot timing.
//
// HONEST LIMIT, do not oversell this in a build note:
//   An internal-flash sector erase on the ESP32-S3 disables the instruction
//   cache while it runs, and that reaches ACROSS both cores. Moving the write
//   off core 1 removes the CPU-side block, which is the bulk of the typical
//   60 ms, but a real erase window can still stall flash-resident code on
//   core 1. Full immunity for the transmit instant would additionally need the
//   fire path in IRAM. That is a separate cut and is NOT claimed here.
//
// PRODUCTION NOTE (2026-09-16, per the badge BOM): the production MCU is the
// STM32U585, a SINGLE-core Cortex-M33. This two-core split does NOT port. On
// the U585 the same discipline is expressed as DMA plus interrupt priority,
// against external flash rather than an internal partition, so the
// cache-stall failure mode above does not exist there. This module is a rig
// optimization for the Heltec V2 / ESP32-S3 boards, deliberately scoped so
// nothing downstream depends on a second core existing.
//
// DESIGN:
//   The loop fills an active buffer exactly as before. At each existing flush
//   trigger it now hands the filled buffer to the writer task on core 0 and
//   picks up a clean buffer from a small pool, instead of writing inline.
//   Write FREQUENCY is unchanged, so flash wear is unchanged. If the writer is
//   inside a GC pause and the loop exhausts the pool, records drop and
//   g_fsDropped counts them, because blocking the mesh loop to protect the log
//   would reintroduce the exact defect this removes. LittleFS is not
//   thread-safe, so every filesystem touch outside the writer (dump reads,
//   trimSave, the erase paths) takes g_fsMutex. Power-off stays synchronous
//   because the task may never be scheduled again.
//
//   LSM_ASYNC_FLUSH 0 compiles the whole thing back out to the proven
//   synchronous path, one define, no other edits, so the bench always has a
//   known-good fallback.
// ---------------------------------------------------------------------------
#ifndef LSM_ASYNC_FLUSH
#define LSM_ASYNC_FLUSH 1        // 1 = writer task on core 0, 0 = original inline blocking flush
#endif
#define LOG_POOL_N      3        // active + 2 in flight; 3 * 128 * 24 B = 9216 B
#define FS_TASK_CORE    0        // mesh loop owns core 1; BLE controller also lives on core 0 but is idle unless an officer is paired
#define FS_TASK_STACK   4096
#define FS_TASK_PRIO    1        // below the Arduino loop task, this work is never urgent

static LogRec  g_logPool[LOG_POOL_N][LOG_BUF_N];
static LogRec* g_logBuf  = g_logPool[0];   // active buffer the loop fills, was a plain array
static uint8_t g_logBufN = 0;
static uint8_t g_logPoolIdx = 0;           // which pool slot is active

// V39: background LittleFS writer / selected RF transaction exclusion.
static uint32_t g_rfFlashAttempts=0,g_rfFlashAcquired=0,g_rfFlashBusy=0,g_rfFlashReleased=0,g_rfFlashBypass=0,g_rfFlashMaxHoldUs=0;
static std::atomic<uint32_t> g_rfFlashActive{0},g_rfFlashOverlap{0};
static std::atomic<bool> g_fsWriteActive{false};
static volatile uint32_t g_fsLastIoUs=0,g_fsMaxIoUs=0,g_fsLastWaitUs=0,g_fsMaxWaitUs=0;
#if LSM_ASYNC_FLUSH
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <freertos/semphr.h>
struct FsJob { uint8_t slot; uint8_t n; uint8_t why; };   // the buffer itself stays in the pool, only the index travels
static QueueHandle_t     g_fsJobQ   = nullptr;   // loop -> writer
static QueueHandle_t     g_fsFreeQ  = nullptr;   // writer -> loop, returns drained slots
static SemaphoreHandle_t g_fsMutex  = nullptr;   // serializes ALL LittleFS access
static TaskHandle_t      g_fsTask   = nullptr;
static volatile uint32_t g_fsQueued  = 0;
static volatile uint32_t g_fsWritten = 0;
static volatile uint32_t g_fsDropped = 0;        // records lost because the pool ran dry
static volatile uint32_t g_fsLastMs  = 0;        // duration of the last write, writer side
static volatile uint32_t g_fsMaxMs   = 0;        // worst write seen, writer side
#define FS_LOCK()    (g_fsMutex ? xSemaphoreTakeRecursive(g_fsMutex, portMAX_DELAY) : pdTRUE)
#define FS_UNLOCK()  do { if (g_fsMutex) xSemaphoreGiveRecursive(g_fsMutex); } while(0)
#else
#define FS_LOCK()    pdTRUE
#define FS_UNLOCK()  do { } while(0)
#endif
static bool    g_fsOk = false;

void logRec(uint8_t type, uint8_t nodeId, uint8_t role, uint8_t aux,
            int16_t e, int16_t n, uint32_t data);   // v7.20.12: forward declaration, logFlush writes FSOP witnesses below
static size_t g_logActiveSz = 0;     // v7.20.12: cached size of the active half, updated at each flush
static bool   g_spareClean  = false; // v7.20.12: the inactive half is known erased and append-ready
// v7.28.33: per-flush witness. Every flash write that logFlush performs is
// bracketed and reported as LOG_FSOP aux 9: e = offset of the write START
// into the current frame in 100 us units (-1 when there is no frame anchor),
// n = duration in 100 us units (open, write, size, close), data = bytes
// written (low 16) | caller (bits 16-17: 1 tail, 2 buffer full, 0 other)
// | records (bits 20-27). The record is queued behind the flush it describes
// and lands in the NEXT write, so its own ms stamp is not the flush instant;
// e and n are. Reason: bench c08 and c09 (2026-09-04) put the missed-beacon
// signature (HeaderErr stamped 30 to 44 ms into a 40 ms packet, or nothing
// at all) in the same neighbourhood as the tail flush, and nothing in the log
// said exactly when each write ran. This does.
static uint8_t g_flushWhy = 0;   // set by the caller just before logFlush, cleared inside

// v7.28.71: the blocking write itself, factored out of logFlush unchanged in
// behavior. Runs on the writer task in async mode, inline on the loop in
// sync mode. Takes an explicit buffer and count so it can drain a pool slot
// the loop has already moved on from. The caller holds g_fsMutex.
static void logWriteBlocking(LogRec* buf, uint8_t n, uint8_t why, int16_t fwOff);
void logFlushSync();             // original inline path, kept for power-off and sync mode

#if LSM_ASYNC_FLUSH
// Writer task. Owns core 0 alongside the (usually idle) BLE controller.
// Blocks on the job queue, drains one pool slot per job, returns the slot.
static void fsWriterTask(void*){
  FsJob job;
  for(;;){
    if (xQueueReceive(g_fsJobQ, &job, portMAX_DELAY) != pdTRUE) continue;
    uint32_t t0 = millis();const uint64_t waitStart=(uint64_t)esp_timer_get_time();
    if (xSemaphoreTakeRecursive(g_fsMutex, portMAX_DELAY) == pdTRUE){
      const uint64_t ioStart=(uint64_t)esp_timer_get_time();
      g_fsLastWaitUs=(uint32_t)(ioStart-waitStart);if(g_fsLastWaitUs>g_fsMaxWaitUs)g_fsMaxWaitUs=g_fsLastWaitUs;
      if(g_rfFlashActive.load(std::memory_order_acquire))g_rfFlashOverlap.fetch_add(1,std::memory_order_acq_rel);
      g_fsWriteActive.store(true,std::memory_order_release);
      logWriteBlocking(g_logPool[job.slot], job.n, job.why, -1);
      g_fsWriteActive.store(false,std::memory_order_release);
      g_fsLastIoUs=(uint32_t)((uint64_t)esp_timer_get_time()-ioStart);if(g_fsLastIoUs>g_fsMaxIoUs)g_fsMaxIoUs=g_fsLastIoUs;
      xSemaphoreGiveRecursive(g_fsMutex);
    }
    uint32_t d = millis() - t0;
    g_fsLastMs = d;
    if (d > g_fsMaxMs) g_fsMaxMs = d;
    g_fsWritten = g_fsWritten + 1;   // v7.28.101: read-add-write; ++ on a volatile is deprecated in C++20 and warns
    xQueueSend(g_fsFreeQ, &job.slot, 0);     // hand the slot back to the loop
  }
}

// Start the writer. Called once from setup after the filesystem is mounted.
// On any allocation failure the module falls back to the synchronous path
// rather than running half-initialized.
static bool fsWriterStart(){
  g_fsMutex = xSemaphoreCreateRecursiveMutex();
  g_fsJobQ  = xQueueCreate(LOG_POOL_N, sizeof(FsJob));
  g_fsFreeQ = xQueueCreate(LOG_POOL_N, sizeof(uint8_t));
  if (!g_fsMutex || !g_fsJobQ || !g_fsFreeQ) return false;
  for (uint8_t i = 1; i < LOG_POOL_N; i++) xQueueSend(g_fsFreeQ, &i, 0);   // slot 0 is active, rest are free
  BaseType_t ok = xTaskCreatePinnedToCore(fsWriterTask, "lsmfsw", FS_TASK_STACK,
                                          nullptr, FS_TASK_PRIO, &g_fsTask, FS_TASK_CORE);
  return ok == pdPASS;
}
static bool g_fsAsync = false;   // true only once the task is genuinely running
#endif

// Never wait for flash in a radio slot. Recursive ownership permits the
// existing same-task trim persistence after RX rearm without deadlocking.
static bool radioFlashAsync(){
#if LSM_ASYNC_FLUSH
 return g_fsAsync;
#else
 return false;
#endif
}
class RadioFlashGuard {
 bool held_=false,locked_=false;uint64_t start_=0;
public:
 RadioFlashGuard(){
  g_rfFlashAttempts++;
#if LSM_ASYNC_FLUSH
  if(g_fsAsync){
   if(!g_fsMutex||xSemaphoreTakeRecursive(g_fsMutex,0)!=pdTRUE){g_rfFlashBusy++;return;}
   locked_=true;
   if(g_fsWriteActive.load(std::memory_order_acquire)){g_rfFlashOverlap.fetch_add(1,std::memory_order_acq_rel);xSemaphoreGiveRecursive(g_fsMutex);locked_=false;g_rfFlashBusy++;return;}
  }else{g_rfFlashBypass++;}
#else
  g_rfFlashBypass++;
#endif
  held_=true;start_=(uint64_t)esp_timer_get_time();g_rfFlashAcquired++;g_rfFlashActive.fetch_add(1,std::memory_order_acq_rel);
 }
 ~RadioFlashGuard(){
  if(!held_)return;
  const uint32_t elapsed=(uint32_t)((uint64_t)esp_timer_get_time()-start_);
  if(elapsed>g_rfFlashMaxHoldUs)g_rfFlashMaxHoldUs=elapsed;
  g_rfFlashActive.fetch_sub(1,std::memory_order_acq_rel);g_rfFlashReleased++;
#if LSM_ASYNC_FLUSH
  if(locked_)xSemaphoreGiveRecursive(g_fsMutex);
#endif
 }
 bool ok()const{return held_;}
 RadioFlashGuard(const RadioFlashGuard&)=delete;
 RadioFlashGuard& operator=(const RadioFlashGuard&)=delete;
};

void logFlush() {
#if LSM_ASYNC_FLUSH
  // v7.28.71: NON-BLOCKING HANDOFF. Stamps the frame offset here, on the loop,
  // because that is the only place the number is meaningful; the writer cannot
  // know where in the frame the loop decided to drain. Then swaps in a clean
  // pool slot and returns. The mesh loop never touches LittleFS on this path.
  if (!g_fsAsync) { logFlushSync(); return; }        // task not running, use the proven path
  if (!g_fsOk || g_logBufN == 0) return;

  uint64_t fwUs0 = (uint64_t)esp_timer_get_time();
  int16_t  fwOff = -1;
  if (g_frameAnchorUs != 0 && g_frameUs != 0 && fwUs0 >= g_frameAnchorUs) {
    uint64_t d = ((fwUs0 - g_frameAnchorUs) % (uint64_t)g_frameUs) / 100ULL;
    fwOff = (d > 32766ULL) ? 32766 : (int16_t)d;
  }

  uint8_t freeSlot;
  if (xQueueReceive(g_fsFreeQ, &freeSlot, 0) != pdTRUE) {
    // Pool is dry: the writer is still inside a GC pause. Dropping records is
    // deliberate and counted. Blocking here to save them would put the mesh
    // loop back behind the flash write, which is the defect this removes.
    g_fsDropped += g_logBufN;
    g_logBufN = 0;
    g_flushWhy = 0;
    return;
  }

  FsJob job; job.slot = g_logPoolIdx; job.n = g_logBufN; job.why = g_flushWhy;
  // Witness record goes into the NEW buffer, not the one being handed off, so
  // the writer is never racing the loop for the same memory. fwOff is the real
  // measured offset; duration is reported separately by the FSOP aux 11 record
  // below on the following flush, since it is not known until the write ends.
  g_logPoolIdx = freeSlot;
  g_logBuf     = g_logPool[freeSlot];
  g_logBufN    = 0;
  g_flushWhy   = 0;

  if (xQueueSend(g_fsJobQ, &job, 0) != pdTRUE) {      // cannot happen (queue depth equals pool size), handled anyway
    g_fsDropped += job.n;
    xQueueSend(g_fsFreeQ, &job.slot, 0);
    return;
  }
  g_fsQueued = g_fsQueued + 1;   // v7.28.101: read-add-write; ++ on a volatile is deprecated in C++20 and warns

  // Async-mode flush witness, written from the loop: aux 11 distinguishes it
  // from the old inline aux 9 so a decoder never confuses the two. e = frame
  // offset at handoff (100 us), n = duration of the PREVIOUS write (ms, writer
  // side), data = records queued | caller << 16 | dropped-so-far << 20.
  logRec(LOG_FSOP, NODE_ID, g_role, 11, fwOff, (int16_t)(g_fsLastMs > 32766 ? 32766 : g_fsLastMs),
         (uint32_t)job.n | ((uint32_t)(job.why & 0x3) << 16)
         | ((uint32_t)(g_fsDropped > 0xFF ? 0xFF : g_fsDropped) << 20));
#else
  logFlushSync();
#endif
}

// v7.28.71: writer-side drain. Writes an explicit buffer that the loop has
// already stopped using. Deliberately does NOT call logRec: emitting a record
// from core 0 would write into the loop's active buffer and race it. Outcomes
// land in volatiles (g_fsLastMs, g_fsMaxMs, g_fsDropped, g_fsOk) and the loop
// reports them in the aux 11 witness on the next handoff. The caller holds
// g_fsMutex. fwOff is unused on this path and kept only for signature
// symmetry with the sync version.
static void logWriteBlocking(LogRec* buf, uint8_t n, uint8_t why, int16_t fwOff) {
  (void)why; (void)fwOff;
  if (!g_fsOk || n == 0) return;
  File f = LittleFS.open(g_logActive, "a");
  if (!f) return;
  size_t want = (size_t)n * sizeof(LogRec);
  size_t got  = f.write((uint8_t*)buf, want);
  size_t sz   = f.size();
  f.close();
  if (got != want) {                         // same policy as the sync path: stop writing a filesystem that cannot take writes
    g_logActiveSz = sz;
    g_fsOk = false;
    return;
  }
  g_logActiveSz = sz;
  if (sz >= LOG_CAP) {                       // wrap to the other half
    const char* spare = (g_logActive == LOG_FA) ? LOG_FB : LOG_FA;
    if (g_spareClean) {
      g_logActive = spare; g_spareClean = false; g_logActiveSz = 0;
    } else {
      LittleFS.remove(spare);                // the slow inline erase, now off the mesh loop entirely
      g_logActive = spare; g_logActiveSz = 0;
    }
  }
}

// The original synchronous flush, behavior unchanged. Still used for power-off,
// for LSM_ASYNC_FLUSH 0, and before the writer task is up during setup.
void logFlushSync() {
  if (!g_fsOk || g_logBufN == 0) return;
  uint32_t fw0 = millis();
  uint64_t fwUs0 = (uint64_t)esp_timer_get_time();
  int16_t  fwOff = -1;
  if (g_frameAnchorUs != 0 && g_frameUs != 0 && fwUs0 >= g_frameAnchorUs) {
    uint64_t d = ((fwUs0 - g_frameAnchorUs) % (uint64_t)g_frameUs) / 100ULL;
    fwOff = (d > 32766ULL) ? 32766 : (int16_t)d;
  }
  uint8_t  fwWhy = g_flushWhy; g_flushWhy = 0;
  uint16_t fwRecs = (uint16_t)g_logBufN;
  File f = LittleFS.open(g_logActive, "a");
  if (!f) return;
  // v7.20.14: the write return was previously discarded and g_logBufN cleared
  // unconditionally, so a full or undersized LittleFS (an old partition table
  // under a new app image) silently dropped every record: mesh running, log
  // empty, nothing on serial. Short write now keeps the buffer, marks the
  // filesystem bad, and announces itself once on serial and as FSOP aux 5.
  size_t want = g_logBufN * sizeof(LogRec);
  size_t got  = f.write((uint8_t*)g_logBuf, want);
  size_t sz = f.size();
  f.close();
  if (got != want) {
    static bool told = false;
    if (!told) {
      told = true;
      if (!serQuiet()) Serial.printf("LOG WRITE SHORT %u of %u, active=%s size=%u, logging stopped\n",
                    (unsigned)got, (unsigned)want, g_logActive, (unsigned)sz);
    }
    g_logActiveSz = sz;
    g_fsOk = false;                          // stop retrying a filesystem that cannot take writes
    logRec(LOG_FSOP, NODE_ID, g_role, 5, (int16_t)(sz/1024), (int16_t)(want - got), 0);
    return;                                  // buffer retained, not discarded
  }
  g_logBufN = 0;
  g_logActiveSz = sz;
  uint32_t fwMs = millis() - fw0;
  { uint64_t dUs = (uint64_t)esp_timer_get_time() - fwUs0;   // v7.28.33: per-flush witness, see the comment above logFlush
    uint64_t d100 = dUs / 100ULL;
    int16_t  fwDur = (d100 > 32766ULL) ? 32766 : (int16_t)d100;
    uint32_t fwData = (uint32_t)(got > 0xFFFFU ? 0xFFFFU : got)
                    | ((uint32_t)(fwWhy & 0x3) << 16)
                    | ((uint32_t)(fwRecs > 0xFF ? 0xFF : fwRecs) << 20);
    logRec(LOG_FSOP, NODE_ID, g_role, 9, fwOff, fwDur, fwData); }
  if (sz >= LOG_CAP) {                       // wrap to the other half
    const char* spare = (g_logActive == LOG_FA) ? LOG_FB : LOG_FA;
    if (g_spareClean) {                      // v7.20.12: spare pre-erased off the hot path, swap is a pointer move
      g_logActive = spare; g_spareClean = false; g_logActiveSz = 0;
      logRec(LOG_FSOP, NODE_ID, g_role, 3, (int16_t)(sz/1024), 0, 0);
    } else {                                 // v7.20.12: inline erase kept as the safety net, now timed. This is the freeze suspect: stalls 5053/12200/29400 ms on boards 06/08/05, bench 2026-08-24, and the GC history at LOG_CAP.
      uint32_t t0 = millis();
      LittleFS.remove(spare);
      g_logActive = spare; g_logActiveSz = 0;
      logRec(LOG_FSOP, NODE_ID, g_role, 1, (int16_t)(sz/1024), 0, millis() - t0);
    }
  } else if (fwMs > 150) {                   // v7.20.12: a plain append that blocked, LittleFS GC suspect
    logRec(LOG_FSOP, NODE_ID, g_role, 4, (int16_t)(sz/1024), 0, fwMs);
  }
}

// Altitude of this badge in centimeters. GPS altitude while there is a fix,
// zero otherwise. A barometer replaces this source on the production badge.
int16_t altitudeCmNow() {
  if (!gps.altitude.isValid()) return 0;
  long cm = lround(gps.altitude.meters() * 100.0);
  if (cm >  32767) return  32767;
  if (cm < -32768) return -32768;
  return (int16_t)cm;
}

// v7.11.7: link quality 0 to 100 from RSSI and SNR, RX records only.
// RSSI -130 dBm (unusable) to -50 dBm (excellent) and SNR -20 dB (LoRa
// demod floor) to +10 dB (clean) each map to a 0-100 sub-score, averaged.
// Non-RX records keep lq at 0, rssi and snr are 0 there too, see the
// LogRec field comments above.
// v7.13.3: local round-to-nearest for the RF capture path. Deliberately not
// lroundf() so this adds no <math.h> dependency on any board in the fleet.
static inline int16_t rnd16(float v){ return (int16_t)(v < 0.0f ? (v - 0.5f) : (v + 0.5f)); }

uint8_t computeLq(int8_t rssi, int8_t snr) {
  int rssiPct = ((int)rssi + 130) * 100 / 80;
  if (rssiPct < 0) rssiPct = 0;
  if (rssiPct > 100) rssiPct = 100;
  int snrPct = ((int)snr + 20) * 100 / 30;
  if (snrPct < 0) snrPct = 0;
  if (snrPct > 100) snrPct = 100;
  return (uint8_t)((rssiPct + snrPct) / 2);
}

static inline bool payloadLeanKeepsLog(uint8_t type, uint8_t aux, uint32_t data) {
#if LSM_PAYLOAD_TEST_LEAN || LSM_SF5_RX_LEAN
  if (type == LOG_BOOT || type == LOG_STATE || type == LOG_VOTE ||
      type == LOG_LOCK || type == LOG_STALL || type == LOG_PWR ||
      type == LOG_FSOP) return true;
  // Retain actual radio failures and recovery, but discard periodic RF
  // witnesses.  Errors use aux 0..2 and carry a non-zero RadioLib status.
  if (type == LOG_RF && aux <= 2u && (int32_t)data != RADIOLIB_ERR_NONE) return true;
  return false;
#else
  (void)type; (void)aux; (void)data;
  return true;
#endif
}

void logRecRf(uint8_t type, uint8_t nodeId, uint8_t role, uint8_t aux,
              int16_t e, int16_t n, uint32_t data,
              int8_t rssi, int8_t snr, int16_t snrRaw) {
#if LSM_PAYLOAD_PROBE
  if (!payloadLeanKeepsLog(type, aux, data)) {
    g_payloadLogSuppressed++;
    return;
  }
#endif
  if (g_logBufN >= LOG_BUF_N) {          // a flush failed earlier, never overrun
    g_flushWhy = 2;                      // v7.28.33: buffer-full caller
    logFlush();
    if (g_logBufN >= LOG_BUF_N) g_logBufN = 0;  // storage is down, drop and keep running
  }
  LogRec& r = g_logBuf[g_logBufN];
  r.ms = millis(); r.type = type; r.nodeId = nodeId; r.role = role;
  r.aux = aux; r.e = e; r.n = n;
  r.floorLevel = FLOOR_LEVEL;
  r.lq = (type == LOG_RX) ? computeLq(rssi, snr) : 0;
  r.altitudeCm = altitudeCmNow();
  r.rssi = rssi; r.snr = snr; r.snrRaw = snrRaw;
  r.data = data;
  if (++g_logBufN >= LOG_BUF_N) { g_flushWhy = 2; logFlush(); }   // v7.28.33: buffer-full caller
}

// Records with no packet attached keep the old seven argument call.
void logRec(uint8_t type, uint8_t nodeId, uint8_t role, uint8_t aux,
            int16_t e, int16_t n, uint32_t data) {
  logRecRf(type, nodeId, role, aux, e, n, data, 0, 0, 0);
}

// ---------- v7.20.24: silent skip witness ----------
// The TK's per member latency measurement has four exits that throw the
// sample away and write nothing. On the 2026-08-26 fleet run node 10 reigned
// as TK for 52 minutes, kept hearing all nine members at a steady rate, kept
// answering the same frame on 98 percent of receptions, and stopped emitting
// DRIFT entirely at 520.7 s. Every candidate explanation was a branch that
// leaves no trace, so the log could not choose between them. These counters
// make each exit name itself.
//
// Bounded by construction: one record per branch per second at most, so four
// records per second worst case against the existing fourteen. The true rate
// is not lost, it moves into the suppressed count, and the member bitmask
// says whether one board or the whole roster is affected. Nothing here feeds
// back into any timing, scheduling or admission decision.
#define SKIP_BRANCHES 6
#define SKIP_THROTTLE_MS 1000UL
static uint32_t g_skipLastMs[SKIP_BRANCHES] = {0};
static uint16_t g_skipSupp[SKIP_BRANCHES]   = {0};
static uint16_t g_skipMask[SKIP_BRANCHES]   = {0};
// A separate armed flag rather than testing g_skipLastMs against zero. millis()
// IS zero for the first millisecond after boot, so a zero timestamp cannot mean
// "this branch has never fired": the throttle would fail to arm and the first
// second of a latched branch would go out unbounded. Caught by the standalone
// logic test before this reached a board.
static bool     g_skipArmed[SKIP_BRANCHES]  = {false};

// Frame offsets run to the 2550 ms frame ceiling, well past a uint16. 64 us
// units put 4.19 s inside 16 bits, which covers any legal frame with room to
// spare and still resolves a disagreement to better than a tenth of a slot.
static inline uint16_t skipPack(uint32_t us){
  uint32_t q = us >> 6;
  return (uint16_t)(q > 65535UL ? 65535UL : q);
}

static void skipWitness(uint8_t branch, uint8_t memberId,
                        uint32_t arrOffUs, uint32_t depOffUs){
  if (branch == 0 || branch >= SKIP_BRANCHES) return;
  if (memberId >= 1 && memberId <= 16) g_skipMask[branch] |= (uint16_t)(1u << (memberId - 1));
  uint32_t now = millis();
  if (g_skipArmed[branch] && (now - g_skipLastMs[branch]) < SKIP_THROTTLE_MS){
    if (g_skipSupp[branch] < 0xFFFF) g_skipSupp[branch]++;
    return;
  }
  g_skipArmed[branch]  = true;
  g_skipLastMs[branch] = now;
  bool haveDep = (depOffUs != 0xFFFFFFFFu);
  int32_t diff = haveDep ? (int32_t)((int64_t)arrOffUs - (int64_t)depOffUs) : 0;
  if (diff >  32767) diff =  32767;
  if (diff < -32768) diff = -32768;
  uint32_t packed = (uint32_t)skipPack(arrOffUs)
                  | ((uint32_t)(haveDep ? skipPack(depOffUs) : 0xFFFFu) << 16);
  logRecRf(LOG_SKIP, memberId, g_role, branch,
           (int16_t)diff,
           (int16_t)(g_skipSupp[branch] > 32767 ? 32767 : g_skipSupp[branch]),
           packed, 0, 0, (int16_t)g_skipMask[branch]);
  g_skipSupp[branch] = 0;
  g_skipMask[branch] = 0;
}

// v7.12.26 self-tuning trim: persistent /st.bin state (magic + CRC, wear
// leveled across TRIM_SLOTS records, highest seq wins), mirrors the position
// seed file. trimPush() feeds one measured devUs, rejects outliers, and on the
// first full window folds the residual into g_trimAdjUs and persists it.
struct TrimState { uint32_t magic; uint32_t seq; int16_t adjUs; uint16_t pad; uint32_t crc; };
static uint32_t g_trimSeq = 0;
static uint32_t trimCrc(const TrimState* s){
  TrimState t = *s; t.crc = 0; const uint8_t* p = (const uint8_t*)&t; uint32_t c = 0xFFFFFFFFUL;
  for (unsigned i=0;i<sizeof(t);i++){ c ^= p[i]; for (int k=0;k<8;k++) c = (c>>1) ^ (0xEDB88320UL & (uint32_t)(-(int32_t)(c&1))); }
  return ~c;
}
static void trimLoad(){
  if (!g_fsOk) return;
  FS_LOCK();                       // v7.28.71: serialize against the core-0 writer
  if (!LittleFS.exists(TRIM_FILE)) { FS_UNLOCK(); return; }   // v7.29.5: probe first, an open on a missing file logs a vfs error line into the dump stream
  File f = LittleFS.open(TRIM_FILE, "r"); if (!f) { FS_UNLOCK(); return; }
  TrimState best; bool have=false;
  for (int i=0;i<TRIM_SLOTS;i++){
    TrimState s; if (f.read((uint8_t*)&s, sizeof(s)) != (int)sizeof(s)) break;
    if (s.magic != TRIM_MAGIC) continue;
    if (trimCrc(&s) != s.crc) continue;
    if (!have || s.seq > best.seq){ best = s; have = true; }
  }
  f.close();
  FS_UNLOCK();
  if (have){ g_trimAdjUs = best.adjUs; g_trimSeq = best.seq; }
}
static void trimSave(){
  if (!g_fsOk) return;
  FS_LOCK();                       // v7.28.71: serialize against the core-0 writer
  TrimState slots[TRIM_SLOTS];
  File f = LittleFS.exists(TRIM_FILE) ? LittleFS.open(TRIM_FILE, "r") : File();   // v7.29.5: probe first, see the reader above
  if (f){ f.read((uint8_t*)slots, sizeof(slots)); f.close(); } else memset(slots,0,sizeof(slots));
  uint32_t mx=0; int oldest=0; uint32_t oldSeq=0xFFFFFFFFUL;
  for (int i=0;i<TRIM_SLOTS;i++){
    if (slots[i].magic==TRIM_MAGIC){ if (slots[i].seq>mx) mx=slots[i].seq; if (slots[i].seq<oldSeq){ oldSeq=slots[i].seq; oldest=i; } }
    else { oldest=i; oldSeq=0; }
  }
  TrimState s; memset(&s,0,sizeof(s)); s.magic=TRIM_MAGIC; s.seq=mx+1; s.adjUs=g_trimAdjUs; s.crc=0; s.crc=trimCrc(&s);
  slots[oldest]=s; g_trimSeq=s.seq;
  File w = LittleFS.open(TRIM_FILE, "w");
  if (w){ w.write((uint8_t*)slots, sizeof(slots)); w.close(); }
  FS_UNLOCK();
}
static void trimPush(int32_t devUs){
  int32_t a = devUs < 0 ? -devUs : devUs;
  if (a > TRIM_REJECT_US){ g_trimReject++; return; }   // slip or relayed frame, keep it out of the average
  if (g_trimCount == TRIM_WINDOW){ g_trimSum -= g_trimRing[g_trimHead]; }
  else { g_trimCount++; }
  g_trimRing[g_trimHead] = devUs; g_trimSum += devUs;
  g_trimHead = (uint16_t)((g_trimHead + 1) % TRIM_WINDOW);
  // one-step convergence: first time the window fills, fold the residual into
  // the applied lead and persist for next cold boot. g_trimLocked stops any
  // re-fold this session, so continued samples only move the live display.
  if (!g_trimLocked && g_trimCount == TRIM_WINDOW){
    int32_t avg = (int32_t)(g_trimSum / (int32_t)TRIM_WINDOW);
    int32_t adj = (int32_t)g_trimAdjUs + avg;
    if (adj < -1000) adj = -1000; if (adj > 1000) adj = 1000;
    g_trimAdjUs = (int16_t)adj; g_trimLocked = true;
    logRec(LOG_TRIM, NODE_ID, g_role, 0xEE, (int16_t)avg, 0, (uint32_t)(uint16_t)g_trimAdjUs);  // fold event: aux 0xEE, e=window avg, data=new adjUs in low 16 bits
    trimSave();
  }
}

// v7.12.25: observe-only slot-time trim. Called right after a granted-slot
// transmit. dOff is this node's actual air-departure offset from the shared
// frame anchor (esp_timer_get_time() - g_frameAnchorUs, stamped at the
// transmit call). schedUs is where the slot boundary sits for g_mySlot, so
// devUs = dOff - schedUs is the per-node process-and-transmit lag to tune
// later. Logged locally only, no wire change; it rides out over USB BINDUMP
// and the BLE dump with every other LogRec.
static inline int16_t departDevFrom(uint32_t dOff){
  if (g_mySlot == 0xFF) return 0;
  uint32_t schedUs = g_memberBaseUs + (uint32_t)g_mySlot * g_slotUsLive;
  int32_t d = (int32_t)((int64_t)dOff - (int64_t)schedUs);
  return (d > 32767) ? 32767 : ((d < -32768) ? -32768 : (int16_t)d);
}

void logSlotTrim(uint32_t dOff) {
  if (g_mySlot == 0xFF) return;                       // only meaningful for a granted slot
  uint32_t schedUs = g_memberBaseUs + (uint32_t)g_mySlot * g_slotUsLive;   // v7.13.0: runtime tier geometry
  int32_t devUs = (int32_t)((int64_t)dOff - (int64_t)schedUs);
  int16_t devClamped = (devUs > 32767) ? 32767 : ((devUs < -32768) ? -32768 : (int16_t)devUs);
  logRec(LOG_TRIM, NODE_ID, g_role, g_mySlot, devClamped, g_dieTempC, dOff);
  trimPush(devUs);                                   // v7.12.26 feed the self-tuning ring
}

void logInit() {
  // v7.20.15: the label must be passed. esp_littlefs resolves the partition by
  // NAME, not subtype, and Arduino LittleFS.begin() defaults that name to
  // "spiffs" while lsm_8mb_noota.csv names it "littlefs". The bare begin(true)
  // therefore searched for a partition that does not exist and returned 261,
  // mount failed, on every board from the first 7.20.13 boot: no store, so
  // logFlush returned at its g_fsOk guard and no record was ever written.
  g_fsOk = LittleFS.begin(true, "/littlefs", 10, "spiffs");
  if (!g_fsOk) { Serial.println("LittleFS mount failed, logging disabled"); return; }
  size_t sa = 0, sb = 0;
  File fa = LittleFS.open(LOG_FA, "r"); if (fa) { sa = fa.size(); fa.close(); }
  File fb = LittleFS.open(LOG_FB, "r"); if (fb) { sb = fb.size(); fb.close(); }
  if ((sa % sizeof(LogRec)) != 0 || (sb % sizeof(LogRec)) != 0) {
    LittleFS.remove(LOG_FA); LittleFS.remove(LOG_FB);
    sa = 0; sb = 0;
    Serial.println("Old format flash log found, erased");
  }
  if (sa < LOG_CAP) g_logActive = LOG_FA;
  else if (sb < LOG_CAP) g_logActive = LOG_FB;
  else { LittleFS.remove(LOG_FA); g_logActive = LOG_FA; }
  Serial.printf("Flash log ready, a=%u b=%u active=%s\n",
                (unsigned)sa, (unsigned)sb, g_logActive);
}

// v7.28.71: settle the writer and drain what is still buffered, synchronously.
// Used by power-off, log erase, and before a dump reads the files. Waits for
// the writer to finish any job in flight (bounded, then gives up rather than
// hanging the board), then writes the loop's own buffer inline.
static void fsDrainForShutdown(){
#if LSM_ASYNC_FLUSH
  if (g_fsAsync) {
    for (int i = 0; i < 200 && uxQueueMessagesWaiting(g_fsJobQ) > 0; i++) delay(10);  // up to 2 s
    if (g_fsMutex && xSemaphoreTakeRecursive(g_fsMutex,pdMS_TO_TICKS(3000))==pdTRUE) xSemaphoreGiveRecursive(g_fsMutex);
  }
#endif
  logFlushSync();
}

void logErase() {
  if (!g_fsOk) return;
  fsDrainForShutdown();              // v7.28.71: settle the writer before removing the files under it
  FS_LOCK();
  LittleFS.remove(LOG_FA); LittleFS.remove(LOG_FB);
  FS_UNLOCK();
  g_logActive = LOG_FA; g_logBufN = 0;
  Serial.println("Flash log erased");
}

void logDumpSerial() {
  if (!g_fsOk) return;
  fsDrainForShutdown();              // v7.28.71: settle the writer so the dump sees a complete log
  FS_LOCK();
  const char* names[2] = { LOG_FA, LOG_FB };
  Serial.println("LOGDUMP begin");
  for (int i = 0; i < 2; i++) {
    File f = LittleFS.open(names[i], "r");
    if (!f) continue;
    LogRec r;
    while (f.read((uint8_t*)&r, sizeof(r)) == sizeof(r)) {
      Serial.printf("LOG %lu t=%u id=%u role=%u aux=%u e=%d n=%d f=%d a=%d rssi=%d snr=%d sq=%d d=%lu\n",
                    (unsigned long)r.ms, r.type, r.nodeId, r.role, r.aux,
                    r.e, r.n, (int)r.floorLevel, (int)r.altitudeCm,
                    (int)r.rssi, (int)r.snr, (int)r.snrRaw, (unsigned long)r.data);
    }
    f.close();
  }
  FS_UNLOCK();                       // v7.28.71
  Serial.println("LOGDUMP end");
}

// Raw binary dump over USB serial. Streams the exact flash bytes, the same
// 24 byte records the BLE path sends, so the bench tool can save a true .bin
// and parse every field including the ones the text dump drops. The total
// length is sent up front so the reader collects an exact byte count and
// never has to guess an end marker.
// v7.20.17 SLICED LOG DUMP.
// Both dump paths used to run to completion inside one call, so the board
// stopped servicing the mesh for the whole transfer. Measured on board 05,
// 2026-08-25: four BLE pulls produced four LOG_STALL records of 56764, 63278,
// 66265 and 100035 ms, and the RX silences in the same log match them. The
// cost was not the radio. Throughput was 3.81 KB/s on every one of the four
// pulls, and frames multiplied by the old delay(25) accounts for 99 percent
// of each stall, so the fixed delay was the outage.
//
// Now: one state machine, two sinks, serviced once per loop pass. It sends a
// bounded slice and returns, so the frame anchor, the beacon and the token
// layer keep running for the whole pull. A dump becomes slower wall clock at
// worst, never an outage.
//
// The BLE sink paces on the peer instead of on a guess. NimBLE-Arduino 1.4.3
// returns void from indicate(), the bool return only arrives in 2.x, so the
// acknowledgement is taken from NimBLECharacteristicCallbacks::onStatus,
// which fires per frame with SUCCESS_INDICATE or an error. That is the
// confirmation the old inline comment claimed to have and did not read.
//
// Frame layout is unchanged: half index, 16 bit sequence, length, payload.
// Payload grows from 96 to whatever the negotiated MTU allows, kept to a
// multiple of the 24 byte record so frames stay record aligned, floor 96 so
// a link that refuses to grow behaves exactly as before.
enum : uint8_t { DUMP_IDLE = 0, DUMP_OPEN, DUMP_READ, DUMP_SEND, DUMP_ACK, DUMP_FINISH };
static const uint16_t DUMP_PAY_MAX   = 240;   // 10 records, and 240 + 4 fits an MTU 247 link
static const uint16_t DUMP_PAY_MIN   = 96;    // the pre 7.20.17 frame, never do worse
static const uint32_t DUMP_ACK_MS    = 400;   // per frame confirmation ceiling
static const uint8_t  DUMP_ACK_TRIES = 3;     // resends before the pull is abandoned
static const uint32_t DUMP_SER_SLICE = 512;   // serial bytes per loop pass

static uint8_t   g_dumpState = DUMP_IDLE;
static bool      g_dumpBle   = false;   // false = USB serial sink, true = BLE sink
static uint8_t   g_dumpHalf  = 0;
static File      g_dumpF;
static bool      g_dumpFOpen = false;
static uint16_t  g_dumpSeq   = 0;
static uint16_t  g_dumpPay   = DUMP_PAY_MIN;
static uint32_t  g_dumpSent  = 0;       // payload bytes handed to the sink
static uint32_t  g_dumpTotal = 0;       // snapshot at open, the declared length
static uint32_t  g_dumpT0    = 0;
static uint32_t  g_dumpAckMs = 0;
static uint8_t   g_dumpTries = 0;
static uint16_t  g_dumpFrames= 0;
static uint16_t  g_dumpRetx  = 0;
static int       g_dumpGot   = 0;
static uint32_t  g_dumpSerOff = 0;      // v7.29.4: bytes of the current slice already on the USB serial ring
// Sized for the LARGER of the two sinks. The serial slice is 512 while the
// BLE payload caps at 240, and an earlier draft of this block sized the buffer
// from DUMP_PAY_MAX alone, which would have overrun it by 272 bytes on the
// first serial pull. Always check the buffer first.
static_assert(DUMP_SER_SLICE >= DUMP_PAY_MAX, "dump buffer is sized from the serial slice");
static uint8_t   g_dumpBuf[DUMP_SER_SLICE + 4];
static volatile bool g_indAck = false;  // written from the NimBLE host task
static volatile bool g_indErr = false;
// v7.20.18: chLog carries both NOTIFY and INDICATE. Which one the peer gets is
// the peer's choice, made in the CCCD when it subscribes. A phone that
// subscribed for notifications makes NimBLE report SUCCESS_NOTIFY, not
// SUCCESS_INDICATE, and 7.20.17 matched neither branch: it waited out the
// 400 ms, resent the same frame three times and abandoned the pull. Observed
// on node 04 bench 2026-08-25 as exactly three identical ten record frames.
// Both success statuses now count. A notify status only means the stack took
// the frame rather than that the peer confirmed it, which is weaker evidence,
// but it is still per frame backpressure from the link and it is what the
// peer has agreed to give us.
static volatile int8_t g_indLast   = -1;    // last status seen, for the witness
static volatile bool   g_indNoInd  = false; // peer refused indications, use notify

// Snapshot both halves without holding either open. The declared total must
// not move once announced, so anything appended during the pull is left for
// the next one.
static uint32_t dumpTotalBytes() {
  const char* names[2] = { LOG_FA, LOG_FB };
  uint32_t t = 0;
  FS_LOCK();                         // v7.28.71: serialize against the core-0 writer
  for (int i = 0; i < 2; i++) {
    if (!LittleFS.exists(names[i])) continue;   // v7.20.22: same probe, same reason
    File f = LittleFS.open(names[i], "r");
    if (f) { t += (uint32_t)f.size(); f.close(); }
  }
  FS_UNLOCK();
  return t;
}

static void dumpAbort(const char* why) {
  // v7.20.22: an abort is also an exit from a running dump, so it must release
  // the UART or the board goes permanently quiet after one failed pull.
  g_serQuiet = false;
  esp_log_level_set("*", ESP_LOG_ERROR);
  if (g_dumpFOpen) { g_dumpF.close(); g_dumpFOpen = false; }
  uint32_t took = millis() - g_dumpT0;
  logRec(LOG_FSOP, NODE_ID, g_role, 8,
         (int16_t)(g_dumpSent / 1024), (int16_t)g_dumpFrames, took);
  if(!serQuiet())Serial.printf("DUMP abort: %s after %u frames, %u bytes, %u ms, last status %d\n",
                why, (unsigned)g_dumpFrames, (unsigned)g_dumpSent, (unsigned)took,
                (int)g_indLast);
  g_dumpState = DUMP_IDLE;
}

// Request a pull. Refuses rather than queues, so a second request mid pull
// cannot interleave two readers on one file handle.
static bool dumpStart(bool overBle) {
  SerialOutputTry output;if(!output.held)return false;
  if(g_telemetryUsbPrefixBusy.load(std::memory_order_acquire))return false;
  if (!g_fsOk) { Serial.println("DUMP refused: no filesystem"); return false; }
  if (g_dumpState != DUMP_IDLE) { Serial.println("DUMP refused: already running"); return false; }
  if (overBle && (chLog == nullptr || !g_connected)) {
    Serial.println("DUMP refused: no BLE client");
    return false;
  }
  logFlush();
  g_dumpBle    = overBle;
  g_dumpHalf   = 0;
  g_dumpSeq    = 0;
  g_dumpSent   = 0;
  g_dumpFrames = 0;
  g_dumpRetx   = 0;
  g_dumpTries  = 0;
  g_dumpGot    = 0;
  g_indAck     = false;
  g_indErr     = false;
  g_indNoInd   = false;
  g_indLast    = -1;
  g_dumpTotal  = dumpTotalBytes();
  g_dumpT0     = millis();
  // Payload sizing. ATT gives MTU minus 3, the frame header takes 4 more, and
  // the length byte in the header caps any frame at 255 either way.
  if (overBle) {
    uint16_t p = (g_bleMtu > 7 + DUMP_PAY_MIN) ? (uint16_t)(g_bleMtu - 7) : DUMP_PAY_MIN;
    if (p > DUMP_PAY_MAX) p = DUMP_PAY_MAX;
    p = (uint16_t)((p / sizeof(LogRec)) * sizeof(LogRec));   // keep frames record aligned
    if (p < DUMP_PAY_MIN) p = DUMP_PAY_MIN;
    g_dumpPay = p;
  } else {
    g_dumpPay = DUMP_SER_SLICE;
  }
  if (!overBle) {
    // v7.20.22: claim the UART. The IDF log level is dropped too, because the
    // filesystem layer prints its own errors and no guard of ours reaches
    // those. Restored in DUMP_FINISH and dumpAbort, the only two exits from a
    // running dump.
    g_serDropped = 0;
    esp_log_level_set("*", ESP_LOG_NONE);
    g_serQuiet = true;
    // FLEET.ps1 parses this header and then collects exactly this many bytes,
    // so the framing has to stay byte identical to the pre 7.20.17 dump.
    Serial.printf("BINDUMP begin %u rec %u\n",
                  (unsigned)g_dumpTotal, (unsigned)sizeof(LogRec));
  }
  logRec(LOG_FSOP, NODE_ID, g_role, 6,
         (int16_t)(g_dumpTotal / 1024), (int16_t)g_dumpPay, overBle ? 1 : 0);
  g_dumpState = DUMP_OPEN;
  return true;
}

// One bounded slice per call. Returns immediately when idle so the loop cost
// is a single compare on every pass that is not dumping.
void dumpService() {
  if (g_dumpState == DUMP_IDLE) return;
  const char* names[2] = { LOG_FA, LOG_FB };

  switch (g_dumpState) {

    case DUMP_OPEN: {
      if (g_dumpHalf > 1) { g_dumpState = DUMP_FINISH; break; }
      // v7.20.22: probe before opening. A bare open of an absent half makes
      // the VFS layer print an error, and during a serial dump that error goes
      // straight into the payload. Observed on node 06 2026-08-26: lb.bin does
      // not exist, printed from inside this very call.
      FS_LOCK();                                  // v7.28.71: serialize against the core-0 writer
      if (!LittleFS.exists(names[g_dumpHalf])) { FS_UNLOCK(); g_dumpHalf++; break; }
      g_dumpF = LittleFS.open(names[g_dumpHalf], "r");
      FS_UNLOCK();
      if (!g_dumpF) { g_dumpHalf++; break; }      // absent half is not an error
      g_dumpFOpen = true;
      g_dumpSeq   = 0;
      g_dumpState = DUMP_READ;
      break;
    }

    case DUMP_READ: {
      uint32_t room = (g_dumpSent < g_dumpTotal) ? (g_dumpTotal - g_dumpSent) : 0;
      if (room == 0) { g_dumpGot = 0; }
      else {
        uint16_t want = g_dumpPay;
        if (want > room) want = (uint16_t)room;
        FS_LOCK();                                // v7.28.71: one bounded slice, serialized
        g_dumpGot = g_dumpF.read(g_dumpBuf + 4, want);
        FS_UNLOCK();
      }
      g_dumpSerOff = 0;   // v7.29.4: fresh slice
      if (g_dumpGot <= 0) {
        g_dumpF.close(); g_dumpFOpen = false;
        g_dumpHalf++;
        g_dumpState = (g_dumpHalf > 1) ? DUMP_FINISH : DUMP_OPEN;
        break;
      }
      g_dumpTries = 0;
      g_dumpState = DUMP_SEND;
      break;
    }

    case DUMP_SEND: {
      if (g_dumpBle) {
        if (!g_connected || chLog == nullptr) { dumpAbort("client gone"); break; }
        g_dumpBuf[0] = g_dumpHalf;
        g_dumpBuf[1] = (uint8_t)(g_dumpSeq & 0xff);
        g_dumpBuf[2] = (uint8_t)(g_dumpSeq >> 8);
        g_dumpBuf[3] = (uint8_t)g_dumpGot;
        g_indAck = false;
        g_indErr = false;
        chLog->setValue(g_dumpBuf, g_dumpGot + 4);
        if (g_indNoInd) chLog->notify(); else chLog->indicate();
        g_dumpAckMs = millis();
        g_dumpState = DUMP_ACK;
      } else {
        // USB CDC. v7.29.4: the old unconditional write of a full 512 byte slice
        // dropped bytes whenever the TX ring was full and the write timed out,
        // and a single dropped byte desynchronises every 24 byte record after it
        // (node 07, 2026-09-23: 3,237,122 bytes, remainder 2, half the records
        // bad past 456 s). Write only what the ring can take right now and carry
        // the rest to the next pass. Slower at worst, never short. Always check
        // the buffer first.
        int avail = Serial.availableForWrite();
        if (avail > 0) {
          uint32_t left = (uint32_t)g_dumpGot - g_dumpSerOff;
          uint32_t n = ((uint32_t)avail < left) ? (uint32_t)avail : left;
          size_t w = Serial.write(g_dumpBuf + 4 + g_dumpSerOff, (size_t)n);
          g_dumpSerOff += (uint32_t)w;
        }
        if (g_dumpSerOff >= (uint32_t)g_dumpGot) {
          g_dumpSent += (uint32_t)g_dumpGot;
          g_dumpSerOff = 0;
          g_dumpFrames++;
          g_dumpState = DUMP_READ;
        }
      }
      break;
    }

    case DUMP_ACK: {
      if (g_indAck) {
        if (g_dumpFrames == 0) {
          if(!serQuiet())Serial.printf("DUMP paced on %s, status %d, payload %u\n",
                        g_indNoInd ? "notify" : "indicate",
                        (int)g_indLast, (unsigned)g_dumpPay);
        }
        g_dumpSent += (uint32_t)g_dumpGot;
        g_dumpSeq++;
        g_dumpFrames++;
        g_dumpState = DUMP_READ;
        break;
      }
      bool timedOut = (millis() - g_dumpAckMs) > DUMP_ACK_MS;
      if (g_indErr || timedOut) {
        if (++g_dumpTries >= DUMP_ACK_TRIES) { dumpAbort(timedOut ? "ack timeout" : "indicate failed"); break; }
        g_dumpRetx++;
        g_dumpState = DUMP_SEND;      // same seq, same payload, resent
      }
      break;
    }

    case DUMP_FINISH: {
      uint32_t took = millis() - g_dumpT0;
      if (g_dumpBle) {
        if (g_connected && chLog != nullptr) {
          memset(g_dumpBuf, 0xFF, 4);            // end marker frame
          chLog->setValue(g_dumpBuf, 4);
          if (g_indNoInd) chLog->notify(); else chLog->indicate();
        }
        if(!serQuiet())Serial.printf("BLE log dump complete: %u bytes, %u frames, %u resent, %u ms\n",
                      (unsigned)g_dumpSent, (unsigned)g_dumpFrames,
                      (unsigned)g_dumpRetx, (unsigned)took);
      } else {
        Serial.flush();
        Serial.print("\nBINDUMP end\n");
        // v7.20.22: release the UART only after the trailer is on the wire.
        g_serQuiet = false;
        esp_log_level_set("*", ESP_LOG_ERROR);
        if (g_serDropped)
          Serial.printf("DUMP held %u serial line(s) to keep the payload clean\n",
                        (unsigned)g_serDropped);
      }
      logRec(LOG_FSOP, NODE_ID, g_role, 7,
             (int16_t)(g_dumpSent / 1024), (int16_t)g_dumpFrames, took);
      g_dumpState = DUMP_IDLE;
      break;
    }

    default: g_dumpState = DUMP_IDLE; break;
  }
}

void logDumpSerialBin() { dumpStart(false); }
void logDumpBLE()       { dumpStart(true);  }

// ----------------------- 915 MHz radio and election -----------------------
#ifdef LSM_BOARD_LILYGO
// v7.28.47: LR1121 on RadioLib 7.1.2 (the version pinned in the vendor tree).
// getStatus, clearIrq, getRssiInst and calibrate are public on LR11x0 in
// 7.1.2, so no Module capture is needed. The witness methods return the
// SX1262-shaped bytes the decoders expect: chip mode is moved from stat2 bits
// 3:1 (LR11x0 numbering, 1 STBY_RC 2 STBY_OSC 3 FS 4 RX 5 TX) to bits 6:4 in
// SX126x numbering (2 STBY_RC 3 STBY_XOSC 4 FS 5 RX 6 TX), so a deaf-wrap
// record decodes identically on both hardware families.
static SPIClass& loraSPI = SPI;    // radio and LCD share FSPI on this board, one bus, two chip selects
class LR1121Patched : public LR1121 {
public:
  LR1121Patched(Module* m) : LR1121(m) {}  // cppcheck-suppress noExplicitConstructor
  uint8_t  chipStatus() {
    uint8_t s1 = 0, s2 = 0; uint32_t irq = 0;
    if (getStatus(&s1, &s2, &irq) != RADIOLIB_ERR_NONE) return 0;
    uint8_t lrMode = (uint8_t)((s2 >> 1) & 0x07);
    uint8_t sxMode = lrMode ? (uint8_t)(lrMode + 1) : 0;
    return (uint8_t)((sxMode & 0x07) << 4);
  }
  // No documented LR1121 register holds the LoRa sync word (it is set by
  // command 0x022B), so this returns the SX1262 register image of LORA_SYNC
  // and the aux 5 / aux 14 sync witness reads as intact on this family. It is
  // NOT a hardware readback: the LilyGO cannot witness sync-word corruption.
  int16_t  readSync(uint8_t* b) { b[0] = (uint8_t)((LORA_SYNC & 0xF0) | 0x04); b[1] = (uint8_t)(((LORA_SYNC & 0x0F) << 4) | 0x04); return RADIOLIB_ERR_NONE; }
  int16_t  clearIrq(uint32_t m = RADIOLIB_LR11X0_IRQ_ALL) { return LR11x0::clearIrq(m); }
  int16_t  setReg8B5() { return RADIOLIB_ERR_NONE; }   // SX1262 register patch, no LR1121 equivalent
  int16_t  calibrateAll() { return LR11x0::calibrate(RADIOLIB_LR11X0_CALIBRATE_ALL); }   // calibrate() is protected in 7.1.2; same name as the SX1262 wrapper
  // getRSSI(false) is the SX126x instantaneous-RSSI idiom used at the wrap and
  // abort witnesses; on the LR1121 that is the GetRssiInst command.
  float    getRSSI(bool packet) { if (packet) return LR11x0::getRSSI(); float r = 0.0f; getRssiInst(&r); return r; }
  float    getRSSI() { return LR11x0::getRSSI(); }
  // v7.28.72-symbvalid: the LR11x0 equivalent of SetLoRaSymbNumTimeout is
  // SetLoRaSynchTimeout, which RadioLib 7.1.2 carries as the protected
  // LR11x0::setLoRaSynchTimeout(uint8_t symbolNum) (LR11x0.h line 1695), so
  // it is reachable from this subclass. No encoding step on this family; the
  // witness bytes carry the raw count and 0.
  int16_t setSymbValid(uint8_t n, uint8_t* cmdOut, uint8_t* regOut) {
    int16_t st = LR11x0::setLoRaSynchTimeout(n);
    if (cmdOut) *cmdOut = n;
    if (regOut) *regOut = 0;
    return st;
  }
};
LR1121Patched radio = new Module(PIN_LORA_NSS, PIN_LORA_DIO1, PIN_LORA_RST, PIN_LORA_BUSY, SPI);
// RF switch table from the vendor LR1121_PingPong_2 example (DIO5/DIO6).
static const uint32_t lsmRfSwitchPins[] = { RADIOLIB_LR11X0_DIO5, RADIOLIB_LR11X0_DIO6, RADIOLIB_NC, RADIOLIB_NC, RADIOLIB_NC };
static const Module::RfSwitchMode_t lsmRfSwitchTable[] = {
  {LR11x0::MODE_STBY,  {LOW,  LOW}},
  {LR11x0::MODE_RX,    {HIGH, LOW}},
  {LR11x0::MODE_TX,    {LOW,  HIGH}},
  {LR11x0::MODE_TX_HP, {LOW,  HIGH}},
  {LR11x0::MODE_TX_HF, {LOW,  LOW}},
  {LR11x0::MODE_GNSS,  {LOW,  LOW}},
  {LR11x0::MODE_WIFI,  {LOW,  LOW}},
  END_OF_MODE_TABLE,
};
// v7.28.47: one begin helper for both families. Vendor order for the LR1121
// (LR1121_PingPong): the switch table, THEN begin, THEN setTCXO(3.0), the
// LilyGO TCXO is 2.85 to 3.15 V, not the 1.8 V the Heltec SX1262 uses.
static int16_t lsmRadioBegin() {
  // v7.28.98: RF switch table BEFORE begin(). The v7.28.47 comment claimed the
  // vendor order was begin-then-table; the vendor sketch does the opposite and
  // says so in as many words ("this has to be done prior to calling begin()").
  // begin() runs standby and image calibration, and with no table registered
  // RadioLib cannot drive DIO5/DIO6, so the RF path is undefined for all of it.
  radio.setRfSwitchTable(lsmRfSwitchPins, lsmRfSwitchTable);
  int16_t st = radio.begin(LORA_FREQ_MHZ, LORA_BW_KHZ, LORA_SF, LORA_CR, LORA_SYNC, LORA_DBM, LORA_PREAMBLE_SYMS, 3.0f);
  if (st != RADIOLIB_ERR_NONE) return st;
  return radio.setTCXO(3.0f);
}
#define LSM_RADIO_NAME "LR1121"
#else
static SPIClass loraSPI(FSPI);
// RadioLib declares readRegister and writeRegister protected, so this thin
// subclass exposes the one register operation the FEM RX patch needs.
// Nothing else changes, every other RadioLib call is inherited untouched.
class SX1262Patched : public SX1262 {
  // v7.28.42: capture the Module* handed to the constructor. RadioLib 6.6.0 keeps
  // SX126x::mod private and PhysicalLayer::getMod() friend-only (private since
  // v5.3.0), so neither is reachable from a subclass; the Module* is, and Module's
  // SPI stream methods are public. Declared before the ctor so init order is clean.
  Module* lsmMod;
public:
  SX1262Patched(Module* m) : SX1262(m), lsmMod(m) {}  // cppcheck-suppress noExplicitConstructor
  // v7.28.31 keeper preflight readbacks. Reads only.
  // v7.28.42: correct GetStatus read. RadioLib getStatus() asks SPIreadStream for
  // 0 payload bytes, so it always returned 0x00 (confirmed in SX126x_commands.cpp,
  // and by the 7.28.41 capture: arm and wrap status bytes 0x00 on every deaf wrap).
  // GetStatus (0xC0) returns one status byte after the opcode; read that one byte
  // the way getRSSI(false) and getPacketType() do internally. Bits 6:4 = chip mode
  // (2 STBY_RC, 3 STBY_XOSC, 4 FS, 5 RX, 6 TX); bits 3:1 = command status.
  uint8_t  chipStatus() {
    uint8_t s = 0;
    lsmMod->SPIreadStream(RADIOLIB_SX126X_CMD_GET_STATUS, &s, 1);
    return s;
  }
  int16_t  readSync(uint8_t* b) { return this->readRegister(0x0740, b, 2); }
  // v7.28.35: the non-destructive receiver watchdog needs to clear the IRQ
  // register without a chip reset. RadioLib keeps clearIrqStatus protected.
  int16_t  clearIrq(uint16_t m = RADIOLIB_SX126X_IRQ_ALL) { return this->clearIrqStatus(m); }
  int16_t setReg8B5() {
    uint8_t v = 0;
    int16_t st = this->readRegister(0x08B5, &v, 1);
    if (st != RADIOLIB_ERR_NONE) return st;
    v |= 0x01;
    return this->writeRegister(0x08B5, &v, 1);
  }
  // v7.28.47: Calibrate(0x7F), all blocks, the same Module::SPIwriteStream
  // primitive Meshtastic resetAGC() and MeshCore sx126xResetAGC() use.
  int16_t calibrateAll() {
    uint8_t cal = RADIOLIB_SX126X_CALIBRATE_ALL;
    return lsmMod->SPIwriteStream(RADIOLIB_SX126X_CMD_CALIBRATE, &cal, 1, true, false);
  }
  // v7.28.72-symbvalid: SetLoRaSymbNumTimeout (0xA0), the receiver preamble
  // validation count. Encoded exactly as Semtech's reference driver does it
  // (LoRaMac-node src/radio/sx126x/sx126x.c, SX126xSetLoRaSymbNumTimeout):
  // mant = (n+1)/2 folded into 5 bits with a 2-bit exponent, the command byte
  // is mant << (2*exp + 1), and for a non-zero count register 0x0706
  // (REG_LR_SYNCH_TIMEOUT) is written with exp + (mant << 3). RadioLib 6.6.0
  // never touches this command, so without this call the chip sits at its
  // reset value of 0, single-symbol validation. Returns the command status;
  // the encoded bytes are handed back for the boot witness.
  int16_t setSymbValid(uint8_t n, uint8_t* cmdOut, uint8_t* regOut) {
    uint8_t mant = (uint8_t)(((n > 248) ? 248 : n) + 1) >> 1;
    uint8_t exp  = 0;
    while (mant > 31) { mant = (uint8_t)((mant + 3) >> 2); exp++; }
    uint8_t cmd = (uint8_t)(mant << (2 * exp + 1));
    int16_t st = lsmMod->SPIwriteStream(RADIOLIB_SX126X_CMD_SET_LORA_SYMB_NUM_TIMEOUT, &cmd, 1, true, false);
    uint8_t reg = 0;
    if (st == RADIOLIB_ERR_NONE && n != 0) {
      reg = (uint8_t)(exp + (mant << 3));
      st = this->writeRegister(0x0706, &reg, 1);
    }
    if (cmdOut) *cmdOut = cmd;
    if (regOut) *regOut = reg;
    return st;
  }
  // v7.28.100: SetRxTxFallbackMode (0x93) = STDBY_XOSC. RadioLib 6.6.0 writes
  // this once, inside config(), from the standbyXOSC flag as it stood during
  // begin() (SX126x.cpp line 2097), and exposes no public setter. Raising the
  // flag after begin() therefore leaves the chip falling back to STDBY_RC
  // after every packet, which is most of the 5900 us turnaround this lineage
  // is closing. Issued here instead, after the TCXO is powered.
  int16_t setFallbackXOSC() {
    uint8_t m = RADIOLIB_SX126X_RX_TX_FALLBACK_MODE_STDBY_XOSC;
    return lsmMod->SPIwriteStream(RADIOLIB_SX126X_CMD_SET_RX_TX_FALLBACK_MODE, &m, 1, true, false);
  }
};

SX1262Patched radio = new Module(PIN_LORA_NSS, PIN_LORA_DIO1, PIN_LORA_RST, PIN_LORA_BUSY, loraSPI);
static int16_t lsmRadioBegin() {
  // v7.28.98 RECEIVE TURNAROUND. Root cause of the SF5 deafness, not the
  // preamble symbol count. RadioLib hardcoded STDBY_RC, so every transmit and
  // every re-arm came out of the 13 MHz RC oscillator and the chip had to spin
  // up and settle the 32 MHz XOSC, then lock the PLL, before it could listen.
  // Measured dead window 5900 us. SF7 preamble is 12.54 ms so ~6.5 symbols
  // survive and detection works; SF5 preamble is 4.67 ms, so the receiver
  // arrives after the preamble has already ended, every time. SF5 cannot work
  // until this is fixed, and some fraction of the SF7 delivery numbers in the
  // KPI ledger are measuring this, not the link.
  //
  // Must be set BEFORE begin(): begin() writes the RX/TX fallback mode, and
  // since RadioLib 9fd7db4 that write reads this flag. Setting it afterwards
  // leaves the fallback mode at STDBY_RC and the chip drops back to the RC
  // oscillator after every packet, which is most of the window we are closing.
  //
  // Cost: the XOSC keeps running in standby, which with a TCXO on DIO3 is
  // about 600 uA to 1.2 mA of extra idle current. Against a 0.81 W board that
  // is well under half a percent, and continuous RX already dominates that
  // budget. For a scheduled TDMA mesh a fast deterministic turnaround is worth
  // far more than the idle current.
  //
  // WITNESS: LOG_RXARM (28) already measures this. e = EWMA dead window in us,
  // n = bare startReceive cost. It should fall hard from ~5900. That witness is
  // how this cut is attributed in the capture, separately from the other seven.
  // v7.28.100 ORDER FIX. The v7.28.98 comment above was WRONG about where the
  // flag has to be set, and it cost a full bench session: every SX1262 board
  // came up with g_radioOk false and sat in LISTEN forever (capture 05.bin,
  // 2026-09-20, 226 s, zero LOG_RX, zero LOG_STATE, no aux 3 and no aux 17,
  // which is radioConfig never completing). RadioLib 6.6.0 SX126x::begin()
  // runs reset(), then the NO-ARG standby(), and only AFTER that setTCXO().
  // The no-arg standby() reads this very flag (SX126x.cpp line 467), so
  // setting it first commands STDBY_XOSC while DIO3 has not yet been told to
  // power the TCXO. The external oscillator never starts, BUSY never drops,
  // SPIwriteStream times out and RADIOLIB_ASSERT aborts begin.
  //
  // Correct order: begin() on the RC oscillator with the flag DOWN, then raise
  // it and apply both effects by hand now that the TCXO is powered:
  //   - SetRxTxFallbackMode 0x30 (STDBY_XOSC), because config() already ran
  //     inside begin() and wrote the 0x20 RC value. This is the half the
  //     v7.28.98 comment was right about: it does NOT get re-applied for free.
  //   - standby(), which now resolves to STDBY_XOSC, so the chip is in the
  //     intended idle mode before the first arm.
  // The flag is cleared on entry so the watchdog hard-kick path, which calls
  // this function again mid-session, cannot re-enter the same trap.
  radio.standbyXOSC = false;
  int16_t st = radio.begin(LORA_FREQ_MHZ, LORA_BW_KHZ, LORA_SF, LORA_CR, LORA_SYNC, LORA_DBM, LORA_PREAMBLE_SYMS, 1.8);
  if (st != RADIOLIB_ERR_NONE) return st;
  radio.standbyXOSC = true;
  st = radio.setFallbackXOSC();
  if (st != RADIOLIB_ERR_NONE) return st;
  return radio.standby();
}
#define LSM_RADIO_NAME "SX1262"
#endif


// v7.29.15: every physical radio path, including backhaul, uses the envelope.
static uint64_t g_joinTxDeadlineUs = 0;
static uint32_t g_joinBudgetBlocked = 0;
static bool joinTxBudgetFits(size_t plainBytes) {
  if (!g_joinTxDeadlineUs) return true;
  uint64_t air = (uint64_t)radio.getTimeOnAir(plainBytes + MESH_SEC_OVERHEAD);
  // The published region ALREADY includes its guard. Charging another whole
  // guard here would leave no start opportunity in member-sized JOIN slots.
  return (uint64_t)esp_timer_get_time() + air <= g_joinTxDeadlineUs;
}
struct OwnedGrant {
  uint64_t anchor=0,start=0,end=0,call=0,ret=0,rearmed=0;
  uint32_t air=0; uint8_t keeper=0,epoch=0,seq=0,slot=0,reason=0;
  bool observed=false,outcome=false,scope=false,called=false,success=false,skipped=false,uncal=false,flashBlocked=false;
};
static OwnedGrant g_owned;
static uint32_t g_ownedOpportunities=0,g_ownedSkips=0,g_ownedAttempts=0,g_ownedSuccess=0,g_ownedDriverFail=0,g_ownedOverruns=0,g_ownedUncalibrated=0;
static uint32_t g_ownedBudgetChecks=0,g_ownedBudgetRejects=0,g_ownedLastRemaining=0,g_ownedLastRequired=0;
static uint32_t g_telemetryControlMs=0;
static uint8_t g_telemetryControlSeq=0;
static bool ownedTxFits(size_t n);
static void ownedTxResult(int16_t st,uint64_t call,uint64_t ret,uint32_t air);
static void ownedGrantObserve();
static inline bool ownedWasSkipped(){return g_owned.scope&&g_owned.skipped;}
struct OwnedScope {
  RadioFlashGuard flashGuard; // Constructed first, released after the outcome destructor body.
  uint32_t control; uint8_t controlSeq;
#if LSM_RELAY_PLEA
  uint8_t plea; uint16_t pleaNext;
#endif
  OwnedScope();
  ~OwnedScope();
};
static int16_t secureTransmit(const uint8_t *p,size_t n) {
  if(!g_irqPolicyVerified)return -2006; // Before admission, sealing, or radio access.
  const uint64_t preSeal=(uint64_t)esp_timer_get_time();
  if(!ownedTxFits(n))return -2004;
  if (ksDenied((uint8_t)NODE_ID)) return -2001;
  if (!joinTxBudgetFits(n)) { ++g_joinBudgetBlocked; return -2001; }
  uint8_t wire[255]; size_t bytes=sizeof(wire);
  if(!securemesh::seal(p,n,wire,bytes)) return -2001;
  if (!joinTxBudgetFits(n)) { ++g_joinBudgetBlocked; return -2001; }
  if(!ownedTxFits(n))return -2004;
  const uint64_t call=(uint64_t)esp_timer_get_time();
  const uint32_t air=g_owned.scope?g_owned.air:(uint32_t)radio.getTimeOnAir(bytes);
  int16_t st = radio.transmit(wire,bytes);
  const uint64_t ret=(uint64_t)esp_timer_get_time();
  ownedTxResult(st,preSeal,ret,air);
  // Direct JOIN has no outer latency sampler. Calibrate only its first success.
  if(st==RADIOLIB_ERR_NONE && !g_txLatSamp && g_role==0 &&
     n==4U && p[0]=='J')txLatSample(preSeal,ret,air); // sizeof(JoinPkt)==4 pinned below
  if (st == RADIOLIB_ERR_SPI_CMD_TIMEOUT) radioFaultNote(11, st); // TX command is the initiating fault
  return st;
}
static uint32_t g_secLenFail = 0;
static uint32_t g_secReadFail = 0;
// Diagnostic counters only. Preserve secureRead results and all authentication gates.
static uint32_t g_secChipCrc=0,g_secChipHeader=0,g_secChipOther=0;
static int16_t g_secChipLastError=0;
static uint32_t g_secOpenFail = 0;
static uint32_t g_secFilterFail = 0;
static size_t securePacketLength() {
  const size_t n=radio.getPacketLength();
  return n>MESH_SEC_OVERHEAD && n<=255 ? n-MESH_SEC_OVERHEAD : 0;
}
static int16_t secureRead(uint8_t *p,size_t n) {
  uint8_t wire[255], sender=0;
  g_secureRxSender = 0;
  const size_t actual=radio.getPacketLength();
  if(!n || n>MESH_SEC_MAX_PLAIN || actual!=n+MESH_SEC_OVERHEAD) { g_secLenFail++; return -2001; }
  int16_t rc=radio.readData(wire,actual);
  if (rc == RADIOLIB_ERR_SPI_CMD_TIMEOUT) radioFaultNote(16, rc);
  // No CRC/header rescue may bypass the mandatory authentication check.
  if(rc!=RADIOLIB_ERR_NONE) { g_secReadFail++;g_secChipLastError=rc;if(rc==RADIOLIB_ERR_CRC_MISMATCH)g_secChipCrc++;else if(rc==RADIOLIB_ERR_LORA_HEADER_DAMAGED)g_secChipHeader++;else g_secChipOther++;return -2002; }
  size_t plain=n;
  // The cryptographic replay table can address 64 production seats, but only
  // identities in this image's explicit fleet manifest may reach a parser.
  // This closes the gap where possession of the test root plus an unused node
  // number could emit control traffic even though roster admission refused it.
  if(!securemesh::open(wire,actual,p,plain,sender) || plain!=n ||
     !ksAllowed(sender) || ksDenied(sender)) { g_secOpenFail++; return -2001; }
  // The volatile bench mask models only the present 1..15 hardware set. IDs
  // above that range are controlled by the production allow-list and topology,
  // and must never enter an undefined 16-bit shift here.
  if (sender <= 15 && !(g_benchLinkMask & (1u << sender))) { g_secFilterFail++; return -2003; }
  g_secureRxSender = sender;
  return RADIOLIB_ERR_NONE;
}
static uint32_t secureAirTime(size_t n) { return (uint32_t)radio.getTimeOnAir(n+MESH_SEC_OVERHEAD); }
static int meshHex(char c) {
  if(c>='0' && c<='9') return c-'0';
  if(c>='a' && c<='f') return c-'a'+10;
  if(c>='A' && c<='F') return c-'A'+10;
  return -1;
}
static void provisionMeshUSB() {
  // Accept only while unprovisioned. No key is printed or logged.
  if(securemesh::ready()) { Serial.println("Mesh key already provisioned"); return; }
  char line[66]={}; uint8_t key[32]={};
  size_t n=Serial.readBytesUntil('\n',line,65);
  if(n && line[n-1]=='\r') --n;
  bool ok=n==64;
  for(unsigned i=0;i<32 && ok;i++) {
    int hi=meshHex(line[2*i]),lo=meshHex(line[2*i+1]);
    if(hi<0 || lo<0) ok=false; else key[i]=(uint8_t)((hi<<4)|lo);
  }
  ok=ok && securemesh::provision(key);
  memset(key,0,sizeof(key)); memset(line,0,sizeof(line));
  Serial.println(ok ? "Mesh key saved; reboot required" : "Mesh key provisioning rejected");
}
static void benchLinkUSB() {
  char text[6]={}; size_t n=Serial.readBytesUntil('\n',text,5);
  if(n && text[n-1]=='\r') --n;
  uint16_t mask=0;
  if(n!=4) { Serial.println("BENCH filter rejected"); return; }
  for(unsigned i=0;i<4;i++) { int h=meshHex(text[i]); if(h<0) {Serial.println("BENCH filter rejected");return;} mask=(uint16_t)((mask<<4)|h); }
  if(mask & ~0xFFFEu) {Serial.println("BENCH filter rejected");return;}
  g_benchLinkMask=mask;
  Serial.printf("BENCH receive filter=%04X; volatile, reset restores all V2 peers\n",mask);
}
// ----------------------- KCT8103L RF front end -----------------------
// The Wireless Tracker V2 has a KCT8103L FEM (PA plus 21 dB LNA) between the
// SX1262 and the antenna. RF path: SX1262, Pi attenuator, KCT8103L, antenna.
// Before v4.4 these pins were never driven, so the whole fleet transmitted
// and received through a shut down amplifier. That was the missing range.
// Pin map from the Heltec schematic via the Meshtastic
// heltec_wireless_tracker_v2 variant, which is the known working reference:
//   GPIO 7  VFEM LDO power, HIGH = FEM rail on
//   GPIO 4  CSD chip enable, HIGH = on, LOW = shutdown
//   GPIO 5  CTX, HIGH for TX, LOW for RX with the LNA
//   DIO2    CPS, TX and RX path select, raised by the SX1262 automatically
//           during transmit (radioConfig sets setDio2AsRfSwitch)
#ifdef LSM_BOARD_LILYGO
// v7.28.47: no KCT8103L on the LilyGO. TX/RX path select is the LR1121
// DIO5/DIO6 switch table (set in lsmRadioBegin); there is no LNA bypass line.
// femTx/femRx stay as empty calls so the 14 transmit sites compile unchanged.
static const int PIN_FEM_POWER = PIN_RT9080_EN;   // the radio rail enable stands in for the FEM LDO at the power-off and wake sites
static const int PIN_FEM_CSD   = -1;
static const int PIN_FEM_CTX   = -1;
void femInit() {
  pinMode(PIN_RT9080_EN, OUTPUT);
  digitalWrite(PIN_RT9080_EN, HIGH);   // RT9080 LDO: radio rail on before radio.begin (vendor LR1121_PingPong_2)
  delay(100);
  Serial.println("RT9080 radio rail on (LilyGO LR1121)");
}
void femTx() {}
void femRx() {}
void femPatch8B5() {}
#else
static const int PIN_FEM_POWER = 7;
static const int PIN_FEM_CSD   = 4;
static const int PIN_FEM_CTX   = 5;

void femInit() {
  pinMode(PIN_FEM_POWER, OUTPUT);
  digitalWrite(PIN_FEM_POWER, HIGH);   // power the FEM rail
  delay(5);
  pinMode(PIN_FEM_CSD, OUTPUT);
  digitalWrite(PIN_FEM_CSD, HIGH);     // enable the chip
  pinMode(PIN_FEM_CTX, OUTPUT);
  digitalWrite(PIN_FEM_CTX, LSM_RX_LNA_BYPASS ? HIGH : LOW); // start in selected RX gain mode
  Serial.println("KCT8103L FEM powered and enabled");
}
void femTx() { digitalWrite(PIN_FEM_CTX, HIGH); }  // v7.28.41: CTX HIGH = RX LNA bypass. DIO2/CPS does the TX/RX path select automatically (setDio2AsRfSwitch); CTX only sets LNA gain.
void femRx() { digitalWrite(PIN_FEM_CTX, LSM_RX_LNA_BYPASS ? HIGH : LOW); } // CTX HIGH bypasses external RX gain; LOW uses full LNA gain.

// Undocumented SX1262 register patch recommended by Heltec and Semtech for
// improved RX sensitivity, applied by Meshtastic: set bit 0 of register
// 0x8B5. Calibration clears the bit, so radioConfig reapplies it every init.
void femPatch8B5() {
  radio.setReg8B5();
}
#endif


// v7 wire. Schedule beacon, TK to all, slot 0. 62 bytes fixed as of v7.15.0.
// This comment said 36 bytes until v7.15.2; the beacon went 36, then 51, then 54,
// then 62, and the prose was never moved. Size is pinned by the static_assert
// below: add a field and that assert fires, and BEACON_AIR_US and TK_SLOT_US
// must move with it.
struct __attribute__((packed)) SchedBeacon {
  uint8_t  magic;                     // 'K'
  uint8_t  ver;                       // 7
  uint8_t  tkId;
  uint8_t  seq;                       // frame counter low 8
  uint8_t  sphere;                    // v7.29.38: authority epoch (legacy sphere byte was always zero and unread)
  uint8_t  nSlots;                    // v7.28.37: count of live slot entries; the slot[] array is now the TAIL of the struct (see below) so the fixed head keeps constant offsets when the beacon is sent short
  uint8_t  grantId;                   // v7.28.59: TAIL TOKEN SLOT grantee this frame. 0 = no tail slot, frame not extended. == tkId = the keeper speaks (its fingerprint or a revocation). Else that member speaks. (v7.28.11 reserved it for the grant-echo cut; written nowhere until now.)
  uint8_t  schedHops;                 // 0 from the TK itself, +1 per relay
  uint16_t frameMs10;                 // v11: dynamic frame length, units of 10 ms (roster-scaled)
                                      // v7.28.98: uint8 capped this at 255 = 2550 ms, and the clamp
                                      // shortened the frame SILENTLY while nSlots stayed published.
  int32_t  tkEastCm;                  // TK absolute position for the dashboard
  int32_t  tkNorthCm;
  int32_t  tkLatI;                    // v7.30.9: keeper latitude, signed microdegrees; 0/0 means unavailable
  int32_t  tkLonI;                    // v7.30.9: keeper longitude, signed microdegrees
  int16_t  tkAltDm;                   // v7.30.9: keeper receiver altitude, decimetres
  uint8_t  tkConf;                    // v7.30.9: keeper position confidence, 0..63
  int16_t  tkScore;                   // v6.1: election score, clamped to int16
  int8_t   tkRssiAvg;                 // v6.1: sender smoothed peer RSSI, tie rung 1
  uint8_t  tkTie;                     // v6.1: rosterCount<<4 | battery, rungs 2 and 3 (v7.28.101: field was described as centrality, it has carried roster size since v7.28.60; wire layout unchanged)
  uint8_t  nodeCount;                 // v6.6: sphere occupancy (roster size at the TK)
  uint8_t  sFlags;                    // v6.6/v7.14: bit0 = sphere_full (TK debounced); bits 1..7 = departResid100us, sender-stamped jitter for relayed-anchor recovery, 100us quantum, 0..12700us range
  uint8_t  successor;                 // v6.6: TK-named best survivor, 0 none
  // v7.12.5: TK-directed frequency switch, dashboard-initiated test. Every
  // member reads these fresh off whatever beacon it most recently heard, no
  // local countdown timer of its own, so a node that missed a few frames
  // still lands on the right absolute frame: it just sees a lower number.
  // freqCountdown == FREQ_SWITCH_NONE (0xFF) means no change pending.
  // freqCountdown == 0 means switch NOW, right after this beacon.
  float    freqTargetMHz;             // target frequency, meaningless if freqCountdown == FREQ_SWITCH_NONE
  uint8_t  freqCountdown;             // frames remaining, FREQ_SWITCH_NONE = no pending change
  // v7.13.0: relay tier geometry + pre-announced resize. schedTiers is the
  // count in force THIS frame; a member never infers it, it is told, so TK and
  // member cannot disagree about where member slots start. resizeCountdown
  // works exactly like freqCountdown: read fresh off whatever beacon was last
  // heard, no local timer, so a node that missed frames still lands on the
  // same ABSOLUTE frame, it just sees a lower number.
  uint8_t  schedTiers;                // relay tiers in force this frame
  uint8_t  resizeTiers;               // pending tier count, meaningless if resizeCountdown == RESIZE_NONE
  uint8_t  resizeCountdown;           // frames remaining, 0xFF = nothing pending
  uint8_t  heardMask[8];              // v7.28.98: 3 bytes = 24 bits against 64 slots. Slots 24-63 were
                                      // invisible to the orphan detector, so no member past slot 23
                                      // could ever be given a relay parent. 8 bytes covers V7_SLOTS_MAX.
  uint8_t  relayForId;
  uint8_t  relayById;
  uint8_t  relayForId2;               // v7.28.104: SECOND NAMED PAIR, same meaning as the first. The keeper names both on the
  uint8_t  relayById2;                // same beacon, same frame. relayById2 is never the same board as relayById. 0 = no second leg.
  uint16_t slotUs10;
  uint8_t  subFrame;
  // v7.16.0: the join window stops being inferred. joinResUs500 is the TOTAL
  // reservation the TK has set aside between the end of the relay schedule
  // region and the start of member slots, in 500 us units, and it is the ONLY
  // thing that decides where member slots begin. A member never adds
  // JOIN_KEYWIN_US and JOIN_ALLOW_US of its own any more; it is told, exactly
  // like schedTiers since v7.13.0, so the TK and the member cannot disagree.
  // This is the field whose absence caused the 2026-07-28 join defect: the
  // reservation was 25000 us of local constants while the join packet on air
  // was 56576 us, so every join overran member slot 0 by 31576 us.
  // joinMod is the join turn modulus in force this frame. 0 means join closed.
  // A node keys in when (seq + NODE_ID) % joinMod == 0, which is a perfect
  // collision free round robin whenever joinMod is at least the span of node
  // IDs in use, and degenerates into permanent pairing when it is smaller.
  uint8_t  joinResUs500;
  uint8_t  joinMod;
  uint8_t  aggGrantId;                 // v7.30.0: relay granted one aggregate position tail, 0 = none.
  uint8_t  aggGrantRecs;               // v7.30.0: maximum compact records the grant may carry.
  // v7.28.37 VARIABLE-LENGTH TAIL. slot[] MUST be the last field: the beacon is
  // built into this full struct but transmitted at beaconWireB(nSlots) bytes, so
  // the fixed head (offsets 0..BEACON_WIRE_FIXED_B-1) travels intact and a
  // receiver overlays the short frame onto this struct with every fixed field in
  // place. The array is sized to the CEILING (V7_SLOTS_MAX), not today's roster;
  // only slot[0..nSlots-1] are ever read or sent. offsetof/sizeof asserts below
  // pin both invariants so this cannot drift.
  uint8_t  slot[V7_SLOTS_MAX];        // member id per slot, 0 empty
};
// v7.15.2: SchedBeacon size is PINNED. MemberPkt has carried this guard since
// v7.13.1; SchedBeacon never did, and SchedBeacon is the struct that drives the
// frame geometry. Its size sets BEACON_AIR_US (62 B, 103 payload symbols, 115.25
// symbols total at 1024 us each, 118016 us), which sets TK_SLOT_US, which sets the
// frame anchor and the relay-schedule region. The existing
// TK_SLOT_US == BEACON_AIR_US + TK_TX_OVERHEAD_US assert only checks two constants
// against each other; it stays true no matter what this struct becomes and cannot
// catch a size drift. The struct is also sent and length-checked with
// sizeof(SchedBeacon), so a size change stays self-consistent on air and silently
// invalidates the timing constants instead of failing loudly. V7_SLOTS_PER_FRAME
// (22) is a term in the size and is exactly what the v7.16.0 sub-frame and
// dynamic-slot-width work will touch. If this fires, recompute the airtime from the
// PHY formula and move BEACON_AIR_US and TK_SLOT_US together. Update the bound
// deliberately, never reflexively.
// v7.28.37 VARIABLE-LENGTH INVARIANTS, replacing the fixed sizeof(SchedBeacon)==64 pin.
// The beacon no longer has one size; it has a fixed head plus a variable slot tail.
// Two things must hold instead, and both are pinned here:
//   (1) the slot array begins exactly at BEACON_WIRE_FIXED_B, so a beacon sent at
//       beaconWireB(nSlots) bytes overlays this struct with every fixed field aligned;
//   (2) the whole struct is the fixed head plus the ceiling of slots, so the build
//       buffer can always hold a maximum-length beacon.
// The airtime and TK-slot timing are no longer derived from a single beacon size;
// they come from beaconAirUsLive(nSlots)/tkSlotUsLive(nSlots), pinned at the SF7/22 reference
// geometry above. If (1) fires, a fixed field was added below the slot tail or the
// head grew: put new fixed fields ABOVE slot[] and correct BEACON_WIRE_FIXED_B.
static_assert(offsetof(SchedBeacon, slot) == BEACON_WIRE_FIXED_B,
  "v7.28.37: slot[] must start at BEACON_WIRE_FIXED_B (42). A fixed field is misplaced "
  "or BEACON_WIRE_FIXED_B is wrong; the short-beacon overlay depends on this exact offset.");
static_assert(sizeof(SchedBeacon) == BEACON_WIRE_FIXED_B + V7_SLOTS_MAX,
  "v7.28.37: SchedBeacon must be the fixed head plus V7_SLOTS_MAX slots. Packing or a "
  "stray field changed the size; the build buffer must hold a full-length beacon.");
// backhaul advertise v1: additive, backhaul-channel-only beacon. Never
// collides with the sphere beacon ('K'); the sphere wire (ver 16) is untouched.
// 8 bytes, CRC-8 guarded like every other LSMESH packet.
struct __attribute__((packed)) BackhaulBeacon {
  uint8_t  magic;        // 'B'
  uint8_t  bhver;        // backhaul protocol version, 1
  uint8_t  tkId;         // advertising TK node id
  uint8_t  sphereSize;   // roster size at the TK, master-selection input
  float    workingMHz;   // the sphere working channel this TK runs
  uint8_t  phyProfile;   // authenticated working PHY; discovery itself is fixed SF7/125
  uint8_t  bhFlags;      // v7.19.0 brick3: bit0 = full (roster >= FULL_LINE, debounced); bit1 = accepting-returns (under FULL_LINE past the reopen debounce). sphereSize above carries the migration math.
  uint16_t bhUptimeS;    // v7.19.0 brick4: seconds this TK has held authority (millis()-g_tkSinceMs). Longest-lived wins the timebase-reference election.
  uint32_t bhTxUs;       // v7.19.0 brick4: this TK's esp_timer at transmit, for the coarse cross-sphere offset a follower records. Diagnostic, ToF-uncompensated.
  uint8_t  crc;          // CRC-8 over the preceding 15 bytes
};
static_assert(sizeof(BackhaulBeacon) == 17, "V7.31: BackhaulBeacon must include the authenticated working PHY profile.");
#define BACKHAUL_BEACON_MAGIC 'B'
// ---- v7.20.0: backhaul command-center telemetry (design lock 2026-07-29) ----
// Two streams, two rhythms, per Stuart: (1) 'O' OFFSET BURST, unconditional on
// every TK backhaul visit, the cheap living map: every live peer's sphere-local
// x/y offset (cm) plus confidence and selfHops. (2) 'G' ANCHOR REPLY, sent ONLY
// when the command center asks with a 4 B 'Q' pull: the top ANCHOR_PULL_N peers
// by confidence whose absolute seed (lat/lon/alt from MemberPkt types 3/4/5,
// already assembled in g_peers[].seedLatI/seedLonI/seedAltDm) is complete
// (seedMask 0x07). Three non-collinear anchors pin translation AND rotation of
// the whole offset cloud; six gives full redundancy plus a least-squares fit at
// the command center. The command center owns the transform; the mesh stays
// dumb. WIRE_VER (24) untouched: these are NEW backhaul magics, the existing
// SchedBeacon/MemberPkt/JoinPkt/BackhaulBeacon formats do not move; old builds
// ignore unknown magics. Flash all 14 together regardless.
#define BH_OFFSET_MAGIC 'O'
#define BH_PULL_MAGIC   'Q'
#define BH_ANCHOR_MAGIC 'G'
#define BH_TLM_VER      1
#define BH_OFFSET_MAX_N 30      // 4 + 7*30 = 214 B, under the 255 B PHY ceiling
#define ANCHOR_PULL_N   6       // need any 3 to solve; 6 = dropout margin + least-squares
struct __attribute__((packed)) BhOffsetRec { uint8_t id; int16_t eCm; int16_t nCm; uint8_t conf; uint8_t selfHops; };
struct __attribute__((packed)) BhAnchorRec { uint8_t id; int32_t latI; int32_t lonI; int16_t altDm; uint8_t conf; };
struct __attribute__((packed)) BhPullReq   { uint8_t magic; uint8_t ver; uint8_t dstTk; uint8_t crc; };  // dstTk 0 = any TK
static_assert(sizeof(BhOffsetRec) == 7,  "v7.20.0: BhOffsetRec is 7 B on air");
static_assert(sizeof(BhAnchorRec) == 12, "v7.20.0: BhAnchorRec is 12 B on air");
static_assert(sizeof(BhPullReq)   == 4,  "v7.20.0: BhPullReq is 4 B on air");
#define BACKHAUL_BEACON_VER   4   // V7.31: fixed SF7 discovery plus authenticated working PHY profile.
static uint32_t g_lastBackhaulAdvMs = 0;   // backhaul advertise v1 throttle
// v7.19.0 brick4: backhaul timebase-reference election state. Reuses the sphere-
// election primitive: longest-lived TK is the shared reference, tie -> lowest node id.
// A follower records an OFFSET to the reference and NOTHING ELSE: per the v9.5.8 rule
// the backhaul INFORMS, it never overrides local timing. Every sphere keeps its own
// data-distributed clock. g_bhRefTkId == NODE_ID means this TK is (so far) the reference.
static uint8_t  g_bhRefTkId     = 0;       // node id of the current timebase reference (0 = none yet)
static uint16_t g_bhRefUptimeS  = 0;       // that reference's advertised uptime, last heard
static int32_t  g_bhRefOffsetUs = 0;       // coarse (localRx - refTx - airtime), diagnostic only, ToF-uncompensated
static uint32_t g_bhRefHeardMs  = 0;       // v7.19.0 brick4: last time the current non-self reference was heard, drives failover
#define BH_ELECT_LISTEN_MS 250   // v7.19.0 brick4: bounded post-advertise listen on backhaul. SHORT by design (off the working channel). Bench-tunable: longer catches peers more reliably, at the cost of frames missed on the working channel.
#define BH_HOLD_CEIL_MS 70              // v7.20.9: hold-to-complete grace on the backhaul listen (doc 41). One 16 B BackhaulBeacon is 52 ms on air; 70 covers any single legitimate reception so a boundary-truncated catch is finished instead of thrown away. A noise-latched preamble costs at most one bounded 70 ms hold, witnessed 0xB5.
#define BH_ERRAND_OVERHEAD_US 90000UL   // v7.20.9: two retunes + FEM + startReceive per errand piece. Measured 84 ms on the v7.20.8 bench (555 freeze minus 118 beacon, 52 B beacon, 52 O burst, 250 listen), budgeted with margin.
static uint8_t  g_bhThisFrame  = 0;     // v7.20.9: 0 none, 1 transmit piece, 2 listen piece. Decided at frame compute, BEFORE the beacon, so the published frameMs10 already budgets the widened tail. Members adopt frameMs10 as always: no wire change.
static uint8_t  g_bhOwedListen = 0;     // v7.20.9: a transmit frame ran, the next TK frame carries the listen piece. Strict alternation; the dynamic frame length is the jitter, two spheres cannot phase-lock (doc 41).
static uint32_t g_bhTailExtUs  = 0;     // v7.20.9: tail widening for the piece this frame carries
// 9-byte member data / join request, production-mirrored, CRC-8 guarded
#define MPKT_GRACE 0x01   // v7.29.5: MemberPkt.graceFlags bit 0, volunteered forward
// v7.29.8: graceFlags[7:1] on every hop-0 origin copy is origin_depth+1.
// 0 = unstamped (pre-7.29.8 board, or this board has no live depth). A relay
// copies the byte and only ORs MPKT_GRACE, so source depth survives the climb.
// Encoded +1 so an all-zero byte from an old board cannot be read as depth 0.
#define MPKT_SRC_DEPTH_SHIFT 1
struct __attribute__((packed)) MemberPkt {
  uint16_t src_id;
  uint8_t  type;        // 0 member data, 2 join request, 6 present/keepalive (v7.11.6), 7 swarm-join request (v7.28.5 MEMBER_TYPE_SWARM_REQ; conf64 = requested window count)
  uint8_t  seq;
  int8_t   x_dm;        // sphere-local X, decimetres
  int8_t   y_dm;
  int8_t   z_floor;
  // v7.28.70-absposbranch: ABSOLUTE position ADDED ALONGSIDE the x/y/z offsets,
  // which are KEPT. Per Stuart 2026-09-16: the decimetre offsets are the indoor
  // ultra-wideband path, officer to officer relative position including floor,
  // and must not be removed. This branch carries both so a mile-apart GPS drive
  // test can be run without disturbing that. The offsets alone are plus or minus
  // 12.7 m, a bench range, so outdoors every node pins the clamp; these two
  // fields carry real position with no seed dependency, which matters because
  // seed parts (types 3/4/5) only travel one hop and a node a mile out never
  // hears them. Growth eight bytes, 22 to 30. Wire format moved, WIRE_VER 31,
  // whole fleet flashes together. Sentinel: both zero means no position held.
  // LONGER TERM (Stuart's direction, not built here): seed absolute position
  // once against known ground truth, then carry only the x, y, z and floor
  // deltas on the wire. That is far shorter than lat/lon on every packet.
  int32_t  latI;        // latitude, microdegrees (degrees times 1e6)
  int32_t  lonI;        // longitude, microdegrees
  uint8_t  flags_conf;  // [7] KEEPALIVE (v7.28.33: set on every type 0 and type 6 packet sent from a granted slot; was EVENT, never set or read), [6] relay, [5..0] conf64
  // v12: departure-timestamp profile. The sender states WHEN it departed,
  // as an offset from the shared TK frame-baseline (g_frameAnchorUs), in
  // units of 1 us. v7.21.0: this comment read "10 us" from v12 until now and
  // was wrong by a factor of ten; the field comment below and departDevFrom
  // have always said and computed raw microseconds, and the code was right.
  // The TK computes delay = its own receive offset minus
  // this, giving the true propagation+processing time with NO dependence on
  // which slot the node holds. This kills the slot-inference balloon that
  // pinned the profile at its clamp under the dynamic frame. Both ends are
  // expressed in the same TK-distributed baseline, so per-node oscillator
  // skew cancels and does not enter the delay.
  int16_t  departDevUs;     // v7.15.0: signed deviation (dOff - schedUs). Cannot wrap; 1 us resolution.
  // v7.21.0: attToken carries the CRYSTAL TAG AND NOTHING ELSE. Until this
  // patch it carried two different things with no discriminator: the low four
  // bytes of the pairwise HMAC once a member enrolled, and the departure
  // integrity value before that. The TK read it as the departure value
  // unconditionally, so every member went permanently unmeasurable the instant
  // it enrolled, at 494.7 s on the 2026-08-26 run. The departure tag now lives
  // in depAttest16 below. DO NOT put a second meaning back on this field: the
  // discriminator that would be needed does not exist on the wire.
  // Also carried opaquely by the aggregating join relay, which forwards it
  // byte for byte and never validates it, so that path is indifferent.
  uint32_t attToken;        // low 4B of the pairwise HMAC tag; 0 when this sender is not enrolled
  // v7.11.0: hidden-node dual-TK relay. Set when this member heard a SECOND
  // live TK different from the one it reports to. 0 tkId = nothing to relay.
  uint8_t  relayRivalTk;      // the OTHER TK's node id, 0 = none seen recently
  uint8_t  relayRivalEpoch;   // v7.29.38: hidden rival authority generation
  uint8_t  relayRivalTie;     // that TK's self-reported rosterCount<<4|battery (v7.28.101 rename, wire layout unchanged)
  int8_t   relayRivalRssiAvg; // that TK's self-reported peer RSSI health
  int16_t  relayRivalScore;   // v7.29.23: signed published election score
  // v7.11.10: real hop count for the data-relay flood, mirrors schedHops on
  // the schedule side. 0 = original sender, transmitting for the first
  // time. A relay bumps this by exactly 1 before resending, never more, so
  // depth is always traceable and never silently understated.
  uint8_t  hops;
  uint8_t  relayerId;
  // v7.28.97: VOLUNTEER RELAY REPORT. On a hop-0 packet this names a member that
  // THIS sender hears directly and that the keeper's own heardMask says the keeper
  // did not hear. 0 = nothing to report. Meaningful ONLY at hops == 0: a relay
  // zeroes it when it bumps hops, exactly as it overwrites relayerId, so a relayed
  // copy can never carry a stale report. Bit 0x04 of the side-channel byte in
  // relayerId is raised on the same packet as the discriminator.
  uint8_t  volunteerFor;
  // v7.29.5: GRACE FLAGS, its own byte. Bit 0 (MPKT_GRACE) marks a VOLUNTEERED
  // forward: a seated board that was NOT the named leg carried this copy after
  // observing one schedule sequence with no forward heard for the sender. Set by
  // the volunteer in memberFloodNote, carried unchanged by every named leg after
  // it (a named leg may carry a grace copy onward, a volunteer may NOT pick one
  // up again: volunteering keys on hops == 0, so the grace is one hop by
  // construction). The keeper reads it at any hop: a grace arrival re-seats a
  // fallen sender and names the relayer as its leg in one step. Zero on every
  // origin packet (all builders memset). Own byte, not a bit in volunteerFor,
  // because that byte is double booked (orphan report at hop 0, forwarder depth
  // on a relayed copy) and flags_conf has no free bit. Payloads 30..33 share
  // one SF7 symbol step, so 32 costs nothing on air; WIRE_VER 34 -> 35.
  uint8_t  graceFlags;
  // v7.21.0: WAS cumDelay100us, reclaimed. That field was WRITE ONLY for its
  // whole life: relayMemberTx read its own prior value and wrote it back, and
  // no other site in any of the twelve board trees ever read it, not the TK,
  // not the log, not one decision. The audit of 2026-08-26 found it to be the
  // only clean sixteen bit hole in the packet. It now carries the departure
  // integrity tag, which used to share attToken and is what broke.
  // A RELAY MUST NOT TOUCH THIS. The tag covers src, seq and departDevUs, none
  // of which a relay changes, so a relayed copy still verifies at the TK.
  // Cost accepted at v7.21.0: the multi hop delay budget cumDelay100us was
  // meant for is now derived from hop count plus per tier geometry instead.
  uint16_t depAttest16;     // departAttest(src, seq, departDevUs); integrity, not authenticity
  uint8_t  crc;         // CRC-8 over all prior bytes
};

// v7.30.0 ADAPTIVE AGGREGATE EPOCH.  A relay asks for capacity with a normal
// slotted MemberPkt type 9.  The keeper grants one relay in the next schedule,
// and that relay answers in a separately budgeted tail with several compact
// position deltas.  This keeps demand, grant and payload independently visible
// in the recorder and avoids pretending several child updates are one badge.
#define AGG_POS_MAGIC 'P'
#define AGG_POS_MAX_REC 12U
#ifndef LSM_ADAPTIVE_AGGREGATE
#define LSM_ADAPTIVE_AGGREGATE 1
#endif
struct __attribute__((packed)) AggPosRec {
  uint8_t id;
  int16_t eCm;
  int16_t nCm;
  uint8_t conf;
  uint8_t age100ms;
};
struct __attribute__((packed)) AggPosPkt {
  uint8_t magic;
  uint8_t ver;
  uint8_t relayId;
  uint8_t seq;
  uint8_t count;
  uint8_t flags;
  AggPosRec rec[AGG_POS_MAX_REC];
  uint8_t crc;
};
static_assert(sizeof(AggPosRec) == 7, "v7.30.0 compact aggregate record must stay 7 bytes");
static constexpr uint32_t AGG_POS_WIRE_MAX_B = 7u + 7u * AGG_POS_MAX_REC;
static constexpr uint32_t AGG_POS_SLOT_US =
  lsmLoraAirUs(AGG_POS_WIRE_MAX_B + MESH_SEC_OVERHEAD, LSM_ACTIVE_SF,
               LSM_ACTIVE_BW, (uint8_t)(LORA_CR - 4)) + 2u * SLOT_GUARD_US;

// v7.13.1: compile-time staleness guard. AIRTIME8_US (36000 us) is the SF7/125k
// airtime of an EIGHT byte payload, but MemberPkt is 19 bytes. The constant is
// arithmetically stale. It is deliberately LEFT AS-IS: bench LOG_TRIM data shows
// a 2 us median departure deviation, because the timing-advance loop disciplines
// every node to the TK clock and the slot self-check cancels the constant on both
// sides. Stale is not the same as harmful. This assert exists so that if MemberPkt
// ever grows again, the build STOPS and a human re-reads this note rather than the
// error compounding silently. Update the bound deliberately, never reflexively.
// v7.21.0: still 22. The depAttest16 swap changed the MEANING of bytes 19-20 and
// not the size, so this assert could not have caught it and did not. That is why
// WIRE_VER moved instead. A size assert cannot police a semantic change; if a
// future patch repurposes a field again, move the wire version in the same commit.
#define MPKT_SRC_DEPTH_SHIFT 1
static uint8_t mpktOriginDepth(const MemberPkt* p){
  uint8_t v = (uint8_t)(p->graceFlags >> MPKT_SRC_DEPTH_SHIFT);
  return v ? (uint8_t)(v - 1) : 255;
}
static void mpktStampOriginDepth(MemberPkt* p){
  if (g_anchorHops == 255) return;
  uint8_t v = (uint8_t)(g_anchorHops + 1);
  if (v > 127) v = 127;
  p->graceFlags = (uint8_t)((p->graceFlags & MPKT_GRACE) | (uint8_t)(v << MPKT_SRC_DEPTH_SHIFT));
}

static_assert(sizeof(MemberPkt) == 35,   // v7.29.38: hidden-rival epoch added, WIRE_VER 38
  "MemberPkt size changed. AIRTIME8_US is an 8-byte-payload figure and is already "
  "stale by design; re-read the v7.13.1 note before touching frame geometry.");
static_assert(MEMBER_WIRE_B == sizeof(MemberPkt),
  "MEMBER_WIRE_B must equal sizeof(MemberPkt); SF-dependent LoRa symbol quantization can otherwise overlap adjacent member slots.");

// v7.16.0: the join request is its own packet now, not a MemberPkt.
// A join needs to say who is asking and nothing else. tkOnJoinReq() reads
// only src_id, and of the 22 bytes the old MemberPkt join carried, 14 were
// memset to zero and transmitted as padding while the altitude and floor
// hint in the rest was consumed nowhere on the receive path for type 2
// (peerSeen is gated to type 0, peerTouch to type 6, seed assembly to 3..5).
// That same information arrives on the first real data packet one frame
// after admission, so nothing is lost by dropping it here.
// 2, 3, 4 and 5 byte payloads all land on 18 symbols at SF7/125k/CR4-5, so
// ver and crc are free and are taken. Airtime 30976 us, against 56576 us for
// the MemberPkt this replaces.
// NOTE for anyone adding a field: the next byte is still free (5 bytes is
// still 18 symbols) but the sixth crosses to 23 symbols and costs 5120 us.
struct __attribute__((packed)) JoinPkt {
  uint8_t magic;    // 'J'
  uint8_t ver;      // set from WIRE_VER, moves in lockstep with SchedBeacon.ver
  uint8_t src_id;   // the joiner
  uint8_t crc;      // CRC-8 over the first 3 bytes
};
static_assert(sizeof(JoinPkt) == 4,
  "JoinPkt size changed. Its airtime is measured at boot with getTimeOnAir and "
  "published by the TK as joinResUs500, so the reservation follows automatically, "
  "but re-check the symbol step: 5 bytes is still 18 symbols, 6 crosses to 23.");

// ----------------------- v7.11.10: real multi-hop flood relay, state -----------------------
// Sizing constants (RELAY_MAX_HOPS, RELAY_SCHED_SLOT_US, RELAY_REPLY_SLOT_US,
// RELAY_NO_DEADLINE) live up with TK_SLOT_US and BEACON_AIR_US, since
// MEMBER_SLOTS_BASE_US needs them for its own offset math. This block is
// just the runtime tracking state, which needs the packet struct types
// defined above it.
//
// Replaces an earlier same-session draft that pinned relay duty to one
// static board and capped depth at one hop. That version could not exceed
// what a single relay board provides and had no answer for two nodes both
// hearing and relaying the same packet, Stu caught both problems directly.
// This is the real one: any node can relay, depth grows hop by hop, real
// LoRa airtime economics are respected by giving every hop tier its own
// fixed sub-window inside a wider contention window, and duplicate
// suppression is the mechanism that keeps a flood from becoming a storm,
// the same mechanism that also stops a relayed duplicate from being
// double-counted as if it were two separate reports.

// ---- schedule-side flood state, one instance, keyed on the current seq ----
// Only one schedule is ever in flight at a time, so a single set of scalars
// is enough, unlike the member side below.
static uint8_t  g_schedFloodSeq      = 0xFF;
static uint8_t  g_schedFloodBestHop  = 255;   // best (lowest) hop count heard so far this seq
static uint8_t  g_schedFloodOutHop   = 255;   // hop value we are scheduled to transmit, if any
static bool     g_schedFloodRelayed  = false;
static uint32_t g_schedFloodDeadlineUs = RELAY_NO_DEADLINE;
static uint8_t  g_relaySchedRaw[sizeof(SchedBeacon)];   // buffer holds a full-length beacon; the relay sends only g_relaySchedLen bytes
struct SchedRelayStats {uint32_t calls=0,success=0,failed=0,geometryBlocked=0,budgetBlocked=0,overruns=0,maxOverrunUs=0,flashBlocked=0;};
static SchedRelayStats g_schedRelayStats{};
struct SchedRelayTiming {uint32_t lastTxUs=0,lastRxUs=0,maxTxOverAirUs=0,maxRxUs=0,lastAirUs=0,lastPredictedEngageUs=0;};
static SchedRelayTiming g_schedRelayTiming{};

static uint8_t  g_relaySchedLen = 0;                    // v7.28.37: on-air length of the copied beacon, beaconWireB(nSlots), set at the copy site, read at the relay transmit
static uint8_t  g_relayProbeCursor = 0;    // v7.28.18: keeper-side rotation for the probe relayer
static uint32_t g_lastDirectSchedMs = 0;   // v7.28.19: millis of the last hop-0 schedule that passed the RSSI gate, 0 = never
static uint32_t g_relayNeedMs1  = 0;       // v7.28.20: deeper-copy evidence dwell (was reason 1), its own timer
static uint32_t g_relayNeedMs2  = 0;       // v7.28.20: unmapped flood-join evidence dwell (was reason 2), its own timer
static uint8_t  g_relayArmNeed  = 0;       // v7.28.16: witness fields for the pending relay: armed on evidence
static uint8_t  g_relayArmProbe = 0;       // v7.28.16: armed on the probe turn
static uint8_t  g_anchorAdoptSeq  = 0xFF;  // v7.28.16: seq of the copy this board last anchored on
static uint8_t  g_anchorAdoptTk   = 0;     // v7.28.18: keeper id of that copy; rival keepers can share a seq
static uint8_t  g_anchorAdoptHops = 255;   // v7.28.16: hops of that copy; a same-seq copy must beat it to anchor
static uint32_t g_schedRejWorse   = 0;     // v7.28.16: same-seq copies refused for not beating the adopted hops
static uint8_t  g_pubIdMap[32];            // v7.28.16: 256-bit map of ids on the last published slot map
static bool     g_pubMapValid = false;     // v7.28.17: true once at least one slot map has been adopted; evidence 2 is meaningless before that
static inline bool pubIdHas(uint8_t id){ return (g_pubIdMap[id >> 3] >> (id & 7)) & 1; }
static inline bool relayNeedLive1(){ return g_relayNeedMs1 != 0 && (millis() - g_relayNeedMs1) < RELAY_NEED_DWELL_MS; }
static inline bool relayNeedLive2(){ return g_relayNeedMs2 != 0 && (millis() - g_relayNeedMs2) < RELAY_NEED_DWELL_MS; }
static void relayNeedNote(uint8_t why){
  // v7.28.20: two independent dwell timers, one per evidence type, so a deeper-copy
  // note (why 1) can no longer overwrite and silently cancel a live flood-join arm
  // (why 2). Logged only on a fresh arm of that type or a re-arm after its own dwell
  // lapsed, not on every refresh, so the log does not fill with it.
  uint32_t* slot = (why == 1) ? &g_relayNeedMs1 : &g_relayNeedMs2;
  bool was = (why == 1) ? relayNeedLive1() : relayNeedLive2();
  *slot = millis(); if (*slot == 0) *slot = 1;
  if (!was) logRec(LOG_STATE, NODE_ID, g_role, 0xEA, 0, 0, why);
}

// ---- member-side flood state, small table, keyed on (src_id, seq) ----
// Unlike the schedule, several distant nodes' data can each need forwarding
// in the same frame, so this needs real slots, not one scalar set. Small
// and fixed size on purpose, this is a first real pass, not a finished
// capacity plan; a table this size covers a handful of concurrent far
// nodes, which is what a first road test actually needs to prove the path.
#define RELAY_MEMBER_TRACK_N V7_MAX_ROSTER
struct MemberFloodEntry {
  bool     active;
  uint16_t srcId;
  uint8_t  seq;
  uint8_t  bestHop;
  uint8_t  outHop;
  bool     relayed;
  uint32_t deadlineUs;
  uint32_t rxUs;
  bool     grace;   // v7.29.5: this scheduled forward is a volunteered carry (MPKT_GRACE set in raw)
  uint8_t  raw[sizeof(MemberPkt)];
};
static MemberFloodEntry g_memberFlood[RELAY_MEMBER_TRACK_N];
static uint32_t g_relayQueueFull = 0;

// ---- v7.19.0 brick2: AGGREGATING RELAY BUFFER ----------------------------------
// The 6-slot flood table above forwards each join record as its own MemberPkt, so
// under a mass join the surplus is evicted and requests never reach the TK: that
// table, not the 22 admission turns, was the measured ceiling. A relay now BUFFERS
// join records it hears and forwards them as ONE aggregated packet up-tree,
// collapsing K records into a single transmission. The ceiling becomes the 255-byte
// PHY payload, not the 6-slot table.
//
// WIRE RECORD: src_id (1B) + attToken (4B, the crystal tag already on the wire;
// v7.21.0 note: carried OPAQUELY, this path has never validated it and does not
// care what it means, so the departure tag split does not touch it) = 5B. Header = magic 'A' + ver + hops + count = 4B, plus a
// trailing CRC-8 = 1B. On-air size at K records = 4 + 5K + 1 = 5 + 5K bytes.
// 255-byte hard cap -> 5 + 5K <= 255 -> K <= 50. At K=50 the packet is EXACTLY 255B,
// the SX1262 max payload and the documented LSMESH ceiling. ZERO MARGIN by design:
// any new header field forces AGG_PKT_MAX_REC down. This is asserted below.
#define AGG_TOKEN_BYTES   4
#define AGG_REC_WIRE      (1 + AGG_TOKEN_BYTES)     // 5B: src_id + attToken
#define AGG_HDR_BYTES     4                          // magic, ver, hops, count
#define AGG_CRC_BYTES     1
#define AGG_PKT_MAX_REC   ((MESH_SEC_MAX_PLAIN - 5 - AGG_CRC_BYTES) / AGG_REC_WIRE)   // = 50
static_assert(AGG_HDR_BYTES + AGG_PKT_MAX_REC*AGG_REC_WIRE + AGG_CRC_BYTES <= 255,
  "aggregated join packet exceeds the 255-byte PHY payload cap");
static_assert(AGG_PKT_MAX_REC == 43,
  "AGG_PKT_MAX_REC drifted from 50; the exact-255B fit and the capacity sim both "
  "assume 50 records per packet. Re-run the capacity sweep if this changes.");
// In-RAM accumulator per relay. Sized ABOVE one packet's worth so records arriving
// during the brief full-to-forward window are not dropped; on flush we emit up to
// AGG_PKT_MAX_REC and keep any remainder for the next packet. 64 records ~768B once the
// uint32 fields force 4B alignment (9B packed is the logical size), trivial
// on the ESP32-S3. In the concentrated worst case (all joiners funnel through one
// upper relay) that relay may see the whole backlog; flush-on-full keeps the buffer
// bounded at AGG_BUF_N even past 200 joiners (back-to-back aggregated packets).
#define AGG_BUF_N         64
// v7.28.102 CHUNK 3 ITEMS 2 AND 3: the aggregate flush now fires in the REPLY WINDOW
// of a JOIN frame, in one of AGG_FLUSH_SLOTS jitter slots each AGG_SLOT_US wide, carrying
// at most AGG_FLUSH_MAX_REC records. Why each of the three:
//  * Placement. Until v7.28.102 the flush had no offUs gate at all and fired on the
//    first loop pass after this board's own schedule relay, i.e. on the tail of the
//    schedule-flood region, which is sized and paid for beacon copies. Twelve hearers
//    flushing there collide with the schedule flood. A JOIN frame schedules no member,
//    so its reply window (tkBuildAndSend budgets one on every frame; applyTiers still
//    sets g_relayReplySlotUs on JOIN) carries no member relay and is empty. That is
//    where aggregates belong.
//  * Slot width. The existing RELAY_JITTER_MAX_US band is 12 ms. A ONE-record aggregate
//    is 41 ms on air at SF7. That band cannot hold even the smallest flush, so the
//    sim's four-bin knee (an abstract collision-group ratio, not a duration) cannot be
//    reused as four windows of it. AGG_SLOT_US is derived from the real airtime of an
//    AGG_FLUSH_MAX_REC-record packet plus a guard.
//  * Record cap. One record per flush keeps every packet at the shortest airtime and
//    keeps the slot at 44 ms, which is what preserves the SPREADING the knee measured.
//    Four 215 ms slots of 24-record packets is a different design and must not
//    inherit the four-slot result. A hearer with more than one cached joiner flushes
//    one per JOIN frame; the remainder rides the next.
// All three are -D overridable so the sim sweep and the bench can move them without
// a source edit. AGG_FLUSH_SLOTS 0 means derive N from the live reply window.
#ifndef AGG_FLUSH_MAX_REC
#define AGG_FLUSH_MAX_REC 1U
#endif
#ifndef AGG_SLOT_GUARD_US
#define AGG_SLOT_GUARD_US 3000UL
#endif
#ifndef AGG_FLUSH_SLOTS
#define AGG_FLUSH_SLOTS   0U
#endif
static const uint32_t AGG_FLUSH_WIRE_B = 5U + (uint32_t)AGG_FLUSH_MAX_REC * (uint32_t)AGG_REC_WIRE + (uint32_t)AGG_CRC_BYTES;
static const uint32_t AGG_SLOT_US = lsmLoraAirUs(AGG_FLUSH_WIRE_B+MESH_SEC_OVERHEAD, LSM_ACTIVE_SF, LSM_ACTIVE_BW, (uint8_t)(LORA_CR - 4)) + AGG_SLOT_GUARD_US;
static uint32_t g_aggSlotUsLive = AGG_SLOT_US;
// v7.28.102 CORRECTION: the flush-slot pick first used the same affine shape as
// the join-window pick, (NODE_ID*7 + seq*13) % N. Simulated at N=3 with twelve
// hearers and it never converged: two hearer ids congruent mod N keep the exact
// same relative offset on EVERY frame under an affine hash, because the seq term
// shifts every hearer's pick by the same amount. Nodes 1, 4, 7 and 10 produced
// the identical slot sequence with zero divergence across the frames checked. It
// is a permanent partition, not jitter, and does not resolve with more frames.
// This is fine for the join-window pick, which is not multiplexed against the
// same formula run by other boards for collision avoidance; it is wrong for slot
// contention between boards. Replaced with a SplitMix64-derived mix, which was
// verified in the sim to spread every node id with no fixed pattern at every
// candidate N before being trusted for a number, and is trusted here for the
// same reason.
static inline uint32_t aggSlotMix(uint32_t nodeId, uint32_t seq, uint32_t n){
  uint64_t x = ((uint64_t)nodeId << 32) | (uint64_t)seq;
  x += 0x9E3779B97F4A7C15ULL;
  uint64_t z = x;
  z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
  z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
  z = z ^ (z >> 31);
  return (uint32_t)(z % (uint64_t)n);
}
static inline uint32_t aggFlushSlotsNow(){
  // N jitter slots that fit the reply window this frame, or the -D override.
  if (AGG_FLUSH_SLOTS != 0U) return (uint32_t)AGG_FLUSH_SLOTS;
  uint32_t n = g_relayReplySlotUs / g_aggSlotUsLive;
  return n ? n : 1U;
}
struct AggRec { uint8_t srcId; uint32_t token; uint32_t rxFrame; };
static AggRec  g_aggBuf[AGG_BUF_N];
static uint8_t g_aggN = 0;                    // records currently buffered
static void aggBufPurgeSeated();   // v7.28.102 item 6: drop cached ids the beacon just seated, defined with aggBufAdd
// v7.28.102 CHUNK 3 ITEM 7: the intermediate re-aggregate gate, shared by 'A' and 'B'.
// Returns true when the record was buffered. Three rules, in order:
//  ceiling  : inHops + 1 must not pass the hop cap or the keeper's published tiers,
//             and this node must have adopted a schedule (a depth to compare against).
//  deeper   : sender strictly deeper than this node (inHops > g_anchorHops + 1) always
//             buffers. This is the v7.28.101 depth-strict rule; information climbs.
//  equal    : sender at the SAME depth (inHops == g_anchorHops + 1) buffers ONCE per
//             joiner id, latched in g_aggEqOnce, refused the second time. This is the
//             one-shot that lets a joiner whose only neighbours sit at equal depth
//             still climb (v7.28.101 refused it outright and could strand that joiner)
//             while making the sideways bounce terminate: the second peer to hear the
//             copy finds the bit set and drops it. Keyed on the id, not on time, because
//             a duration window resets on every receipt and does not terminate.
// The bit is cleared when the id is seated (aggBufPurgeSeated), which is the
// discovery-to-exclusive boundary of item 6.
static bool aggReaggregate(uint8_t sid, uint32_t tok, uint8_t inHops);
static void aggBufAdd(uint8_t srcId, uint32_t token, uint32_t frame, bool firstHand);  // v7.28.103: firstHand true only from a direct type-2/hops-0 receipt. v7.19.0 brick2: fwd decl, defined in the relay region below but called from handleMember/handleBeacon above
static void aggFlush(uint8_t hops);                                    // v7.19.0 brick2: fwd decl (paired with aggBufAdd)
#define AGG_JOIN_MAGIC    'A'
// v7.28.102 CHUNK 3 ITEM 5: 'B' is the aggregate WITH A SENDER BYTE. The 'A' header
// (magic, ver, hops, count) told the keeper WHICH joiners were heard and never WHO
// heard them, so the keeper seated the id and had nobody to name as its parent. The
// next frame it was an unheard roster member, some hearer's volPick found it in
// slot[], volunteered, and only then was a parent named: seat and name, two frames
// apart, and the volunteer path itself was blind to any id NOT yet in slot[]. The
// aggregate IS the volunteer report for a stranger, it was just missing the byte
// that made it one. 'B' adds relayerId after count. A 102 board transmits 'B'; the
// keeper accepts both, 'A' seats without naming exactly as before, so a mixed
// v7.28.101 / v7.28.102 sphere degrades to the old behaviour rather than dropping
// packets. No WIRE_VER bump: the beacon and MemberPkt layouts are untouched.
#define AGG_JOIN_MAGIC2   'B'
#define AGG_HDR2_BYTES    5                          // magic, ver, hops, count, relayerId
// v7.28.102 CHUNK 3 ITEM 7: one-shot equal-depth latch, KEYED ON THE JOINER ID and
// living OUTSIDE the aggregate buffer. It has to, because aggFlush removes a record
// once flushed: if the latch lived on the record, two equal-depth peers would each
// flush, forget, re-hear the other's copy, re-add, and bounce the same id sideways
// forever. A bit here survives the flush. Set the first time an id is re-aggregated
// at EQUAL depth, refused the second time, cleared only when the id is seated.
static uint8_t g_aggEqOnce[32];
static inline bool aggEqOnceHas(uint8_t id){ return (g_aggEqOnce[id >> 3] >> (id & 7)) & 1; }
static inline void aggEqOnceSet(uint8_t id){ g_aggEqOnce[id >> 3] |= (uint8_t)(1U << (id & 7)); }
static inline void aggEqOnceClr(uint8_t id){ g_aggEqOnce[id >> 3] &= (uint8_t)~(1U << (id & 7)); }


// ---- processed-packet dedup, separate from the flood tables above ----
// This is what answers Stu's actual question: without this, a node that
// hears both an original data packet AND a relayed copy of the exact same
// report would feed the position and the timing measurement twice. Keyed
// on (src_id, seq) only, deliberately blind to hop count, since a relayed
// copy and the original are the SAME logical report and must only ever be
// acted on once regardless of how many paths it arrived by.
#define RELAY_SEEN_N (V7_MAX_ROSTER * 2)
struct SeenEntry { uint16_t srcId; uint8_t seq; bool valid; uint32_t atMs; };
static SeenEntry g_memberSeenRing[RELAY_SEEN_N];
static uint16_t  g_memberSeenNext = 0;

static bool memberSeenCheckAndNote(uint16_t srcId, uint8_t seq){
  for (int i = 0; i < RELAY_SEEN_N; i++){
    if (g_memberSeenRing[i].valid && g_memberSeenRing[i].srcId == srcId && g_memberSeenRing[i].seq == seq &&
        (uint32_t)(millis()-g_memberSeenRing[i].atMs) <= 2UL*(g_frameUs/1000UL))
      return true;   // already processed this exact report this cycle
  }
  g_memberSeenRing[g_memberSeenNext] = { srcId, seq, true, millis() };
  g_memberSeenNext = (uint16_t)((g_memberSeenNext + 1) % RELAY_SEEN_N);
  return false;
}

// v7.12.0: direct-link RSSI floor/hysteresis, PRODUCTION values. Below
// DIRECT_RSSI_FLOOR_DBM on a direct (unrelayed, hop 0) reception, the link is
// treated as unusable and the node falls back to whatever relay path it has.
// It must climb back past DIRECT_RSSI_RECOVER_DBM, not just back over the
// floor, before being trusted direct again; the 25 dB gap stops a link
// sitting near the boundary from flapping state on every sample. A relayed
// copy (schedHops >= 1 or hops >= 1) is never subject to this, each relay leg
// keeps its own real range, only the "can I hear the origin directly"
// perception is gated. Both directions (schedule and data) need this, per
// Stu: "that's the hop logic and the data buffer of packet info to be
// relayed from upstream branches and leafs."
static const int16_t DIRECT_RSSI_FLOOR_DBM   = -90;   // v7.20.3 (was -100, v7.12.16 hop-push). Trigger the relay search at -90, not -100: -100 rides a direct link almost into the noise floor (~-110 for SF7 here, conservative), leaving ~10 dB of headroom; -90 leaves ~20 dB. TRIANGLE AVOIDANCE is the reason: a too-far floor makes a node cling to a fading direct link until the node it SHOULD relay through is ALSO marginal, so it grabs a sideways/behind neighbor -> a dogleg A->(sideways)->B instead of a clean forward spine. Triggering at -90 the node still hears several candidate repeaters clearly, so parent arbitration (hop-count -> RSSI -> stability -> random) has real forward choices. Earlier trigger, straighter chain.
static const int16_t DIRECT_RSSI_RECOVER_DBM = -65;   // v7.20.3 (was -80). Recover to direct only above -65, a 25 dB hysteresis band over the -90 floor (was 20 dB over -100). Return-to-direct STILL also requires equal-or-fewer hops than the current relay path (guards the triangle in reverse: no dropping a relay for a strong-but-sideways direct link that costs a hop).

// Schedule side is one stream, one real source (the TK), so a single scalar
// EMA is enough. Data side has several different leaf sources, each needs
// its own EMA, hence the small table, same shape and eviction rule as the
// flood tables above. Both use the same 1/8 shift idiom electNoteRssi()
// already uses for election scoring.
static int16_t g_directSchedRssiEma = 0;
static bool    g_directSchedRssiPrimed = false;
static bool    g_directSchedLost = false;

static bool directRssiGateSched(int16_t rssi){
  if (!g_directSchedRssiPrimed) { g_directSchedRssiEma = rssi; g_directSchedRssiPrimed = true; }
  else g_directSchedRssiEma = (int16_t)(g_directSchedRssiEma - (g_directSchedRssiEma>>3) + (rssi>>3));
  if (g_directSchedLost) { if (g_directSchedRssiEma >= DIRECT_RSSI_RECOVER_DBM) g_directSchedLost = false; }
  else { if (g_directSchedRssiEma < DIRECT_RSSI_FLOOR_DBM) g_directSchedLost = true; }
  return g_directSchedLost;   // true = treat this direct copy as unheard
}

#define DIRECT_RSSI_TRACK_N V7_MAX_ROSTER
struct DirectRssiEntry { bool active; uint16_t srcId; int16_t ema; bool primed; bool lost; uint32_t seenMs; };
static DirectRssiEntry g_directDataRssi[DIRECT_RSSI_TRACK_N];

static bool directRssiGateData(uint16_t srcId, int16_t rssi){
  int slot = -1;
  for (int i=0;i<DIRECT_RSSI_TRACK_N;i++){
    if (g_directDataRssi[i].active && g_directDataRssi[i].srcId == srcId){ slot=i; break; }
  }
  if (slot < 0){
    for (int i=0;i<DIRECT_RSSI_TRACK_N;i++){ if (!g_directDataRssi[i].active){ slot=i; break; } }
  }
  if (slot < 0) {
    slot = 0;
    for (int i=1;i<DIRECT_RSSI_TRACK_N;i++)
      if ((uint32_t)(millis()-g_directDataRssi[i].seenMs) > (uint32_t)(millis()-g_directDataRssi[slot].seenMs)) slot=i;
  }
  DirectRssiEntry &e = g_directDataRssi[slot];
  e.seenMs = millis();
  if (!e.active || e.srcId != srcId){ e.active=true; e.srcId=srcId; e.primed=false; e.lost=false; }
  if (!e.primed){ e.ema = rssi; e.primed = true; }
  else e.ema = (int16_t)(e.ema - (e.ema>>3) + (rssi>>3));
  if (e.lost){ if (e.ema >= DIRECT_RSSI_RECOVER_DBM) e.lost = false; }
  else { if (e.ema < DIRECT_RSSI_FLOOR_DBM) e.lost = true; }
  return e.lost;
}

// v7.12.0: RSSI-weighted relay jitter. Hop count stays the primary sort key,
// unchanged: each hop tier is still its own fixed window, closer hops still
// always go first. This only changes HOW a node picks its jitter delay
// within its own tier. A stronger link to the packet being relayed biases
// toward a SHORTER jitter (transmits sooner, more likely to be heard first
// and suppress the rest); a weaker link biases toward a longer jitter. When
// RSSI is close between two candidates the bias is close too, so genuine
// ties still settle by the same random draw as before, hop count, then
// RSSI, then random yield, exactly the stack Stu asked for. Total jitter
// budget is unchanged (RELAY_JITTER_MAX_US), so RELAY_SCHED_SLOT_US,
// RELAY_REPLY_SLOT_US, and the superframe sizing in
// RIG_DYNAMIC_SUPERFRAME_NOTE.md do not need to change.
#define RELAY_RSSI_BIAS_BEST_DBM   (-40)   // at or above this, minimum jitter ceiling
#define RELAY_RSSI_BIAS_WORST_DBM (-110)   // at or below this, full jitter ceiling
// v7.22.0: width of the random tiebreak that sits on top of the RSSI base.
// Everything below this width is a tie and settles at random; everything above
// it is ordered. 1500 us against the 12000 us budget leaves 10500 us of base
// spread across the 70 dB bias window, which is 150 us per dB.
#define RELAY_JITTER_TIEBREAK_US 1500UL
static_assert(RELAY_JITTER_TIEBREAK_US < RELAY_JITTER_MAX_US,
  "relay jitter tiebreak must fit inside the total jitter budget");
static uint32_t relayJitterBaseUs(int16_t rssi){   // v7.29.5: RSSI-biased base only, no random draw
  int16_t r = rssi;
  if (r > RELAY_RSSI_BIAS_BEST_DBM) r = RELAY_RSSI_BIAS_BEST_DBM;
  if (r < RELAY_RSSI_BIAS_WORST_DBM) r = RELAY_RSSI_BIAS_WORST_DBM;
  uint32_t span = (uint32_t)(RELAY_RSSI_BIAS_BEST_DBM - RELAY_RSSI_BIAS_WORST_DBM);
  // frac1000: 0 at worst RSSI, 1000 at best RSSI
  uint32_t frac1000 = (uint32_t)(r - RELAY_RSSI_BIAS_WORST_DBM) * 1000UL / span;
  // strong RSSI (frac1000 near 1000) -> small ceiling (jitters short, likely first)
  // weak RSSI   (frac1000 near 0)    -> ceiling near RELAY_JITTER_MAX_US
  // v7.22.0 ORDERING FIX. What this function did until now was draw uniformly
  // from zero up to an RSSI derived CEILING, which does not order candidates,
  // it only biases them. Two candidates whose ceilings overlap can invert on
  // any given frame because the weaker one is free to draw near zero while the
  // stronger one draws near its own smaller ceiling. Measured by simulation on
  // 200000 trials per pair against the v7.21.3 source: at minus 60 against
  // minus 70 dBm the WORSE linked candidate wins the slot 33.4 percent of the
  // time, at minus 45 against minus 65 it wins 10.1 percent, and even a 40 dB
  // gap leaks 5.7 percent. The comment above has claimed strong links transmit
  // sooner since v7.12.0 and the code has never made that true.
  // The shape that does order them is a BASE offset carrying the whole RSSI
  // term plus a small random tiebreak on top, so a candidate can only be
  // overtaken from within one tiebreak width of itself. Genuine ties, which
  // are the case the random draw exists for, still settle exactly as before
  // because equal RSSI gives equal base and the draw is all that is left.
  // GUARANTEE AND ITS LIMIT, stated honestly: the base spans
  // RELAY_JITTER_MAX_US - RELAY_JITTER_TIEBREAK_US over the 70 dB bias window,
  // which is 150 us per dB, so the ordering is STRICT for gaps above about
  // 10 dB and remains probabilistic below that. That is the right place to put
  // the boundary. Below 10 dB the two links are close enough that either is a
  // reasonable relay and rotating between them spreads the duty; above it the
  // better link now always wins, which is what stops a distant node being
  // chosen over a near one and doubling the path back to the TK.
  // The total budget is UNCHANGED at RELAY_JITTER_MAX_US, so tier widths,
  // RELAY_SCHED_SLOT_US, RELAY_REPLY_SLOT_US and the superframe sizing are all
  // untouched, and the sFlags jitter stamp still fits its 7 bit 100 us field
  // (worst case 11999 us, code 119, against the 127 cap).
  uint32_t baseSpan = RELAY_JITTER_MAX_US - RELAY_JITTER_TIEBREAK_US;
  uint32_t base = baseSpan - (baseSpan * frac1000) / 1000UL;
  return base;   // v7.29.5: split; the caller below adds the draw, the volunteer path adds a node-ID tiebreak instead
}
static uint32_t relayJitterUs(int16_t rssi){
  return relayJitterBaseUs(rssi) + (uint32_t)(esp_random() % RELAY_JITTER_TIEBREAK_US);   // v7.28.11: esp_random (per-board), not unseeded random() which was fleet-identical and never broke the equal-RSSI tie
}

// defined later, right before frameEngine, needs MemberFloodEntry (above) and radio/femTx (below)
static void memberFloodNote(const MemberPkt* p, const uint8_t* raw, int len, int16_t rssi);
static void volCarryDissolve(uint8_t src, uint8_t namedRelayer);   // v7.29.5: drop a volunteer claim when the keeper names a real leg. v7.29.13: only on evidence the named leg is alive

// v7.29.9 FindOldest with signed age (modular arithmetic safe)


// v7.29.9 NEW: Kill a g_volClaim entry by srcId and record cooldown atomically
// Also: FindOldest helper for claims (needs current_seq to calculate age correctly)
static void volClaimKillAndCooldown(uint8_t src) {
  if (src == 0) return;
  
  // Find and kill the g_volClaim entry for this src
  for (uint8_t i = 0; i < VOL_CARRY_N; i++) {
    if (volClaimIsAlive(&g_volClaims[i]) && g_volClaims[i].srcId == src) {
      volClaimKill(&g_volClaims[i]);
      if (g_volClaimCount > 0) g_volClaimCount--;
      break;
    }
  }
  
  // Record cooldown so src cannot re-arm immediately
  uint8_t cooldown_idx = volCooldownFindFree(g_volCooldowns);
  if (cooldown_idx >= VOL_CARRY_N) {
    // table full: evict oldest by signed age (not raw expiry_seq)
    cooldown_idx = volCooldownFindOldest(g_volCooldowns, g_seqHigh);
  }
  if (cooldown_idx < VOL_CARRY_N) {
    g_volCooldowns[cooldown_idx].srcId = src;
    g_volCooldowns[cooldown_idx].expiry_seq = (int8_t)(g_seqHigh + VOL_REARM_COOLDOWN_SEQS);
  }
}

// v7.29.9 HARDENING: Recount live claims to validate g_volClaimCount
// Derives count from a live scan instead of relying on manual increment/decrement.
// Returns the actual number of alive claims in the table.
// v7.29.9 HARDENING: Periodic TTL sweep
// Walk the claim table and kill any claim older than VOL_CLAIM_TTL_SEQS.
// Called once per frame from seq-advance to prevent expired claims from
// sitting in the table and burning a slot. A claim that goes quiet after
// arming would otherwise stay until the src re-arms again.
static void volClaimCheckTTL(int8_t now) {
  for (uint8_t i = 0; i < VOL_CARRY_N; i++) {
    if (volClaimIsAlive(&g_volClaims[i])) {
      int8_t age = (int8_t)(now - g_volClaims[i].born_seq);
      if (age >= VOL_CLAIM_TTL_SEQS) {
        // Claim is expired; kill it and record cooldown atomically
        uint8_t expired_src = g_volClaims[i].srcId;
        volClaimKillAndCooldown(expired_src);
      }
    }
  }
  
  // Resync counter after sweep to catch any drift from missed increments/decrements
  g_volClaimCount = 0;
  for (uint8_t i = 0; i < VOL_CARRY_N; i++) {
    if (volClaimIsAlive(&g_volClaims[i])) {
      g_volClaimCount++;
    }
  }
}

void drawStatusBase();   // v7.13.0: baseline bake countdown page

// v12: departure attestation tag. HONEST: this is integrity, not crypto.
// entMix is an xorshift PRNG, not a keyed MAC. It catches corruption and
// reserves the verify path; it does NOT prove authenticity. The real keyed
// token (shared-secret MAC over the departure stamp, per the L1/L2 token IP)
// is the next-session build and will replace the body of this function with
// NO wire change, since the field is already sized.
static uint16_t departAttest(uint16_t src, uint8_t seq, int16_t departDevUs){
  uint32_t m = entMix(((uint32_t)src<<16) ^ ((uint32_t)seq<<8) ^ (uint32_t)(uint16_t)departDevUs ^ 0xA5A5u);
  return (uint16_t)(m ^ (m>>16));
}
static uint8_t crc8(const uint8_t* data, size_t len){
  // CRC-8, poly 0x07, init 0x00, no reflect. Computed once per TX and once
  // per RX on an 8-byte packet, cheap enough not to matter.
  uint8_t crc = 0x00;
  for (size_t i=0;i<len;i++){
    crc ^= data[i];
    for (int b=0;b<8;b++) crc = (crc & 0x80) ? (uint8_t)((crc<<1) ^ 0x07) : (uint8_t)(crc<<1);
  }
  return crc;
}

volatile bool g_loraIrq = false;
volatile int64_t g_loraIrqUs = 0;   // v4.15: packet completion instant, stamped in the ISR
// ctok: esp_cpu_get_cycle_count() is the IDF 5.x name for the CPU cycle counter, same value as the old call.
// v7.28.27: receive-loss witnesses. See FW_PATCH v7.28.27 for what each counts.
volatile uint32_t g_irqOverrun = 0;   // IRQ fired with the previous completion still unserviced: a packet overwritten in the one-buffer radio
static uint32_t   g_rdFail     = 0;   // readData not ERR_NONE, or RxDone with packet length 0
static int16_t    g_rdLastErr  = 0;   // last readData status that was not ERR_NONE
static uint32_t   g_crcFail    = 0;   // dispatcher crc8 drops (member data, join, aggregate)
static uint32_t   g_irqLatMaxUs = 0;  // worst IRQ-to-service latency this window
static uint16_t   g_irqLatOver  = 0;  // services later than 5 ms this window
void IRAM_ATTR onLoraIrq() { if (g_loraIrq) g_irqOverrun = g_irqOverrun + 1; g_loraIrqUs = esp_timer_get_time(); g_loraIrqCyc = esp_cpu_get_cycle_count(); g_loraIrq = true; }
#ifdef LSM_BOARD_LILYGO
// v7.28.47: IRQ word normalization for the LR1121. RadioLib 7.1.2
// LR11x0::startReceive takes GENERIC flag bits (1 << RADIOLIB_IRQ_x), which
// are numerically the SX126x chip constants (bit 1 RX_DONE .. bit 9 TIMEOUT),
// so the SX126X_IRQ_* masks handed to startReceive in this file are correct
// as written and go through getIrqMapped inside RadioLib. getIrqStatus()
// however returns LR11x0 chip-native bits (RX_DONE 1<<3, PREAMBLE 1<<4,
// SYNC_WORD_HEADER_VALID 1<<5, HEADER_ERR 1<<6, CRC_ERR 1<<7, TIMEOUT 1<<10).
// lsmIrqRead() folds those back into the SX126x layout so every comparison
// and every LOG record keeps its meaning and decode2842.py needs no
// per-family branch. RADIOLIB_SX126X_IRQ_RX_DEFAULT is a 6.6.0 macro that
// 7.1.2 dropped; it is restored here with its 6.6.0 value.
#ifndef RADIOLIB_SX126X_IRQ_RX_DEFAULT
#define RADIOLIB_SX126X_IRQ_RX_DEFAULT (RADIOLIB_SX126X_IRQ_RX_DONE | RADIOLIB_SX126X_IRQ_TIMEOUT | RADIOLIB_SX126X_IRQ_CRC_ERR | RADIOLIB_SX126X_IRQ_HEADER_ERR)
#endif
static inline uint32_t lsmIrqRead() {
  uint32_t lr = radio.getIrqStatus();
  uint32_t sx = 0;
  if (lr & RADIOLIB_LR11X0_IRQ_TX_DONE)                sx |= RADIOLIB_SX126X_IRQ_TX_DONE;
  if (lr & RADIOLIB_LR11X0_IRQ_RX_DONE)                sx |= RADIOLIB_SX126X_IRQ_RX_DONE;
  if (lr & RADIOLIB_LR11X0_IRQ_PREAMBLE_DETECTED)      sx |= RADIOLIB_SX126X_IRQ_PREAMBLE_DETECTED;
  if (lr & RADIOLIB_LR11X0_IRQ_SYNC_WORD_HEADER_VALID) sx |= RADIOLIB_SX126X_IRQ_HEADER_VALID;
  if (lr & RADIOLIB_LR11X0_IRQ_HEADER_ERR)             sx |= RADIOLIB_SX126X_IRQ_HEADER_ERR;
  if (lr & RADIOLIB_LR11X0_IRQ_CRC_ERR)                sx |= RADIOLIB_SX126X_IRQ_CRC_ERR;
  if (lr & RADIOLIB_LR11X0_IRQ_CAD_DONE)               sx |= RADIOLIB_SX126X_IRQ_CAD_DONE;
  if (lr & RADIOLIB_LR11X0_IRQ_CAD_DETECTED)           sx |= RADIOLIB_SX126X_IRQ_CAD_DETECTED;
  if (lr & RADIOLIB_LR11X0_IRQ_TIMEOUT)                sx |= RADIOLIB_SX126X_IRQ_TIMEOUT;
  return sx;
}
static inline void lsmIrqAttach() { if(g_irqPolicyVerified)radio.setIrqAction(onLoraIrq); }
#else
static inline uint32_t lsmIrqRead()   { uint16_t w = radio.getIrqStatus(); return w; }
static inline void     lsmIrqAttach() { if(g_irqPolicyVerified)radio.setDio1Action(&onLoraIrq); }
#endif
// v7.28.29: every working-channel receive arm goes through here. HeaderValid is
// latched so a stale HeaderErr can be told from a real one, and HeaderErr is
// routed to DIO1 so a header abort is serviced and cleared instead of
// poisoning the next packet. Same public-parameter path bhListenArm uses.
static uint32_t g_hdrAbort  = 0;   // header aborts serviced (cumulative)
static uint32_t g_hdrRescue = 0;   // readData CRC_MISMATCH overruled by a clean IRQ word (cumulative)
static inline int16_t lsmRxArm() {
  // v7.28.72-symbvalid: TIMEOUT is routed to DIO1 as well. With the validation
  // count non-zero the datasheet describes a reception that fails validation
  // as a timeout; in continuous receive the modem is expected to fall back to
  // preamble search on its own, but if this chip instead drops to standby the
  // only way to know is to see the IRQ. radioPoll counts it (aux 18) and
  // re-arms. On the A build (count 0) the bit can only come from an explicit
  // timeout, which infinite receive never raises, so the path is inert there.
  // v7.28.78: PREAMBLE_DETECTED and HEADER_VALID are added to the LATCHED flag
  // mask (first arg) but NOT to the DIO1 mask (second arg), so they accumulate
  // in the IRQ status register and show up in the irqW read at the next serviced
  // event WITHOUT pulling DIO1 mid-reception. That makes every serviced slot
  // carry its three detection stages - preamble seen, header valid, CRC good -
  // in the irqW already logged by the aux 10 and aux 11 witnesses, at zero
  // timing cost. A clean receive is a three-stage pass by definition. This does
  // NOT witness a fully silent slot (no DIO event at all); see the build note.
  return radio.startReceive(RADIOLIB_SX126X_RX_TIMEOUT_INF,
                            (uint16_t)(RADIOLIB_SX126X_IRQ_RX_DEFAULT | RADIOLIB_SX126X_IRQ_HEADER_VALID | RADIOLIB_SX126X_IRQ_PREAMBLE_DETECTED),
                            (uint16_t)(RADIOLIB_SX126X_IRQ_RX_DONE | RADIOLIB_SX126X_IRQ_HEADER_ERR | RADIOLIB_SX126X_IRQ_TIMEOUT), 0);
}
// v7.28.41: paired deaf-wrap snapshot state. g_armStatus holds the GetStatus
// byte captured at the end of the last turnaround arm (radioPostTxReset), so a
// deaf wrap can be logged with BOTH the mode the chip armed into and the mode it
// is in now. g_armStatusOk is false until the first arm after boot.
static uint8_t g_armStatus   = 0;
static bool    g_armStatusOk = false;
// v7.28.39: full reset on the transmit-to-receive turnaround. Standby the radio,
// then arm receive. Standby handles radio state reset; explicit IRQ clear is
// protected in RadioLib 6.6.0 SX126x. SX1262 specific; abstraction point for
// future radio backends. Called at every working-channel transmit site.
// v7.28.40: TWO-FAULT TURNAROUND COMPENSATION. GRADED FAIL on the four-board
// soak 2026-09-06: the 100/100 us settle delays plus the ISR shield moved the
// P(hear after transmit) toggle not at all, flat at the v7.28.38 baseline
// across every 5-minute bucket on two independent members. The delays are kept
// only as tunable no-ops; they are not the fix and should not be grown.
// v7.28.41: what the settle-delay theory got wrong, corrected in place.
// Fault 1 (FEM/DIO2 timing): ruled out. 200 us of settle is far longer than any
//   PA ramp and it changed nothing. And CTX (GPIO5) is not the path select at
//   all: DIO2 drives the CPS pin (TX/RX path) automatically via
//   setDio2AsRfSwitch, while CTX only switches the RX LNA between bypass (HIGH,
//   femTx) and full gain (LOW, femRx), per the established Heltec Tracker
//   KCT8103L pinout. So femTx/femRx are NOT redundant with DIO2 and deletion is
//   ruled out; they drive a different FEM input on purpose.
// Fault 2 (ring-buffer window): ruled out. g_irqOverrun reads ~0 every soak.
// Fault 3 (RxTx fallback mode): still open, but there is NO confirmed readable
//   register for it. The SX1262 sets fallback only via the SetRxTxFallbackMode
//   command (opcode 0x93); the datasheet lists no register, and 0x01B7 (asserted
//   in an earlier note) is not in the datasheet map, RadioLib SX126x_registers.h,
//   or any open driver. The live chip MODE is instead read from the GetStatus
//   byte bits 6:4 (STBY_RC/STBY_XOSC/FS/RX/TX), which is what the v7.28.41
//   deaf-wrap snapshot logs. SX1262Patched already exposes readRegister,
//   getStatus and clearIrqStatus, so no RadioLib patch is needed for the reads.
// Configurable constants, kept as no-ops per the grade above:
#define TX_STANDBY_SETTLE_US    100  // delay after radio.standby() for DIO2/PA settle
#define RX_ARM_SETTLE_US        100  // delay after startReceive() for RX stabilize

// v7.28.91: RX ARM LATENCY WITNESS state. Mirrors g_txLatUs for the receive
// turnaround. MEASURES only, adds no delay (the settle-delay theory was graded
// FAIL in v7.28.40/41). g_rxArmUs is the full standby->armed dead window;
// g_rxArmLastCmd is the bare startReceive command cost, so a capture can tell
// how much of the dead window is the chip versus the fixed no-op settles.
static uint32_t g_rxArmUs      = 0;   // EWMA total tx->rx turnaround dead window, us
static uint16_t g_rxArmLastCmd = 0;   // last bare startReceive() command time, us
static uint32_t g_rxArmSamples = 0;   // saturating sample count
static inline void radioPostTxReset() {
  uint32_t rxArmT0 = micros();   // v7.28.91: start of the tx->rx dead window
  // v7.28.40: Full turnaround reset with compensation for Faults 1 & 2
  
  // Put radio into standby
  int16_t radioStep = radio.standby();
  if (radioStep != RADIOLIB_ERR_NONE) radioFaultNote(1, radioStep);
  
  // FAULT 1: Settle delay after standby
  // Allows DIO2 to finish transitioning from TX to RX state.
  // Also gives PA internal state time to ramp down fully before we key the RX LNA.
  // Without this delay, GPIO LOW (femRx) fires too early, LNA is keyed before PA settled.
  if (TX_STANDBY_SETTLE_US > 0) {
    delayMicroseconds(TX_STANDBY_SETTLE_US);
  }
  
  // FAULT 2: Close the ring buffer window
  // Between radio.transmit() return and startReceive() activation, there's a
  // ~10-100 us unshielded window where a beacon arriving could be lost:
  // 1. Packet fires DIO1 -> g_loraIrq set
  // 2. Packet lands in buffer
  // 3. Buffer gets overwritten before radioPoll reads it
  // Disable interrupts during this critical section to ensure atomicity.
  noInterrupts();
  
  // Arm receive with standard flags and mask (startReceive clears IRQ register)
  uint32_t rxArmCmd0 = micros();   // v7.28.91: bracket the bare startReceive command
  radioStep = lsmRxArm();
  if (radioStep != RADIOLIB_ERR_NONE) radioFaultNote(2, radioStep);
  uint32_t rxArmCmdDt = micros() - rxArmCmd0;
  g_rxArmLastCmd = (uint16_t)(rxArmCmdDt > 32767U ? 32767U : rxArmCmdDt);
  
  // FAULT 1: Settle delay after startReceive
  // Allows the radio to fully enter RX mode and DIO2-controlled LNA to stabilize.
  // Also gives FEM's switching transients time to decay before reception begins.
  // Radio is in RX now, but the receive state machine may still be settling.
  if (RX_ARM_SETTLE_US > 0) {
    delayMicroseconds(RX_ARM_SETTLE_US);
  }
  
  // Re-enable interrupts now that startReceive is complete and stable
  interrupts();

  // v7.28.91: sample the total tx->rx turnaround dead window (standby -> armed).
  {
    uint32_t rxArmDt = micros() - rxArmT0;
    if (rxArmDt <= 60000U) {                 // >60 ms is an error, not a turnaround
      if (g_rxArmSamples == 0) g_rxArmUs = rxArmDt;   // first sample sets it outright
      else g_rxArmUs = g_rxArmUs - (g_rxArmUs >> 2) + (rxArmDt >> 2);   // same >>2 EWMA as g_txLatUs
      if (g_rxArmSamples < 0xFFFFFFFF) g_rxArmSamples++;
    }
  }

  // v7.28.41: ARM-TIME chip mode. The persistent-vs-transient question for the
  // deaf case: did the turnaround ARM the chip into a wrong mode (persistent),
  // or did it arm into RX and then drift deaf before the beacon (transient)?
  // Capture the GetStatus byte (bits 6:4 = mode) right after the arm and hold
  // it; the deaf-wrap witness (LOG_RF aux 14) logs it beside the wrap-time mode.
  // One SPI read per turnaround, a read not a state change, outside the ISR gap.
  g_armStatus   = radio.chipStatus();
  g_armStatusOk = true;
}
// v7.28.38: FIRST-RECEIVE-AFTER-TRANSMIT WITNESS. The three-board capture
// 2026-09-05 (V7.28.37, node01 keeper) showed downlink beacon reception is a
// near perfect toggle keyed on this board's own transmit: after a frame it
// heard the beacon (and so sent a keepalive) it heard the next beacon 12 to 15
// percent of the time; after a frame it stayed silent it heard the next 88 to
// 92 percent. Success does NOT climb with the gap from the keepalive to the
// next beacon (flat 0.10 to 0.18 from 120 ms out to 600 ms), so it is not a
// settling time, it is the first reception after a transmit that fails. Two
// witnesses partition it. rxArmAfterTx() marks a working-channel re-arm that
// FOLLOWS a transmit, so radioPoll can log the first service after it (aux 12)
// and the missed-frame branch can log whether any service happened at all
// since that transmit (aux 13). g_txSinceAnchor gates aux 13 to misses that
// actually followed a transmit. These feed logging only; the radio path is
// unchanged, rxArmAfterTx() does exactly what the g_loraIrq/lsmRxArm tail did.
static volatile bool g_awaitFirstRxSvc = false;  // set by rxArmAfterTx, cleared by the first radioPoll service after it
static uint16_t      g_svcSinceTx      = 0;       // radioPoll services since the last marked transmit (0 at a miss = never fired)
static bool          g_txSinceAnchor   = false;   // this board transmitted since it last anchored on a beacon
static inline void rxArmAfterTx(){
  femRx(); g_loraIrq = false;
  g_awaitFirstRxSvc = true; g_svcSinceTx = 0; g_txSinceAnchor = true;
  radioPostTxReset();  // v7.28.39: full reset on the transmit-to-receive turnaround
  if(g_owned.scope&&g_owned.called)g_owned.rearmed=(uint64_t)esp_timer_get_time();
}
// v7.28.25: the transmit DONE instant from the ISR. RadioLib's blocking
// transmit() polls DIO1 from the caller and then reads and clears the IRQ
// over SPI, so its return lands some hundreds of microseconds after TxDone.
// The ISR above is attached for RX and it also fires on TxDone during the
// blocking transmit, which is why every transmit site clears g_loraIrq
// afterwards: the stamp was always being taken, it was not being read. This
// reads it. A stamp outside the call/return bracket is a stale RX stamp or a
// missed IRQ and the return instant is used instead, counted so the log can
// show whether the ISR path is actually carrying the measurement.
static uint32_t g_txDoneIsrHit  = 0;
static uint32_t g_txDoneIsrMiss = 0;
static uint32_t g_txDoneResidUs = 0;    // last (return minus ISR done), the residual this cut removes
static uint32_t g_txDoneCount   = 0;
static void ownedWitness(uint8_t aux,uint8_t reason=0){
  logRec(LOG_TRIM,NODE_ID,g_role,aux,(int16_t)((uint16_t)g_owned.keeper|((uint16_t)g_owned.epoch<<8)),(int16_t)((uint16_t)g_owned.seq|((uint16_t)g_owned.slot<<8)),(uint32_t)(g_owned.anchor/1000));
  if(reason)logRec(LOG_TRIM,NODE_ID,g_role,0xEF,reason,0,(uint32_t)(g_owned.anchor/1000));
}
static void ownedGrantObserve(){
  const uint64_t now=(uint64_t)esp_timer_get_time();
  const bool named=g_role==1&&g_mySlot!=0xFF&&g_frameType==SF_TYPE_DATA;
  if(g_owned.observed&&!g_owned.outcome&&
     (now>=g_owned.end||!named||g_owned.anchor!=g_frameAnchorUs)){
    g_owned.outcome=true;g_ownedSkips++;ownedWitness(0xE1,2);
  }
  if(!named||(g_owned.observed&&g_owned.anchor==g_frameAnchorUs))return;
  g_owned=OwnedGrant{};g_owned.observed=true;g_owned.anchor=g_frameAnchorUs;
  g_owned.start=g_frameAnchorUs+g_memberBaseUs+(uint64_t)g_mySlot*g_slotUsLive;
  g_owned.end=g_owned.start+g_slotUsLive;g_owned.keeper=g_tkId;g_owned.epoch=g_tkEpoch;
  g_owned.seq=g_curSchedSeq;g_owned.slot=g_mySlot;g_ownedOpportunities++;ownedWitness(0xE0);
}
static bool ownedTxFits(size_t n){
  if(!g_owned.scope)return true;
  if(g_owned.flashBlocked){g_owned.skipped=true;g_owned.reason=4;return false;}
  const bool same=g_owned.observed&&!g_owned.outcome&&g_role==1&&g_frameType==SF_TYPE_DATA&&
    g_owned.anchor!=0&&g_frameAnchorUs==g_owned.anchor&&g_tkId==g_owned.keeper&&
    g_tkEpoch==g_owned.epoch&&g_curSchedSeq==g_owned.seq&&g_mySlot==g_owned.slot&&
    g_owned.keeper!=0&&g_owned.end<=g_owned.anchor+(uint64_t)g_frameUs;
  const uint32_t rx=g_rxArmUs+100U>SLOT_GUARD_US?g_rxArmUs+100U:SLOT_GUARD_US;
  g_owned.air=(uint32_t)radio.getTimeOnAir(n+MESH_SEC_OVERHEAD);
  const uint64_t now=(uint64_t)esp_timer_get_time();
  const auto reason=ownedslot::fits(same&&now>=g_owned.anchor,now,g_owned.end,
    g_owned.air,g_txLatUs,rx);
  g_ownedBudgetChecks++;
  if(reason!=ownedslot::FIT){
    if(reason==ownedslot::BUDGET){
      g_ownedBudgetRejects++;
      g_ownedLastRemaining=(uint32_t)(g_owned.end>now?g_owned.end-now:0);
      g_ownedLastRequired=g_owned.air+g_txLatUs+rx+(uint32_t)ownedslot::UNCERTAINTY_US;
      const int64_t spare=(int64_t)g_ownedLastRemaining-(int64_t)g_ownedLastRequired;
      logRec(LOG_TRIM,NODE_ID,g_role,0xEF,7,(int16_t)(spare < -32768 ? -32768 : spare > 32767 ? 32767 : spare),(uint32_t)(g_owned.anchor/1000));
    }
    g_owned.skipped=true;g_owned.reason=(uint8_t)reason;return false;
  }
  return true;
}
static void ownedTxResult(int16_t st,uint64_t call,uint64_t ret,uint32_t air){
  if(!g_owned.scope)return;
  g_owned.called=true;g_owned.call=call;g_owned.ret=ret;g_owned.air=air;
  g_owned.success=st==RADIOLIB_ERR_NONE;g_ownedAttempts++;
  if(g_owned.uncal){g_ownedUncalibrated++;ownedWitness(0xE6);}
}
OwnedScope::OwnedScope():control(g_telemetryControlMs),controlSeq(g_telemetryControlSeq){
  g_owned.scope=true;g_owned.uncal=!g_txLatSamp;g_owned.flashBlocked=!flashGuard.ok();
#if LSM_RELAY_PLEA
  plea=g_pleaTries;pleaNext=g_pleaNextFr;
#endif
}
OwnedScope::~OwnedScope(){
  if(!g_owned.success){
    g_telemetryControlMs=control;g_telemetryControlSeq=controlSeq;
#if LSM_RELAY_PLEA
    g_pleaTries=plea;g_pleaNextFr=pleaNext;
#endif
  }
  if(g_owned.called&&!g_txLatSamp&&g_owned.success)txLatSample(g_owned.call,g_owned.ret,g_owned.air);
  if(g_owned.success){g_ownedSuccess++;ownedWitness(0xE4);}
  else if(g_owned.called){g_ownedDriverFail++;ownedWitness(0xE3);}
  else {g_ownedSkips++;ownedWitness(0xE1,g_owned.reason?g_owned.reason:5);}
  if(g_owned.called&&(!g_owned.rearmed||g_owned.rearmed>g_owned.end)){
    g_ownedOverruns++;ownedWitness(0xE5);
    const uint64_t excess=g_owned.rearmed?g_owned.rearmed-g_owned.end:32767ULL;
    logRec(LOG_TRIM,NODE_ID,g_role,0xEF,6,(int16_t)(excess>32767ULL?32767ULL:excess),(uint32_t)(g_owned.anchor/1000));
  }
  g_owned.outcome=true;g_owned.scope=false;
}
static inline uint64_t txDoneInstant(uint64_t callUs, uint64_t retUs){
  int64_t isr = g_loraIrqUs;
  if (isr > (int64_t)callUs && isr <= (int64_t)retUs){
    g_txDoneIsrHit++; g_txDoneResidUs = (uint32_t)(retUs - (uint64_t)isr); return (uint64_t)isr;
  }
  g_txDoneIsrMiss++; return retUs;
}
// LOG_ANCH aux 4, every 16th transmit on this board: e = return minus ISR
// done in us, n = ISR misses this session, data = ISR hits.
static inline void txDoneWitness(){
  if ((++g_txDoneCount & 15U) != 0) return;
  logRecRf(LOG_ANCH, NODE_ID, g_role, 4,
           (int16_t)(g_txDoneResidUs > 32767U ? 32767 : g_txDoneResidUs),
           (int16_t)(g_txDoneIsrMiss > 32767U ? 32767 : g_txDoneIsrMiss),
           g_txDoneIsrHit, 0, 0, 0);
  // v7.28.70-absposbranch: same 1-in-16 gate, no extra flash pressure.
  logRec(LOG_TXLAT, NODE_ID, g_role, (uint8_t)(g_txLatSamp ? 4 : 0),
         (int16_t)(g_txLatUs   > 32767U ? 32767 : g_txLatUs),
         (int16_t)(g_txLatLast > 32767U ? 32767 : g_txLatLast),
         g_txLatSamp);
  // v7.28.91: RX arm latency on the same 1-in-16 gate, no extra flash pressure.
  logRec(LOG_RXARM, NODE_ID, g_role, (uint8_t)(g_rxArmSamples ? 4 : 0),
         (int16_t)(g_rxArmUs      > 32767U ? 32767 : g_rxArmUs),
         (int16_t)(g_rxArmLastCmd > 32767U ? 32767 : g_rxArmLastCmd),
         g_rxArmSamples);
}

// Set every modem parameter explicitly from Semtech datasheet values instead
// of trusting library defaults. Returns 0 or the first failing call's code.
int16_t radioConfig() {
  int16_t st;
  st = radio.setFrequency(LORA_FREQ_MHZ);      if (st != RADIOLIB_ERR_NONE) return st;
  st = radio.setBandwidth(LORA_BW_KHZ);        if (st != RADIOLIB_ERR_NONE) return st;
  st = radio.setSpreadingFactor(LORA_SF);      if (st != RADIOLIB_ERR_NONE) return st;
  st = radio.setCodingRate(LORA_CR);           if (st != RADIOLIB_ERR_NONE) return st;
  st = radio.setSyncWord(LORA_SYNC);           if (st != RADIOLIB_ERR_NONE) return st;
  st = radio.setPreambleLength(LORA_PREAMBLE_SYMS); if (st != RADIOLIB_ERR_NONE) return st;   // v7.28.1: was 8, deaf at SF5
  st = radio.setCRC(2);                        if (st != RADIOLIB_ERR_NONE) return st;
  st = radio.explicitHeader();                 if (st != RADIOLIB_ERR_NONE) return st;
  // v7.28.72-symbvalid: receiver preamble validation, applied after the LoRa
  // modem parameters and before the first arm. This is a modem setting, not an
  // arm setting: it persists across every SetRx until the next chip reset, and
  // both reset paths (boot and the watchdog's hard kick) come through here.
  // The result is held for the boot witness (LOG_RF aux 17) and never fails
  // the config: a refused command is logged, not fatal, so a board with an
  // odd driver still joins the sphere and the log says what happened.
  g_symbValidRc = radio.setSymbValid(LORA_RX_SYMB_VALID, &g_symbValidCmd, &g_symbValidReg);

  // v7.13.1: PASSIVE airtime witness. Ask the radio what a MemberPkt actually
  // costs on the air at the PHY we just programmed, and compare to AIRTIME8_US.
  // The result is logged and shown on the diag screen; it does NOT feed the
  // frame math. If witness and constant ever diverge on a new board family or
  // a PHY tweak, the log says so at boot instead of the drift being silent.
  // v7.16.0: measure this node's own join packet airtime instead of carrying a
  // compile time figure. The TK turns this into the published reservation; a
  // member uses it to work out its own latest legal keying instant. The
  // witness immediately below already proves this call is exact on this
  // hardware: it reported 56576 us for a 22 byte MemberPkt on all 31 boots in
  // the board 05 capture of 2026-07-28, with no deviation.
  // The reset just programmed the compile-time PHY; restore its timing mirrors
  // even when the previous working profile was different. No extra RF changes.
  g_workingSf = LORA_SF;
  g_workingBw = LSM_ACTIVE_BW;
  g_workingProfileId = lsm_dual_phy::idFor(g_workingSf, g_workingBw);
  g_memberAirUsLive = MEMBER_AIR_US;
  g_slotUsLive = membercapacity::slotUs(g_memberAirUsLive);
  g_relayMemberTierUsLive = g_memberAirUsLive + 2000UL + RELAY_JITTER_MAX_US;
  g_tokSlotUsLive = lsmLoraAirUs(TOK_WIRE_MAX_B + MESH_SEC_OVERHEAD,
      g_workingSf, g_workingBw, (uint8_t)(LORA_CR - 4)) + 2u*SLOT_GUARD_US;
  g_aggSlotUsLive = lsmLoraAirUs(AGG_FLUSH_WIRE_B + MESH_SEC_OVERHEAD,
      g_workingSf, g_workingBw, (uint8_t)(LORA_CR - 4)) + AGG_SLOT_GUARD_US;
  g_joinAirUs = (uint32_t)secureAirTime(sizeof(JoinPkt));
  // v7.16.0: turn the measured airtime into the reservation, rounded UP to the
  // 500 us publishing quantum. Rounding up matches the existing frame
  // quantise-up rule: never advertise less space than the airtime physically
  // needs. A member overwrites this from its first beacon; the TK keeps it and
  // publishes it. applyTiers re-derives g_memberBaseUs from the new value.
  { uint32_t r = JOIN_KEYWIN_US + g_joinAirUs + SLOT_GUARD_US;
    g_joinResUs = ((r + 499U) / 500U) * 500U; }
  applyTiers(g_schedTiers);
  { uint32_t w = (uint32_t)secureAirTime(sizeof(MemberPkt));
    g_airWitnessUs  = w;
    g_airWitnessDev = (int32_t)w - (int32_t)AIRTIME8_US;
    int16_t devClamped = (g_airWitnessDev > 32767) ? 32767
                       : ((g_airWitnessDev < -32768) ? -32768 : (int16_t)g_airWitnessDev);
    // aux 3 = airtime witness. aux 0/1/2 are already taken by LOG_RF's
    // tx-error / reinit / backhaul-hop-error paths, so 3 is the first free
    // code. Decoder must not confuse this with a real radio fault.
    logRec(LOG_RF, NODE_ID, g_role, 3, devClamped, (int16_t)sizeof(MemberPkt), w); }
  // v7.28.72-symbvalid: aux 17 = receiver validation witness, once per config.
  // e = symbols asked for (0 on the A build), n = command status (0 = accepted),
  // data = SF | command byte << 8 | register 0x0706 byte << 16. Written at the
  // same site as aux 3 so it lands after logInit on every path that reaches here.
  logRec(LOG_RF, NODE_ID, g_role, 17, (int16_t)LORA_RX_SYMB_VALID, g_symbValidRc,
         (uint32_t)LORA_SF | ((uint32_t)g_symbValidCmd << 8) | ((uint32_t)g_symbValidReg << 16));
  st = radio.invertIQ(false);                  if (st != RADIOLIB_ERR_NONE) return st;
#ifdef LSM_BOARD_LILYGO
  st = radio.setRxBoostedGainMode(LSM_RX_BOOSTED != 0); if (st != RADIOLIB_ERR_NONE) return st;
  // no setDio2AsRfSwitch (DIO5/DIO6 switch table), no setCurrentLimit, no 0x8B5 patch on the LR1121
#else
  st = radio.setRxBoostedGainMode(LSM_RX_BOOSTED != 0); if (st != RADIOLIB_ERR_NONE) return st;
  st = radio.setDio2AsRfSwitch(true);          if (st != RADIOLIB_ERR_NONE) return st;
  st = radio.setCurrentLimit(140.0);           if (st != RADIOLIB_ERR_NONE) return st;
  femPatch8B5();                               // RX sensitivity patch, best effort
#endif
  return RADIOLIB_ERR_NONE;
}

// V7.31: discovery always uses the conservative SF7/125 profile. A sphere's
// authenticated advert selects SF6/125 or SF7/125 for its working channel.
// The scheduler itself remains dynamic; only its PHY-derived mirrors move.
static int16_t radioApplyProfileRaw(const lsm_dual_phy::Profile& p) {
  if (!lsm_dual_phy::valid(p.id)) return RADIOLIB_ERR_INVALID_SPREADING_FACTOR;
  int16_t st = radio.setBandwidth((float)p.bandwidthHz / 1000.0f); if (st != RADIOLIB_ERR_NONE) return st;
  st = radio.setSpreadingFactor(p.sf);                 if (st != RADIOLIB_ERR_NONE) return st;
  st = radio.setCodingRate(LORA_CR);                   if (st != RADIOLIB_ERR_NONE) return st;
  st = radio.setSyncWord(LORA_SYNC);                   if (st != RADIOLIB_ERR_NONE) return st;
  st = radio.setPreambleLength(p.preambleSymbols);     if (st != RADIOLIB_ERR_NONE) return st;
  st = radio.setCRC(2);                                if (st != RADIOLIB_ERR_NONE) return st;
  st = radio.explicitHeader();                         if (st != RADIOLIB_ERR_NONE) return st;
  uint8_t cmd = 0, reg = 0;
  // Respect the board's disabled-validation build policy on every PHY change.
  // A profile must not silently re-enable symbol timeouts after radioConfig
  // disabled them. Propagate a refused command instead of claiming success.
  const uint8_t validation = LSM_RX_SYMB_VALID == 0 ? 0 : p.receiverValidationSymbols;
  return radio.setSymbValid(validation, &cmd, &reg);
}

static int16_t radioApplyDiscoveryProfile() {
  return radioApplyProfileRaw(lsm_dual_phy::profileForId(lsm_dual_phy::PROFILE_SF7_125));
}

static int16_t radioApplyWorkingProfile(uint8_t profileId) {
  const lsm_dual_phy::Profile p = lsm_dual_phy::profileForId(profileId);
  int16_t st = radioApplyProfileRaw(p);
  if (st != RADIOLIB_ERR_NONE) return st;
  g_workingProfileId = p.id;
  g_workingSf = p.sf;
  g_workingBw = p.bandwidthHz;
  g_memberAirUsLive = lsmLoraAirUs(MEMBER_WIRE_B + MESH_SEC_OVERHEAD,
                                    g_workingSf, g_workingBw,
                                    (uint8_t)(LORA_CR - 4));
  g_slotUsLive = membercapacity::slotUs(g_memberAirUsLive);
  if(!membercapacity::wireFits(g_slotUsLive))return -2005;
  g_relayMemberTierUsLive = g_memberAirUsLive + 2000UL + RELAY_JITTER_MAX_US;
  g_tokSlotUsLive = lsmLoraAirUs(TOK_WIRE_MAX_B + MESH_SEC_OVERHEAD,
                                  g_workingSf, g_workingBw,
                                  (uint8_t)(LORA_CR - 4)) + 2u*SLOT_GUARD_US;
  g_aggSlotUsLive = lsmLoraAirUs(AGG_FLUSH_WIRE_B + MESH_SEC_OVERHEAD,
                                  g_workingSf, g_workingBw,
                                  (uint8_t)(LORA_CR - 4)) + AGG_SLOT_GUARD_US;
  g_joinAirUs = (uint32_t)secureAirTime(sizeof(JoinPkt));
  { uint32_t r = JOIN_KEYWIN_US + g_joinAirUs + SLOT_GUARD_US;
    g_joinResUs = ((r + 499U) / 500U) * 500U; }
  g_airWitnessUs = (uint32_t)secureAirTime(sizeof(MemberPkt));
  applyTiers(g_schedTiers, g_nSlotsThisFrame ? g_nSlotsThisFrame : V7_SLOTS_PER_FRAME);
  return RADIOLIB_ERR_NONE;
}

struct Peer {
  uint8_t  id;
  uint8_t  role;
  int16_t  e;
  int16_t  n;
  // v7.28.70-absposbranch: absolute position as last heard on a type 0 member
  // packet. ADDITIVE. e and n above are untouched and remain the sphere-local
  // offset in cm that every existing consumer reads. 0/0 means none held.
  int32_t  absLatI;
  int32_t  absLonI;
  uint8_t  selfHops;  // the origin node's own advertised hops, 255 unknown
  uint8_t  viaHops;   // hops of the neighbor we heard this data from
  uint8_t  conf;      // v6.7: peer position confidence 0..63
  uint32_t lastMs;
  // v7.2: absolute seed assembly, from overheard type 3/4/5 SEED packets.
  // seedMask bit0=lat, bit1=lon, bit2=alt, complete only at 0x07.
  int32_t  seedLatI, seedLonI;
  int16_t  seedAltDm;
  uint8_t  seedMask;
  // v7.29.9 PEER UPLINK: gateway discovery via grant-named or overheard-confirmed relay
  uint8_t  gwCap;      // bit0 = can gateway to dashboard (sticky capability)
  int16_t  gwRssi;     // RSSI of last gatewayed / relay-confirmed packet, dBm
};
// g_hopsToCmd moved up with the other volatile state in v4.8. v7.28.104: drawStatus NO LONGER reads it; the glass paints hops to the TK from g_anchorHops. g_hopsToCmd is reserved (see its declaration) and read only by the election score.
#define PEER_TABLE_SIZE 64   // v7.30.0: dashboard and aggregate cache cover the full on-air roster.
static Peer     g_peers[PEER_TABLE_SIZE];

// v7.30.0 aggregate demand/grant state.  Demand tables are indexed by the
// one-byte fleet identity already used on this wire generation; no roster
// compaction bookkeeping is needed.
static uint8_t  g_aggDemand[256];
static uint8_t  g_aggDemandDepth[256];
static uint32_t g_aggDemandMs[256];
static bool     g_aggPosGrantMe = false;
static uint8_t  g_aggPosGrantRecs = 0;
static uint32_t g_aggPosSlotStartUs = 0;
static uint64_t g_aggPosLastTxAnchor = 0;
static uint8_t  g_aggGrantCursor = 0;

// v7.29.9 PEER UPLINK: gateway discovery via grant-named or overheard-confirmed relay
struct GwPending {
  uint8_t  relayer;
  uint8_t  src;
  int16_t  rssi;
  uint8_t  seq;
};
static GwPending g_gwPending = {0, 0, -200, 0};
static int8_t    g_gwLastPick = -1;

static int peerFind(uint8_t id) {
  for (int i = 0; i < PEER_TABLE_SIZE; i++)
    if (g_peers[i].id == id) return i;
  return -1;
}

static void peerMarkGateway(uint8_t id, int16_t rssi) {
  if (id == 0 || id == (uint8_t)NODE_ID) return;
  int i = peerFind(id);
  if (i < 0) {
    for (int k = 0; k < PEER_TABLE_SIZE; k++) {
      if (g_peers[k].id == 0 || millis() - g_peers[k].lastMs > 10000) {
        i = k;
        memset(&g_peers[k], 0, sizeof(Peer));
        g_peers[k].id = id;
        g_peers[k].gwRssi = -200;
        break;
      }
    }
    if (i < 0) return;
  }
  g_peers[i].gwCap = 1;
  if (rssi > -200) g_peers[i].gwRssi = rssi;
  g_peers[i].lastMs = millis();
}

static void peerNoteGranted(uint8_t id) {
  if (id == 0 || id == (uint8_t)NODE_ID) return;
  int i = peerFind(id);
  uint8_t was = (i >= 0) ? g_peers[i].gwCap : 0;
  peerMarkGateway(id, -200);
  if (!was) logRec(LOG_STATE, NODE_ID, g_role, 0xDD, (int16_t)id, 0, (uint32_t)g_seqHigh);
}

static void peerNoteRelayHeard(uint8_t relayer, uint8_t src, int16_t rssi) {
  if (relayer == 0 || relayer == (uint8_t)NODE_ID || src == 0) return;
  g_gwPending.relayer = relayer;
  g_gwPending.src     = src;
  g_gwPending.rssi    = rssi;
  g_gwPending.seq     = (uint8_t)g_seqHigh;
}

static void peerConfirmPending(void) {
  if (!g_gwPending.relayer) return;
  peerMarkGateway(g_gwPending.relayer, g_gwPending.rssi);
  logRec(LOG_STATE, NODE_ID, g_role, 0xDF, (int16_t)g_gwPending.relayer, (int16_t)g_gwPending.src, (uint32_t)g_seqHigh);
  g_gwPending.relayer = 0;
}

static int peerBestGateway(void) {
  const uint32_t now = millis();
  int best = -1;
  int16_t bestRssi = -201;

  for (int i = 0; i < PEER_TABLE_SIZE; i++) {
    Peer* p = &g_peers[i];
    if (!p->id || p->id == (uint8_t)NODE_ID) continue;
    if (!p->gwCap) continue;
    uint32_t age = now - p->lastMs;
    if (age > 10000UL) continue;
    if (p->gwRssi > bestRssi) { bestRssi = p->gwRssi; best = i; }
  }

  if (g_gwLastPick >= 0 && g_gwLastPick < PEER_TABLE_SIZE) {
    Peer* last = &g_peers[g_gwLastPick];
    if (last->id && last->gwCap && (now - last->lastMs) <= 10000UL) {
      if (best < 0 || last->gwRssi + 5 >= bestRssi) {
        best = g_gwLastPick;
      }
    }
  }
  
  if (best != g_gwLastPick) {
    logRec(LOG_STATE, NODE_ID, g_role, 0xF3,
           (int16_t)(best >= 0 ? g_peers[best].id : 0),
           (int16_t)(best >= 0 ? g_peers[best].gwRssi : -200),
           (uint32_t)g_seqHigh);
    g_gwLastPick = (int8_t)best;
  }
  return best;
}

// v7.28.64: the v6.7 GPS fusion state block was moved up beside originSet,
// see the globals section. Declarations only moved; nothing here changed.
// ---- v7.1: origin settle buffer, continuous re-center, and velocity ----
// A cold GPS fix is routinely 10 to 50 m off true position. Locking the
// origin on the very first raw fix bakes that error in permanently, every
// later good fix then shows a real, stuck offset from a bad origin. Fix:
// buffer fixes for ORIGIN_SETTLE_MS before locking origin, then keep
// re-centering the origin toward the live fix every tick so any residual
// error, whether from a rough origin lock or real motion, self-heals
// instead of sitting there forever.
static double   g_prevFixLat = 0, g_prevFixLon = 0;
static uint32_t g_prevFixMs  = 0;
static bool     g_havePrevFix = false;
static float    g_velE = 0, g_velN = 0;   // cm/s, derived from consecutive raw fixes
// v7.11.8: dead reckoning between real fix updates. g_fusBaseE/N hold the
// offset as of the last real re-center (the anchor), g_fusE/N become the
// live extrapolated value reported to the mesh and BLE. Velocity is zeroed
// if the last real fix is older than VEL_STALE_MS so a stale reading never
// runs away unbounded once GPS drops out.
static float    g_fusBaseE = 0, g_fusBaseN = 0;
#define VEL_STALE_MS 5000U
// v7.28.75: raw position. The origin is held once locked so the reported
// offset is the raw fix minus a fixed origin, which is what the dashboard
// can actually plot (seed plus offset). It re-centers only when the offset
// nears the int16 cm field limit, and every re-center re-seeds every listener.
#define RECENTER_CM       25000.0f   // 250 m, field limit is 327 m
#define BLE_SELF_SEED_MS  10000UL    // paired dashboard gets this board's own seed every 10 s, any role
static bool     g_reseedAir = false;  // set on re-center, consumed by the member seed-burst arm
static void queueSeedBle(uint32_t id, int32_t latI, int32_t lonI, int16_t altDm);
static void queueSelfSeedBle(){
  int32_t latI=(int32_t)llround(lat0*1000000.0), lonI=(int32_t)llround(lon0*1000000.0);   // v7.28.75: the seed IS the held origin, never the live fix
  int16_t altDm = gps.altitude.isValid() ? (int16_t)(altitudeCmNow()/10) : 0;
  queueSeedBle(NODE_ID, latI, lonI, altDm);
}
static void posFusionUpdate(bool haveFix, bool highQual, double lat, double lon, uint32_t now, uint32_t sats){
  static uint32_t lastPull = 0;
  // v7.11.8: dead-reckon the reported offset forward every call using the
  // last measured velocity, instead of holding the last real fix static
  // until the next once-a-second re-center catches up. This is what makes
  // a moving node's reported position track motion in real time; the
  // re-center below still corrects the anchor whenever a fresh fix lands.
  if (g_haveRealFix && g_posValid){
    uint32_t sinceFix = now - g_prevFixMs;
    if (sinceFix > VEL_STALE_MS){
      g_velE = 0; g_velN = 0;
    } else if (sinceFix > 0){
      float dtS = sinceFix / 1000.0f;
      g_fusE = g_fusBaseE + g_velE * dtS;
      g_fusN = g_fusBaseN + g_velN * dtS;
    }
  }
  // v7.28.64: RAW fix, before any real fix. Set a provisional origin on the
  // first one so there is something to be relative to, then report the raw
  // offset from it. No re-center, no velocity, no seed: the provisional
  // origin is a bookmark, not a claim. Confidence 1..3 from satellite count.
  if (haveFix && !highQual && !g_haveRealFix){
    if (!originSet){
      lat0 = lat; lon0 = lon; originSet = true; g_rawOrigin = true;
      if (gps.altitude.isValid()) { alt0 = altitudeCmNow(); altOriginSet = true; }
    }
    int16_t re=0, rn=0; offsetCm(lat, lon, re, rn);
    g_fusE = (float)re; g_fusN = (float)rn; g_fusBaseE = g_fusE; g_fusBaseN = g_fusN;
    g_posLat = lat; g_posLon = lon;
    g_posValid = true; g_posConf = rawConfFrom(sats); g_posLastGpsMs = now; g_posState = 1;
    return;
  }
  // v7.28.64: RAW fix after a real fix has been held. Do not re-center the
  // real origin off a weak fix; hold, dead reckon, and let confidence decay
  // through the existing staleness path below (g_posLastGpsMs untouched).
  if (haveFix && !highQual && g_haveRealFix){
    haveFix = false; g_posState = 3;
  }
  if (haveFix){
    if (!g_haveRealFix){
      // v7.28.64: re-seed. If a provisional origin was set from a raw fix,
      // record how far the real lock moved it, then lock for real below.
      if (g_rawOrigin){
        int16_t je=0, jn=0; offsetCm(lat, lon, je, jn);
        float jm = sqrtf((float)je*(float)je + (float)jn*(float)jn) / 100.0f;
        g_posLogJumpM = (uint8_t)(jm > 255.0f ? 255 : (jm < 0 ? 0 : jm));
        g_rawOrigin = false;
      }
      // v7.8: settle window skipped, per Stu 2026-07-07. Lock origin on the
      // very first raw fix instead of averaging a window first. The
      // continuous re-center below (unchanged, v7.1) is what pulls a rough
      // first fix toward truth over the next several seconds, the same way
      // it already pulls a moved node back to true position.
      lat0 = lat; lon0 = lon;
      originSet = true;
      // v7.12.6: capture the Z baseline here too when altitude happens to be
      // fresh at the same instant; if not, altOriginSet stays false and the
      // info screen just shows the E/N offset with no Z until it catches up.
      if (gps.altitude.isValid()) { alt0 = altitudeCmNow(); altOriginSet = true; }
      g_fusE = 0; g_fusN = 0; g_fusBaseE = 0; g_fusBaseN = 0; g_posLat = lat0; g_posLon = lon0;
      g_haveRealFix = true; g_posValid = true; fixSinceMs = now; g_posState = 2;   // v7.28.64
      g_prevFixLat = lat0; g_prevFixLon = lon0; g_prevFixMs = now; g_havePrevFix = true;
      g_posConf = 63; g_posLastGpsMs = now;
      queueSelfSeedBle();   // v7.28.75: own seed to the paired dashboard at lock, any role
      // v7.28.66: log absolute position at lock
      { int32_t latI = (int32_t)llround(lat0 * 1000000.0); int32_t lonI = (int32_t)llround(lon0 * 1000000.0);
        int16_t altI = gps.altitude.isValid() ? (int16_t)(altitudeCmNow() / 10) : 0;
        logRec(LOG_SEED, NODE_ID, g_role, g_posConf, (int16_t)(latI/100000), (int16_t)(lonI/100000), 
               (uint32_t)altI | ((uint32_t)((latI/1000)%100) << 16) | ((uint32_t)((lonI/1000)%100) << 24)); }
      return;
    }
    if (now - lastPull >= FUSION_PULL_MS){
      lastPull = now;
      int16_t re=0, rn=0; offsetCm(lat, lon, re, rn);
      float err = sqrtf((float)re*(float)re + (float)rn*(float)rn);   // cm, raw fix vs current origin
      // v7.1: continuously re-center the ORIGIN toward the live fix, once a
      // second, instead of smoothing a separate offset variable toward a
      // fixed origin. This is what makes a rough origin lock, or real
      // motion, self-heal instead of converging to a permanent stuck offset.
      // v7.28.75: RAW. The origin is HELD; the offset is the raw fix minus the
      // held origin, every pull. Re-center only near the int16 field limit,
      // and when we do, re-seed the paired dashboard now and the air next slot.
      if (err > RECENTER_CM){
        lat0 = lat; lon0 = lon;
        g_posLat = lat; g_posLon = lon;
        queueSelfSeedBle();
        g_reseedAir = true;
        logRec(LOG_STATE, NODE_ID, g_role, 0xEA, (int16_t)(err/100.0f), 0, 1);   // aux 0xEA data 1 = origin re-centered, e = metres moved
      }
      offsetCm(lat, lon, re, rn);         // raw residual against the held origin
      g_fusE = (float)re; g_fusN = (float)rn;
      g_fusBaseE = g_fusE; g_fusBaseN = g_fusN;   // v7.11.8: anchor for extrapolation until the next real update
      // v7.28.66: log absolute position on update
      { int32_t latI = (int32_t)llround(g_posLat * 1000000.0); int32_t lonI = (int32_t)llround(g_posLon * 1000000.0);
        int16_t altI = gps.altitude.isValid() ? (int16_t)(altitudeCmNow() / 10) : 0;
        logRec(LOG_SEED, NODE_ID, g_role, g_posConf, (int16_t)(latI/100000), (int16_t)(lonI/100000), 
               (uint32_t)altI | ((uint32_t)((latI/1000)%100) << 16) | ((uint32_t)((lonI/1000)%100) << 24)); }
      // v7.1: velocity from consecutive raw fixes, cm/s east and north, so a
      // genuinely moving node can be told apart from settling drift and so
      // the fused point can track motion instead of lagging behind it.
      if (g_havePrevFix){
        float dtS = (now - g_prevFixMs) / 1000.0f;
        if (dtS > 0.05f){
          int16_t pe=0, pn=0; offsetCm(g_prevFixLat, g_prevFixLon, pe, pn);
          // v7.11.9: light smoothing before the estimate is trusted for
          // dead reckoning. At 10Hz the same raw GPS jitter that was
          // negligible at 1Hz becomes a much bigger apparent velocity spike,
          // same jitter divided by a tenth of the time, so blend the new
          // raw sample with the prior smoothed value instead of using each
          // raw fix-to-fix delta directly.
          float rawVelE = ((float)re - (float)pe) / dtS;
          float rawVelN = ((float)rn - (float)pn) / dtS;
          g_velE = rawVelE;   // v7.28.75: alpha 1, raw fix-to-fix velocity
          g_velN = rawVelN;
        }
      }
      g_prevFixLat = lat; g_prevFixLon = lon; g_prevFixMs = now; g_havePrevFix = true;
      g_posLat = lat; g_posLon = lon;
    }
    g_posConf = 63; g_posLastGpsMs = now; g_posState = 2;   // v7.28.64
  } else if (g_posValid){
    uint32_t age = now - g_posLastGpsMs;
    if (age > POS_STALE_MS){
      if (g_haveRealFix){ int c = 63 - (int)((age - POS_STALE_MS)/500U); g_posConf = (uint8_t)(c < 4 ? 4 : c); g_posState = 3; }
      else { g_posConf = 1; }   // v7.28.64: a raw position that went stale sits at the raw floor, never climbs into the real range
    }
  }
}

// ---- v7.2: absolute seed protocol ----
// A SEED burst (lat, lon, alt as three separate 9-byte packets, types 3/4/5)
// is only ever sent when this node's own GPS confidence is high, never
// otherwise, no exceptions. First burst fires the moment confidence crosses
// the line, then again every SEED_RESEND_MS as a keep-alive verify. If
// confidence is low when the timer comes due, the send is skipped, not
// queued, and tried again the next time confidence is checked, so a node
// that regains confidence sends on the very next opportunity rather than
// waiting out a missed window.
#define SEED_CONF_HIGH    16U
#define SEED_RESEND_MS    150000UL   // 2.5 minutes
static uint32_t g_lastSeedMs    = 0;
static bool     g_seedSentOnce  = false;
static uint8_t  g_seedBurstPart = 0;   // 0 none pending, 1 lat next, 2 lon next, 3 alt next

// v7.2: push an assembled absolute seed (this node's own, or a peer's once
// all three parts have arrived) out over BLE so the dashboard can cache it
// and start plotting that node's true position instead of a bare offset.
// v7.2 fix: a seed notify must never fire straight off the radio frame
// engine. That path runs asynchronously to the BLE connection handshake, and
// notifying a characteristic whose CCCD the client has not finished
// subscribing to will make Chrome Web Bluetooth abort the link ("connection
// cancelled"). So seeds are QUEUED here and drained only from the slow
// 1-second houseTick, the same safe cadence sendPosition and
// sendDiagnostics already use. The notify itself also checks that the
// characteristic actually has a subscriber before sending.
struct PendingSeed { uint32_t id; int32_t latI; int32_t lonI; int16_t altDm; bool full; };
static PendingSeed g_pendSeed[64];  // v7.30.0: one pending absolute seed per possible sphere member.
static void queueSeedBle(uint32_t id, int32_t latI, int32_t lonI, int16_t altDm){
  for (int i = 0; i < (int)(sizeof(g_pendSeed)/sizeof(g_pendSeed[0])); i++){
    if (g_pendSeed[i].full && g_pendSeed[i].id == id){   // coalesce, keep newest
      g_pendSeed[i].latI=latI; g_pendSeed[i].lonI=lonI; g_pendSeed[i].altDm=altDm; return;
    }
  }
  for (int i = 0; i < (int)(sizeof(g_pendSeed)/sizeof(g_pendSeed[0])); i++){
    if (!g_pendSeed[i].full){
      g_pendSeed[i].id=id; g_pendSeed[i].latI=latI; g_pendSeed[i].lonI=lonI;
      g_pendSeed[i].altDm=altDm; g_pendSeed[i].full=true; return;
    }
  }
}
void sendSeedBle(uint32_t id, int32_t latI, int32_t lonI, int16_t altDm){
  if (!g_connected || chSeed == nullptr) return;
  if (chSeed->getSubscribedCount() == 0) return;   // client has not subscribed to CSEED yet
  uint8_t b[16]; memset(b, 0, sizeof(b));
  put_u32(b + 0, id);
  memcpy(b + 4, &latI, 4);
  memcpy(b + 8, &lonI, 4);
  memcpy(b + 12, &altDm, 2);
  chSeed->setValue(b, sizeof(b));
  chSeed->notify();
}
// Drained once per second from houseTick, on the safe BLE cadence.
void flushPendingSeeds(){
  if (!g_connected || chSeed == nullptr || chSeed->getSubscribedCount() == 0) return;
  for (int i = 0; i < (int)(sizeof(g_pendSeed)/sizeof(g_pendSeed[0])); i++){
    if (g_pendSeed[i].full){
      sendSeedBle(g_pendSeed[i].id, g_pendSeed[i].latI, g_pendSeed[i].lonI, g_pendSeed[i].altDm);
      g_pendSeed[i].full = false;
    }
  }
}

// v7.2: fold one SEED part into a peer's assembly slot. Complete only once
// all three parts (lat, lon, alt) have arrived; a partial seed is never
// pushed to the dashboard, half a coordinate is worse than none.
void peerTouch(uint8_t id, bool memberRole=false);   // v7.11.6: forward decl, defined after peerSeen below
void peerSeedPart(uint8_t id, uint8_t type, const uint8_t* payload4){
  for (int i = 0; i < PEER_TABLE_SIZE; i++) {
    if (g_peers[i].id != id) continue;
    if (type == 3) { memcpy(&g_peers[i].seedLatI, payload4, 4); g_peers[i].seedMask |= 0x01; }
    else if (type == 4) { memcpy(&g_peers[i].seedLonI, payload4, 4); g_peers[i].seedMask |= 0x02; }
    else if (type == 5) { memcpy(&g_peers[i].seedAltDm, payload4, 2); g_peers[i].seedMask |= 0x04; }
    if (g_peers[i].seedMask == 0x07) {
      queueSeedBle(id, g_peers[i].seedLatI, g_peers[i].seedLonI, g_peers[i].seedAltDm);
      // v7.28.67: log relay position from peer
      logRec(LOG_RELAY_POS, id, g_role, g_peers[i].conf, (int16_t)(g_peers[i].seedLatI/100000), (int16_t)(g_peers[i].seedLonI/100000), 
             (uint32_t)(g_peers[i].seedAltDm & 0xFFFF) | ((uint32_t)((g_peers[i].seedLatI/1000)%100) << 16) | ((uint32_t)((g_peers[i].seedLonI/1000)%100) << 24));
    }
    return;
  }
}

static uint32_t g_lastRxMs = 0;
// v7.29.26: the generic RX clock is advanced by every valid packet and cannot
// distinguish a healthy member uplink from unrelated traffic.  The keeper uses
// this separate clock to detect the fleet-wide symptom seen in the V25 capture:
// schedules continue, but every seated member disappears from RX together.
static uint32_t g_lastMemberRxMs = 0;
/* g_lastTkHeardMs defined in v6.0 election module */
static uint32_t g_lastSyncMs    = 0;   // last valid sync, direct TK beacon or relayed anchor
// v7.29.6: the orphan g_candSinceMs that sat here (declared and set at boot, never read) is
// retired; the live declaration is beside g_role, where the stranding timer now reads it.

void peerSeen(uint8_t id, uint8_t role, int16_t e, int16_t n,
              uint8_t selfHops, uint8_t viaHops, uint8_t conf, uint32_t ageMs) {
  uint32_t stamp = millis() - ageMs;
  for (int i = 0; i < PEER_TABLE_SIZE; i++) {
    if (g_peers[i].id == id) {
      if (stamp + 500 < g_peers[i].lastMs) return;  // we already hold fresher data
      g_peers[i].role = role; g_peers[i].e = e; g_peers[i].n = n;
      g_peers[i].selfHops = selfHops; g_peers[i].viaHops = viaHops; g_peers[i].conf = conf;
      g_peers[i].lastMs = stamp; return;
    }
  }
  for (int i = 0; i < PEER_TABLE_SIZE; i++) {
    if (g_peers[i].id == 0 || millis() - g_peers[i].lastMs > 10000) {
      g_peers[i].id = id; g_peers[i].role = role; g_peers[i].e = e; g_peers[i].n = n;
      g_peers[i].selfHops = selfHops; g_peers[i].viaHops = viaHops; g_peers[i].conf = conf;
      g_peers[i].lastMs = stamp;
      // v7.2: a reused slot must not inherit the previous occupant's seed.
      g_peers[i].seedLatI = 0; g_peers[i].seedLonI = 0; g_peers[i].seedAltDm = 0; g_peers[i].seedMask = 0;
      g_peers[i].absLatI = 0; g_peers[i].absLonI = 0;   // v7.28.70-absposbranch: same v7.2 rule, no inherited absolute
      g_peers[i].gwCap = 0; g_peers[i].gwRssi = -200;  // v7.29.9: slot reuse must not leak gateway capability
      return;
    }
  }
}

// v7.11.6: refresh liveness only, no position write. Used for type=6 present
// pings, which carry no real x/y, so an existing entry's last known position
// must not be stomped with zeros.
// v7.12.2: a present ping from an id with NO existing peer entry used to do
// nothing at all, so a node that never once sent real position data never
// got a peer table slot, and was structurally invisible to sendPeerPositions
// and therefore the dashboard, not just shown as low confidence. Root caused
// 2026-07-11 tracing node 09's flash log against board 05's. Fix: give it a
// real slot here too, same reused-slot rule peerSeen already uses (empty or
// stale over 10s), position and hops zeroed, conf 0. Conf 0 is already the
// dashboard's reserved "on mesh, no fix" sentinel, firmware position decay
// never sends it (floors at 4), so this is unambiguous on the receiving end.
// V40: a new authenticated member report also updates its role. The old
// liveness-only path preserved role3 forever after a keeper became a member,
// making healthy former keepers ineligible for successor selection. Relayed
// snapshots alone do not prove a new role; preserve their previous behavior.
// Never override the current schedule keeper using a late member report.
void peerTouch(uint8_t id, bool memberRole) {
  uint32_t stamp = millis();
  for (int i = 0; i < PEER_TABLE_SIZE; i++) {
    if (g_peers[i].id == id) { if(memberRole && id!=g_tkId) g_peers[i].role=1; g_peers[i].lastMs = stamp; return; }
  }
  for (int i = 0; i < PEER_TABLE_SIZE; i++) {
    if (g_peers[i].id == 0 || millis() - g_peers[i].lastMs > 10000) {
      g_peers[i].id = id; g_peers[i].role = (memberRole && id!=g_tkId)?1:0; g_peers[i].e = 0; g_peers[i].n = 0;
      g_peers[i].selfHops = 0; g_peers[i].viaHops = 0; g_peers[i].conf = 0;
      g_peers[i].lastMs = stamp;
      g_peers[i].seedLatI = 0; g_peers[i].seedLonI = 0; g_peers[i].seedAltDm = 0; g_peers[i].seedMask = 0;
      g_peers[i].absLatI = 0; g_peers[i].absLonI = 0;   // v7.28.70-absposbranch: same rule in peerTouch
      g_peers[i].gwCap = 0; g_peers[i].gwRssi = -200;  // v7.29.9: slot reuse must not leak gateway capability
      return;
    }
  }
}

// v7.28.70-absposbranch: absolute position write, additive and deliberately SEPARATE
// from peerSeen. peerSeen's signature is left exactly as it was so every existing
// call site stays byte-identical and cannot be broken by this branch. Called right
// after peerSeen on a type 0. 0/0 is the no-position sentinel and is ignored, so a
// peer that loses its fix keeps its last known absolute rather than being nulled.
void peerSetAbs(uint8_t id, int32_t latI, int32_t lonI) {
  if (latI == 0 && lonI == 0) return;
  for (int i = 0; i < PEER_TABLE_SIZE; i++) {
    if (g_peers[i].id == id) { g_peers[i].absLatI = latI; g_peers[i].absLonI = lonI; return; }
  }
}

uint8_t peerCount() {
  uint8_t c = 0;
  for (int i = 0; i < PEER_TABLE_SIZE; i++)
    if (g_peers[i].id != 0 && millis() - g_peers[i].lastMs < 5000) c++;
  return c;
}

#if IS_COMMAND_CENTER
// Push each fresh peer heard on 915 to the dashboard as its own position
// packet. The dashboard plots by node id, so one BLE pairing to this badge
// shows the entire mesh. Stale peers are not sent, no ghosts on the map.
void sendPeerPositions(uint64_t deadlineUs) {
  if (!g_connected || chPos == nullptr || chPos->getSubscribedCount() == 0) return;
  uint32_t now = millis();
  // Bound legacy compatibility work independently of fleet size. At most
  // ten peer reports and nine3ms pacing waits in one maintenance job.
  // The round-robin cursor preserves service to every fresh peer.
  static uint8_t cursor=0;
  uint8_t sent=0;
  for (int step = 0; step < PEER_TABLE_SIZE && sent < 10; ++step) {
    const int i=cursor;cursor=(uint8_t)((cursor+1)%PEER_TABLE_SIZE);
    if (g_peers[i].id == 0) continue;
    uint32_t age = now - g_peers[i].lastMs;
    if (age > 10000) continue;
    // Reserve notification overhead before pacing; the caller owns the whole
    // BLE job deadline, including diagnostics/seed work that ran before us.
    const uint64_t needUs=(sent?3000ULL:0ULL)+1000ULL;
    if((uint64_t)esp_timer_get_time()+needUs>deadlineUs)break;
    if(sent)delay(3); // At most27ms pacing; never sleep after the final report.
    uint8_t b[16];
    memset(b, 0, sizeof(b));
    put_u32(b + 0, g_peers[i].id);
    put_i16(b + 4, g_peers[i].e);
    put_i16(b + 6, g_peers[i].n);
    b[10] = 0;                                // floor
    b[12] = 0x00;                             // flags
    b[11] = g_peers[i].conf;                  // v6.7: peer position confidence
    b[13] = (uint8_t)(age > 255000 ? 255 : age / 1000); // age in seconds
    if(!legacyPeerNotifyChecked(b,sizeof(b))){cursor=(uint8_t)i;break;} // Retry this peer on a later turn after a stack rejection.
    ++sent;
  }
}
#endif

void setRole(uint8_t r, uint8_t tk, const char* why) {
  if (g_role == r && g_tkId == tk) return;
  g_role = r; g_tkId = tk;
  int16_t e = 0, n = 0;
  if (originSet && gps.location.isValid()) offsetCm(gps.location.lat(), gps.location.lng(), e, n);
  logRec(LOG_STATE, NODE_ID, g_role, g_tkId, e, n, 0);
  if (!serQuiet()) Serial.printf("STATE role=%s tk=%u (%s)\n", roleStr(), g_tkId, why);
}

void tkOnJoinReq(uint8_t id);
void tkOnData(uint8_t id, uint32_t arrivalOffUs, uint32_t departOffUs, uint8_t hops, int16_t departDevUs);
int tkRosterFind(uint8_t id);
void profileDecayStep(LatProfile* pr);

// ----------------------- v7.28.50: EDGE PEEL -----------------------
// Design locked 2026-09-01. Overlapping co-channel spheres resolve by members
// peeling one at a time at the edge, never by a keeper-to-keeper handoff.
// BEFORE THIS CUT a rostered member adopted ANY beacon it decoded, from any
// keeper (the unconditional g_tkId = s->tkId below), so two spheres in
// earshot on one channel made every boundary member flip keepers beacon by
// beacon. Now:
//   OBSERVE. A member with a LIVE home keeper (beacon within 3 frames) and a
//     slot at home (own id seen in a home slot within 3 frames) does not adopt
//     a foreign beacon. It records the foreign RSSI (direct copies only,
//     schedHops 0; a relayed copy carries the relay's RSSI, not the keeper's)
//     into a per-target EWMA, and its own schedule RSSI (whichever copy it
//     adopted, direct or relayed, the beacon that actually carries its
//     schedule) into a home EWMA. Only decoded beacons feed either; a missed
//     frame feeds nothing. Neither is trusted below PEEL_MIN_SAMPLES.
//   TRIGGER. Foreign stronger than home by PEEL_MARGIN_DB, held on
//     PEEL_HOLD_FRAMES consecutive decoded foreign beacons. Hop count never
//     enters (coupled, thrashes). A foreign sphere flagged full is never a
//     target: with SPHERE_CAP=4 that is the common case, and a member must not
//     knock at a door that cannot open. One target at a time, the strongest.
//   KNOCK. Make before break: still synced to home, the member sends the
//     ordinary 4 byte JoinPkt (its global id) inside the FOREIGN keeper's join
//     reservation, timed off the foreign beacon's own on-air anchor, frame
//     length, tier count and join modulus turn, all read off that beacon; only
//     in a foreign frame whose beacon was decoded, never over its own home
//     beacon region or its own home slot. The foreign keeper runs plain
//     admission and has no idea the joiner is foreign.
//   JUMP. When the member sees its own id in the foreign slot array, it adopts
//     that beacon through the normal path (this is the one foreign beacon that
//     is allowed through), reseeds the freshness reference to the new keeper's
//     seq, and goes quiet at home; the home slot is silence-evicted. A dwell
//     (PEEL_DWELL_MS) then holds it: no second move, and no fresh target, until
//     the dwell runs out. PEEL_KNOCK_MAX unanswered knocks also end in a dwell.
//   ORPHAN. A member whose home keeper has gone silent, or that holds no home
//     slot, is not peeling; it adopts the foreign beacon exactly as before this
//     cut (stage 9 in the log), so keeper failover and cold join are untouched.
//   TIEBREAK. Inside the deadband a rostered member stays put; lowest tkId
//     decides only for an orphan hearing two keepers, and that is the pre-
//     existing last-beacon-wins path, which this cut does not change.
// KEEPER SIDE: nothing. Same as the locked design.
// WITNESS: LOG_STATE aux 0xED. e = stage: 1 armed (margin held), 2 knock sent,
//   3 granted and moved, 4 target flagged full, 5 target lost (no beacon for
//   PEEL_FOREIGN_TTL_MS), 6 gave up after PEEL_KNOCK_MAX, 9 orphan adopt.
//   n = foreign tkId. data = home EWMA dBm (int16, high 16) | foreign EWMA dBm
//   (int16, low 16). The knock itself also logs the usual LOG_TX aux 0xFE.
// LOG_LOOP errand id 10 = peelService.
#define PEEL_MARGIN_DB        25       // same figure as the relay recovery hysteresis, separately named so either moves alone
#define PEEL_HOLD_FRAMES      5
#define PEEL_MIN_SAMPLES      8
#define PEEL_DWELL_MS         60000UL
#define PEEL_KNOCK_MAX        8
#define PEEL_FOREIGN_TTL_MS   5000UL
#define PEEL_HOME_LIVE_FRAMES 3
// v7.28.101: a node admitted in a birth frame is the LEAST settled node in the
// sphere. Its home RSSI average has almost no samples, so a single strong foreign
// beacon can outrank a home link that is actually fine, and peel throws it straight
// back off the roster it just joined. A burst of joiners at the edge, which is
// exactly what the birth frame exists to admit, is the worst case for this. Hold
// every freshly admitted board immune to peel until it has had time to build a
// real home average. This only delays a peel; it never prevents one.
#define PEEL_BIRTH_GRACE_MS   30000UL
static int16_t  g_peelHomeX4 = 0;  static uint8_t g_peelHomeN = 0;      // home schedule RSSI EWMA, quarter dB
static uint8_t  g_peelForTk  = 0;  static int16_t g_peelForX4 = 0; static uint8_t g_peelForN = 0;
static uint8_t  g_peelHold = 0, g_peelStage = 0, g_peelKnocks = 0;     // stage 0 idle, 1 knocking, 2 dwell
static uint32_t g_peelDwellUntilMs = 0, g_peelForSeenMs = 0, g_peelRosteredMs = 0, g_peelMoves = 0;
static uint32_t g_admittedMs = 0;   // v7.28.101: millis when this board most recently went from unslotted to slotted. Peel grace runs from here.
static uint64_t g_peelForAnchorUs = 0;
static uint32_t g_peelForFrameUs = 0, g_peelForJoinWinUs = 0, g_peelForJoinWinEndUs = 0;
static uint8_t  g_peelForJoinMod = 0, g_peelForSeq = 0;
static bool     g_peelForBeaconFresh = false;
bool memberSendJoin();
#if LSM_RELAY_PLEA
static bool pleaSeenHas(uint8_t src, uint8_t seq);
static void pleaSeenAdd(uint8_t src, uint8_t seq);
static void pleaForward(const MemberPkt* in);
void        memberSendPlea();
static bool pleaWantThisFrame();
#endif
static inline void peelEwma(int16_t& x4, uint8_t& n, int16_t rssi) {
  int16_t v = (int16_t)(rssi * 4);
  if (n == 0) x4 = v; else x4 = (int16_t)(x4 - (x4 >> 3) + (v >> 3));
  if (n < 255) n++;
}
static inline void peelHomeSample(int16_t rssi) { peelEwma(g_peelHomeX4, g_peelHomeN, rssi); }
static void peelLog(uint8_t stage, uint8_t forTk) {
  uint16_t h = (uint16_t)(int16_t)(g_peelHomeX4 / 4), f = (uint16_t)(int16_t)(g_peelForX4 / 4);
  logRec(LOG_STATE, NODE_ID, g_role, 0xED, (int16_t)stage, (int16_t)forTk, ((uint32_t)h << 16) | (uint32_t)f);
}
static inline void peelDropTarget() { g_peelForTk = 0; g_peelForN = 0; g_peelHold = 0; g_peelKnocks = 0; g_peelForBeaconFresh = false; }
// Returns true when handleSched should go on and ADOPT this foreign beacon
// (grant, or orphan); false when it was measured only and must not be adopted.
static bool peelObserveForeign(const SchedBeacon* s, int16_t rssi, int64_t rxUs) {
  uint32_t liveMs = (uint32_t)PEEL_HOME_LIVE_FRAMES * (g_frameUs / 1000UL) + 50UL;
  bool homeLive = (g_lastSchedMs != 0) && (millis() - g_lastSchedMs) <= liveMs;
  bool rostered = (g_peelRosteredMs != 0) && (millis() - g_peelRosteredMs) <= liveMs;
  if (!homeLive || !rostered) { peelLog(9, s->tkId); peelDropTarget(); g_peelStage = 0; g_peelHomeN = 0; return true; }
  if (s->schedHops != 0) return false;
  if (rssi < DIRECT_RSSI_FLOOR_DBM) return false;
  if (g_peelStage == 2) { if ((int32_t)(millis() - g_peelDwellUntilMs) < 0) return false; g_peelStage = 0; }
  if (g_peelForTk != s->tkId) {
    if (g_peelForTk != 0 && g_peelForN >= PEEL_MIN_SAMPLES && (int16_t)(rssi * 4) <= g_peelForX4
        && (millis() - g_peelForSeenMs) <= PEEL_FOREIGN_TTL_MS) return false;   // a stronger target is already tracked
    peelDropTarget(); g_peelForTk = s->tkId; if (g_peelStage == 1) g_peelStage = 0;
  }
  peelEwma(g_peelForX4, g_peelForN, rssi);
  g_peelForSeenMs = millis();
  // v7.28.101 BIRTH GRACE. Placed HERE on purpose, not at the top of the function:
  // above this point the beacon has already passed the direct-only and RSSI-floor
  // filters and the target has already been selected, so g_peelForX4 is the average
  // for THIS foreign keeper and nothing else. Gating any earlier would have folded
  // relayed beacons, weak beacons and samples from different keepers into one number,
  // which is the opposite of what the grace window is for.
  // A board admitted in a birth frame is the least settled board in the sphere: its
  // home RSSI average has almost no samples, so one strong foreign beacon can outrank
  // a home link that is actually fine and peel throws it straight back off the roster
  // it just joined. A burst of joiners at the edge, which is exactly what the birth
  // frame exists to admit, is the worst case. So keep MEASURING and refuse to ACT:
  // the averages keep accumulating and any knock in flight is stood down, so when the
  // window closes the decision is made on real data instead of on two or three samples.
  // This only ever delays a peel. It never prevents one.
  if (g_admittedMs != 0 && (millis() - g_admittedMs) < PEEL_BIRTH_GRACE_MS) {
    if (g_peelStage != 0) { peelLog(10, s->tkId); g_peelStage = 0; g_peelKnocks = 0; }   // stage 10 = held off by birth grace
    g_peelHold = 0;
    return false;
  }
  { // foreign geometry for the knock, from this beacon and nothing else
    uint32_t n = s->nSlots;
    uint8_t tiers = (s->resizeCountdown == 0) ? s->resizeTiers : s->schedTiers;
    if (tiers > RELAY_TIERS_MAX) tiers = RELAY_TIERS_MAX;
    int64_t bAir = (int64_t)beaconAirUsLive(n);
    int64_t tx0  = rxUs > bAir ? rxUs - bAir : rxUs;
    g_peelForAnchorUs = (uint64_t)tx0;
    g_peelForFrameUs  = s->frameMs10 ? (uint32_t)s->frameMs10 * 10000UL : g_frameUs;
    uint32_t joinRes  = s->joinResUs500 ? (uint32_t)s->joinResUs500 * 500U : g_joinResUs;
    g_peelForJoinWinUs = tkSlotUsLive(n) + (uint32_t)tiers * relaySchedTierUsLive(n);
    uint32_t tail = g_joinAirUs + SLOT_GUARD_US;
    g_peelForJoinWinEndUs = (joinRes > tail) ? (g_peelForJoinWinUs + joinRes - tail) : g_peelForJoinWinUs;
    g_peelForJoinMod = s->joinMod; g_peelForSeq = s->seq;
    g_peelForBeaconFresh = (SF_CUR(s->subFrame) == SF_TYPE_DATA);   // knock only through the fixed reservation of a DATA frame
  }
  if (g_peelStage == 1) {
    for (int i = 0; i < s->nSlots && i < V7_SLOTS_MAX; i++) {
      if (s->slot[i] == (uint8_t)NODE_ID) {   // GRANT: jump
        g_peelStage = 2; g_peelDwellUntilMs = millis() + PEEL_DWELL_MS; g_peelMoves++;
        peelLog(3, s->tkId);
        g_haveSchedSeq = true; g_maxSchedSeq = s->seq;   // freshness reference re-seeded to the new keeper
        g_peelHomeN = 0; g_peelHold = 0; g_peelKnocks = 0; g_peelForTk = 0; g_peelForN = 0; g_peelForBeaconFresh = false;
        return true;
      }
    }
  }
  if (s->sFlags & 0x01) {   // foreign sphere full: not a door that opens
    if (g_peelStage == 1) { peelLog(4, s->tkId); g_peelStage = 0; }
    g_peelHold = 0; return false;
  }
  if (g_peelStage == 1) return false;
  if (g_peelHomeN < PEEL_MIN_SAMPLES || g_peelForN < PEEL_MIN_SAMPLES) return false;
  if (g_peelForX4 >= (int16_t)(g_peelHomeX4 + PEEL_MARGIN_DB * 4)) { if (g_peelHold < 255) g_peelHold++; } else g_peelHold = 0;
  if (g_peelHold >= PEEL_HOLD_FRAMES) { g_peelStage = 1; g_peelKnocks = 0; peelLog(1, s->tkId); }
  return false;
}
// The knock, from loop(): fires inside the foreign join reservation on this
// board's modulus turn of the foreign frame, once per decoded foreign beacon.
static void peelService() {
  if (g_peelStage != 1 || g_role == 3 || !g_radioOk) return;
  if (g_peelForTk == 0 || (millis() - g_peelForSeenMs) > PEEL_FOREIGN_TTL_MS) { peelLog(5, g_peelForTk); peelDropTarget(); g_peelStage = 0; return; }
  if (!g_peelForBeaconFresh || g_peelForJoinMod == 0 || g_peelForFrameUs == 0) return;
  if ((((uint32_t)g_peelForSeq + NODE_ID) % (uint32_t)g_peelForJoinMod) != 0) { g_peelForBeaconFresh = false; return; }
  uint64_t nowUs = (uint64_t)esp_timer_get_time();
  if (nowUs < g_peelForAnchorUs) return;
  if (nowUs - g_peelForAnchorUs >= (uint64_t)g_peelForFrameUs) { g_peelForBeaconFresh = false; return; }   // that foreign frame is over
  uint32_t fOff = (uint32_t)(nowUs - g_peelForAnchorUs);
  if (fOff < g_peelForJoinWinUs || fOff >= g_peelForJoinWinEndUs) return;
  if (g_frameAnchorUs != 0 && g_frameUs != 0) {   // never over home's keeper region or this board's own home slot
    uint32_t hOff = (uint32_t)((nowUs - g_frameAnchorUs) % (uint64_t)g_frameUs);
    if (hOff < g_memberBaseUs) return;
    if (g_mySlot != 0xFF) {
      uint32_t s0 = g_memberBaseUs + (uint32_t)g_mySlot * g_slotUsLive;
      if (hOff + g_joinAirUs + SLOT_GUARD_US >= s0 && hOff < s0 + g_slotUsLive) return;
    }
  }
  if (g_loraIrq) return;
  g_peelForBeaconFresh = false;
  memberSendJoin();
  g_peelKnocks++;
  peelLog(2, g_peelForTk);
  if (g_peelKnocks >= PEEL_KNOCK_MAX) { peelLog(6, g_peelForTk); peelDropTarget(); g_peelStage = 2; g_peelDwellUntilMs = millis() + PEEL_DWELL_MS; }
}

// v7.28.97 VOLUNTEER RELAY REPORT.
// The problem it solves, from the bench capture of 2026-09-20: the keeper names a
// relay for a member only when that member already has a relay parent latched
// (tkBuildAndSend: "if (par == 0) continue;"), and the latch only populates when a
// RELAYED copy of that member arrives. No copy, no latch, no grant, no copy. A node
// that has just walked out to two hops has no history at that depth, so it is never
// named, never relays, and stays unreachable while every board around it is fine.
// In that capture the keeper issued 1699 grant records and not ONE carried a real
// relayForId: every single one fell through to the rotating probe.
// The fix keeps the keeper in charge and adds no speculative transmissions. A member
// that hears another member DIRECTLY, and reads in the beacon's heardMask that the
// keeper did NOT hear that member, names it in volunteerFor on its own hop-0 packet
// and raises bit 0x04 of the side-channel byte. The keeper seeds the parent latch
// from that report, so the very next pass of its own naming loop can grant properly.
// Detection needs nothing new on the wire: slot[] already carries member id per slot
// and heardMask already says which slots the keeper heard.
// ONE report per frame, rotating. A volunteer hearing ten orphans serves them one per
// frame, and each pairing is self-sustaining once a real relayed copy starts arriving
// and refreshes the latch on its own, so ten orphans are wired up inside ten frames.
// The keeper does NOT overwrite a latch that is still live, so two volunteers naming
// the same orphan cannot flip-flop it frame to frame: first report wins, and the
// existing RELAY_PARENT_HOLD_MS sliding latch owns it from there.
#define VOL_HEARD_N       16
#define VOL_HEARD_TTL_MS  8000UL
static uint8_t  g_volHeardId[VOL_HEARD_N];
static uint32_t g_volHeardMs[VOL_HEARD_N];
static uint8_t  g_volCursor = 0;
static uint8_t  g_volunteerFor = 0;   // orphan named on THIS frame's packet, 0 = nothing to report
// v7.28.102 CHUNK 4: the id of the most recent joiner THIS BOARD directly heard
// via its own type-2 receipt, latched here so the existing type-7 swarm-ask can
// carry it up the tree without a new packet. Set ONLY at aggBufAdd's first insert
// for a fresh srcId, which fires only from the p->type==2 && p->hops==0 receive
// path, i.e. only on direct physical hearing. A magic-B or aggregate receive is
// secondhand and never touches this. Cleared when aggBufPurgeSeated drops the id
// (seated), so a missed type-7 retries on the next DATA frame rather than being
// silently lost, and a stale id is never carried past its own admission.
static uint8_t  g_admitId      = 0;
static uint8_t  g_orphanSeen   = 0;   // v7.28.101: how many slots the keeper has not heard that THIS board CAN hear. volPick already walks every slot to pick one; this counts them all on the same pass, at no extra cost.
static uint8_t  g_lastSwarmAsk = 0;   // v7.28.101: windows requested by the most recent swarm request this board sent, 0 = never sent one
// v7.29.5 MASK SKEW FIX for volPick. The beacon heardMask is indexed by the PREVIOUS
// frame's slots (v7.28.21 g_slotOfPrev on the keeper), so the id that owned slot k
// LAST frame is the one the bit describes. volPick read s->slot[k], THIS frame's
// owner; under any roster churn that shifts slots the read pairs the bit with the
// wrong id, exactly the skew v7.29.4 fixed for heardMe. The previous adopted
// beacon's slot array is cached here after each adoption and the orphan walk reads
// the mask at the slot the id held last frame. g_prevNSlots 0 (first beacon, or a
// JOIN frame last time) means the mask describes nothing and nothing is an orphan.
// The two bitmaps are what the volunteer carry gate consumes: an id is a carry
// candidate only if the keeper did not hear it last frame (orphan) or it is not
// seated at all this frame (a join request from a fallen node).
static uint8_t  g_prevSlot[V7_SLOTS_MAX];
static uint8_t  g_prevNSlots = 0;
static uint8_t  g_volOrphanMap[32];    // bit per node id: keeper did NOT hear it last frame (mask read at last frame's slot)
static uint8_t  g_volSlottedMap[32];   // bit per node id: holds a slot in THIS frame's beacon
static inline bool volMapGet(const uint8_t* m, uint8_t id){ return (m[id >> 3] >> (id & 7)) & 1u; }
static inline void volMapSet(uint8_t* m, uint8_t id){ m[id >> 3] |= (uint8_t)(1u << (id & 7)); }
static void volNoteHeard(uint8_t id){
  if (id == 0 || id == (uint8_t)NODE_ID) return;
  uint32_t nowMs = millis();
  int freeSlot = -1, oldest = 0;
  for (int i = 0; i < VOL_HEARD_N; i++){
    if (g_volHeardId[i] == id) { g_volHeardMs[i] = nowMs; return; }
    if (g_volHeardId[i] == 0 && freeSlot < 0) freeSlot = i;
    if (g_volHeardMs[i] < g_volHeardMs[oldest]) oldest = i;
  }
  int k = (freeSlot >= 0) ? freeSlot : oldest;
  g_volHeardId[k] = id; g_volHeardMs[k] = nowMs;
}
static void volPick(const SchedBeacon* s){
  g_volunteerFor = 0;
  g_orphanSeen   = 0;   // v7.28.101: recomputed from scratch on every beacon, never accumulated
  memset(g_volOrphanMap, 0, sizeof(g_volOrphanMap));
  memset(g_volSlottedMap, 0, sizeof(g_volSlottedMap));
  if (g_role == 3) return;                 // a keeper reports to nobody
  uint32_t nThis = (uint32_t)s->nSlots;
  if (nThis > V7_SLOTS_MAX) nThis = 0;
  for (uint32_t k = 0; k < nThis; k++) if (s->slot[k] != 0) volMapSet(g_volSlottedMap, s->slot[k]);
  // v7.29.5: the orphan walk runs over LAST frame's slot array, the one this mask describes
  uint32_t n = (uint32_t)g_prevNSlots;
  if (n == 0 || n > V7_SLOTS_MAX) return;
  uint32_t nowMs = millis();
  // v7.28.101: this loop no longer returns on the first match. It runs the full slot
  // walk so g_orphanSeen is a true count, and latches the FIRST qualifying orphan as
  // the one to report. The rotating cursor still advances off that first pick, so the
  // round-robin behaviour that v7.28.97 relies on is byte-for-byte unchanged: a
  // volunteer hearing ten orphans still serves exactly one per frame, in the same
  // order, and ten orphans are still wired up inside ten frames.
  bool picked = false;
  for (uint32_t k = 0; k < n; k++){
    uint32_t sp = ((uint32_t)g_volCursor + k) % n;
    uint8_t id = g_prevSlot[sp];   // v7.29.5: the id that held slot sp LAST frame, which is what heardMask bit sp describes
    if (id == 0 || id == (uint8_t)NODE_ID) continue;
    if ((s->heardMask[sp >> 3] >> (sp & 7)) & 1u) continue;   // keeper heard it directly, not an orphan
    volMapSet(g_volOrphanMap, id);   // v7.29.5: every unheard seated id, whether or not THIS board heard it; the carry gate reads this
    bool heardByMe = false;
    for (int i = 0; i < VOL_HEARD_N; i++)
      if (g_volHeardId[i] == id && (uint32_t)(nowMs - g_volHeardMs[i]) <= VOL_HEARD_TTL_MS) { heardByMe = true; break; }
    if (!heardByMe) continue;
    if (g_orphanSeen < 255) g_orphanSeen++;
    if (!picked) {
      picked = true;
      g_volunteerFor = id;
      g_volCursor = (uint8_t)((sp + 1) % n);
    }
  }
}
void handleSched(const uint8_t* raw, int len, int16_t rssi, int8_t snr, int16_t snrRaw) {
  if (len < (int)BEACON_WIRE_FIXED_B) return;   // v7.28.37: need the fixed head present to read nSlots and ver before sizing the rest
  const SchedBeacon* s = (const SchedBeacon*)raw;
  if (s->magic != 'K' || s->ver != WIRE_VER) return;   // v7.14.0: wire ver 19 (was 18). Stamp-fresh anchor fix: sFlags bits 1..7 carry per-hop jitter residual. Keep in lockstep with dispatcher raw[1] and build-site s.ver. v7.13.2: wire ver 18 (was 17 here). THIS LINE WAS THE BUG. v7.13.0 bumped the SchedBeacon build site 17->18 for schedTiers/resizeTiers/resizeCountdown but left both receive gates at 17, so every board transmitted 18 and every board dropped 18. handleSched was never entered, g_lastTkHeardMs never refreshed, every node read the TK as dead, took the vacuum-election path, and self-elected. Whole rig went all-TK with no rival detection, because rival detection also lives downstream of this gate. Keep this in lockstep with the dispatcher raw[1] check and the s.ver build site: all three move together or the sphere goes deaf to itself.
  if (ksDenied(s->tkId)) {   // v7.28.59: a revoked board can never be our keeper; dropping its beacons lets the stall path walk us off it
    static uint32_t lastDenyLogMs = 0;
    if (millis() - lastDenyLogMs > 5000) { lastDenyLogMs = millis(); logRec(LOG_CTOK, s->tkId, g_role, 21, 0, 0, 0); }
    return;
  }
  // v7.12.0: production direct-link RSSI floor. A relayed copy (schedHops >= 1)
  // is exempt, this only gates "can I hear the real TK directly."
  // v7.17.0 typed superframe, member adopt. Read the TK's published frame type,
  // target and countdown fresh off this beacon, the same told-not-inferred rule
  // freqCountdown and resizeCountdown already use. The member stores the current
  // type because the type governs how it reads this frame's slots and whether it
  // may transmit. v7.28.0 comment fix: since the v7.19.0 bricks the TK DOES
  // publish SF_TYPE_JOIN under join demand, so this adopt path is LIVE, not
  // behaviour-preserving; the stale claim that only DATA is ever published
  // dated from v7.17.0 and was false from v7.19.0 on. FAIL-SAFE
  // (Decision 6): a member not certain of the next frame's type must fall back to
  // listen-only and transmit nothing rather than transmit into the wrong region.
  // That TX gate is scaffolded in the handoff and NOT wired this build, which is
  // safe precisely because no non-DATA type is ever announced yet.
  // v7.28.37 VARIABLE-LENGTH GATES. The beacon is sent at beaconWireB(nSlots)
  // bytes, so the receiver validates the count then confirms every claimed slot
  // is actually present before reading the tail. A corrupt nSlots past the ceiling
  // is rejected outright (the sphere never places more than V7_SLOTS_MAX), which
  // also bounds the frame-length math below.
  if (s->nSlots > V7_SLOTS_MAX) { g_schedRejMag++; return; }
  if (len != (int)beaconWireB((uint32_t)s->nSlots) || !s->tkId || !s->frameMs10) return;
  const uint8_t beaconTiers=lsmgeometry::effectiveTiers(s->schedTiers,s->resizeTiers,s->resizeCountdown,RELAY_TIERS_MAX);
  // v7.28.50 EDGE PEEL hook. A member that already follows a keeper treats a
  // different keeper's beacon as evidence, not as a schedule. Sits before any
  // state is written from this beacon (frame type, freshness reference, anchor)
  // so a foreign beacon can neither retype the home frame nor be dropped as
  // stale by the seq gate before it is measured. The v7.11.0 hidden-node note
  // is kept so this board's own data packet still relays the rival home.
  if (g_role != 3 && g_tkId != 0 && s->tkId != g_tkId) {
    // v7.30.0 AUTHORITY-TUPLE MERGE.  A direct authenticated schedule is
    // stronger evidence than the RSSI peel heuristic.  Every follower must
    // compare the same (epoch, keeper id) tuple or equal-epoch partitions can
    // divide according to local signal strength and keep both authorities
    // alive.  Newer epoch wins; at equal epoch the lower provisioned id wins.
    // A losing tuple is still remembered for the hidden-rival report, but is
    // never allowed to move the frame anchor.  RSSI peeling remains only for
    // the same-authority mobility case handled elsewhere.
    int8_t foreignEpochDelta =
        (int8_t)((uint8_t)s->sphere - (uint8_t)g_tkEpoch);
    g_relayRivalTkId = s->tkId; g_relayRivalEpoch = s->sphere;
    g_relayRivalTie = s->tkTie; g_relayRivalRssiAvg = s->tkRssiAvg;
    g_relayRivalScore = s->tkScore; g_relayRivalSeenMs = millis();
    bool foreignAuthorityWins = foreignEpochDelta > 0 ||
        (foreignEpochDelta == 0 && s->tkId < g_tkId);
    if (!foreignAuthorityWins) return;
    logRec(LOG_STATE, NODE_ID, g_role, 0xCA, (int16_t)g_tkId,
           (int16_t)s->tkId,
           ((uint32_t)g_tkEpoch << 8) | (uint32_t)s->sphere);
  }
  // v7.23.0 RECEIVE-SIDE SANITY GATES, ahead of both the flood-relay block and
  // the anchor correction so a bad beacon is neither relayed onward nor used to
  // place the frame. The transmit sites at 3064, 3673 and 4644 clamp what this
  // fleet EMITS to g_schedTiers; nothing ever checked what it ACCEPTS, so a
  // beacon claiming a hop depth far above the tiers in force fell straight
  // through and displaced the anchor by whole seconds. Rejecting means: return
  // now, keep the previous anchor, sit the frame out. Silence is the cheap
  // mistake; acting on a corrupt schedule collides with a neighbour.
  {
    // Receive and relay against THIS authenticated beacon's effective geometry.
    // A previous-frame cap rejects growth and permits a stale relay on shrink.
    const uint8_t schedDepthCap=beaconTiers;
    if (s->schedHops > schedDepthCap) { g_schedRejDepth++; return; }
    // Gate 2, FRESHNESS. A relayed copy of the current frame carries the current
    // seq; a copy more than one frame behind the newest seq seen is stale and
    // must not set the anchor. One frame of tolerance because a deep relay is
    // legitimately one frame late; two frames is refused. The first reception
    // seeds the reference so a board that boots into a running mesh is not
    // locked out, and a returning board that missed many frames advances the
    // reference on its next fresh beacon rather than rejecting it.
    if (g_schedSeqTk != s->tkId) { g_schedSeqTk=s->tkId; g_haveSchedSeq=false; }
    if (g_seqHighTk == s->tkId && (uint32_t)(millis()-g_seqAdvMs) > tkStallMs()
        && meshRecovery.observe(s->tkId, s->seq, millis(), g_frameUs/1000UL)) {
      g_haveSchedSeq=false; g_seqHighTk=0;
      g_schedFloodSeq=(uint8_t)(s->seq-1); g_anchorAdoptTk=0;
    }
    if (!g_haveSchedSeq) { g_haveSchedSeq = true; g_maxSchedSeq = s->seq; }
    else {
      if ((int8_t)((uint8_t)s->seq - g_maxSchedSeq) > 0) g_maxSchedSeq = s->seq;
      if ((int8_t)(g_maxSchedSeq - (uint8_t)s->seq) > 1) { g_schedRejStale++; return; }
    }
  }
  // v7.28.16: a copy deeper than the tier this board would produce can only
  // come from a board that never heard the tier above it: downstream evidence.
  if (g_schedFloodBestHop != 255 && s->schedHops > (uint8_t)(g_schedFloodBestHop + 1)) relayNeedNote(1);
  if (s->schedHops == 0 && directRssiGateSched(rssi)) return;
  g_frameType          = SF_CUR(s->subFrame);
  g_frameTypeTarget    = SF_TGT(s->subFrame);
  g_frameTypeCountdown = SF_CD(s->subFrame);

  if (s->schedHops == 0) { g_lastDirectSchedMs = millis(); if (g_lastDirectSchedMs == 0) g_lastDirectSchedMs = 1; }   // v7.28.19
  {
    // v7.11.10: real flood relay tracking. Any node participates, not just
    // one designated board. A new seq resets the per-seq state. Whenever a
    // STRICTLY BETTER (lower) hop count than anything seen so far this seq
    // arrives, adopt it and schedule a relay attempt at hop+1, in that
    // tier's own fixed sub-window inside RELAY_SCHED_SLOT_US so it never
    // fires before the previous tier has had its chance and never collides
    // with the TK's own slot or the join window. Hearing that someone else
    // ALREADY completed the exact tier this node was about to produce
    // cancels the pending attempt, this is the suppression that keeps the
    // flood to roughly one real transmission per hop tier.
    if (s->seq != g_schedFloodSeq) {
      g_schedFloodSeq = s->seq;
      g_schedFloodBestHop = 255;
      g_schedFloodOutHop = 255;
      g_schedFloodRelayed = false;  // v7.28.89: reset suppression flag on new seq so suppression can fire again
      g_schedFloodDeadlineUs = RELAY_NO_DEADLINE;
      // v7.11.10: a new schedule seq is the real "new frame" signal for
      // flood purposes, unlike g_anchorFresh, which can also fire again
      // mid-frame when a later, relayed copy re-anchors. A stale member
      // flood entry left over from the previous frame must never fire
      // against this frame's offUs, so the whole table clears here.
      for (int i=0;i<RELAY_MEMBER_TRACK_N;i++) g_memberFlood[i].active = false;
    }
    if (s->schedHops < g_schedFloodBestHop && (size_t)len == beaconWireB((uint32_t)s->nSlots)) {   // v7.28.37: full beacon at its real length
      g_schedFloodBestHop = s->schedHops;
      uint8_t outHop = (uint8_t)(s->schedHops + 1);
      // v7.19.0 brick6: clamp to the RUNTIME tier count, not the static ceiling, so a
      // relay never transmits past a shrunk dynamic-depth window. No-op by default
      // (g_schedTiers == RELAY_TIERS_MAX == RELAY_MAX_HOPS-1).
      // v7.28.16: relay only on downstream evidence or on this board's probe turn.
      // bestHop and outHop bookkeeping above still runs so the suppression branch
      // below keeps tracking the tier whether or not this board arms.
      bool relayNeed  = (outHop >= 2) ? (relayNeedLive1() || relayNeedLive2()) : relayNeedLive2();   // v7.28.20: split evidence dwell, deeper-copy (why 1) never arms hop 1 and can no longer cancel a live flood-join arm
      bool relayProbe;
      const bool benchForceRelay = (g_benchLinkMask != 0xFFFEu);
      if (outHop == 1) {
        // v7.28.18: hop 1 is named by the keeper. relayById carries either a real
        // data-relay grant (relayForId != 0) or, when nobody is unheard, a rotating
        // probe (relayForId == 0). One relayer per frame, no jitter band contention.
        bool named1 = (s->relayById  == (uint8_t)NODE_ID);
        bool named2 = (s->relayById2 == (uint8_t)NODE_ID);   // v7.28.104: the second named board relays hop 1 exactly as the first; the existing RSSI-weighted jitter (under 12 ms) separates them
        relayProbe = named1 || named2 || benchForceRelay;
        g_relayArmNeed = named1 ? (s->relayForId != 0 ? 1 : 2) : (named2 ? (s->relayForId2 != 0 ? 1 : 2) : 0);
      } else {
        relayProbe = benchForceRelay || ((((uint32_t)s->seq) + NODE_ID) % RELAY_PROBE_MOD) == 0;
        g_relayArmNeed = 0;
      }
      if (!relayNeed && !relayProbe) {
        g_schedFloodOutHop = outHop;
        g_schedFloodRelayed = false;
        g_schedFloodDeadlineUs = RELAY_NO_DEADLINE;
      } else
      if (outHop < RELAY_MAX_HOPS && lsmgeometry::relayTierAllowed(outHop,beaconTiers)) {
        g_relayArmProbe = relayNeed ? 1 : 0;   // v7.28.18: n = armed on heard evidence; e set above = keeper naming
        g_schedFloodRelayed = false;
        g_schedFloodOutHop = outHop;
        uint32_t relayLen = beaconWireB((uint32_t)s->nSlots);   // v7.28.37: copy and later retransmit only the real length
        memcpy(g_relaySchedRaw, raw, relayLen);
        g_relaySchedLen = (uint8_t)relayLen;
        g_relaySchedRaw[offsetof(SchedBeacon, schedHops)] = outHop;
        uint32_t tierStart = tkSlotUsLive((uint32_t)s->nSlots) + (uint32_t)(outHop-1) * relaySchedTierUsLive((uint32_t)s->nSlots);   // v7.28.37: per-frame keeper slot and relay tier width
        uint32_t jitterUs = relayJitterUs(rssi);   // v7.12.0: RSSI-weighted jitter, chosen once
        g_schedFloodDeadlineUs = tierStart + jitterUs;
        // v7.14.0: stamp own jitter into sFlags bits 1..7 (100us quantum) so
        // downstream receivers can subtract this hops residual from their
        // recovered on-air-start and land on the true slot-0 anchor. Preserves
        // bit0 (sphere_full) untouched.
        {
          uint8_t oldF = g_relaySchedRaw[offsetof(SchedBeacon, sFlags)];
          uint32_t code = jitterUs / 100UL;
          if (code > 0x7F) code = 0x7F;
          g_relaySchedRaw[offsetof(SchedBeacon, sFlags)] = (uint8_t)((oldF & 0x01) | ((uint8_t)code << 1));
        }
      } else {
        g_schedFloodDeadlineUs = RELAY_NO_DEADLINE;   // beyond the depth cap, do not relay further
      }
    } else if (s->schedHops == (uint8_t)(g_schedFloodBestHop + 1) && !g_schedFloodRelayed) {
      // someone else already completed the exact tier this node was about
      // to produce: stand down, no need to repeat it
      g_schedFloodDeadlineUs = RELAY_NO_DEADLINE;
      g_schedFloodRelayed = true;
    }
  }
  int64_t rxUs = g_loraIrqUs;
  // v7.21.3: the fallback below is an anchor corrupting path and was unwitnessed.
  // If the RxDone stamp is missing or stale the code anchors off the CURRENT
  // instant instead, which places the frame boundary wherever the loop happened
  // to get here. rxStale records that it fired; rxLagUs records the ordinary
  // ISR to processing gap when it did not.
  uint8_t rxStale = 0; int32_t rxLagUs = 0;
  { int64_t nowUs = esp_timer_get_time();
    rxLagUs = (int32_t)(nowUs - rxUs);
    if (rxUs <= 0 || nowUs - rxUs > 500000) { rxUs = nowUs; rxStale = 1; rxLagUs = 0; } }
  // A node processes a schedule as a MEMBER whenever it is not itself the TK.
  // The elected TK ignores foreign schedules except to run the election compare.
  // v7.28.16: only the best copy of a seq anchors. A later copy with equal or
  // worse hops carries nothing new and used to overwrite a direct anchor with a
  // relayed one, putting a direct-range board into flood mode.
  if (g_anchorAdoptTk == s->tkId && g_anchorAdoptSeq == s->seq && s->schedHops >= g_anchorAdoptHops) { g_schedRejWorse++; return; }
  g_anchorAdoptTk = s->tkId; g_anchorAdoptSeq = s->seq; g_anchorAdoptHops = s->schedHops;
  if (g_role != 3 && s->tkId == g_tkId) peelHomeSample(rssi);   // v7.28.50: the beacon that carries this board's schedule, direct or relayed
  electNoteRssi(rssi);
  g_lastTkHeardMs = millis(); g_relistenAttempts = 0;   // v7.28.10: a real TK heard clears the re-walk counter
  g_coldCommitSinceMs = 0;                              // v7.29.47: any authenticated schedule cancels a pending cold commit
  // v7.28.22: seq advance is the liveness signal. seq is (uint8_t)g_frame at the
  // build site, so it wraps every 256 frames, about 170 s at the 664 ms frame
  // measured on 2026-09-03. Newer-than MUST therefore be the modular test, not
  // a plain >, or liveness breaks once every wrap. Against a 15 frame threshold
  // the margin is enormous. A different tkId reseeds rather than compares: two
  // keepers' seq spaces are unrelated and comparing across them is meaningless.
  if (g_seqHighTk != s->tkId) {
    g_seqHighTk = s->tkId; g_seqHigh = s->seq; g_seqAdvMs = millis(); volClaimCheckTTL(g_seqHigh);
    g_peerSeqTk = s->tkId; g_peerSeqHigh = s->seq; g_peerSeqAdvMs = 0;
  }
  else if ((int8_t)((uint8_t)s->seq - g_seqHigh) > 0) {
    g_seqHigh = s->seq; g_seqAdvMs = millis(); volClaimCheckTTL(g_seqHigh);
    if (g_peerSeqTk != s->tkId || (int8_t)((uint8_t)s->seq - g_peerSeqHigh) >= 0) {
      g_peerSeqTk = s->tkId; g_peerSeqHigh = s->seq; g_peerSeqAdvMs = 0;
    }
  }
  g_anchorHops = s->schedHops;   // v7.18.0: remember whether this schedule reached us direct (0) or relayed (>0), for the join-escalation decision
  if (g_role != 3) {
  // the schedule beacon anchors slot 0 for this frame. rxUs is the RxDone ISR,
  // fired at the END of the beacon reception; subtract the beacon airtime to
  // recover the on-air START, the same instant the TK anchors on. Without this
  // the member frame is skewed a full beacon airtime late and the TK measures
  // that skew as delay, railing DRIFT (bench log 25).
  // v7.14.0: relayed-anchor stamp-fresh recovery. rxUs - BEACON_AIR_US is the
  // on-air START of THIS beacon. For schedHops==0 (heard direct from TK) that IS
  // slot 0 and no correction is needed. For schedHops>=1 the on-air start is
  // offset from real slot 0 by a deterministic tier position plus the relaying
  // nodes per-tier jitter (stamped in sFlags bits 1..7, 100us quantum). Subtract
  // both to recover the actual slot-0 anchor. Each hop stamps only its own jitter,
  // so no accumulation of prior-hop residuals rides the wire; per-hop rx noise is
  // the only residual error, which the sim shows adds in quadrature to well inside
  // the 1000us slot guard through 8 hops.
  int64_t manchCorrUs = 0;   // v7.21.3: hoisted so the witness below can read it. Value unchanged.
  {
    int64_t bAir = (int64_t)beaconAirUsLive((uint32_t)s->nSlots);   // v7.28.37: airtime of THIS beacon's slot count, matching what the keeper sent
    int64_t txStartUs = rxUs > bAir ? rxUs - bAir : rxUs;
    int64_t offsetUs = 0;
    if (s->schedHops >= 1) {
      offsetUs  = (int64_t)tkSlotUsLive((uint32_t)s->nSlots) + (int64_t)(s->schedHops - 1) * (int64_t)relaySchedTierUsLive((uint32_t)s->nSlots);   // v7.28.37: per-frame keeper slot and relay tier width, matching the keeper's placement
      offsetUs += (int64_t)((uint32_t)((s->sFlags >> 1) & 0x7F) * 100UL);
    }
    manchCorrUs = offsetUs;
    // v7.23.0 MAGNITUDE BACKSTOP. Even a legal hop depth must land inside one
    // frame; a correction longer than the frame is physically impossible on any
    // topology this geometry can hold. The depth gate above already bounds the
    // tier term, so this catches a correction inflated by the per-hop jitter
    // term or any arithmetic surprise: milliseconds are possible, seconds are
    // not. Reject rather than anchor, keeping the previous frame boundary.
    // g_frameUs is skipped when zero, before the first frame is measured, since
    // the depth gate already protects that window.
    if (g_frameUs != 0 && offsetUs > (int64_t)g_frameUs) { g_schedRejMag++; return; }
    g_frameAnchorUs = (uint64_t)(txStartUs > offsetUs ? txStartUs - offsetUs : 0);
  }
  // v7.21.3 member anchor witness, aux 1. Emitted immediately after the stamp
  // so nothing between the two can move it. Reads state only, feeds back nothing.
  { int32_t mslip = 0;
    if (g_manchPrevAnchorUs && g_manchPrevFrameUs)
      mslip = (int32_t)(((int64_t)(g_frameAnchorUs - g_manchPrevAnchorUs)
                         - (int64_t)g_manchPrevFrameUs) / 100);
    int32_t cjump = (int32_t)(((int64_t)manchCorrUs - (int64_t)g_manchPrevCorrUs) / 100);
    int8_t  jit   = rxStale ? (int8_t)-1
                            : (int8_t)((uint32_t)((s->sFlags >> 1) & 0x7F));
    logRecRf(LOG_MANCH, NODE_ID, g_role, 1,
             anchClamp(mslip), anchClamp(rxLagUs / 100), (uint32_t)manchCorrUs,
             (int8_t)(s->schedHops > 127 ? 127 : s->schedHops), jit,
             anchClamp(cjump));
    g_manchPrevAnchorUs = g_frameAnchorUs;
    g_manchPrevFrameUs  = g_frameUs;
    g_manchPrevCorrUs   = (uint32_t)manchCorrUs; }
  // v7.28.30 anchor identity, aux 3. Ties this board's slot-0 instant to the
  // beacon seq it anchored on and carries the frames missed since the last
  // anchor, read before the zero below. Reads state only, feeds back nothing.
  logRecRf(LOG_MANCH, NODE_ID, g_role, 3,
           (int16_t)s->seq,
           (int16_t)(g_framesSilent > 32767UL ? 32767 : g_framesSilent),
           (uint32_t)(g_frameAnchorUs / 1000ULL),
           (int8_t)(rssi < -127 ? -127 : (rssi > 127 ? 127 : rssi)), 0,
           (int16_t)(g_frameUs / 100UL > 32767UL ? 32767 : g_frameUs / 100UL));
  g_anchorValid = true;
  g_anchorFresh = true;               // tell the frame engine: boundary = this beacon
  g_schedThisFrame = true;            // a join may be requested this frame
  g_nSlotsThisFrame = s->nSlots;      // v5.4: adaptive join boundary
  g_frameGeometrySlots = s->nSlots;
  // v5.5: hop distance to command. The schedule carries its relay depth,
  // 0 from the TK itself. v7.20.7: a direct member now reads H0 (the +1 was
  // removed). Relayed copies arrive with schedHops bumped, so a one-hop
  // member reads H1 and so on. This is display and election-score only; it
  // does NOT touch schedHops on the wire, so relay timing math is unchanged.
  { bool directRecentHop = g_lastDirectSchedMs != 0 && (millis() - g_lastDirectSchedMs) < JOIN_DIRECT_WINDOW_MS;   // v7.28.86
    uint8_t shHop = (uint8_t)(s->schedHops < 255 ? s->schedHops : 255);
    g_hopsToCmd = (shHop > 0 && directRecentHop) ? 0 : shHop; }   // v7.28.86: hold H0 through one missed origin; show relayed depth only when direct is genuinely gone
  g_lastSchedMs = millis();
  g_framesSilent = 0;
  // v7.11.0: hidden-node dual-TK fix. If we already had a tracked TK and this
  // beacon is from a DIFFERENT one, a second live TK exists that we can hear
  // but it cannot hear itself, or the direct rival-yield path below would
  // already have resolved it. Remember it so our own data packet can relay
  // it home this frame.
  if (g_tkId != 0 && s->tkId != g_tkId) {
    g_relayRivalTkId = s->tkId;
    g_relayRivalEpoch = s->sphere;
    g_relayRivalTie = s->tkTie;
    g_relayRivalRssiAvg = s->tkRssiAvg;
    g_relayRivalScore = s->tkScore;
    g_relayRivalSeenMs = millis();
  }
  g_tkId = s->tkId;
  g_tkEpoch = s->sphere;
  g_homeTkTie = s->tkTie;
  g_homeTkRssiAvg = s->tkRssiAvg;
  // v6.1: members track the LIVE TK's published score. Before this the member
  // hysteresis compared against g_tkScore stuck at 0, so any member whose own
  // score crossed the bare margin would usurp a healthy TK after the hold. On
  // a 9 board mesh the centrality term alone gets scores there.
  g_tkScore = (int32_t)s->tkScore;
  // v7.10.9: listen + random backoff with reset. If we are still trying to
  // join and the roster just grew, somebody else's join landed, defer:
  // cancel our current window and re-arm a fresh random one in frameEngine
  // instead of racing whatever queued up right behind that success.
  // v7.12.1: the any-roster-growth reset that used to live here is gone.
  g_sphereCount = s->nodeCount;                 // v6.6: occupancy from the TK
  g_sphereFull  = (uint8_t)(s->sFlags & 0x01);  // v6.6: full flag from the TK
  g_successor   = s->successor;                 // v6.6: named successor
  // v7.29.38: mirror the published roster for an immediate warm handover.
  if (s->nSlots != 0) { // JOIN frames intentionally publish no member slots; retain the last DATA snapshot
    g_standbyRosterN = 0;
    for (uint8_t si = 0; si < s->nSlots && si < V7_SLOTS_MAX; si++) {
      uint8_t sid = s->slot[si];
      if (!sid || sid == (uint8_t)NODE_ID) continue;
      bool seen = false;
      for (uint8_t sj = 0; sj < g_standbyRosterN; sj++) if (g_standbyRoster[sj] == sid) { seen = true; break; }
      if (!seen) g_standbyRoster[g_standbyRosterN++] = sid;
    }
  }
  g_curSchedSeq = s->seq;
  // Adopt exact wire width before dependent member/tail geometry.
  if (s->slotUs10 != 0) {
    uint32_t adv = membercapacity::adoptUs(s->slotUs10);
    if (adv != g_slotUsLive) {
      g_slotUsLive = adv;
      logRec(LOG_RF, NODE_ID, g_role, 7, (int16_t)(adv/10U), 0, g_slotUsLive);
    }
  }
  // v7.13.0: adopt the tier geometry BEFORE the frame length, since every
  // member-slot offset this frame is measured from the anchor it defines.
  // The member is told the count, never infers it, so TK and member cannot
  // disagree about where member slots begin.
  if (s->ver >= 18) {
    // v7.16.0: adopt the TK's join reservation and turn modulus BEFORE the tier
    // geometry below, so applyTiers() re-derives g_memberBaseUs from the value
    // the TK actually published rather than this board's own idea of it. A
    // member never computes the reservation locally past this point. A zero is
    // treated as "not published" and the current value is kept, so a malformed
    // or truncated beacon cannot collapse the reservation to nothing.
    { uint32_t told = (uint32_t)s->joinResUs500 * 500U;
      if (told != 0) g_joinResUs = told; }   // v7.28.37: adopt the reservation; the single applyTiers below re-derives the base
    g_joinMod = s->joinMod;
    // v7.28.37: g_memberBaseUs now depends on THIS frame's slot count as well as
    // the tier count and the reservation, so it must be re-derived every beacon
    // from s->nSlots, not only when schedTiers changes. Pick the tier count in
    // force: a switch frame (resizeCountdown==0) adopts resizeTiers this frame,
    // otherwise schedTiers. One applyTiers call per beacon keeps TK and member
    // agreeing on where member slots begin at every roster size.
    uint8_t tiersInForce = beaconTiers;
    applyTiers(tiersInForce, (uint32_t)s->nSlots);
    if (s->resizeCountdown == 0)
      logRec(LOG_STATE, NODE_ID, g_role, s->tkId, 0, 0, (uint32_t)s->resizeTiers);   // this beacon IS the switch frame
  }
  if (s->frameMs10) g_frameUs = (uint32_t)s->frameMs10 * 10000UL;   // v11: adopt TK frame length (ms10 -> us)
  // v7.12.5: TK-directed frequency switch, dashboard-initiated test. Read
  // fresh off whatever beacon we just heard, no local countdown timer, so a
  // node that missed some frames still switches on the right absolute frame,
  // it just sees a lower number when it does catch one. countdown == 0 means
  // this beacon IS the switch frame, right after processing it, retune now,
  // same instant the TK itself retunes right after sending it.
  if (s->freqCountdown == 0) {
    int16_t fst = radio.setFrequency(s->freqTargetMHz);
    lsmRxArm();
    logRec(LOG_STATE, NODE_ID, g_role, s->tkId, 0, 0, (uint32_t)lround(s->freqTargetMHz * 1000000.0));  // v7.12.11: actual Hz logged, not a flat marker
    if (fst != RADIOLIB_ERR_NONE) logRec(LOG_RF, NODE_ID, g_role, 1, 0, 0, (uint32_t)(int32_t)fst);
    if (fst == RADIOLIB_ERR_NONE) g_currentFreqMHz = s->freqTargetMHz;  // v7.12.12: track actual tuned freq for the glass
  }
  // v7.10.1: a candidate was never granted a slot by any TK, so hearing a
  // live schedule must not declare it JOINED. Stand down to LISTEN instead;
  // the slot check right below promotes it to MEM in this same frame if the
  // TK still lists it, otherwise it falls through to the real join window
  // like any new arrival. Ported from v7.9.5, same root cause found in node
  // 08's flash log: the candidate skipped the join request entirely and the
  // TK never learned to slot it.
  if (g_role == 2) { g_role = 0; }
  // grant is per frame: cleared at the boundary, set only if named here
  g_mySlotPrevFrame = g_mySlotLastFrame;   // v7.29.4: heardMask in THIS beacon describes the previous frame, so keep that frame's slot
  g_mySlotLastFrame = 0xFF;
  g_mySlot = 0xFF;
  memset(g_pubIdMap, 0, sizeof(g_pubIdMap));   // v7.28.16: rebuild the published-id map from this beacon
  g_pubMapValid = true;                        // v7.28.17
  for (int i = 0; i < s->nSlots && i < V7_SLOTS_MAX; i++){
    uint8_t v = s->slot[i];
    if (v != 0 && v != 0xFF && v != 0xFE) g_pubIdMap[v >> 3] |= (uint8_t)(1U << (v & 7));
    if (v == (uint8_t)NODE_ID && g_mySlot == 0xFF) { g_mySlot = (uint8_t)i; g_mySlotLastFrame = (uint8_t)i; }   // v7.29.4
  }
  aggBufPurgeSeated();   // v7.28.102 item 6: this beacon just seated whoever is in slot[]; stop discovering them
  if (g_mySlot != 0xFF) {
    // v7.28.101: latch the admission edge. g_peelRosteredMs refreshes every frame a
    // slot is held, so it cannot say how LONG the slot has been held; g_admittedMs
    // is set only on the unslotted-to-slotted transition and is what the peel grace
    // window measures from.
    if (g_peelRosteredMs == 0 || (millis() - g_peelRosteredMs) > (PEEL_HOME_LIVE_FRAMES * (g_frameUs / 1000UL) + 1000UL)) g_admittedMs = millis();
    g_peelRosteredMs = millis();   // v7.28.50: this board holds a slot at home this frame
  }
#ifdef CRYSTAL_TOKEN
  // v7.28.59: tail token slot grant, read straight off this beacon. Only a board that holds a
  // slot at home this frame and heard the keeper direct answers; the keeper grants direct members only.
  g_tokNSlots  = s->nSlots;
  g_tokGrantMe = (s->grantId != 0) && (s->grantId == (uint8_t)NODE_ID) && (g_mySlot != 0xFF);   // chunk 2: a relayed beacon copy carries the grant too
  g_tokRelayMe = (s->grantId != 0) && (s->relayById == (uint8_t)NODE_ID) && (s->grantId != (uint8_t)NODE_ID) && (g_mySlot != 0xFF);
  g_tokRelayLen = 0;
#endif
  // v7.30.0: an aggregate grant is explicit in the schedule and begins after
  // any crystal-token tail sub-slots.  Every listener derives the same start.
  {
    uint8_t tokSlots = s->grantId ? (s->relayById ? 2U : 1U) : 0U;
    telemetryAdopt(s->aggGrantId,s->seq,s->relayForId,s->relayById,s->relayForId2,s->relayById2);
    g_aggPosGrantMe = (s->aggGrantId == (uint8_t)NODE_ID) && (g_mySlot != 0xFF);
    g_aggPosGrantRecs = g_aggPosGrantMe ? s->aggGrantRecs : 0;
    if (g_aggPosGrantRecs > AGG_POS_MAX_REC) g_aggPosGrantRecs = AGG_POS_MAX_REC;
    g_aggPosSlotStartUs = g_memberBaseUs + (uint32_t)s->nSlots * g_slotUsLive +
                          g_relayReplySlotUs + (uint32_t)tokSlots * g_tokSlotUsLive;
  }
  // v7.28.0: JOIN superframe burst windows, read straight off this beacon's own
  // slot array. v7.28.5: a birth frame publishes EVERY available slot as a join
  // window (the v7.28.0 leaf-yield is gone), so the empty-entry scan below finds
  // them all; the TK and every joiner derive the same layout from the same bytes
  // and no new wire field exists. An entry of 0 or 0xFF counts as empty under
  // either fill convention; a real member ID can be neither. The pick is a
  // deterministic salted hash of (NODE_ID, authenticated schedule seq) into
  // the empty list. The old linear expression moved every node by the same
  // amount each frame, so IDs congruent modulo nEmpty collided forever. This
  // avalanche changes the relationship on every authenticated birth round:
  // stable inside one frame, but a collision gets a different slot next time.
  g_burstSlotPick = 0xFF;
  if (g_frameType == SF_TYPE_JOIN) {
    uint8_t emptyIdx[V7_SLOTS_MAX]; uint8_t nEmpty = 0;
    for (int i = 0; i < s->nSlots && i < V7_SLOTS_MAX; i++){
      uint8_t v = s->slot[i];
      if (v == 0 || v == 0xFF) emptyIdx[nEmpty++] = (uint8_t)i;
    }
    if (nEmpty) {
      uint32_t x = (uint32_t)NODE_ID * 0x9E3779B1UL;
      x ^= (uint32_t)s->seq * 0x85EBCA6BUL;
      x ^= x >> 16; x *= 0x7FEB352DUL;
      x ^= x >> 15; x *= 0x846CA68BUL;
      x ^= x >> 16;
      g_burstSlotPick = emptyIdx[(uint8_t)(x % nEmpty)];
    }
  }
  if (g_mySlot != 0xFF && g_role == 0) {
    g_role = 1;                                  // admitted: LISTEN -> JOINED
    g_missedGrants = 0;
    g_joinAttemptCount = 0;   // v7.12.1: fresh count for next time this node ever needs to rejoin
    g_joinRadioRecoverReq = false;
    g_joinRadioRecovered = false; // v7.29.43: a later LISTEN episode may perform one recovery again
    g_joinFloodMode = false;  // v7.18.0: admitted, drop back to cheap direct join if we ever rejoin
    g_joinGiveUp    = false;  // v7.28.20: clear the give-up latch so a future rejoin starts fresh on direct
    g_joinFastFrames = 0;
    g_resignSwarmReq = false; g_resignSwarmTarget = 0; g_resignSwarmTries = 0;   // v7.28.6: absorbed by the winner, stop asking
    logRec(LOG_STATE, NODE_ID, g_role, g_tkId, 0, 0, s->seq);
  }
  // v6.2: grant-loss rejoin. A JOINED member named in no slot for three
  // consecutive schedules is not in this TK's roster: the TK changed, or the
  // roster dropped us. The old behavior waited forever as a silent member,
  // the bench-repeating "member receiving, not transmitting" (log 31). The
  // roster names every member every frame (quarantine only pads placement),
  // so three unnamed schedules is decisive. Drop to LISTEN and re-join
  // through the window like any new arrival. Missed SCHEDULES do not count,
  // only schedules heard that fail to name us.
  if (g_role == 1) {
    if (g_mySlot == 0xFF) {
      if (g_frameType != SF_TYPE_JOIN) {     // v7.20.12: a JOIN schedule names no member slots (v7.28.5 birth frame: every slot is a join window), so an unnamed JOIN schedule is not roster evidence. Count neither up nor down; unnamed DATA schedules still accumulate, so a genuine eviction is still caught.
        g_missedGrants = g_missedGrants + 1; // v7.19.1: assignment on its own line; reading the value of a volatile assignment is deprecated in C++20
        if (g_missedGrants >= 3) {           // plain volatile read, warning-free, same behavior
          g_role = 0; g_missedGrants = 0;
          g_joinFastFrames = JOIN_FAST_FRAMES;
          g_joinAttemptCount = 0;
          g_joinFloodMode = false;
          g_joinGiveUp = false;
          logRec(LOG_STATE, NODE_ID, g_role, g_tkId, 0, 0, 0xEE);
        }
      }
    } else g_missedGrants = 0;
  }
  ownedGrantObserve();
  g_relayAssignedFor = (s->relayById == (uint8_t)NODE_ID) ? s->relayForId : 0;
  g_relayAssignedFor2 = (s->relayById2 == (uint8_t)NODE_ID) ? s->relayForId2 : 0;   // v7.28.104
  volCarryDissolve(s->relayForId, s->relayById); volCarryDissolve(s->relayForId2, s->relayById2);   // v7.29.5: the keeper's grant outranks a volunteer claim. v7.29.13: the beacon's own relayById is passed in; g_relayAssignedFor cannot carry it because it is only written when THIS board is the named relayer
  // v7.29.9 PEER UPLINK: mark keeper-named gateways
  if (s->relayById)  peerNoteGranted(s->relayById);
  if (s->relayById2) peerNoteGranted(s->relayById2);
  // Confirm pending only if this beacon named that relayer (proves overhear reached keeper)
  if (g_gwPending.relayer &&
      (s->relayById == g_gwPending.relayer || s->relayById2 == g_gwPending.relayer)) {
    peerConfirmPending();
  }
#if LSM_RELAY_PLEA
  // v7.29.1: stand down the plea the moment this beacon shows us reachable, i.e. the
  // keeper's heardMask confirms it heard our own slot, OR the beacon names a relay FOR
  // us (relayForId / relayForId2 == our id). Either way a leg exists and we stop pleading.
  {
    bool namedForMe = (s->relayForId == (uint8_t)NODE_ID) || (s->relayForId2 == (uint8_t)NODE_ID);
    uint8_t heardMe = (g_mySlotPrevFrame < V7_SLOTS_MAX) ? (uint8_t)((s->heardMask[g_mySlotPrevFrame >> 3] >> (g_mySlotPrevFrame & 7)) & 1u) : 0;   // v7.29.4: read at LAST frame's slot, the one the mask is indexed by
    if (namedForMe || heardMe) { g_pleaSinceHeardFr = 0; g_pleaTries = 0; }
  }
#endif
  // v7.28.105 MEMBER RELAY-NAMING WITNESS. LOG_STATE 0xDB pair 1, 0xDC pair 2,
  // both distinct from the keeper-side 0xEB/0xAD. A member never recorded which
  // src it adopted as its relay-for, so its 0xFC data relays could not be traced
  // to the naming that caused them: the exact gap that left node04's 27 relays
  // unexplained on the v7.28.104 walk. Emit here, where g_relayAssignedFor and
  // g_relayAssignedFor2 are written from the adopted beacon, one per adopt so the
  // grader lines a member's view up with the keeper's naming by seq. Fields
  // mirror 0xEB from the receive side: e = relayForId, n = relayById, data = seq.
  // Keeper excluded, it already emits 0xEB/0xAD for the same fact.
  if (g_role != 3) {
    logRec(LOG_STATE, NODE_ID, g_role, 0xDB, (int16_t)s->relayForId, (int16_t)s->relayById, s->seq);
    if (s->relayById2 != 0) logRec(LOG_STATE, NODE_ID, g_role, 0xDC, (int16_t)s->relayForId2, (int16_t)s->relayById2, s->seq);
  }
  if (s->seq != g_relayLastSeq) { g_relayLastSeq = s->seq; g_relayFrameCtr++;
#if LSM_RELAY_PLEA
    if (g_mySlotPrevFrame != 0xFF && g_pleaSinceHeardFr < 0xFFFF) g_pleaSinceHeardFr++;   // v7.29.4: age only when we held a slot the mask could describe (a JOIN frame grants none). v7.29.1: age since last confirmed reachable; the reset above pins it near 0 while a leg exists
#endif
  }      // v7.28.104: GUARD 3 frame boundary, once per frame
  volPick(s);   // v7.28.97: pick this frame's volunteer report from slot[] against heardMask
  { uint32_t nn = (uint32_t)s->nSlots; if (nn > V7_SLOTS_MAX) nn = 0;   // v7.29.5: cache THIS frame's slot array; the NEXT beacon's heardMask is indexed by it
    memcpy(g_prevSlot, s->slot, nn); g_prevNSlots = (uint8_t)nn; }
  if (g_role == 1 && g_mySlotPrevFrame < V7_SLOTS_MAX) {   // v7.29.4: same one-frame skew as heardMe, same fix
    uint8_t mine = (s->heardMask[g_mySlotPrevFrame >> 3] >> (g_mySlotPrevFrame & 7)) & 1u;
    g_linkBits = (uint8_t)((g_linkBits << 1) | mine);
    if (g_linkWin < 8) g_linkWin++;
    if (g_linkWin >= 8) {
      uint8_t n = 0;
      for (uint8_t b = 0; b < 8; b++) if (g_linkBits & (1u << b)) n++;
      if (!g_linkDegraded && n < 4) {
        g_linkDegraded = 1;
        logRec(LOG_RF, NODE_ID, g_role, 5, (int16_t)n, 0, (uint32_t)g_linkBits);
      } else if (g_linkDegraded && n == 8) {
        g_linkDegraded = 0;
        logRec(LOG_RF, NODE_ID, g_role, 6, (int16_t)n, 0, (uint32_t)g_linkBits);
      }
    }
  }
  logRecRf(LOG_RX, s->tkId, 3, g_mySlot, s->tkEastCm, s->tkNorthCm, ((uint32_t)s->seq | ((uint32_t)s->schedHops << 24)), rssi, snr, snrRaw);   // v7.28.86: schedHops in data bits 24-31
  {
    // v7.7: register the TK itself as a peer from its own beacon, heard every
    // frame, far more reliable than waiting on a granted member slot. A TK
    // never transmits a MemberPkt while serving, so without this it was
    // invisible to peerSeen() and dropped out of every other node's peer
    // table, and therefore the dashboard roster, the whole time it held the
    // role. v7.30.9 carries the keeper's confidence and absolute seed in every
    // schedule beacon so a remote keeper remains a live dashboard dot instead
    // of aging gray merely because it no longer owns a member-data slot.
    int32_t te = s->tkEastCm, tn = s->tkNorthCm;
    int16_t ce = (int16_t)(te > 32767 ? 32767 : (te < -32768 ? -32768 : te));
    int16_t cn = (int16_t)(tn > 32767 ? 32767 : (tn < -32768 ? -32768 : tn));
    peerSeen(s->tkId, 3, ce, cn, 1, 1, (uint8_t)(s->tkConf & 0x3F), 0);
    if (s->tkLatI != 0 || s->tkLonI != 0) {
      queueSeedBle(s->tkId, s->tkLatI, s->tkLonI, s->tkAltDm);
    }
  }
  } else {
    // we ARE the TK: another TK's beacon is an election rival. Note its score
    // and, if it legitimately outranks us by the production margin, we will
    // stand down in the frame engine. Two TKs cannot coexist; the loser yields.
    if (s->tkId != (uint8_t)NODE_ID) {
      g_tkScore = (int32_t)s->tkScore;
      g_tkId_rival = s->tkId;
      g_rivalEpoch = s->sphere;
      g_rivalRssiAvg = s->tkRssiAvg;   // v6.1: rival's self-reported tie tuple
      g_rivalTie = s->tkTie;
      g_rivalSeenMs = millis();
      g_rivalDirect = true;             // v7.29.44: this keeper received the rival schedule itself
    }
  }
  // every node captures the TK's broadcast position so ANY node gatewaying to a
  // dashboard can pin the origin and plot offsets, not just the old command 07.
  g_tkEastCm = s->tkEastCm; g_tkNorthCm = s->tkNorthCm;
  // v7.29.9 PEER UPLINK: observe picker state (query only, no TX change)
  peerBestGateway();
}

void handleMember(const uint8_t* raw, int len, int16_t rssi, int8_t snr, int16_t snrRaw) {
#ifdef CRYSTAL_TOKEN
  if (!ctokTkVerify(raw, len)) return;   // v7.28.59: an enforced FAIL or an eviction drops the packet here, after the CRC gate in handleBeacon
#endif
  if (len != (int)sizeof(MemberPkt)) return;
  const MemberPkt* p = (const MemberPkt*)raw;
  if (p->src_id == 0 || p->src_id == NODE_ID) return;
  // v7.29.26: ctokTkVerify and the secure envelope have already accepted this
  // packet.  Count it as member-channel health before packet-type, route, RSSI,
  // timing, or logical-sequence gates can return.  Duplicates do not extend an
  // individual roster lease, but they do prove that the keeper receiver is live.
  if (g_role == 3) g_lastMemberRxMs = millis();
  // v7.29.17: decide logical novelty before any routing gate or packet-type
  // early return. The secure envelope has already authenticated and replay-
  // checked this physical transmission, and ctokTkVerify above has accepted
  // the origin token for data/keepalive packets. A new source sequence is
  // therefore liveness evidence even when it is too late for timing math or
  // its direct RSSI selects a relay route. Source-sequence dedup in
  // tkNoteAlive prevents a re-sealed relay copy from extending the lease.
  const bool kaBit = (p->flags_conf & 0x80) != 0;
  bool memberAlreadyProcessed = false;
  // Control packets that replace the sender's ordinary slot report participate
  // in the same logical-sequence dedup. Type 7 (swarm request) and type 8
  // (relay plea) are live traffic from a seated sender, not silence.
  if (p->type == 0 || p->type == 6 || p->type == 2 ||
      p->type == MEMBER_TYPE_SWARM_REQ || p->type == MEMBER_TYPE_RELAY_PLEA || kaBit) {
    memberAlreadyProcessed = memberSeenCheckAndNote(p->src_id, p->seq);
#if LSM_PAYLOAD_PROBE
    if (p->type == 0 || p->type == 6)
      payloadProbeRx(p->src_id, p->seq, memberAlreadyProcessed);
#endif
    if (g_role == 3 && !memberAlreadyProcessed &&
        (p->type == 0 || p->type == 6 || p->type == MEMBER_TYPE_SWARM_REQ ||
         p->type == MEMBER_TYPE_RELAY_PLEA || kaBit))
      tkNoteAlive((uint8_t)p->src_id, p->seq, p->hops);
  }
  // v7.29.46: learn an authority lease only from a logically new,
  // authenticated keepalive that names a non-self keeper. The first packet is
  // a baseline. A second bounded modular advance activates the lease; every
  // later advance refreshes it. The secure envelope and crystal-token gate
  // above provide sender authenticity and replay protection. A stopped
  // sequence expires naturally, so this cannot hold a dead keeper forever.
  if (!memberAlreadyProcessed && kaBit && (p->type == 0 || p->type == 6) &&
      p->relayRivalTk != 0 && p->relayRivalTk != (uint8_t)NODE_ID) {
    if(g_meshLease.observe(p->relayRivalTk,p->relayRivalEpoch,p->seq,
                           (uint8_t)p->src_id,millis(),TK_SUCCESSOR_MISS_FRAMES+1U)){
      logRec(LOG_STATE,NODE_ID,g_role,0xF6,(int16_t)p->relayRivalTk,
             (int16_t)__builtin_popcount(g_meshLease.witnesses),
             (uint32_t)p->seq|((uint32_t)p->relayRivalEpoch<<8));
    }
  }
  // v7.29.39: close the false warm-takeover path found in the three-board
  // split capture. Node 02 was the named successor and missed three direct
  // schedule advances while node 01 remained alive. Node 07 was still
  // receiving those schedules and transmitting authenticated keepalives with
  // the advancing schedule sequence, but the successor ignored that proof and
  // promoted. Count only a NEW type-0/type-6 keepalive from an id in the
  // current published roster, with no reported rival, and only when its seq is
  // a small modular step ahead of the last schedule we adopted. This cannot
  // anchor timing and does not change g_seqHigh; it only refreshes the warm
  // successor's failure detector. When the keeper really dies no member can
  // advance this sequence, so the three-frame takeover budget is preserved.
  if (g_role == 1 && g_successor == (uint8_t)NODE_ID && !memberAlreadyProcessed &&
      kaBit && (p->type == 0 || p->type == 6) &&
      g_pubMapValid && pubIdHas((uint8_t)p->src_id) &&
      g_tkId != 0 && g_seqHighTk == g_tkId &&
      (p->relayRivalTk == 0 || p->relayRivalTk == g_tkId)) {
    if (g_peerSeqTk != g_tkId) {
      g_peerSeqTk = g_tkId;
      g_peerSeqHigh = g_seqHigh;
      g_peerSeqAdvMs = 0;
    }
    int8_t peerStep = (int8_t)((uint8_t)p->seq - g_peerSeqHigh);
    int8_t directAhead = (int8_t)((uint8_t)p->seq - g_seqHigh);
    bool startsFromDirect = (g_peerSeqAdvMs != 0) ||
                            (directAhead > 0 && directAhead <= (int8_t)(TK_SUCCESSOR_MISS_FRAMES + 1U));
    if (peerStep > 0 && peerStep <= (int8_t)(TK_SUCCESSOR_MISS_FRAMES + 1U) && startsFromDirect) {
      g_peerSeqHigh = p->seq;
      g_peerSeqAdvMs = millis();
      if ((uint32_t)(g_peerSeqAdvMs - g_seqAdvMs) > (g_frameUs / 1000UL))
        logRec(LOG_STATE, NODE_ID, g_role, 0xF5, (int16_t)p->src_id,
               (int16_t)directAhead,
               (uint32_t)p->seq | ((uint32_t)g_seqHigh << 8));
    }
  }
  if (g_role != 3 && p->hops == 0) volNoteHeard((uint8_t)p->src_id);   // v7.28.97: first-hand sighting, the evidence a volunteer report is built from
  // v7.12.0: production direct-link RSSI floor, mirrors the schedule side.
  // A relayed copy (hops >= 1) is exempt, only the leaf's own direct
  // transmission is gated.
  if (g_role == 3 && p->hops > 0 && p->relayerId != 0) {
    int rr = tkRosterFind((uint8_t)p->src_id);
    if (rr >= 0) {
      g_lastRelayer[rr] = p->relayerId; g_lastRelayerMs[rr] = millis();
      // v7.22.0 sliding parent latch. A copy through the latched parent
      // refreshes it; a copy through anyone else is IGNORED while the latch is
      // live, which is the whole point, since that is the sample that used to
      // steal the assignment. The latch is only reconsidered once it has gone
      // RELAY_PARENT_HOLD_MS without a copy through it, meaning that path has
      // actually stopped working.
      uint32_t nowMs = millis();
      bool stale = (g_relayParent[rr] == 0) ||
                   ((uint32_t)(nowMs - g_relayParentMs[rr]) >= relayParentHoldMs());
      if (stale) g_relayParent[rr] = p->relayerId;
      if (g_relayParent[rr] == p->relayerId) g_relayParentMs[rr] = nowMs;
    }
  }
  // v7.29.2: heard-accum hoisted here from below the plea handler. A hop-0 packet the keeper
  // hears directly, INCLUDING a direct plea, marks the sender's slot in the keeper heardMask
  // before the plea handler's return skips the rest of the function. A stranded board is
  // unheard by definition, but if its direct link returns a plea now proves life. OUTSIDE the
  // ifdef on purpose, so a build with LSM_RELAY_PLEA off still marks heard for normal packets.
  if (g_role == 3 && p->hops == 0) {
    int ri = tkRosterFind((uint8_t)p->src_id);
    if (ri >= 0 && g_slotOf[ri] < V7_SLOTS_MAX) {
      uint8_t sp = g_slotOf[ri];
      g_heardAccum[sp >> 3] |= (uint8_t)(1u << (sp & 7));
    }
  }
#if LSM_RELAY_PLEA
  // v7.29.1: RELAY PLEA. A seated board the keeper cannot hear directly, and that no
  // beacon names a relay FOR, pleads for a leg. The keeper-side learn block just above
  // already latched relayerId as this pleader's parent when a RELAYED plea (hops>0)
  // arrives from a rostered source, exactly as it does for a relayed data copy, so the
  // keeper needs no new naming code: the next beacon names the leg. Two roles act here:
  //   keeper (role 3), relayed copy: witness only, the leg is already learned above.
  //   member (role 1), first-hand copy (hops==0): forward it ONCE toward the keeper,
  //   stamping our own id as relayerId. Hop limit 1 is structural: this branch gates on
  //   hops==0, so a hops==1 relayed copy is never re-forwarded (no ping-pong). Dedupe on
  //   (src,seq) so we forward a given plea at most once even if we hear the original twice.
  if (p->type == MEMBER_TYPE_RELAY_PLEA) {
    if (g_role == 3 && p->hops > 0) {
      // v7.29.3: split the keeper witness on roster membership. The learn block above latches
      // the parent only when tkRosterFind(src) >= 0, so a plea from a board the keeper has
      // already evicted (90 s AIR_TIMEOUT_MS with no direct and no relayed copy, which is the
      // stranded case itself) forwards fine and used to log 0xD9 while naming NO leg: a plea
      // into the void that read as success. 0xD9 now means the leg WAS learned. 0xD7 means the
      // pleader is not on the roster and nothing was latched. Log only, NOT a roster insert: a
      // relayed plea bypasses the admission gate, so inserting from it would be a spoofing vector.
      if (tkRosterFind((uint8_t)p->src_id) >= 0)
        logRec(LOG_STATE, NODE_ID, g_role, 0xD9, (int16_t)p->src_id, (int16_t)p->relayerId, (uint32_t)p->seq);   // aux 0xD9 = keeper witnessed a relayed plea, pleader rostered, leg learned above; e = pleader, n = forwarder
      else
        logRec(LOG_STATE, NODE_ID, g_role, 0xD7, (int16_t)p->src_id, (int16_t)p->relayerId, (uint32_t)p->seq);   // aux 0xD7 = relayed plea from a pleader NOT on the roster: no parent latched, no leg named; e = pleader, n = forwarder
    } else if (g_role == 1 && p->hops == 0 && g_anchorHops != 255) {
      if (!pleaSeenHas((uint8_t)p->src_id, p->seq)) {
        pleaSeenAdd((uint8_t)p->src_id, p->seq);
        pleaForward(p);
        logRec(LOG_STATE, NODE_ID, g_role, 0xDA, (int16_t)p->src_id, (int16_t)NODE_ID, (uint32_t)p->seq);      // aux 0xDA = forwarded a plea once; e = pleader, n = us (the forwarder)
      }
    }
    return;   // a plea is not member data, does not gate on RSSI, and is not join demand
  }
#endif
  // v7.28.97: VOLUNTEER RELAY REPORT, keeper side. A direct report names a member
  // this sender can reach that we cannot. Seed the parent latch from it so the very
  // next pass of the naming loop in tkBuildAndSend has a parent to name and stops
  // skipping this member at "if (par == 0) continue;". A latch that is still LIVE is
  // never overwritten, so a working path is not stolen and two volunteers naming the
  // same orphan cannot oscillate it: first report wins, the sliding latch owns it after.
  if (g_role == 3 && p->hops == 0 && p->volunteerFor != 0) {
    uint8_t orph = p->volunteerFor;
    if (orph != (uint8_t)NODE_ID && orph != (uint8_t)p->src_id) {
      int oi = tkRosterFind(orph);
      if (oi >= 0) {
        uint32_t volNowMs = millis();
        bool latchLive = (g_relayParent[oi] != 0) &&
                         ((uint32_t)(volNowMs - g_relayParentMs[oi]) < relayParentHoldMs());
        // v7.28.102 item 8: adopt side of the asymmetric hold. g_relayParentMs refreshes
        // on every copy through the parent, so its age IS the parent's silence.
        bool parentQuiet = (g_relayParent[oi] != 0) && (g_relayParent[oi] != (uint8_t)p->src_id) &&
                           ((uint32_t)(volNowMs - g_relayParentMs[oi]) >= (uint32_t)PARENT_SWITCH_SILENT_FRAMES * (g_frameUs / 1000UL));
        if (!latchLive || parentQuiet) {
          g_relayParent[oi]   = (uint8_t)p->src_id;
          g_relayParentMs[oi] = volNowMs;
          logRec(LOG_STATE, NODE_ID, g_role, 0xEC, (int16_t)orph, (int16_t)p->src_id, (uint32_t)p->seq);   // v7.28.97: aux 0xEC = volunteer report accepted, e = orphan, n = volunteer
        }
      }
    }
  }
  if (p->hops == 0 && directRssiGateData(p->src_id, rssi)) return;
  electNoteRssi(rssi);
  // v7.10.8: count overheard join requests from anyone, on every board
  // regardless of role, feeds the adaptive backoff in joinModEffective().
  if (p->type == 2) demandNote((uint8_t)p->src_id);   // v7.28.2: distinct joiners
  // v7.28.5: explicit funnel swarm-join request. A funnel with buffered distant
  // joiners it cannot admit through the modulus sends MemberPkt type 7; conf64
  // carries how many windows it wants. The TK arms a birth frame at the flip logic
  // (subject to the one-on-one-off cooldown) and also counts it as demand so a lone
  // board's pressure still registers in joinModEffective().
  if (p->type == MEMBER_TYPE_SWARM_REQ) {
    demandNote((uint8_t)p->src_id);
    if (g_role == 3) {
      uint8_t reqN = (uint8_t)(p->flags_conf & 0x3F);   // conf64 = requested window count
      g_swarmReqPending = true;
      if (reqN > g_swarmReqCount) g_swarmReqCount = reqN;   // hold the largest outstanding ask until it is served
      // v7.28.7 Part B: a DIRECT swarm request (hops==0, heard first-hand from a
      // board in earshot) is a resigned TK asking to be re-absorbed. Admit it on
      // the spot, exactly as the type-2 direct-join gate does, so it does not have
      // to send a second type-2 and race the birth window it just armed. A relayed
      // request (hops>0) is a funnel speaking for distant joiners this TK cannot
      // hear, so we only arm the birth for it, unchanged. tkOnJoinReq de-dups an
      // id already on the roster (a funnel's own request), so that is a no-op.
      if (p->hops == 0) tkOnJoinReq((uint8_t)p->src_id);
      // v7.28.102 CHUNK 4: parallel local admission. volunteerFor on a type-7
      // names a joiner this sender claims to have physically heard first-hand.
      // tkOnJoinReq runs every existing gate (allow-list, SPHERE_CAP, hard-full
      // latch) exactly as it does for a magic-B aggregate or a direct type-2;
      // this is a new NAMING path, not a new admission door. relayParent is set
      // to p->src_id, the sender, the correct immediate upstream neighbour for
      // future exclusive-grant relay. aux 0xA7 marks a naming that arrived via
      // this field, distinct from 0xB0 for a magic-B aggregate.
      // CORRECTED before this left the working tree: the first draft of this
      // comment claimed the sender was "a seated, roster-checked sender by the
      // time we are inside this block." That was false. ctokTkVerify, which
      // gates handleMember at entry, explicitly skips every type other than 0
      // and 6 ("swarm asks are gated by id at admission, not by tag"), so
      // nothing upstream of this point checks whether p->src_id is a real,
      // currently-seated node at all. Without an explicit check here, any
      // board that can construct a valid CRC on a type-7, seated or not, ever
      // admitted or not, could name an arbitrary stranger and have it admitted.
      // The tkRosterFind(src) check below is that missing gate: it is the
      // entire chain-of-custody property, not a redundant belt-and-suspenders
      // add. Without it, "the TK already trusts the claimant" was aspirational
      // text, not an enforced property.
      // SCOPE, STILL STATED PLAINLY: even with this fixed, the check proves the
      // claimant IS a currently-seated, trusted node. It does not prove that
      // node actually heard the joiner. A seated node could still name a
      // joiner it never heard. That is the accepted v1 limit.
      // v7.28.103 CUT 2: the hop-0 requirement is dropped here so a climbed
      // admit (real hops, per Cut 2's memberSendSwarmReq change) can be honored,
      // not just a direct one. Part B's own self-admit two lines above is
      // untouched and still requires hops==0. The v7.28.102 first draft of this
      // block tried to bound depth with p->hops <= g_anchorHops + 1, which does
      // not work: g_anchorHops is a single scalar per board, and evaluated here
      // it reads THIS BOARD's (the keeper's) own depth, always 0 the moment it
      // wins election, never the claimant's. That comparison silently rejected
      // every admit that climbed past one hop, defeating the entire purpose of
      // admit-relay. There is no per-claimant depth stored anywhere the keeper
      // could read instead, so the bound here is RELAY_MAX_HOPS, the same
      // ceiling aggReaggregate already trusts on the other admission path, not
      // a re-derived expectation.
      int srcIdx = tkRosterFind((uint8_t)p->src_id);
      if (p->volunteerFor != 0 && srcIdx >= 0 &&
          p->volunteerFor != (uint8_t)NODE_ID && p->volunteerFor != (uint8_t)p->src_id &&
          p->hops < RELAY_MAX_HOPS) {
        tkOnJoinReq(p->volunteerFor);
        int oi = tkRosterFind(p->volunteerFor);
        if (oi >= 0) {
          g_relayParent[oi]   = (uint8_t)p->src_id;
          g_relayParentMs[oi] = millis();
          logRec(LOG_STATE, NODE_ID, g_role, 0xEC, (int16_t)p->volunteerFor, (int16_t)p->src_id, 0xA7000000UL);
        }
      }
    }
  }
  // v7.19.0 brick2: a non-TK node buffers the join record for aggregated forward.
  // The TK does not buffer, it admits directly below. Token = attToken already on wire.
  // v7.28.102 CHUNK 4: exclusive grant does not forward a type 2 today (see the
  // v7.28.101 correction at the dispatch gate above), so every type-2 this board
  // ever receives already arrives at hops==0 in practice. Made explicit rather
  // than relied upon, because this is the ONE call site allowed to set g_admitId:
  // it is the only place aggBufAdd is ever called from a receipt that is
  // guaranteed first-hand, and the whole safety property of the admit field
  // (a hearer may only name a joiner it physically heard) rests on that guarantee
  // holding here and nowhere else.
  if (p->type == 2 && p->hops == 0 && g_role != 3) aggBufAdd((uint8_t)p->src_id, p->attToken, g_frame, true);   // v7.28.103: the one genuinely first-hand call site
  // v7.11.10: dedup so a flood-relayed duplicate of the same logical report
  // is never processed twice, position or timing sample either one. Keyed
  // on (src_id, seq) only, blind to hop count on purpose: a relayed copy
  // and the original are the same report and are only ever acted on once.
  // This is separate from memberFloodNote() below, which still needs to see
  // every copy regardless of dedup outcome, since a "duplicate" for
  // processing purposes can still carry a better hop count worth relaying.
  // v7.18.0: type 2 (join request) joins 0 and 6 as a FLOODABLE type so a
  // multi-hop joiner the TK cannot hear directly is carried up the relay
  // tree. memberFloodNote dedups on (src_id, seq) and bumps hops; it does
  // not gate on type, so a relayed type-2 MemberPkt relays like any report.
  if (g_pubMapValid && p->type == 2 && !pubIdHas((uint8_t)p->src_id)) relayNeedNote(2);   // v7.28.17: only once a map has been adopted   // v7.28.16: a board asking through the tree that the keeper has not seated: downstream evidence
  if (kaBit && p->src_id > 0 && p->src_id < 32) g_kaSeenMs[p->src_id] = millis();   // v7.28.60: quorum witness, a slot keepalive means its sender anchored within SLOT_MUTE_FRAMES
  // v7.29.20: a seated funnel's type-7 admission request must traverse its
  // keeper-named parent path just like its ordinary report. The receive
  // dispatcher accepted type 7, but this relay gate omitted it, so requests
  // from depth >= 1 stopped at the first intermediate board.
  if (p->type == 0 || p->type == 6 || p->type == 2 || p->type == MEMBER_TYPE_SWARM_REQ || p->type == MEMBER_TYPE_AGG_DEMAND || kaBit) {
    memberFloodNote(p, raw, len, rssi);
    // v7.13.0: observed network depth. MemberPkt.hops is bumped by exactly 1
    // per relay leg and is never silently understated, so the largest value
    // the TK sees in a frame IS the depth of the deepest node reporting in.
    // v7.28.11: the TK now uses this for relay-tier sizing (observed depth + 1, below).
    if (p->hops > g_obsDepth) g_obsDepth = p->hops;
    if (p->hops > g_meshDeepHops) g_meshDeepHops = p->hops;   // v7.28.101: own high-water mark, cleared by the LOG_MESH emit, not by the frame
    if (p->hops > g_obsDepthWin) g_obsDepthWin = p->hops;   // v7.28.98: window max, survives a quiet frame
  }
  if (p->type == MEMBER_TYPE_AGG_DEMAND) {
    if (g_role == 3) {
      uint8_t id = (uint8_t)p->src_id;
      uint8_t ask = (uint8_t)(p->flags_conf & 0x3F);
      if (ask > AGG_POS_MAX_REC) ask = AGG_POS_MAX_REC;
      if (tkRosterFind(id) >= 0 && ask) {
        g_aggDemand[id] = ask;
        g_aggDemandDepth[id] = p->hops;
        g_aggDemandMs[id] = millis();
        logRec(LOG_STATE, id, g_role, 0xA2, ask, p->hops, p->seq);
      }
    }
    return;
  }
  // v7.29.5 KEEPER GRACE ARRIVAL. A copy carried by a volunteer (MPKT_GRACE, hops >= 1)
  // is the only evidence a stranded node exists at all, so it is acted on, not
  // filtered: a fallen sender is re-seated through tkOnJoinReq, the same seat step the
  // aggregate magic B uses, and the relayer is named its parent under the existing
  // latch rule (a live latch is not stolen; a quiet one is replaced). Once seated the
  // normal line below raises its depth and the normal eviction timer releases it, so
  // no bespoke hold is created. This block sits ABOVE the depth raise on purpose.
  if (g_role == 3 && p->hops >= 1 && (p->graceFlags & MPKT_GRACE) && p->src_id > 0 && p->src_id < 256) {
    uint8_t gsrc = (uint8_t)p->src_id, gvol = p->relayerId;
    bool reseated = false;
    int gi = tkRosterFind(gsrc);
    if (gi < 0 && gsrc != (uint8_t)NODE_ID) { tkOnJoinReq(gsrc); gi = tkRosterFind(gsrc); reseated = (gi >= 0); }
    if (gi >= 0 && gvol != 0 && gvol != gsrc && gvol != (uint8_t)NODE_ID) {
      uint32_t gNowMs = millis();
      bool gLive  = (g_relayParent[gi] != 0) && ((uint32_t)(gNowMs - g_relayParentMs[gi]) < relayParentHoldMs());
      bool gQuiet = (g_relayParent[gi] != 0) && (g_relayParent[gi] != gvol) &&
                    ((uint32_t)(gNowMs - g_relayParentMs[gi]) >= (uint32_t)PARENT_SWITCH_SILENT_FRAMES * (g_frameUs / 1000UL));
      if (!gLive || gQuiet || reseated) { g_relayParent[gi] = gvol; g_relayParentMs[gi] = gNowMs; }
    }
    logRec(LOG_STATE, NODE_ID, g_role, 0xD2, (int16_t)gsrc, (int16_t)gvol, (uint32_t)p->seq | ((uint32_t)(reseated ? 1 : 0) << 24));   // v7.29.5: grace arrival, data hi byte 1 = re-seated
  }
  if (g_role == 3) {
    { int _sdi = tkRosterFind((uint8_t)p->src_id); if (_sdi >= 0 && p->hops > g_seatDepth[_sdi]) g_seatDepth[_sdi] = p->hops; }   // v7.28.105: seated-depth high-water feeds the tier shrink floor
  int64_t rxUs = g_loraIrqUs;
  { int64_t nowUs = esp_timer_get_time();
    if (rxUs <= 0 || nowUs - rxUs > 500000) rxUs = nowUs; }
  uint8_t id = (uint8_t)p->src_id;
  // v7.11.0 hidden-node dual-TK path, hardened by v7.29.44. A single bridge
  // report proves that one member heard another keeper; it does NOT prove that
  // the replacement schedule reaches this keeper's roster. The 2026-10-06 walk
  // showed exactly that failure: keeper 01 yielded on node 05's lone report of
  // keeper 04, while 04 reached none of 01's first ring. Require distinct
  // roster witnesses for the same (keeper, epoch) inside one bounded window.
  // The threshold is a roster majority, clamped 2..4 so a large sphere can
  // still merge. Direct rival schedules bypass this path in handleSched.
  if (g_role == 3 && p->relayRivalTk != 0 && p->relayRivalTk != (uint8_t)NODE_ID) {
    logRec(LOG_VOTE, p->relayRivalTk, 2, id, 0, 0, g_frame);  // aux 2 = rival TK learned via member relay
    uint32_t voteNow = millis();
    bool sameVote = g_hiddenRivalTk == p->relayRivalTk &&
                    g_hiddenRivalEpoch == p->relayRivalEpoch &&
                    g_hiddenRivalLastMs != 0 &&
                    (uint32_t)(voteNow - g_hiddenRivalLastMs) <= HIDDEN_RIVAL_CONFIRM_MS;
    if (!sameVote) {
      g_hiddenRivalTk = p->relayRivalTk;
      g_hiddenRivalEpoch = p->relayRivalEpoch;
      g_hiddenRivalWitnessMask = 0;
      g_hiddenRivalFirstMs = voteNow;
    }
    g_hiddenRivalLastMs = voteNow;
    if (id > 0 && id < 32) g_hiddenRivalWitnessMask |= (uint32_t)1U << id;
    uint8_t witnesses = (uint8_t)__builtin_popcount(g_hiddenRivalWitnessMask);
    uint8_t needed = (uint8_t)(g_rosterN / 2U + 1U);
    if (needed < HIDDEN_RIVAL_MIN_WITNESSES) needed = HIDDEN_RIVAL_MIN_WITNESSES;
    if (needed > HIDDEN_RIVAL_MAX_WITNESSES) needed = HIDDEN_RIVAL_MAX_WITNESSES;
    if (witnesses >= needed) {
      g_tkId_rival = p->relayRivalTk;
      g_rivalEpoch = p->relayRivalEpoch;
      g_rivalRssiAvg = p->relayRivalRssiAvg;
      g_rivalTie = p->relayRivalTie;
      g_tkScore = p->relayRivalScore;
      g_rivalSeenMs = voteNow;
      g_rivalDirect = false;
      logRec(LOG_VOTE, p->relayRivalTk, 5, id, (int16_t)witnesses,
             (int16_t)needed, g_frame); // role 5 = hidden rival confirmed by distinct-member quorum
    }
  }
  if (p->type == 2 && p->hops == 0) {            // join request heard DIRECTLY: this TK grants it
    // v7.18.0: hops>0 means this is a RELAYED join we are only carrying
    // toward the command post; forwarding happened above via the flood
    // gate. We must NOT admit it into our own roster, or a relayer (worst
    // case a rival TK, exactly board 08 on the range log) would hijack a
    // joiner meant for a TK deeper in. Admission stays a one-hop decision
    // at whatever TK the joiner can actually reach.
    tkOnJoinReq(id);
  } else if ((p->type == 0 || p->type == 6 || kaBit) && !memberAlreadyProcessed) {     // v7.28.33: the KEEPALIVE bit admits the packet to the timing and liveness path whatever its type. v7.11.6: a present ping feeds the same timing measurement as real data; v7.11.10: skip if this exact report was already processed via another path
    // measured propagation: the member packet's RxDone ISR is at the END of its
    // airtime; subtract it so the offset is measured to the packet START, which
    // is what the granted slot start means. What remains is propagation plus
    // processing, the real delay we want, not the airtimes.
    // v7.20.20: the airtime subtracted here is the MEMBER packet's, and it was
    // AIRTIME8_US, the 8 byte payload figure of 36000 us, while a 22 byte
    // MemberPkt costs 56576 us on this PHY. The radio itself has been reporting
    // that number at every boot through the aux 3 witness, deviation logged as
    // exactly 20576 us on boards 04, 05 and 06 with no variance. So every
    // reconstructed arrival instant was 20576 us LATE, and because this feeds
    // tkOnData the whole constant landed in the profile mean: node 04 measured a
    // 35711 us median mean where 20576 of it was this bookkeeping error. Now it
    // reads the runtime witness, so a PHY change carries itself and no second
    // retune is needed. g_memberAirUsLive is the fallback for the window before the
    // radio has been programmed, which is the same physical quantity and the
    // same value (SR-8): AIRTIME8_US and g_memberAirUsLive were one quantity under
    // two names and only one of them was right.
    uint32_t memAirUs = g_airWitnessUs ? g_airWitnessUs : g_memberAirUsLive;
    uint64_t startUs = (uint64_t)rxUs > (uint64_t)memAirUs ? (uint64_t)rxUs - (uint64_t)memAirUs : (uint64_t)rxUs;
    // v7.10.2: same-frame check replaces the modulo fold. The TK and the
    // member each independently adopt g_frameUs from the schedule, but the
    // frame length itself changes as the roster grows or shrinks, and it can
    // change between the instant the TK sets its own g_frameUs and the instant
    // a member catches up on a fresh beacon. Modulo-ing each side against its
    // OWN possibly different frame length produced wildly different offsets
    // right at the wrap boundary, reballooning the profile straight back to
    // the 32767 clamp, this time through the departure token math rather than
    // the old anchor math, exactly while new members were joining and the
    // frame was actively resizing (bench 2026-07-08, node 06 flash log, mean
    // pinned 32767 on nearly every DRIFT record). Fix: only trust this
    // measurement when the packet answers THIS exact frame, p->seq equal to
    // the TK's own current frame counter. In that case both sides anchored on
    // the identical beacon instant, so the raw, un-modulo'd offset is
    // unambiguous on both ends and no fold is needed. A reply to a stale frame
    // is skipped for profile purposes rather than risked through a cross-frame
    // modulo reconstruction.
    // v7.29.16: authenticated + deduplicated traffic refreshes the eviction
    // timer even when relay latency makes it stale for timing calibration.
    // The same-frame gate below continues to protect all profile math.
    bool sameFrame = (p->seq == (uint8_t)g_frame);
    if (sameFrame){
      uint32_t offUs = (uint32_t)((uint64_t)(startUs - g_frameAnchorUs));
      // v12: the member states its own departure offset in the shared baseline.
      // delay = arrival offset - departure offset, both raw now, safe because
      // sameFrame already guarantees a shared anchor instant.
      // v7.21.0: reads depAttest16, NOT attToken. This one comparison is the
      // whole defect. From v7.20.11 it compared against attToken, which the
      // token layer overwrote with the pairwise HMAC tag the moment a member
      // enrolled, so depOk was false forever afterwards and every member became
      // permanently unmeasurable. The comment that used to sit here claimed a
      // failed tag falls back to slot inference. IT DOES NOT AND NEVER DID: the
      // else branch below decays the profile, exactly as the v7.11.2 comment
      // inside tkOnData states. That wrong sentence is the reason this read as
      // benign for thirteen versions, so it is corrected and not merely deleted.
      uint16_t depTok = departAttest(p->src_id, p->seq, p->departDevUs);
      bool depOk = (depTok == p->depAttest16);
      uint32_t depOffUs = 0xFFFFFFFFu;
      if (depOk) {
        int ri = tkRosterFind(id);
        if (ri >= 0 && g_slotOf[ri] != 0xFF) {
          int64_t abs64 = (int64_t)(g_memberBaseUs + (uint32_t)g_slotOf[ri] * g_slotUsLive)
                        + (int64_t)p->departDevUs;
          if (abs64 >= 0) depOffUs = (uint32_t)abs64;
        } else if (ri >= 0) {
          // v7.20.24: in the roster but the packer granted it no slot this
          // frame, so there is no baseline to reconstruct a departure against.
          // Silent before this patch, and a live suspect given the measured
          // slot churn of 2026-08-26.
          skipWitness(4, (uint8_t)id, offUs, 0xFFFFFFFFu);
        }
      } else {
        // v7.20.24: the departure stamp failed its integrity tag. Silent before
        // this patch and indistinguishable in the log from the no slot case.
        skipWitness(1, (uint8_t)id, offUs, 0xFFFFFFFFu);
      }
      tkOnData(id, offUs, depOffUs, p->hops, p->departDevUs);
    } else {
      // v7.11.1: this packet answered a different frame than ours. The
      // measurement is still skipped, same-frame safety unchanged, but the
      // profile now decays a step toward the conservative default instead
      // of sitting frozen at whatever it last validly measured. Same root
      // cause as v7.10.2, a different door this time (dual-TK frame
      // disagreement instead of roster resize), same missing piece: nothing
      // ever pulled a stale profile back down before now.
      int pi = tkRosterFind(id);
      if (pi >= 0) profileDecayStep(&g_prof[pi]);
    }
  }
  // v7.2: SEED parts (3=lat, 4=lon, 5=alt) are a rare, best-effort burst,
  // never part of the deterministic slot timing measurement above, on
  // purpose. They just get folded into the peer's seed assembly below,
  // same as any other node hears them.
  }  // end TK-only measurement
  // EVERY node tracks peers: for centrality scoring and so ANY node can gateway
  // the full roster to a dashboard, not just the TK. v7.11.10: gated on the
  // same dedup as the TK-side measurement above, a relayed duplicate must
  // not double-update a peer's position either.
  if (p->type == 0 && !memberAlreadyProcessed && (p->flags_conf & 0x3F) == 0) {
    peerTouch((uint8_t)p->src_id,true);   // v7.28.68: a type 0 with conf 0 is liveness only, never fused
  } else if (p->type == 0 && !memberAlreadyProcessed) {
    peerSeen((uint8_t)p->src_id, 1, (int16_t)(p->x_dm*10), (int16_t)(p->y_dm*10), 1, 1, (uint8_t)(p->flags_conf & 0x3F), 0);
    peerSetAbs((uint8_t)p->src_id, p->latI, p->lonI);   // v7.28.70-absposbranch: absolute alongside the offset above, offset path untouched
    if (p->latI != 0 || p->lonI != 0) {   // v7.28.70-absposbranch: witness received absolute, sentinel-gated
      logRec(LOG_RXABS, (uint8_t)p->src_id, g_role, (uint8_t)(p->flags_conf & 0x3F),
             (int16_t)(p->latI/100000), (int16_t)(p->lonI/100000),
             ((uint32_t)(p->flags_conf & 0x3F) << 24) | ((uint32_t)(((p->lonI/1000)%100)&0xFF) << 16) | ((uint32_t)(((p->latI/1000)%100)&0xFF) << 8));
    }
  } else if (p->type == 6 && !memberAlreadyProcessed) {
    peerTouch((uint8_t)p->src_id,true);   // v7.11.6: liveness only, a present ping carries no real position
  } else if (p->type == 3 || p->type == 4 || p->type == 5) {
    // v7.2: absolute seed part, overheard from a peer. peerSeedPart only
    // folds this in if that id already has a live peer slot (from type 0
    // traffic); a seed with no matching peer entry is simply dropped, there
    // is nothing to attach it to yet.
    peerSeedPart((uint8_t)p->src_id, p->type, &raw[offsetof(MemberPkt, latI)]);   // v7.28.70-absposbranch: was raw[4] (x_dm); follows memberSendSeedPart onto latI
  }
  logRecRf(LOG_RX, (uint8_t)p->src_id, p->type, p->flags_conf,   // v7.28.33: aux = flags_conf (bit 7 keepalive, bit 6 relayed, low 6 conf); seq stays in data
           (int16_t)(p->x_dm*10), (int16_t)(p->y_dm*10), ((uint32_t)p->seq | ((uint32_t)p->hops << 24)), rssi, snr, snrRaw);   // v7.28.86: hops in data bits 24-31 for relay-depth telemetry
}


// ================= CRYSTAL TOKEN, sub-GHz member-to-TK gate (v0.1, UNVERIFIED) =================
// Ported from the 2.4 GHz cross-node rejection test onto the real sub-GHz fleet
// (v7.12.33 V4FIX base). Model: each token node learns its own crystal baseline,
// learns the current TK's baseline (heard as a fingerprint announce, or fetched
// with an on-demand request), and mints a pairwise tag bound to (self, current
// TK) that rides the 4-byte widened attToken slot. The TK validates every member
// packet against its own crystal. A blind node (no baseline, no token code) stays
// a full mesh member but its data never carries a valid tag, so the TK logs it
// REJECT. This hook OBSERVES and LOGS, it does NOT drop packets, so blind nodes
// remain visible in the roster exactly as the test intends. Control packets are
// best-effort and sent at a low rate outside the tight timing paths; treat any
// slot interaction as a known rough edge for v0.1. Nothing here is confirmed
// until it runs on the bench.
// ============================================================================
// v7.28.59 KAIROSHIELD IDENTITY GATE. Per Stuart 2026-09-13.
//
// Three separate things, kept separate on purpose:
//   identity   is proved by the crystal (pair_token, the fingerprint and the tag);
//   membership is the baked allow list of node ids below;
//   removal    is a signed revocation record, verified against the public key
//              baked below, held in NVS as fleet state, and gossiped over the air
//              through the tail token slot so one injection reaches every board.
//
// The fingerprint values are NOT baked. Baking them would turn a physical
// identity into a shared secret in flash and would go stale with temperature.
// Only the id list and the verifying key are constants.
//
// The signing key never exists on any board. A revocation is produced on an
// offline box (tools/ks-revoke-sign.py) and injected on ANY board over the
// serial port ('R' + 146 hex chars). That board verifies it, stores it, evicts
// the id if it holds it, and repeats it from its tail slot; every board that
// hears it does the same. A board that never hears it still trusts the revoked
// id until it does; that is the honest limit and why the epoch exists.
//
// BENCH KEY. The private half of the key below was generated on the tool
// machine on 2026-09-13, NOT on an offline signing box. It is for the bench
// only. Generate a fresh pair offline and replace these 32 bytes before any
// deployment. The public half is safe to read and to share.
// ============================================================================
#include <Preferences.h>
#include <sodium.h>

static const uint8_t KS_REVOKE_PUBKEY[32] = {
  0xf8,0x7e,0x6e,0xaa,0x66,0x03,0x3e,0xd2,0x48,0xac,0x46,0x2f,0xe5,0x10,0x19,0x0a,
  0x9a,0x97,0x56,0x35,0xc1,0x9c,0xbb,0x1f,0xd3,0xaa,0xf2,0xe7,0x3b,0xac,0x4e,0xdc
};
#ifndef KS_NODE_ALLOW_LIST
#define KS_NODE_ALLOW_LIST 1,2,3,4,5,6,7,8,9,10,11,12,15,16   // the fourteen boards on the bench; override with -D KS_NODE_ALLOW_LIST=...
#endif
static const uint8_t  KS_NODE_ALLOW[]   = { KS_NODE_ALLOW_LIST };
static const uint8_t  KS_REVOKE_VER     = 1;
static const uint8_t  KS_DENY_MAX       = 16;
static const uint8_t  KS_GOSSIP_TK      = 3;    // repeats of a new record from the keeper's own tail slot
static const uint8_t  KS_GOSSIP_MEMBER  = 2;    // repeats from a member's granted tail slots

struct __attribute__((packed)) KsRevokeWire {
  uint8_t  magic;      // 'R'
  uint8_t  ver;        // KS_REVOKE_VER
  uint8_t  nodeId;     // the board being removed
  uint8_t  rsv;        // 0
  uint32_t epoch;      // little-endian fleet counter, advanced on the signing box, never reused
  uint8_t  sig[64];    // Ed25519 over the 12 signed bytes: 'K' 'S' 'R' 'E' 'V' ver nodeId rsv epoch(LE32)
  uint8_t  hops;       // v7.28.59 chunk 2: 0 from the origin, 1 from the frame's named relayer. Outside the signature, a relay may rewrite it.
  uint8_t  relayerId;  // 0 from the origin, the relayer's id on a relayed copy
  uint8_t  crc;        // CRC-8 over all prior bytes, recomputed by the relay
};
static_assert(sizeof(KsRevokeWire) == 75, "KsRevokeWire size moved: TOK_WIRE_MAX_B and g_tokSlotUsLive must move with it");
static_assert(sizeof(KsRevokeWire) == TOK_WIRE_MAX_B, "TOK_WIRE_MAX_B must equal the revocation record size, it sizes the tail slot");

struct __attribute__((packed)) KsDenyEnt { uint8_t id; uint8_t ver; uint8_t rsv0; uint8_t rsv1; uint32_t epoch; uint8_t sig[64]; };   // 72 bytes, sig kept so the record can be repeated verbatim
static KsDenyEnt g_ksDeny[KS_DENY_MAX];
static uint8_t   g_ksDenyN       = 0;
static uint32_t  g_ksEpoch       = 0;     // highest epoch held
static int8_t    g_ksGossipIdx   = -1;    // deny entry being repeated on the air, -1 none
static uint8_t   g_ksGossipLeft  = 0;     // repeats remaining
static bool      g_ksSodiumOk    = false;
static uint32_t  g_ksRevStored   = 0, g_ksRevRejected = 0;
// token counters live here, always compiled, so the status print and the
// side-channel byte build with or without CRYSTAL_TOKEN
static uint32_t  g_ctGrants = 0, g_ctSilentTotal = 0, g_ctDropped = 0, g_ctEvicted = 0;
static bool      g_ctWantAnnounce = false;   // member: baseline just became available, ask the keeper for a refresh slot

int tkRosterFind(uint8_t id);   // defined with the TK arbiter below

static uint8_t aggFreshPeerCount(){
  uint8_t n = 0;
  uint32_t now = millis();
  for (int i = 0; i < PEER_TABLE_SIZE && n < AGG_POS_MAX_REC; i++) {
    if (!g_peers[i].id || g_peers[i].id == (uint8_t)NODE_ID || g_peers[i].id == g_tkId) continue;
    if ((uint32_t)(now - g_peers[i].lastMs) > 2500UL) continue;
    // Hearing an already reachable peer is not relay demand. Use the keeper's
    // published previous-slot heard evidence, the same orphan map used by the
    // existing volunteer path. Do not spend control slots requesting duplicate
    // aggregates for every nearby member on a small, fully connected sphere.
    if(!g_pubMapValid||!volMapGet(g_volOrphanMap,g_peers[i].id))continue;
    n++;
  }
  return n;
}

// Variable-length compact packet; the CRC follows the last live record rather
// than the maximum-sized backing buffer.
static void aggPosTailTx(uint32_t offUs){
  if (g_role != 1 || !g_aggPosGrantMe || !g_aggPosGrantRecs) return;
  if (g_frameAnchorUs == g_aggPosLastTxAnchor) return;
  if (offUs < g_aggPosSlotStartUs) return;
  if(telemetryAggregateTx(offUs,false))return;
  g_aggPosLastTxAnchor = g_frameAnchorUs;
  g_aggPosGrantMe = false;
  if (offUs >= g_aggPosSlotStartUs + AGG_POS_SLOT_US) {
    logRec(LOG_STATE, NODE_ID, g_role, 0xA4, (int16_t)((offUs-g_aggPosSlotStartUs)/1000UL), 0, g_curSchedSeq);
    return;
  }
  uint8_t raw[AGG_POS_WIRE_MAX_B];
  raw[0] = AGG_POS_MAGIC; raw[1] = WIRE_VER; raw[2] = (uint8_t)NODE_ID;
  raw[3] = g_curSchedSeq; raw[4] = 0; raw[5] = 0;
  uint8_t count = 0; uint32_t now = millis(); int o = 6;
  for (int i = 0; i < PEER_TABLE_SIZE && count < g_aggPosGrantRecs && count < AGG_POS_MAX_REC; i++) {
    Peer *p = &g_peers[i];
    if (!p->id || p->id == (uint8_t)NODE_ID || p->id == g_tkId) continue;
    uint32_t age = now - p->lastMs;
    if (age > 2500UL) continue;
    raw[o++] = p->id;
    memcpy(raw + o, &p->e, 2); o += 2;
    memcpy(raw + o, &p->n, 2); o += 2;
    raw[o++] = p->conf;
    raw[o++] = (uint8_t)((age / 100UL) > 255UL ? 255UL : (age / 100UL));
    count++;
  }
  if (!count) return;
  raw[4] = count;
  raw[o] = crc8(raw, o); o++;
  femTx(); int16_t st = LSM_TX(raw, (size_t)o); rxArmAfterTx();
  logRec(LOG_TX, NODE_ID, g_role, 0xA5, count, (int16_t)o,
         (uint32_t)g_curSchedSeq | ((uint32_t)(st == RADIOLIB_ERR_NONE) << 31));
}

static void handleAggPos(const uint8_t *raw, int len){
  if (len < 14 || raw[0] != AGG_POS_MAGIC || raw[1] != WIRE_VER) return;
  uint8_t relay = raw[2], count = raw[4];
  if (relay == 0 || relay != g_secureRxSender) { g_senderBindReject++; return; }
  int need = 7 + (int)count * 7;
  if (!relay || !count || count > AGG_POS_MAX_REC || len != need) return;
  if (raw[len-1] != crc8(raw, len-1)) { g_crcFail++; return; }
  if (g_role != 3 || tkRosterFind(relay) < 0) return;
  uint32_t now = millis();
  for (uint8_t i = 0; i < count; i++) {
    int o = 6 + (int)i * 7;
    uint8_t id = raw[o++]; int16_t e = 0, n = 0;
    memcpy(&e, raw + o, 2); o += 2; memcpy(&n, raw + o, 2); o += 2;
    uint8_t conf = raw[o++], age100 = raw[o++];
    if (!id || id == (uint8_t)NODE_ID || id == relay) continue;
    uint32_t ageMs = (uint32_t)age100 * 100UL;
    peerSeen(id, 1, e, n, 1, 1, conf, ageMs);
    int ri = tkRosterFind(id);
    if (ri >= 0) {
      uint32_t stamp = now - ageMs;
      if ((int32_t)(stamp - g_lastAirMs[ri]) > 0) g_lastAirMs[ri] = stamp;
      g_lastAirFr[ri] = g_frame;
    }
  }
  g_aggDemand[relay] = 0;
  logRec(LOG_STATE, relay, g_role, 0xA6, count, len, raw[3]);
}

static bool ksDenied(uint8_t id){
  for (uint8_t i=0;i<g_ksDenyN;i++) if (g_ksDeny[i].id==id) return true;
  return false;
}

// Diagnostic-only admission window used by the node-12 phantom carrier.
// Production builds do not define RIG_ACCEPT_PHANTOMS and remain byte-for-byte
// closed to these identities.  Keeping the exception at the keeper admission
// gate exercises the real aggregate, birth-frame, seat, and eviction paths
// without adding the synthetic identities to the production fleet allow-list.
#ifndef RIG_PHANTOM_ID_BASE
#define RIG_PHANTOM_ID_BASE 210U
#endif
#ifndef RIG_PHANTOM_ID_COUNT
#define RIG_PHANTOM_ID_COUNT 16U
#endif
#if defined(RIG_ACCEPT_PHANTOMS) && (NODE_ID != 1)
#error "RIG_ACCEPT_PHANTOMS is a keeper-node-1 diagnostic build only"
#endif
static bool ksAllowed(uint8_t id){
#if defined(RIG_ACCEPT_PHANTOMS) && (NODE_ID == 1)
  if (id >= (uint8_t)RIG_PHANTOM_ID_BASE &&
      id < (uint8_t)(RIG_PHANTOM_ID_BASE + RIG_PHANTOM_ID_COUNT)) return true;
#endif
  for (size_t i=0;i<sizeof(KS_NODE_ALLOW);i++) if (KS_NODE_ALLOW[i]==id) return true;
  return false;
}
// Admission gate, both roster sites. Refuses an id that is not ours, then an id
// that has been revoked. Logged so the grader can see every refusal.
static bool ksIdAdmissible(uint8_t id){
  if (!ksAllowed(id)) { logRec(LOG_CTOK, id, g_role, 18, 0, 0, g_frame);  return false; }   // aux 18 = join refused, not on the allow list
  if (ksDenied(id))   { logRec(LOG_CTOK, id, g_role, 19, 0, 0, g_ksEpoch); return false; }  // aux 19 = join refused, revoked
  return true;
}

static void ksSave(){
  Preferences p;
  if (!p.begin("ksrev", false)) return;
  p.putUInt("epoch", g_ksEpoch);
  p.putUChar("n", g_ksDenyN);
  if (g_ksDenyN) p.putBytes("list", g_ksDeny, (size_t)g_ksDenyN*sizeof(KsDenyEnt)); else p.remove("list");
  p.end();
}
static void ksLoad(){
  Preferences p;
  if (!p.begin("ksrev", true)) return;
  g_ksEpoch = p.getUInt("epoch", 0);
  uint8_t n = p.getUChar("n", 0); if (n > KS_DENY_MAX) n = KS_DENY_MAX;
  size_t want = (size_t)n*sizeof(KsDenyEnt);
  if (n && p.getBytesLength("list") == want) { p.getBytes("list", g_ksDeny, want); g_ksDenyN = n; }
  p.end();
}
static void ksBegin(){
  g_ksSodiumOk = (sodium_init() >= 0);
  ksLoad();
  logRec(LOG_CTOK, (uint8_t)NODE_ID, g_role, 27, (int16_t)g_ksDenyN, g_ksSodiumOk ? 1 : 0, g_ksEpoch);   // aux 27 = gate up: e = deny count, n = verifier ready
  if (!serQuiet()) Serial.printf("KSGATE,up,sodium=%d,denyN=%u,epoch=%lu,enforce=%d\n", g_ksSodiumOk ? 1 : 0, (unsigned)g_ksDenyN, (unsigned long)g_ksEpoch, (int)CTOK_ENFORCE);
}

static bool ksVerifyRecord(const KsRevokeWire* r){
  if (!g_ksSodiumOk) return false;
  uint8_t msg[12];
  msg[0]='K'; msg[1]='S'; msg[2]='R'; msg[3]='E'; msg[4]='V';
  msg[5]=r->ver; msg[6]=r->nodeId; msg[7]=r->rsv;
  memcpy(&msg[8], &r->epoch, 4);   // ESP32 is little-endian; the signer writes epoch.to_bytes(4, 'little')
  return crypto_sign_ed25519_verify_detached(r->sig, msg, sizeof(msg), KS_REVOKE_PUBKEY) == 0;
}

// What a stored revocation does on THIS board, whatever its role.
static void ksEnforceRevocation(uint8_t id){
  if (g_role == 3) {
    int i = tkRosterFind(id);
    if (i >= 0) { tkRosterDrop(i); logRec(LOG_CTOK, id, g_role, 20, (int16_t)g_rosterN, 0, g_ksEpoch); }   // aux 20 = member evicted, revoked
  }
#ifdef CRYSTAL_TOKEN
  if (pairtok::forgetPeer((uint16_t)id)) logRec(LOG_CTOK, id, g_role, 23, 0, 0, 0);   // aux 23 = fingerprint forgotten
#endif
  for (int i=0;i<PEER_TABLE_SIZE;i++) if (g_peers[i].id == id) memset(&g_peers[i], 0, sizeof(g_peers[i]));   // never seeded back onto a roster
  if (g_role != 3 && g_tkId != 0 && g_tkId == id) logRec(LOG_CTOK, id, g_role, 21, 0, 0, g_ksEpoch);        // aux 21 = our keeper is revoked; handleSched now drops its beacons and the stall path walks us off
  if (id == (uint8_t)NODE_ID) logRec(LOG_CTOK, id, g_role, 24, 0, 0, g_ksEpoch);                             // aux 24 = this board heard its own revocation (witness only; the fleet enforces)
}

// A revocation record arrived, from the air (via 0) or the serial port (via 1).
// Returns 1 stored, 0 already held, -1 rejected. Only a record that verifies
// against the baked key gets past the second check; everything after it is trusted.
static int ksRevokeAccept(const uint8_t* raw, int len, uint8_t via){
  if (len != (int)sizeof(KsRevokeWire)) return -1;
  const KsRevokeWire* r = (const KsRevokeWire*)raw;
  if (r->magic != 'R' || r->ver != KS_REVOKE_VER)      { g_ksRevRejected++; logRec(LOG_CTOK, r->nodeId, g_role, 17, 2, via, r->epoch); return -1; }   // aux 17 = rejected; e 2 = magic/version
  if (r->crc != crc8(raw, sizeof(KsRevokeWire)-1))    { g_ksRevRejected++; logRec(LOG_CTOK, r->nodeId, g_role, 17, 3, via, r->epoch); return -1; }   // e 3 = crc
  if (!ksVerifyRecord(r))                              { g_ksRevRejected++; logRec(LOG_CTOK, r->nodeId, g_role, 17, 1, via, r->epoch); return -1; }   // e 1 = signature
  int idx = -1;
  for (uint8_t i=0;i<g_ksDenyN;i++) if (g_ksDeny[i].id == r->nodeId) { idx = i; break; }
  if (idx >= 0 && g_ksDeny[idx].epoch >= r->epoch) { logRec(LOG_CTOK, r->nodeId, g_role, 17, 4, via, r->epoch); return 0; }   // e 4 = already held at this epoch or newer, not an error
  if (idx < 0) {
    if (g_ksDenyN >= KS_DENY_MAX) { g_ksRevRejected++; logRec(LOG_CTOK, r->nodeId, g_role, 17, 5, via, r->epoch); return -1; }   // e 5 = list full
    idx = g_ksDenyN++;
  }
  KsDenyEnt* e = &g_ksDeny[idx];
  e->id = r->nodeId; e->ver = r->ver; e->rsv0 = r->rsv; e->rsv1 = 0; e->epoch = r->epoch; memcpy(e->sig, r->sig, 64);
  if (r->epoch > g_ksEpoch) g_ksEpoch = r->epoch;
  ksSave();
  g_ksRevStored++;
  logRec(LOG_CTOK, r->nodeId, g_role, 16, (int16_t)g_ksDenyN, via, r->epoch);   // aux 16 = revocation stored
  if (!serQuiet()) Serial.printf("KSREV,STORED,node=%u,epoch=%lu,via=%u,denyN=%u\n", (unsigned)r->nodeId, (unsigned long)r->epoch, (unsigned)via, (unsigned)g_ksDenyN);
  g_ksGossipIdx  = (int8_t)idx;
  g_ksGossipLeft = (g_role == 3) ? KS_GOSSIP_TK : KS_GOSSIP_MEMBER;
  ksEnforceRevocation(r->nodeId);
  return 1;
}

static inline int ksHexVal(char c){
  if (c>='0'&&c<='9') return c-'0';
  if (c>='a'&&c<='f') return c-'a'+10;
  if (c>='A'&&c<='F') return c-'A'+10;
  return -1;
}
// Serial 'R': the operator pastes the 146 hex characters of a signed record
// (73 bytes, crc included, exactly what ks-revoke-sign.py prints), newline
// terminated. Runs the same acceptance path as an on-air record.
static void ksSerialRevoke(){
  char hex[2*sizeof(KsRevokeWire)]; size_t n = 0; uint32_t t0 = millis();
  while (millis() - t0 < 3000) {
    if (!Serial.available()) { delay(1); continue; }
    char c = (char)Serial.read();
    if (c == '\n' || c == '\r') { if (n) break; else continue; }
    if (ksHexVal(c) >= 0 && n < sizeof(hex)) hex[n++] = c;
  }
  if (n != sizeof(hex)) { Serial.printf("R: need %u hex chars, got %u\n", (unsigned)sizeof(hex), (unsigned)n); return; }
  uint8_t raw[sizeof(KsRevokeWire)];
  for (size_t i=0;i<sizeof(raw);i++) raw[i] = (uint8_t)((ksHexVal(hex[2*i])<<4) | ksHexVal(hex[2*i+1]));
  int r = ksRevokeAccept(raw, (int)sizeof(raw), 1);
  Serial.printf("R: %s node=%u epoch=%lu denyN=%u gossip=%u\n",
                r > 0 ? "STORED" : (r == 0 ? "DUPLICATE" : "REJECTED"),
                (unsigned)raw[2], (unsigned long)((const KsRevokeWire*)raw)->epoch, (unsigned)g_ksDenyN, (unsigned)g_ksGossipLeft);
}
static void ksSerialStatus(){
  Serial.printf("KSGATE node=%u role=%s sodium=%d enforce=%d epoch=%lu denyN=%u stored=%lu rejected=%lu gossipLeft=%u\n",
                (unsigned)NODE_ID, roleStr(), g_ksSodiumOk ? 1 : 0, (int)CTOK_ENFORCE, (unsigned long)g_ksEpoch,
                (unsigned)g_ksDenyN, (unsigned long)g_ksRevStored, (unsigned long)g_ksRevRejected, (unsigned)g_ksGossipLeft);
  for (uint8_t i=0;i<g_ksDenyN;i++) Serial.printf("  DENY node=%u epoch=%lu\n", (unsigned)g_ksDeny[i].id, (unsigned long)g_ksDeny[i].epoch);
  Serial.print("  ALLOW"); for (size_t i=0;i<sizeof(KS_NODE_ALLOW);i++) Serial.printf(" %u", (unsigned)KS_NODE_ALLOW[i]); Serial.println();
#ifdef CRYSTAL_TOKEN
  { uint16_t ids[24]; uint8_t k = pairtok::peerList(ids, 24);
    Serial.printf("  TOKEN baseline=%d whitelist=%u:", pairtok::haveBaseline() ? 1 : 0, (unsigned)k);
    for (uint8_t i=0;i<k;i++) Serial.printf(" %u", (unsigned)ids[i]);
    Serial.printf("  A=%lu R=%lu grants=%lu silent=%lu dropped=%lu evicted=%lu\n",
                  (unsigned long)g_tokAccept, (unsigned long)g_tokReject, (unsigned long)g_ctGrants,
                  (unsigned long)g_ctSilentTotal, (unsigned long)g_ctDropped, (unsigned long)g_ctEvicted); }
#endif
}
// chunk 2: a tail packet heard at hop 0 while this board is the frame's named relayer is
// copied, marked hop 1 with our id, crc redone, and sent in the second tail sub-slot.
// Both tail packets end hops, relayerId, crc, so one rule serves both.
static void ksTailRelayNote(const uint8_t* raw, int len){
  if (g_role != 1 || !g_tokRelayMe || len < 4 || len > (int)sizeof(g_tokRelayRaw)) return;
  if (raw[len-3] != 0) return;                                  // only an origin copy is forwarded, never a relay of a relay
  if (raw[len-1] != crc8(raw, (size_t)len-1)) return;
  memcpy(g_tokRelayRaw, raw, (size_t)len);
  g_tokRelayRaw[len-3] = 1; g_tokRelayRaw[len-2] = (uint8_t)NODE_ID;
  g_tokRelayRaw[len-1] = crc8(g_tokRelayRaw, (size_t)len-1);
  g_tokRelayLen = (uint8_t)len;
}
static void ksSerialClearDeny(){   // bench only: wipe the deny list so a revoked board can be readmitted for the next test
  Preferences p; if (p.begin("ksrev", false)) { p.clear(); p.end(); }
  g_ksDenyN = 0; g_ksEpoch = 0; g_ksGossipIdx = -1; g_ksGossipLeft = 0; memset(g_ksDeny, 0, sizeof(g_ksDeny));
  logRec(LOG_CTOK, (uint8_t)NODE_ID, g_role, 28, 0, 0, 0);   // aux 28 = deny list cleared over serial
  Serial.println("Q: deny list cleared (this board only; every other board keeps its copy)");
}
// The side-channel request byte a member puts in MemberPkt.relayerId on a hop-0
// packet (the byte carried nothing there: hops 0 already names the sender).
// bit0 = I hold a revocation to repeat, grant me the tail. bit1 = my fingerprint
// changed, grant me a refresh. A relay overwrites the byte and bumps hops, so a
// relayed copy never carries a stale request.
static uint8_t ksSideReq(){
  uint8_t b = 0;
  if (g_ksGossipLeft && g_ksGossipIdx >= 0 && g_role != 3) b |= 0x01;
  if (g_ctWantAnnounce) b |= 0x02;
  if (g_volunteerFor != 0) b |= 0x04;   // v7.28.97: a volunteer relay report rides volunteerFor on this same hop-0 packet
  return b;
}
// v7.28.59: token state for a freshly admitted roster index, both admission sites.
static void ksRosterInit(int idx){
  g_ctFail[idx]=0; g_ctSilent[idx]=0; g_ctNotReadyFr[idx]=0; g_ctSideReq[idx]=0; g_ctLastGrantFr[idx]=0;
  g_ctPassed[idx]=0; g_ctDirectMs[idx]=0; g_ctAdmitMs[idx]=millis();
#ifdef CRYSTAL_TOKEN
  g_ctRefreshFr[idx] = pairtok::peerKnown((uint16_t)g_roster[idx]) ? 1 : 0;   // known from before: ancient, refreshed after the unknowns; 0 = UNKNOWN
#else
  g_ctRefreshFr[idx] = 0;
#endif
}

#ifdef CRYSTAL_TOKEN
#ifndef CTOK_LEARN_SECS
#define CTOK_LEARN_SECS 480      // 8 minute bake-in, override with -D CTOK_LEARN_SECS=NN
#endif

struct __attribute__((packed)) CtokWire {
  uint8_t  magic;                // 'C', distinct from 'K' sched, 'B' backhaul, 'R' revocation
  uint8_t  sub;                  // 0 = fingerprint announce. 2 = not ready (baseline still baking, fp zeroed). v7.28.59: sub 1, the baseline request, is retired with the unscheduled path
  uint16_t src_id;
  uint16_t dst_id;               // 0 = broadcast
  pairtok::Fingerprint fp;       // valid when sub==0
  uint8_t  hops;                 // v7.28.59 chunk 2: 0 from the origin, 1 from the frame's named relayer
  uint8_t  relayerId;            // 0 from the origin, the relayer's id on a relayed copy
  uint8_t  crc;                  // CRC-8 over all prior bytes, recomputed by the relay
};
static_assert(sizeof(CtokWire) == 37, "CtokWire size moved: it must stay under TOK_WIRE_MAX_B");

static void ctokLog(const String& s) { if (!Serial || serQuiet()) return; Serial.println(s); }   // v7.14.1: v7.11.23 native-CDC host guard. Headless board must never block on

// v7.28.59 TAIL TOKEN SLOT. Per Stuart 2026-09-13. The token no longer has an
// unscheduled transmit anywhere. The keeper names ONE board per frame in
// SchedBeacon.grantId; that board speaks in the tail slot, which sits after the
// last member slot and the relay reply region and before the backhaul errand,
// so it can never land on the beacon (the v7.28.56 residual 15 percent).
// grantId 0 means no tail slot and the frame is not extended. grantId == tkId
// means the keeper itself speaks (its own fingerprint, or a revocation).
//
// Grant policy, in order: a revocation to repeat; the keeper's own fingerprint
// (first frame of the tenure, then every CTOK_TK_ANNOUNCE_FRAMES, sooner while a
// member is still sending zero tags); a member that asked for the slot to repeat
// a revocation; a member with no fingerprint on file (UNKNOWN); the member whose
// fingerprint is oldest once it passes CTOK_REFRESH_FRAMES. Staleness drives the
// grant, so bring-up, re-walk and thermal drift are one path. The slot idles in
// steady state at zero cost.
//
// Only members the keeper hears DIRECT (hop 0, within CTOK_DIRECT_MS) are ever
// granted, and only they are subject to the silence and prove-window evictions.
// The tail packet is not relayed in this cut, so a member heard only through a
// relay can never prove itself here: it stays admitted and its verdicts are
// logged UNKNOWN. Multi-hop identity needs the relay to carry the announce and
// is its own cut.
#ifndef CTOK_TK_ANNOUNCE_FRAMES
#define CTOK_TK_ANNOUNCE_FRAMES 240     // keeper repeats its own fingerprint on this cadence (about two minutes at 500 ms frames)
#endif
#ifndef CTOK_TK_REANNOUNCE_MIN
#define CTOK_TK_REANNOUNCE_MIN  16      // floor between keeper announces when a member is still sending a zero tag
#endif
#ifndef CTOK_REFRESH_FRAMES
#define CTOK_REFRESH_FRAMES     600     // a member fingerprint older than this is due for a refresh grant (about five minutes at 500 ms frames)
#endif
#ifndef CTOK_NOTREADY_BACKOFF
#define CTOK_NOTREADY_BACKOFF   64      // frames between grants to a member that answered NOT READY (baseline still baking)
#endif
#ifndef CTOK_FAIL_EVICT
#define CTOK_FAIL_EVICT         6       // consecutive FAIL verdicts before eviction; one corrupted tag never tears down a link
#endif
#ifndef CTOK_SILENT_EVICT
#define CTOK_SILENT_EVICT       8       // tail grants answered by nothing before eviction: a board with no token code at all
#endif
#ifndef CTOK_PROVE_MS
#define CTOK_PROVE_MS           ((uint32_t)(CTOK_LEARN_SECS + 180) * 1000UL)   // a member admitted UNKNOWN must PASS within a bake plus three minutes
#endif
#ifndef CTOK_DIRECT_MS
#define CTOK_DIRECT_MS          10000   // heard hop 0 within this window counts as direct
#endif

static bool     g_tokGrantSelf    = false;   // keeper: this frame's tail slot is ours
static uint8_t  g_tokGrantId      = 0;       // keeper: who holds the tail slot this frame, 0 none
static uint8_t  g_tokGrantKind    = 0;       // keeper self grant: 1 announce, 2 revocation
static uint8_t  g_tokLastGrantId  = 0;       // keeper: the member granted last frame, for the silence witness
static bool     g_tokHeardGrantee = false;   // keeper: that member answered in the tail slot
static uint32_t g_tokSlotStartUs  = 0;       // keeper: where the tail slot begins this frame
static uint64_t g_tokLastTxAnchor = 0;       // keeper: once per frame latch on the frame anchor
static uint32_t g_ctTkAnnFr       = 0;       // keeper: frame of our last own announce, 0 = not yet this tenure
static bool     g_ctNoTagSeen     = false;   // keeper: a member sent a zero tag since our last announce
static bool     g_ctBaselineWas   = false;   // member: edge detector for baseline availability

// The one transmit site the token has. kind 0 = our fingerprint, 1 = the
// revocation being repeated, 2 = not ready. Called only from a granted tail slot.
static void ctokTailSend(uint8_t kind){
  if (!g_radioOk) return;
  if (kind == 1) {
    if (g_ksGossipIdx < 0 || g_ksGossipIdx >= (int8_t)g_ksDenyN) { g_ksGossipLeft = 0; return; }
    const KsDenyEnt* e = &g_ksDeny[g_ksGossipIdx];
    KsRevokeWire r; memset(&r, 0, sizeof(r));
    r.magic = 'R'; r.ver = e->ver; r.nodeId = e->id; r.rsv = e->rsv0; r.epoch = e->epoch; memcpy(r.sig, e->sig, 64);
    r.hops = 0; r.relayerId = 0;   // origin copy
    r.crc = crc8((uint8_t*)&r, sizeof(r)-1);
    logRec(LOG_CTOK, e->id, g_role, 15, 1, (int16_t)g_ksGossipLeft, g_role == 3 ? g_frame : (uint32_t)g_curSchedSeq);   // aux 15 = tail TX, e 1 = revocation
    logRec(LOG_TX, NODE_ID, g_role, 0xC7, (int16_t)sizeof(r), 0, e->epoch);                                              // v7.28.59: every transmit site logs; 0xC7 = revocation repeat
    femTx(); LSM_TX((uint8_t*)&r, sizeof(r)); rxArmAfterTx();
    if (g_ksGossipLeft) g_ksGossipLeft--;
    return;
  }
  CtokWire c; memset(&c, 0, sizeof(c));
  c.magic = 'C'; c.src_id = (uint16_t)NODE_ID; c.dst_id = 0; c.hops = 0; c.relayerId = 0;   // origin copy
  if (kind == 0 && pairtok::haveBaseline() && pairtok::announceBytes(&c.fp)) { c.sub = 0; g_ctWantAnnounce = false; }
  else { c.sub = 2; kind = 2; }
  logRec(LOG_CTOK, (uint8_t)NODE_ID, g_role, 15, (int16_t)kind, 0, g_role == 3 ? g_frame : (uint32_t)g_curSchedSeq);   // aux 15 = tail TX, e 0 announce, e 2 not ready
  logRec(LOG_TX, NODE_ID, g_role, kind == 0 ? 0xC4 : 0xC5, (int16_t)sizeof(c), 0, 0);                                    // 0xC4 announce (same code as before, now scheduled), 0xC5 not ready
  c.crc = crc8((uint8_t*)&c, sizeof(c)-1);
  femTx(); LSM_TX((uint8_t*)&c, sizeof(c)); rxArmAfterTx();
}

static void handleCtok(const uint8_t* raw, int len) {
  if (len != (int)sizeof(CtokWire)) return;
  const CtokWire* c = (const CtokWire*)raw;
  if (c->crc != crc8(raw, sizeof(CtokWire)-1)) return;
  if (c->src_id == (uint16_t)NODE_ID) return;               // never our own echo
  uint8_t src = (uint8_t)c->src_id;
  if (g_role == 3) {
    int idx = tkRosterFind(src);
    if (src == g_tokLastGrantId) g_tokHeardGrantee = true;
    if (c->sub == 0) {
      if (pairtok::absorbPeer(&c->fp)) {
        if (idx >= 0) { g_ctRefreshFr[idx] = g_frame; g_ctSilent[idx] = 0; g_ctNotReadyFr[idx] = 0; }
        logRec(LOG_CTOK, src, g_role, 5 /*peer absorbed*/, (int16_t)idx, 0, g_frame);
        if (!serQuiet()) Serial.printf("CTOK,PEER,src=%u,idx=%d\n", (unsigned)src, idx);
      }
    } else if (c->sub == 2) {
      if (idx >= 0) { g_ctNotReadyFr[idx] = g_frame; g_ctSilent[idx] = 0; }
      logRec(LOG_CTOK, src, g_role, 25 /*not ready heard*/, (int16_t)idx, 0, g_frame);
    }
    return;
  }
  // member: absorb whoever speaks in the tail, the keeper's fingerprint is what lets us mint
  if (c->sub == 0 && pairtok::absorbPeer(&c->fp)) {
    logRec(LOG_CTOK, src, g_role, 5 /*peer absorbed*/, 0, 0, (uint32_t)src);
    if (!serQuiet()) Serial.printf("CTOK,PEER,src=%u\n", (unsigned)src);
  }
}

// Keeper side. Runs on every CRC-clean MemberPkt before handleMember uses it.
// Returns false when the packet must be DROPPED (an enforced FAIL, or an eviction).
// Three verdicts plus the honest zero:
//   NOTAG   attToken 0: the member has no tag for us yet (no baseline, or it has
//           not heard our announce). Admitted, logged, nudges a keeper announce.
//   UNKNOWN no fingerprint on file for this member. Admitted, logged, and the
//           grant policy puts it first in line for the tail slot.
//   PASS    the tag opened against the fingerprint on file.
//   FAIL    a fingerprint is on file and the tag did not open it. Under
//           CTOK_ENFORCE the packet is refused and logged as a distinct record so
//           the grader can subtract policy drops from radio loss; CTOK_FAIL_EVICT
//           consecutive failures evict the member and forget its fingerprint.
// A member admitted UNKNOWN that never PASSes inside CTOK_PROVE_MS is evicted.
// chunk 2: which path can carry this member's tail packet to us. 0 none, 1 direct, 2 via a
// live relay parent (the same latch the data-relay naming uses, fallback to the last relayer).
static uint8_t ctokParentOf(int i, uint32_t nowMs){
  uint8_t par = g_relayParent[i];
  if (par != 0 && (uint32_t)(nowMs - g_relayParentMs[i]) >= relayParentHoldMs()) par = 0;
  if (par == 0 && (uint32_t)(nowMs - g_lastRelayerMs[i]) < relayParentHoldMs()) par = g_lastRelayer[i];
  return par;
}
static uint8_t ctokReach(int i, uint32_t nowMs){
  if (g_ctDirectMs[i] && (nowMs - g_ctDirectMs[i]) <= CTOK_DIRECT_MS) return 1;
  if (ctokParentOf(i, nowMs) != 0 && (nowMs - g_lastAirMs[i]) <= CTOK_DIRECT_MS) return 2;   // heard through the relay recently
  return 0;
}
// chunk 2: on a keeper self-grant, name a relayer so hop-1 boards hear our fingerprint (they
// cannot mint without it). Keeps a relayer the naming pass already chose; otherwise the next
// direct member that is somebody's relay parent, rotating.
static bool ksTokSelfRelay(SchedBeacon& s){
  if (s.relayById != 0) { if (s.relayForId == 0) s.relayForId = (uint8_t)NODE_ID; return true; }
  static uint8_t cursor = 0; uint32_t nowMs = millis();
  for (int k=0;k<g_rosterN;k++){
    int i = (int)(((uint32_t)cursor + (uint32_t)k) % (uint32_t)g_rosterN);
    if (!g_ctDirectMs[i] || (nowMs - g_ctDirectMs[i]) > CTOK_DIRECT_MS) continue;
    bool isParent = false;
    for (int j=0;j<g_rosterN;j++) if (j != i && ctokParentOf(j, nowMs) == g_roster[i]) { isParent = true; break; }
    if (!isParent) continue;
    s.relayForId = (uint8_t)NODE_ID; s.relayById = g_roster[i]; cursor = (uint8_t)((i + 1) % g_rosterN);
    return true;
  }
  return false;
}
static bool ctokProveWindow(int idx, uint32_t nowMs){
#if CTOK_ENFORCE
  if (idx >= 0 && idx < g_rosterN && !g_ctPassed[idx] && ctokReach(idx, nowMs)
      && (nowMs - g_ctAdmitMs[idx]) > CTOK_PROVE_MS) {
    uint8_t id = g_roster[idx];
    logRec(LOG_CTOK, id, g_role, 12, (int16_t)((nowMs - g_ctAdmitMs[idx]) / 1000UL), 0, g_frame);   // aux 12 = evicted, prove window expired
    pairtok::forgetPeer((uint16_t)id); tkRosterDrop(idx); g_ctEvicted++;
    return false;
  }
#else
  (void)idx; (void)nowMs;
#endif
  return true;
}
static bool ctokTkVerify(const uint8_t* raw, int len) {
  if (g_role != 3) return true;
  if (len != (int)sizeof(MemberPkt)) return true;
  const MemberPkt* p = (const MemberPkt*)raw;
  if (p->src_id == 0 || p->src_id == (uint16_t)NODE_ID) return true;
  if (p->type != 0 && p->type != 6) return true;            // joins and swarm asks are gated by id at admission, not by tag
  uint8_t src = (uint8_t)p->src_id;
  int idx = tkRosterFind(src);
  if (idx < 0) return true;                                  // not on our roster: the admission gate owns it
  uint32_t nowMs = millis();
  if (p->hops == 0) { g_ctDirectMs[idx] = nowMs; g_ctSideReq[idx] = p->relayerId; }   // side-channel request rides relayerId on a hop-0 packet
  if (p->attToken == 0) {
    g_ctNoTagSeen = true;
    logRec(LOG_CTOK, src, g_role, 9 /*NOTAG*/, (int16_t)idx, (int16_t)p->hops, (uint32_t)p->seq);
    return ctokProveWindow(idx, nowMs);
  }
  if (!pairtok::peerKnown((uint16_t)src)) {
    logRec(LOG_CTOK, src, g_role, 8 /*UNKNOWN*/, (int16_t)idx, (int16_t)p->hops, (uint32_t)p->seq);
    return ctokProveWindow(idx, nowMs);
  }
  uint8_t t4[4]; memcpy(t4, &p->attToken, 4);
  bool ok = pairtok::validateTagN((uint16_t)src, (uint32_t)p->seq, t4, 4);
  // ctok 2026-07-21: record every verdict for the published dump, not just serial
  if (ok) g_tokAccept++; else g_tokReject++;
  g_tokLastSrc = p->src_id; g_tokLastSeq = p->seq; g_tokLastOk = ok; g_tokHadVerdict = true;
  logRec(LOG_CTOK, src, g_role, ok ? 1 : 2,
         (int16_t)(g_tokAccept > 32767 ? 32767 : g_tokAccept),
         (int16_t)(g_tokReject > 32767 ? 32767 : g_tokReject),
         (uint32_t)p->seq);
  if (!serQuiet()) Serial.printf("CTOK,%s,src=%u,seq=%u,A=%lu,R=%lu\n",
                ok ? "ACCEPT" : "REJECT", (unsigned)src, (unsigned)p->seq,
                (unsigned long)g_tokAccept, (unsigned long)g_tokReject);
  if (ok) { g_ctFail[idx] = 0; g_ctPassed[idx] = 1; return true; }
#if CTOK_ENFORCE
  g_ctFail[idx]++; g_ctDropped++;
  logRec(LOG_CTOK, src, g_role, 10 /*FAIL dropped*/, (int16_t)g_ctFail[idx], (int16_t)p->hops, (uint32_t)p->seq);
  if (g_ctFail[idx] >= CTOK_FAIL_EVICT) {
    logRec(LOG_CTOK, src, g_role, 11 /*evicted, consecutive fails*/, (int16_t)g_ctFail[idx], 0, g_frame);
    pairtok::forgetPeer((uint16_t)src); tkRosterDrop(idx); g_ctEvicted++;
  }
  return false;
#else
  return true;
#endif
}

// Keeper side, once per frame from tkBuildAndSend before the frame length is
// sized. Closes last frame's grant (the silence witness), then decides this
// frame's grantee. Returns the grantId to publish.
static uint8_t ksTokGrantDecide(uint8_t nSlots, SchedBeacon& s){
  if (g_tokLastGrantId) {
    int li = tkRosterFind(g_tokLastGrantId);
    if (li >= 0 && !g_tokHeardGrantee) {
      g_ctSilent[li]++; g_ctSilentTotal++;
      logRec(LOG_CTOK, g_tokLastGrantId, g_role, 22 /*grant answered by nothing*/, (int16_t)g_ctSilent[li], 0, g_frame);
#if CTOK_ENFORCE
      if (g_ctSilent[li] >= CTOK_SILENT_EVICT) {
        logRec(LOG_CTOK, g_tokLastGrantId, g_role, 13 /*evicted, silent grants*/, (int16_t)g_ctSilent[li], 0, g_frame);
        pairtok::forgetPeer((uint16_t)g_tokLastGrantId); tkRosterDrop(li); g_ctEvicted++;
      }
#endif
    }
    g_tokLastGrantId = 0; g_tokHeardGrantee = false;
  }
  g_tokGrantId = 0; g_tokGrantSelf = false; g_tokGrantKind = 0; g_tokExtSlots = 0;
  g_tokSlotStartUs = g_memberBaseUs + (uint32_t)nSlots*g_slotUsLive + g_relayReplySlotUs;
  if (g_frameType == SF_TYPE_JOIN) return 0;   // a birth frame publishes every slot as a join window; no tail
  if (!g_radioOk) return 0;
  // 1. a revocation to repeat beats everything
  if (g_ksGossipLeft && g_ksGossipIdx >= 0) {
    g_tokGrantSelf = true; g_tokGrantKind = 2; g_tokGrantId = (uint8_t)NODE_ID;
    g_tokExtSlots = ksTokSelfRelay(s) ? 2 : 1;
    logRec(LOG_CTOK, g_tokGrantId, g_role, 14 /*grant*/, 0, 2, g_frame);
    return g_tokGrantId;
  }
  // 2. our own fingerprint: without it no member can mint a tag for us
  if (pairtok::haveBaseline()) {
    bool never = (g_ctTkAnnFr == 0);
    bool due   = (g_frame - g_ctTkAnnFr) >= CTOK_TK_ANNOUNCE_FRAMES;
    bool nudge = g_ctNoTagSeen && (g_frame - g_ctTkAnnFr) >= CTOK_TK_REANNOUNCE_MIN;
    if (never || due || nudge) {
      g_tokGrantSelf = true; g_tokGrantKind = 1; g_tokGrantId = (uint8_t)NODE_ID;
      g_ctTkAnnFr = g_frame ? g_frame : 1; g_ctNoTagSeen = false;
      g_tokExtSlots = ksTokSelfRelay(s) ? 2 : 1;
      logRec(LOG_CTOK, g_tokGrantId, g_role, 14 /*grant*/, 0, 1, g_frame);
      return g_tokGrantId;
    }
  }
  // 3. a member. Priority 3 repeats a revocation, 2 is UNKNOWN, 1 is a refresh due.
  uint32_t nowMs = millis();
  int best = -1; int bestPri = 0; uint32_t bestKey = 0;
  for (int i=0;i<g_rosterN;i++){
    if (!ctokReach(i, nowMs)) continue;   // chunk 2: direct, or through a live relay parent
    if (g_ctLastGrantFr[i] && (g_frame - g_ctLastGrantFr[i]) < 2) continue;         // a frame between grants to the same member
    int pri = 0; uint32_t key = 0;
    if (g_ctSideReq[i] & 0x01) { pri = 3; key = g_frame - g_ctLastGrantFr[i]; }
    else if (g_ctRefreshFr[i] == 0) {
      if (g_ctNotReadyFr[i] && (g_frame - g_ctNotReadyFr[i]) < CTOK_NOTREADY_BACKOFF) continue;
      pri = 2; key = g_frame - g_ctLastGrantFr[i];
    } else if ((g_ctSideReq[i] & 0x02) || (g_frame - g_ctRefreshFr[i]) >= CTOK_REFRESH_FRAMES) {
      pri = 1; key = g_frame - g_ctRefreshFr[i];
    }
    if (pri > bestPri || (pri == bestPri && pri && key > bestKey)) { best = i; bestPri = pri; bestKey = key; }
  }
  if (best < 0) return 0;
  g_tokGrantId = g_roster[best]; g_tokLastGrantId = g_tokGrantId; g_ctLastGrantFr[best] = g_frame; g_ctGrants++;
  // chunk 2: a member we do not hear direct answers through its relay parent. Name that parent
  // as this frame's relayer (it is the board already forwarding this member's data), and
  // budget the second sub-slot. If a relayer was already named for someone else this frame
  // it forwards this tail packet too, so a direct grantee also gets two sub-slots then.
  if (ctokReach(best, nowMs) == 2) { s.relayForId = g_tokGrantId; s.relayById = ctokParentOf(best, nowMs); }
  g_tokExtSlots = (s.relayById != 0) ? 2 : 1;
  logRec(LOG_CTOK, g_tokGrantId, g_role, 14 /*grant*/, (int16_t)bestPri, (int16_t)best, g_frame);
  return g_tokGrantId;
}

// Keeper side, from loop() next to bhTailErrand. Phase-gated into the tail
// slot the frame compute budgeted, latched once per frame on the frame anchor.
// If the loop arrives after the slot has closed it does NOT transmit late into
// the errand region; it logs the miss and the grant simply recurs.
static void ksTailTxKeeper(){
  if (g_role != 3 || !g_tokGrantSelf) return;
  if (g_frameAnchorUs == 0 || g_frameUs == 0) return;
  if (g_frameAnchorUs == g_tokLastTxAnchor) return;
  uint64_t nowUs = (uint64_t)esp_timer_get_time();
  uint32_t offUs = (uint32_t)((nowUs - g_frameAnchorUs) % (uint64_t)g_frameUs);
  if (offUs < g_tokSlotStartUs) return;
  g_tokLastTxAnchor = g_frameAnchorUs; g_tokGrantSelf = false;
  if (offUs >= g_tokSlotStartUs + g_tokSlotUsLive) {
    logRec(LOG_CTOK, (uint8_t)NODE_ID, g_role, 26 /*keeper missed its own tail slot*/, (int16_t)((offUs - g_tokSlotStartUs) / 1000UL), 0, g_frame);
    if (g_tokGrantKind == 1) g_ctTkAnnFr = 0;   // announce did not go out, do it next frame
    return;
  }
  ctokTailSend(g_tokGrantKind == 2 ? 1 : 0);
}

// Member side, from the granted-slot block in the member loop with the current
// frame offset. Engages early by the measured latency exactly like a data slot.
static void ksTailTxMember(uint32_t offUs){
  if (g_role != 1 || !g_tokGrantMe) return;
  static uint8_t sentTokSeq = 0xFF;
  uint32_t start = g_memberBaseUs + (uint32_t)g_tokNSlots*g_slotUsLive + g_relayReplySlotUs;
  int32_t engLeadS = (int32_t)g_txLatUs + (int32_t)TX_ENGAGE_US + (int32_t)g_trimAdjUs;
  uint32_t engLead = engLeadS > 0 ? (uint32_t)engLeadS : 0;
  if (offUs >= (start > engLead ? start - engLead : 0) && offUs < start + g_tokSlotUsLive) {
    if (sentTokSeq != g_curSchedSeq) {
      sentTokSeq = g_curSchedSeq;
      g_tokGrantMe = false;
      ctokTailSend((g_ksGossipLeft && g_ksGossipIdx >= 0) ? 1 : 0);
    }
  } else if (offUs >= start + g_tokSlotUsLive) {
    g_tokGrantMe = false;   // window passed, the grant recurs
  }
}
// chunk 2: the named relayer forwards the armed copy in the second tail sub-slot.
static void ksTailRelayTx(uint32_t offUs){
  if (g_role != 1 || !g_tokRelayMe || g_tokRelayLen == 0) return;
  static uint8_t sentRelaySeq = 0xFF;
  uint32_t start = g_memberBaseUs + (uint32_t)g_tokNSlots*g_slotUsLive + g_relayReplySlotUs + g_tokSlotUsLive;
  int32_t engLeadS = (int32_t)g_txLatUs + (int32_t)TX_ENGAGE_US + (int32_t)g_trimAdjUs;
  uint32_t engLead = engLeadS > 0 ? (uint32_t)engLeadS : 0;
  if (offUs >= (start > engLead ? start - engLead : 0) && offUs < start + g_tokSlotUsLive) {
    if (sentRelaySeq != g_curSchedSeq) {
      sentRelaySeq = g_curSchedSeq;
      logRec(LOG_TX, NODE_ID, g_role, 0xC8, (int16_t)g_tokRelayLen, 0, (uint32_t)g_tokRelayRaw[2]);   // 0xC8 = tail relay resend; data = origin id byte
      femTx(); LSM_TX(g_tokRelayRaw, g_tokRelayLen); rxArmAfterTx();
      g_tokRelayLen = 0; g_tokRelayMe = false;
    }
  } else if (offUs >= start + g_tokSlotUsLive) {
    g_tokRelayLen = 0; g_tokRelayMe = false;
  }
}

// Member-side mint helper. If we hold the current TK's baseline, return the low
// 4 bytes of the pairwise tag; otherwise ZERO. v7.21.0: this used to fall back to
// departAttest, which is what put two meanings on attToken in the first place and
// broke the TK departure check at enrollment. The departure value now travels in
// depAttest16 and is written unconditionally at both pack sites, so an un-enrolled
// sender is still fully measurable; a zero tag is the honest statement that it has
// no crystal tag yet, and the TK reads it as NOTAG (v7.28.59) rather than a FAIL.
static uint32_t ctokMintOr(uint16_t src, uint8_t seq, int16_t depoff) {
  uint8_t t4[4];
  if (pairtok::haveBaseline() && g_tkId != 0 && g_tkId != (uint8_t)NODE_ID
      && pairtok::peerKnown((uint16_t)g_tkId)
      && pairtok::mintTagN((uint16_t)g_tkId, (uint32_t)seq, t4, 4)) {
    g_tokMint++; // ctok 2026-07-21
    logRec(LOG_CTOK, (uint8_t)g_tkId, g_role, 7 /*mint*/, (int16_t)(g_tokMint>32767?32767:g_tokMint), 0, (uint32_t)seq);
    uint32_t v; memcpy(&v, t4, 4); return v;
  }
  (void)src; (void)depoff;   // v7.21.0: no longer minted from the departure stamp
  return 0u;
}

static void ctokService(uint32_t nowMs) {
  pairtok::tick(nowMs);
  if (pairtok::haveBaseline() && !g_baseLoggedDone) { // ctok 2026-07-21: one-shot baseline-ready marker
    g_baseLoggedDone = true;
    logRec(LOG_CTOK, (uint8_t)NODE_ID, g_role, 3 /*baseline ready*/,
           (int16_t)lround(pairtok::sepUnits() * 100.0),
           (int16_t)pairtok::peerCount(), 0);
  }
  // v7.28.59: the periodic announce and the baseline request that lived here
  // were the unscheduled transmits. Gone. The only thing left is the edge
  // detector that asks the keeper for a refresh slot when our baseline appears.
  bool have = pairtok::haveBaseline();
  if (have && !g_ctBaselineWas) g_ctWantAnnounce = true;
  g_ctBaselineWas = have;
}
#endif // CRYSTAL_TOKEN
#ifndef CRYSTAL_TOKEN
// v7.28.59: without the token the tail slot is never granted and never answered
static uint8_t ksTokGrantDecide(uint8_t nSlots, SchedBeacon& s){ (void)nSlots; (void)s; g_tokExtSlots = 0; return 0; }
static void    ksTailTxKeeper(){}
static void    ksTailTxMember(uint32_t offUs){ (void)offUs; }
static void    ksTailRelayTx(uint32_t offUs){ (void)offUs; }
#endif

// v7.28.31: token state for the per-second aux 5 witness. Reads only.
static uint32_t ctokStateWord() {
#ifdef CRYSTAL_TOKEN
  uint32_t w = 0;
  if (pairtok::haveBaseline()) w |= 1UL;
  if (g_tkId != 0 && pairtok::peerKnown((uint16_t)g_tkId)) w |= 2UL;
  { uint32_t pc = (uint32_t)pairtok::peerCount(); if (pc > 255UL) pc = 255UL; w |= pc << 8; }
  w |= ((uint32_t)g_tokMint & 0xFFFFUL) << 16;
  return w;
#else
  return 0;
#endif
}
// ============================================================================

void handleBeacon(const uint8_t* raw, int len, int16_t rssi, int8_t snr, int16_t snrRaw) {
  if (len <= 0) return;
  if ((raw[0]=='R' && len==(int)sizeof(KsRevokeWire)) || (raw[0]=='C' && len==37)) ksTailRelayNote(raw, len);   // chunk 2: arm the forward if we are this frame's relayer
  if (raw[0]=='R' && len==(int)sizeof(KsRevokeWire)) { ksRevokeAccept(raw,len,0); return; }   // v7.28.59: signed revocation record off the tail slot. 'R' is 0x52, no node id is that high
#ifdef CRYSTAL_TOKEN
  if (raw[0]=='C' && len==(int)sizeof(CtokWire)) { handleCtok(raw,len); return; }
#endif
  // v7.16.0: 4 byte join request. Magic plus exact length, tested ahead of the
  // length based MemberPkt path, mirroring the CtokWire 'C' check above. 'J'
  // is 0x4A and cannot collide with a MemberPkt, whose first byte is the low
  // byte of a node id. THIS IS THE FOURTH WIRE VERSION GATE: it moves with the
  // beacon build site, handleSched and the raw[1] check below, or the sphere
  // goes deaf to itself. That is exactly the v7.13.0 to v7.13.2 all-TK failure,
  // and it happened with only three gates to keep in step.
  // v7.28.101 CORRECTION, SECOND PASS. The four lines that stood here said joins are
  // NOT relayed and that memberFloodNote is called only for type 0 and 6. The second
  // half of that is false: v7.18.0 added type 2 to the dispatch gate, which now reads
  // "p->type == 0 || p->type == 6 || p->type == 2 || kaBit", and memberFloodNote does
  // not gate on type, so a type-2 DOES reach it.
  // But reaching it is not relaying it, and the first pass of this correction wrongly
  // claimed a joiner out of keeper range is "already carried up the relay tree". It is
  // not. memberFloodNote forwards only when iAmRelay is true, and iAmRelay is
  // (g_relayAssignedFor != 0 && src == g_relayAssignedFor). g_relayAssignedFor comes
  // off relayForId, and the keeper assigns relayForId as g_roster[i] - ALWAYS a
  // rostered member. An unseated joiner is by definition not in the roster, so no
  // beacon ever names a relay for it, iAmRelay is never true for a join, and the
  // individual type-2 is tracked for dedup and then dropped.
  // So the route a distant joiner actually takes up the tree is the AGGREGATE path
  // ('A' packets, aggBufAdd/aggFlush) plus the v7.28.101 sized swarm request, and only
  // on a board that relayed the schedule this frame or has filled its buffer. The old
  // single-join hole is smaller than it was, not closed.
  // Related structural note, corrected v7.29.1 (the old text here claimed hops could not
  // reach 2 and that a LOG_MESH aux of 1 was the ceiling; two v7.29.0 boards logged aux 2,
  // so the old claim was wrong). Exactly ONE relayForId/relayById pair exists per beacon, so
  // the SCHEDULE-relay flood adds at most one hop per beacon. But a CLIMBED ADMIT reports its
  // own depth: memberSendSwarmReq (and the plea forward) set hops = g_anchorHops + 1, so a
  // board seated at depth N transmits at hops N+1 with no second relay needed. The true
  // ceiling on MemberPkt.hops is RELAY_MAX_HOPS (the gates at the aggregate re-aggregation and
  // memberFloodNote both bound on RELAY_MAX_HOPS / g_schedTiers), NOT 1. A LOG_MESH aux above
  // 1 is real depth being reported, not a defect; the tier floor (v7.28.105) exists precisely
  // so the keeper holds enough tiers to schedule those deeper reports rather than refusing them.
  // v7.19.0 brick2: aggregated join packet. magic 'A', variable length 5 + 5K bytes.
  // Tested ahead of 'J' and the MemberPkt length path; 'A' is 0x41, cannot collide
  // with a MemberPkt first byte (low byte of a node id) at these lengths. FIFTH wire
  // gate: raw[1] moves with WIRE_VER exactly like the others.
  if (raw[0]==AGG_JOIN_MAGIC2 && len >= AGG_HDR2_BYTES + AGG_REC_WIRE + AGG_CRC_BYTES){
    // v7.28.102 CHUNK 3 ITEM 5: aggregate WITH sender. Same record loop as 'A' below,
    // plus: the keeper names raw[4] as the parent of every id it seats from this
    // packet, in the same step. The sender is the keeper's direct child on the path
    // (an intermediate re-aggregator rewrites the byte when it flushes), which is the
    // right parent for the exclusive grant. On a non-keeper the sender byte is
    // ignored and the item-7 depth gate decides whether to re-aggregate.
    uint8_t k = raw[3];
    uint8_t relayerId = raw[4];
    if (relayerId == 0 || relayerId != g_secureRxSender) { g_senderBindReject++; return; }
    int need = AGG_HDR2_BYTES + (int)k*AGG_REC_WIRE + AGG_CRC_BYTES;
    if (raw[1]==WIRE_VER && k>0 && k<=AGG_PKT_MAX_REC && len==need && raw[need-1]!=crc8(raw, need-1)) g_crcFail++;
    if (raw[1]==WIRE_VER && k>0 && k<=AGG_PKT_MAX_REC && len==need
        && raw[need-1]==crc8(raw, need-1)){
      uint8_t inHops = raw[2];
      for (uint8_t i=0;i<k;i++){
        int o = AGG_HDR2_BYTES + (int)i*AGG_REC_WIRE;
        uint8_t sid = raw[o];
        uint32_t tok = (uint32_t)raw[o+1] | ((uint32_t)raw[o+2]<<8)
                     | ((uint32_t)raw[o+3]<<16) | ((uint32_t)raw[o+4]<<24);
        if (sid==0 || sid==(uint8_t)NODE_ID) continue;
        demandNote(sid);
        if (g_role == 3) {
          tkOnJoinReq(sid);                 // seat
          int oi = tkRosterFind(sid);
          if (oi >= 0 && relayerId != 0 && relayerId != sid) {
            g_relayParent[oi]   = relayerId;   // and name, same step
            g_relayParentMs[oi] = millis();
            logRec(LOG_STATE, NODE_ID, g_role, 0xEC, (int16_t)sid, (int16_t)relayerId, 0xB0000000UL | (uint32_t)inHops);   // aux 0xEC volunteer accepted; data hi byte 0xB0 marks it came via a 'B' aggregate
          }
        } else {
          aggReaggregate(sid, tok, inHops);   // item 7 gate
        }
      }
    }
    return;
  }
  if (raw[0]==AGG_JOIN_MAGIC && len >= AGG_HDR_BYTES + AGG_REC_WIRE + AGG_CRC_BYTES){
    uint8_t k = raw[3];
    int need = AGG_HDR_BYTES + (int)k*AGG_REC_WIRE + AGG_CRC_BYTES;
    if (raw[1]==WIRE_VER && k>0 && k<=AGG_PKT_MAX_REC && len==need && raw[need-1]!=crc8(raw, need-1)) g_crcFail++;   // v7.28.27
    if (raw[1]==WIRE_VER && k>0 && k<=AGG_PKT_MAX_REC && len==need
        && raw[need-1]==crc8(raw, need-1)){
      uint8_t inHops = raw[2];
      for (uint8_t i=0;i<k;i++){
        int o = AGG_HDR_BYTES + (int)i*AGG_REC_WIRE;
        uint8_t sid = raw[o];
        uint32_t tok = (uint32_t)raw[o+1] | ((uint32_t)raw[o+2]<<8)
                     | ((uint32_t)raw[o+3]<<16) | ((uint32_t)raw[o+4]<<24);
        if (sid==0 || sid==(uint8_t)NODE_ID) continue;
        demandNote(sid);   // v7.28.2: distinct joiners, echo-proof
        if (g_role == 3) {
          tkOnJoinReq(sid);                 // TK admits every record in the aggregate
        } else if (aggReaggregate(sid, tok, inHops)) {   // v7.28.102 item 7: helper, one-shot equal depth. The v7.28.101 strict gate and its comment are inside it.
          // (re-aggregated inside aggReaggregate)
        }
      }
    }
    return;
  }
  if(telemetryReceive(raw,len)||telemetryReceiveAggregate(raw,len))return;
  if (raw[0] == AGG_POS_MAGIC) {
    handleAggPos(raw, len);
    return;
  }
  if (raw[0]=='J' && len==(int)sizeof(JoinPkt)){
    const JoinPkt* j = (const JoinPkt*)raw;
    if (j->src_id != g_secureRxSender) { g_senderBindReject++; return; }
    if (j->ver == WIRE_VER && j->crc != crc8(raw, sizeof(JoinPkt)-1)) g_crcFail++;   // v7.28.27
    if (j->ver == WIRE_VER && j->crc == crc8(raw, sizeof(JoinPkt)-1)
        && j->src_id != 0 && j->src_id != (uint8_t)NODE_ID){
      // every node counts overheard joins, same as the old type 2 path did,
      // but only the TK acts on one.
      demandNote(j->src_id);   // v7.28.2: distinct joiners
      if (g_role == 3) tkOnJoinReq(j->src_id);
    }
    return;
  }
  if (raw[0]=='K'){
    // a schedule style frame. Only ver 9 is ours; any other version badge on
    // air is mutually deaf by design, drop it silently instead of
    // mis-parsing it. v7.2 bumped 8 to 9: the JOIN and SEED payload meaning
    // changed, so a v8 board and a v9 board must not think they can talk.
    if (!g_benchDropSched && len >= (int)BEACON_WIRE_FIXED_B && raw[1]==WIRE_VER   // v7.29.39: the volatile Y fixture drops schedule packets only while member packets continue, proving indirect liveness. v7.28.37: gate on the fixed head only; handleSched reads nSlots and rejects any frame shorter than beaconWireB(nSlots), so a truncated beacon is dropped there, not mis-parsed here.   // v7.14.0: wire ver 19 (was 18). Second half of the stamp-fresh anchor fix; both receive gates and the s.ver build site move together. v7.13.2: dispatcher wire-gate, ver 18 (was 17 here). Second half of the v7.13.0 miss: this gate drops the frame before handleSched ever sees it, so it has to move with the build site too. Must match handleSched (s->ver != 18) and the s.ver build site. This is exactly the lockstep the old 15/16 note warned about, and the warning was not heeded on the 17->18 bump.
        && raw[2] != (uint8_t)NODE_ID)          // never our own echo
      handleSched(raw,len,rssi,snr,snrRaw);
    return;
  }
  // member data, join request, or a SEED part: exactly 9 bytes, known type,
  // never our own id. v7.2 adds 3 (seed lat), 4 (seed lon), 5 (seed alt).
  // v7.6: CRC-8 guard, drop silently on any bit flip before it ever reaches
  // the roster, the peer table, or a phantom node id on the dashboard.
  if (len == (int)sizeof(MemberPkt)){
    const MemberPkt* p = (const MemberPkt*)raw;
    if (p->crc != crc8(raw, sizeof(MemberPkt)-1)) { g_crcFail++; return; }   // v7.28.27: was a silent drop
    // Origin copies must be sealed by their origin. Forwarded copies must be
    // sealed by the relay named in the mutable hop field. The original officer
    // id remains intact for end-to-end sequence and liveness accounting.
    if ((p->hops == 0 && p->src_id != g_secureRxSender) ||
        (p->hops > 0 && (p->relayerId == 0 || p->relayerId != g_secureRxSender))) {
      g_senderBindReject++;
      return;
    }
    // v7.28.102 CHUNK 4 CORRECTION: this gate excluded MEMBER_TYPE_SWARM_REQ (7)
    // ever since the type was introduced at v7.28.5. Confirmed unchanged in v100
    // (hardware-proven) and v101: this is not a Chunk 3/4 regression, it predates
    // all of it. Every swarm-request packet any board has ever transmitted,
    // including the original v7.28.6 resigned-keeper failover, was dropped right
    // here, before handleMember ever ran, on every version flashed to date. This
    // is the missing half of the v100 walk's unexplained finding: node 02 sent
    // exactly one 0xFB failover request and there was never any confirmation the
    // keeper acted on it, because it never reached the code that would have.
    // Widened to admit type 7 specifically, not the range generally: every branch
    // inside handleMember tests an explicit type value or an explicit small OR-list
    // (checked before this change), so a type-7 packet cannot be misread as some
    // other type by falling into a range check meant for it.
    // v7.29.2: type 8 (MEMBER_TYPE_RELAY_PLEA) added here for the same reason. v7.29.1 added
    // the type but never widened this gate, so every plea was dropped RIGHT HERE before
    // handleMember ran. Same defect class as the type-7 omission above; named, not ranged.
    if ((p->type <= 6 || p->type == MEMBER_TYPE_SWARM_REQ || p->type == MEMBER_TYPE_RELAY_PLEA || p->type == MEMBER_TYPE_AGG_DEMAND) && p->src_id != 0 && p->src_id != NODE_ID)
      handleMember(raw,len,rssi,snr,snrRaw);
  }
}
void radioPoll() {
  if (!g_radioOk || !g_loraIrq) return;
  g_loraIrq = false;
  { uint32_t lat = (uint32_t)(esp_timer_get_time() - g_loraIrqUs);   // v7.28.27: IRQ-to-service latency
    if (lat > g_irqLatMaxUs) g_irqLatMaxUs = lat;
    if (lat > 5000UL && g_irqLatOver < 65535U) g_irqLatOver++; }
  // v7.28.38: is THIS service the first one after a marked transmit? Capture it
  // now and count every service since that transmit, so the record below fires
  // exactly once and the missed-frame branch can tell a never-fired beacon
  // (count 0) from one that fired and was rejected (count >= 1, detail in aux 12).
  bool firstAfterTx = g_awaitFirstRxSvc;
  g_awaitFirstRxSvc = false;
  if (g_svcSinceTx < 0xFFFFU) g_svcSinceTx++;
  // v7.28.102 CHUNK 3 ITEM 4: 128 -> 256. The SX126x delivers up to 255 bytes and
  // aggFlush transmits up to AGG_PKT_MAX_REC (50) records, 255 bytes. The clamp below
  // used to cut that to 128, the dispatcher's len == need test then failed, and the
  // whole aggregate was dropped with NO witness of any kind. Any flush over 24 records
  // vanished silently, and the drain-at-50-per-frame the birth-frame design assumed
  // was never reachable. Never exercised on hardware (zero 0xAA transmits in the
  // v7.28.100 walk), found by reading the buffer first. Chunk 3 flushes one record at
  // a time so this cut would not have hit it, but the resigned-keeper path and any
  // later fat flush share this exact read, and a silent drop is the worst kind.
  // 256 also leaves the birth beacon (48 + 64 = 112) and every other type with headroom.
  uint8_t buf[256];
  uint16_t irqW = (uint16_t)lsmIrqRead();                      // v7.28.28: read BEFORE readData, which clears it
  if ((irqW & RADIOLIB_SX126X_IRQ_TIMEOUT) && !(irqW & RADIOLIB_SX126X_IRQ_RX_DONE) && !(irqW & RADIOLIB_SX126X_IRQ_HEADER_ERR)) {
    // v7.28.72-symbvalid: a validation fell through and the chip raised TIMEOUT.
    // Counted for the aux 18 per-second witness, then a full re-arm, because a
    // timeout on the SX126x ends the receive. If this fires at hundreds per
    // second on the B build the chip is NOT staying in continuous receive
    // across a failed validation and the design moves to single receive per
    // slot; that is the question this witness exists to answer.
    g_rxSymbTimeout++;
    lsmRxArm();
    return;
  }
  if ((irqW & RADIOLIB_SX126X_IRQ_HEADER_ERR) && !(irqW & RADIOLIB_SX126X_IRQ_RX_DONE)) {
    // v7.28.29: header abort. No packet completed; witness it, then re-arm; startReceive clears the register.
    g_hdrAbort++;
    float ir = radio.getRSSI(false);
    int16_t irRssi = rnd16(ir);
    uint32_t offA = 0xFFFFUL;
    if (g_frameAnchorUs != 0 && (uint64_t)g_loraIrqUs >= g_frameAnchorUs) {
      uint64_t d = ((uint64_t)g_loraIrqUs - g_frameAnchorUs) / 100ULL;
      offA = (d > 0xFFFEULL) ? 0xFFFEUL : (uint32_t)d;
    }
    logRecRf(LOG_RF, NODE_ID, g_role, 11,
             (int16_t)(g_hdrAbort > 32767UL ? 32767 : g_hdrAbort),
             (int16_t)(g_hdrRescue > 32767UL ? 32767 : g_hdrRescue),
             (uint32_t)irqW | (offA << 16),
             (int8_t)(irRssi < -128 ? -128 : (irRssi > 127 ? 127 : irRssi)), 0, 0);
    if (firstAfterTx)                                                  // v7.28.38: first service after a transmit landed as a header abort
      logRecRf(LOG_RF, NODE_ID, g_role, 12, (int16_t)irqW, (int16_t)0,
               ((uint32_t)1u << 16),                                   // data hi16 = path 1 (header abort), lo16 pktLen 0
               (int8_t)(irRssi < -128 ? -128 : (irRssi > 127 ? 127 : irRssi)), 0,
               (int16_t)(offA > 0x7FFEUL ? 0x7FFE : (int16_t)offA));   // v7.28.41: snrRaw = frame offset (100us units, 0xFFFE=no anchor) to place the abort vs the beacon window
#ifdef LSM_ABORT_REARM
    lsmRxArm();                                                        // pre-v7.28.72 path: full startReceive after every header abort
#else
    // v7.28.72-symbvalid: NO full re-arm after a header abort. In continuous
    // receive the modem returns to preamble search by itself after a header
    // failure; the startReceive that used to sit here restarted the
    // demodulator, and when the abort came late it landed inside the next real
    // preamble. The 2026-09-16 capture put delivery at 0.46 when an abort was
    // witnessed in the 12 ms before a packet against 0.74 otherwise. Only the
    // IRQ register is cleared, which DIO1 needs (RadioLib attaches a rising
    // edge; a flag left set holds the line high and no later IRQ is seen).
    // The 30 s receiver watchdog in houseTick remains the safety net for a chip
    // that does wedge. Build with -D LSM_ABORT_REARM to restore the old path.
    radio.clearIrq();
    g_abortNoRearm++;
#endif
    return;
  }
  size_t n = securePacketLength();
  size_t nChip = n;                                                     // v7.28.28: length as the chip reported it, before the clamp
  if (n > sizeof(buf)) n = sizeof(buf);
  if (n == 0) g_rdFail++;                                              // v7.28.27: RxDone with nothing to read
  int16_t st = secureRead(buf, n);
  // v7.28.29: validity from the IRQ word, as RadioLib master does it. A CRC_MISMATCH
  // from readData on a word that is not bad is a stale HeaderErr from an earlier
  // abort; the buffer is already filled and the packet is good.
  { bool badW = (irqW & RADIOLIB_SX126X_IRQ_CRC_ERR) ||
                ((irqW & RADIOLIB_SX126X_IRQ_HEADER_ERR) && !(irqW & RADIOLIB_SX126X_IRQ_HEADER_VALID));
    if (st == RADIOLIB_ERR_CRC_MISMATCH && !badW) { st = RADIOLIB_ERR_NONE; g_hdrRescue++; } }
  if (st != RADIOLIB_ERR_NONE) { g_rdFail++; g_rdLastErr = st; }        // v7.28.27: the silent fall-through, now counted
  if (firstAfterTx) {                                                   // v7.28.38: first service after a transmit went through readData
    uint32_t off12 = 0xFFFFUL;                                          // v7.28.41: frame offset for the aux 12 stamp, same formula as aux 10/11
    if (g_frameAnchorUs != 0 && (uint64_t)g_loraIrqUs >= g_frameAnchorUs) {
      uint64_t d = ((uint64_t)g_loraIrqUs - g_frameAnchorUs) / 100ULL;
      off12 = (d > 0xFFFEULL) ? 0xFFFEUL : (uint32_t)d;
    }
    logRecRf(LOG_RF, NODE_ID, g_role, 12, (int16_t)irqW, st,
             ((uint32_t)(nChip > 0xFFFFu ? 0xFFFFu : nChip)) | ((uint32_t)(st == RADIOLIB_ERR_NONE ? 3u : 2u) << 16),   // data hi16 = path 3 good / 2 read-fail, lo16 = chip pktLen
             0, 0,
             (int16_t)(off12 > 0x7FFEUL ? 0x7FFE : (int16_t)off12));    // v7.28.41: snrRaw = frame offset (100us units, 0xFFFE=no anchor)
  }
  if (st != RADIOLIB_ERR_NONE || nChip == 0) {
    // v7.28.28: per-failure witness. Packet status is valid after any RxDone
    // regardless of CRC, so the same triple read the good path uses applies.
    float fr = radio.getRSSI(); if (fr == 0.0f) fr = radio.getRSSI();
    float fs = radio.getSNR();  if (fr == 0.0f) fr = radio.getRSSI(); // intentional post-SNR RSSI retry; zero SNR is valid
    int16_t frRssi = rnd16(fr); int16_t frSnrRaw = rnd16(fs * 4.0f);
    uint32_t offW = 0xFFFFUL;
    if (g_frameAnchorUs != 0 && (uint64_t)g_loraIrqUs >= g_frameAnchorUs) {
      uint64_t d = ((uint64_t)g_loraIrqUs - g_frameAnchorUs) / 100ULL;
      offW = (d > 0xFFFEULL) ? 0xFFFEUL : (uint32_t)d;
    }
    logRecRf(LOG_RF, NODE_ID, g_role, 10,
             (int16_t)(nChip > 32767 ? 32767 : nChip), st,
             (uint32_t)irqW | (offW << 16),
             (int8_t)(frRssi < -128 ? -128 : (frRssi > 127 ? 127 : frRssi)),
             (int8_t)rnd16(fs), frSnrRaw);
  }
  if (st == RADIOLIB_ERR_NONE){
    g_lastRxMs = millis();
    if (!g_radioElectionReady) radioElectionGateSet(true, g_lastRxMs);
    g_radioRecoverRequested = false;
    g_radioFirstFaultStage = 0;
    g_radioFirstFaultStatus = 0;
    g_rxCount = g_rxCount + 1;  // ctok 2026-07-21: plain assign, avoids C++20 -Wvolatile on ++
    // v7.13.3: RF CAPTURE FIX. Two separate defects lived in this block.
    //
    // (1) snrRaw was a hardcoded literal 0. LogRec.snrRaw was therefore 0 on
    //     100% of RX records, on every board, fleet-wide, for as long as the
    //     field has existed. Confirmed on boards 06 and 08 under v7.13.2:
    //     3578/3578 and 3056/3056 records with snrRaw == 0.
    //
    // (2) radio.getRSSI() intermittently returns exactly 0.0. Same two logs:
    //     RX rssi was exactly 0 on 65.7% (06) and 73.7% (08) of records, while
    //     snr on the SAME record was valid 98.6% of the time. The rssi
    //     histogram is bimodal: a hard spike at exactly 0, plus a clean and
    //     entirely normal -1..-119 dBm distribution for the remainder. That
    //     shape is a capture dropout, NOT front-end saturation; a saturating
    //     receiver clips smoothly at the top of its range, it does not return
    //     exact zeros two thirds of the time and correct values the other
    //     third. RadioLib issues a SEPARATE GetPacketStatus SPI transaction
    //     for getRSSI() and for getSNR(), which is the mechanism by which one
    //     can fail while the other succeeds on the same packet.
    //
    // Fix is deliberately NON-BEHAVIOURAL. One retry on a zero read, and on
    // total failure rssi stays 0 exactly as it does today.
    //
    // REJECTED ALTERNATIVE, recorded because it looks correct and is not:
    // storing a -128 "no capture" sentinel in LogRec.rssi so a failed read is
    // permanently distinguishable from a real one. That value does not stay in
    // the log. It flows through handleBeacon into handleSched/handleMember and
    // straight into the direct-link RSSI floor (DIRECT_RSSI_FLOOR_DBM, -90 on this rig, v7.20.3).
    // A failed capture reads 0 today, which the floor treats as an excellent
    // link; -128 would read as unusable and would flip roughly two thirds of
    // all receptions from "direct link fine" to "fall back to relay". That is
    // a protocol behaviour change hidden inside an observability patch, and on
    // a drive test it would be indistinguishable from real range loss. The
    // dropout is instead measured by the counters and the aux=4 witness below.
    float   rssiF = radio.getRSSI();
    if (rssiF == 0.0f) rssiF = radio.getRSSI();   // one retry, loses the SPI race far less often
    float   snrF  = radio.getSNR();
    // v7.20.10: post-SNR retry. Bench v7.20.8 (boards 05/06/07): both pre-SNR
    // reads return exactly 0.0 on ~96 percent of receptions, TK and members
    // alike, while getSNR on the SAME packet succeeds 1944/1944. RadioLib 6.6.0
    // issues the identical GetPacketStatus command for both calls and parses
    // different bytes of the reply, so there is no host-side ordering effect;
    // this read is simply the third transaction, placed where transaction three
    // provably works. Non-behavioural: total failure still reads 0, and the
    // aux=4 witness below scores this fix with no new instrumentation.
    if (rssiF == 0.0f) rssiF = radio.getRSSI();
    bool    rssiOk = (rssiF != 0.0f);
    int16_t rssi   = rnd16(rssiF);
    int8_t  snr    = (int8_t)rnd16(snrF);
    int16_t snrRaw = rnd16(snrF * 4.0f);          // recovers quarter-dB, exactly the divide RadioLib applied
    g_rssiRxTotal  = g_rssiRxTotal + 1;           // plain assign, avoids C++20 -Wvolatile on ++
    if (!rssiOk) g_rssiNoCap = g_rssiNoCap + 1;
    if (rssiOk)  g_lastRssi  = rssi;              // hold the last GOOD reading, do not blank the glass on a dropout
    handleBeacon(buf, (int)n, rssi, snr, snrRaw);
    // aux 4 = RF capture-dropout witness. aux 0/1/2 are radio api errors and
    // aux 3 is the airtime witness, so 4 is the next free code. e = last good
    // rssi, n = running no-capture count, data = running total receptions.
    if ((g_rssiRxTotal & 0xFF) == 0)
      logRec(LOG_RF, NODE_ID, g_role, 4, (int16_t)g_lastRssi,
             (int16_t)(g_rssiNoCap & 0x7FFF), (uint32_t)g_rssiRxTotal);
  }
#if LSM_RX_STAY
  // v7.28.77-stayonlisten: NO startReceive after a clean receive. The chip is
  // in continuous receive and returns to preamble search on its own; the
  // startReceive that sat here restarted the demodulator inside the 800 us
  // guard before the next slot's 3 ms preamble. Clear the IRQ register only so
  // DIO1 drops and the next flag produces an edge. Counted for aux 19.
  { int16_t clearSt = radio.clearIrq();
    if (clearSt != RADIOLIB_ERR_NONE) radioFaultNote(10, clearSt); }
  g_rxNoRearm++;
#else
  lsmRxArm();                                                          // pre-v7.28.77 path: full startReceive after every clean receive
#endif
}

// ----------------------- v7 TK arbiter (command center) -----------------------
int tkRosterFind(uint8_t id){ for (int i=0;i<g_rosterN;i++) if (g_roster[i]==id) return i; return -1; }

// v7.16.0: the TK owns the join turn modulus and publishes it as joinMod.
//
// WHY THE OLD POLICY WAS WRONG, and it was the policy, not the arithmetic:
// joinModBase() returned 4 for any roster under 30. At cold start the roster
// is near zero, which is precisely when every node in the fleet is outside
// contending for the join window, and the policy therefore selected its
// SMALLEST modulus. It was sized against the population that is NOT
// contending. With IDs 05 to 12 and M=4 the fleet splits into four pairs,
// (08,12) (07,11) (06,10) (05,09), and each pair shares every single turn
// forever. Board 08's partner was board 12.
//
// (seq + NODE_ID) % M gives every ID in a block a distinct residue as long as
// M is at least the span of that block, so the correct sizing input is the ID
// SPAN the TK has actually observed, not the roster count. Span rather than
// count because IDs need not be contiguous: 1,5,9,13 is four nodes but needs
// M=16, not M=4, for the residues to separate.
//
// The v7.10.8 pressure backoff is kept, but only as a RAISER. It can widen the
// modulus when join traffic says there are more contenders than the observed
// span suggests; it can never pull it back below the span derived floor.
static uint32_t joinModEffective();
static uint8_t  g_joinIdLo = 0;   // lowest node id the TK has heard ask to join
static uint8_t  g_joinIdHi = 0;   // highest

static uint8_t tkJoinMod(){
  // v7.28.15: inside a birth frame the modulus is pure throttle. The burst slot
  // pick (NODE_ID*7 + seq*13 mod nEmpty) already separates joiners across the
  // published windows, so gating a quarter or an eighth of the backlog per birth
  // frame only stretched absorption (cold boot 2026-08-31: 94 s of tail after the
  // keeper was uncontested). Every waiting board keys in on every birth frame.
  if (g_frameType == SF_TYPE_JOIN) return 1;
  uint8_t lo = g_joinIdLo, hi = g_joinIdHi;
  for (int i = 0; i < g_rosterN; i++){          // everyone already in was a joiner once
    uint8_t id = g_roster[i];
    if (!id) continue;
    if (lo == 0 || id < lo) lo = id;
    if (id > hi) hi = id;
  }
  uint32_t m = 8;                               // floor: never smaller than the old base of 4
  if (lo != 0 && hi >= lo){
    uint32_t span = (uint32_t)(hi - lo) + 1U;
    while (m < span && m < JOIN_SLOT_MOD_MAX) m <<= 1;
  }
  uint32_t pressure = joinModEffective();       // v7.10.8, raiser only
  if (pressure > m) m = pressure;
  if (m > JOIN_SLOT_MOD_MAX) m = JOIN_SLOT_MOD_MAX;
  return (uint8_t)m;
}

void tkOnJoinReq(uint8_t id){
  if (id==0 || id==(uint8_t)NODE_ID) return;
  if (!ksIdAdmissible(id)) return;   // v7.28.59: not on the allow list, or revoked. Logged inside.
  // v7.16.0: widen the observed ID span. Done here rather than at the receive
  // site so a repeat join from an already admitted node still counts: the span
  // is about which addresses exist, not about who is currently outside.
  if (g_joinIdLo == 0 || id < g_joinIdLo) g_joinIdLo = id;
  if (id > g_joinIdHi) g_joinIdHi = id;
  int existing = tkRosterFind(id);
  if (existing >= 0) {
    // v7.11.6: a repeat join from an id already on the roster used to be a
    // silent no-op here, so a member that dropped to LISTEN client-side
    // (grant loss, a dual-TK moment, whatever) while the TK still believed
    // it was present got every retry ignored until the slow AIR_TIMEOUT_MS
    // eviction finally cleared the stale entry. Treat a repeat join as a
    // liveness signal instead: refresh the same wall-clock timer real data
    // traffic refreshes, so the node reacquires on its next schedule
    // instead of waiting out the full eviction window.
    g_lastAirFr[existing]=g_frame; g_lastAirMs[existing]=millis(); g_missedAirOpp[existing]=0;
    logRec(LOG_VOTE, id, 3, (uint8_t)NODE_ID, 0, 0, g_frame);  // role 3 = repeat-join roster refresh, not a fresh admission
    return;
  }
  // v7.10.1: the old 25 percent probabilistic admit here existed to soften
  // simultaneous-joiner collisions. That job now belongs to the deterministic
  // join turn on the member side (JOIN_SLOT_MOD), so a request that reaches
  // this point was never going to collide with another ID's request in the
  // first place, and gating it again only added a 4x delay for no remaining
  // benefit. Admit on receipt.
  // v7.19.2: make SPHERE_CAP a real admission gate. Before this the only
  // gate was V7_MAX_ROSTER (22), so the cap was purely advisory and the
  // cap-4 bench roster hit 4 while FULL_LINE=3 flagged full. FULL_LINE still
  // latches the full flag early (steering new joiners to spill); the slots
  // between FULL_LINE and SPHERE_CAP remain reachable only by a joiner that
  // raced the flag inside the debounce window, which is the cushion behaving
  // as designed. This line stops admission dead at the hard cap. Repeat
  // joins from ids already on the roster are handled above, unaffected.
  // v7.19.4: the hard-full latch makes the refusal STICKY. Once the roster has
  // touched the cap, admission stays closed even after an eviction drops the
  // count back into the cushion, until the roster falls UNDER FULL_LINE and the
  // latch releases at the beacon-build maintenance site. Without this a sphere
  // hovering at cap-1 admits and evicts in a flap right at the boundary.
  if (g_hardFull) return;
  if (g_rosterN >= SPHERE_CAP) return;
  if (g_rosterN >= V7_MAX_ROSTER) return;
  g_roster[g_rosterN]=id; g_lastAirFr[g_rosterN]=g_frame; g_lastAirMs[g_rosterN]=millis(); g_lastAirSeq[g_rosterN]=0; g_lastAirSeqValid[g_rosterN]=0; g_missedAirOpp[g_rosterN]=0;
  g_slotOf[g_rosterN]=0xFF; g_lastRelayer[g_rosterN]=0; g_lastRelayerMs[g_rosterN]=0; g_slotOfPrev[g_rosterN]=0xFF; g_seatDepth[g_rosterN]=0;   // v7.28.105: fresh seat starts at depth 0, raised by its own reports
  g_prof[g_rosterN].meanUs=PROFILE_DEFAULT_MEAN_US;   // conservative until the profile learns
  g_prof[g_rosterN].spreadUs=PROFILE_DEFAULT_SPREAD_US;
  g_prof[g_rosterN].trendUs=0; g_prof[g_rosterN].nSamp=0; g_prof[g_rosterN].tempC=0;
  // v7.28.23: a fresh member starts at the physical floor and climbs on its
  // own evidence. Explicitly zeroed here and not left to whatever the
  // previous occupant of this roster index left behind, so a recycled index
  // never inherits a stranger's drift.
  g_prof[g_rosterN].devMeanUs=GUARD_DEV_DEFAULT_MEAN_US;
  g_prof[g_rosterN].devSpreadUs=GUARD_DEV_DEFAULT_SPREAD_US;
  g_prof[g_rosterN].devSamp=0;
  g_prof[g_rosterN].guardUs=0;
  g_quar[g_rosterN]=8;  // empty slot shield until the profile converges
  ksRosterInit(g_rosterN);   // v7.28.59
  g_rosterN++;
  g_birthMaintDataAge = 0;   // v7.29.50: a join landed; allow ordinary DATA service before the next keeper-owned maintenance offer
  logRec(LOG_VOTE, id, 1, (uint8_t)NODE_ID, 0, 0, g_frame);  // admission record
  if (g_rosterN >= SPHERE_CAP && !g_hardFull) {
    g_hardFull = true;   // v7.19.4: latch the instant the cap is reached, no debounce
    logRec(LOG_STATE, NODE_ID, g_role, 0xF1, (int16_t)g_rosterN, 0, 1);   // data 1 = latched at admission
  }
}

static void seedRosterFromStandby(uint8_t failedKeeper){
  // v7.29.38: the warm successor receives the complete published slot list on
  // every schedule. Restore those seats before adding any recently heard peers,
  // so the first replacement beacon keeps the fleet roster instead of forcing
  // every member through the join funnel again.
  uint32_t nowMs = millis();
  for (uint8_t si = 0; si < g_standbyRosterN; si++) {
    uint8_t id = g_standbyRoster[si];
    if (!id || id == (uint8_t)NODE_ID || id == failedKeeper || tkRosterFind(id) >= 0) continue;
    if (!ksIdAdmissible(id)) continue;
    if (g_rosterN >= SPHERE_CAP || g_rosterN >= V7_MAX_ROSTER) break;
    int i = g_rosterN;
    g_roster[i]=id; g_lastAirFr[i]=g_frame; g_lastAirMs[i]=nowMs;
    g_lastAirSeq[i]=0; g_lastAirSeqValid[i]=0; g_missedAirOpp[i]=0;
    g_slotOf[i]=0xFF; g_slotOfPrev[i]=0xFF; g_lastRelayer[i]=0;
    g_lastRelayerMs[i]=0; g_relayParent[i]=0; g_relayParentMs[i]=0;
    g_seatDepth[i]=0;
    g_prof[i].meanUs=PROFILE_DEFAULT_MEAN_US;
    g_prof[i].spreadUs=PROFILE_DEFAULT_SPREAD_US;
    g_prof[i].trendUs=0; g_prof[i].nSamp=0; g_prof[i].tempC=0;
    g_prof[i].devMeanUs=GUARD_DEV_DEFAULT_MEAN_US;
    g_prof[i].devSpreadUs=GUARD_DEV_DEFAULT_SPREAD_US;
    g_prof[i].devSamp=0; g_prof[i].guardUs=0; g_quar[i]=8;
    ksRosterInit(i);
    g_rosterN++;
    logRec(LOG_VOTE, id, 4, (uint8_t)NODE_ID, 0, 0, g_frame); // role 4 = warm roster restore
  }
}

void seedRosterFromPeers(uint8_t failedKeeper=0){
  // v7.10.3: a board that self elects TK has never held a roster before, so
  // it always started empty, forcing every already active member to rejoin
  // from scratch on every handover, the restart the odds from zero problem
  // called out after the 06/08 TK churn bench session. g_peers[] already
  // holds recently heard members and the outgoing TK (peerSeen, v7.7), so
  // seed from that instead of leaving the new TK roster empty. This only
  // restores WHO is already known active, slot timing still starts fresh
  // and conservative for every seeded id, same as a normal join admission.
  uint32_t nowMs = millis();
  for (int i=0;i<PEER_TABLE_SIZE;i++){
    if (g_peers[i].id==0) continue;
    if (g_peers[i].id==(uint8_t)NODE_ID) continue;                // never seed self
    if (g_peers[i].id==failedKeeper) continue;                    // do not name the failed predecessor as the next backup
    if (nowMs - g_peers[i].lastMs > PEER_SEED_FRESH_MS) continue; // stale, do not seed
    if (tkRosterFind(g_peers[i].id)>=0) continue;                 // already present
    if (!ksIdAdmissible(g_peers[i].id)) continue;                 // v7.28.59: the seed is an admission site too
    if (g_rosterN >= SPHERE_CAP) break;   // v7.19.4: a TK handover cannot mint capacity past the hard cap; only tkOnJoinReq gated admission grows a sphere
    if (g_rosterN >= V7_MAX_ROSTER) break;
    uint8_t id = g_peers[i].id;
    g_roster[g_rosterN]=id; g_lastAirFr[g_rosterN]=g_frame; g_lastAirMs[g_rosterN]=nowMs; g_lastAirSeq[g_rosterN]=0; g_lastAirSeqValid[g_rosterN]=0; g_missedAirOpp[g_rosterN]=0;
    g_slotOf[g_rosterN]=0xFF; g_lastRelayer[g_rosterN]=0; g_lastRelayerMs[g_rosterN]=0; g_slotOfPrev[g_rosterN]=0xFF;
    g_prof[g_rosterN].meanUs=PROFILE_DEFAULT_MEAN_US;   // conservative until the profile learns
    g_prof[g_rosterN].spreadUs=PROFILE_DEFAULT_SPREAD_US;
    g_prof[g_rosterN].trendUs=0; g_prof[g_rosterN].nSamp=0; g_prof[g_rosterN].tempC=0;
    // v7.28.23: same floor seed as the direct admission site above.
    g_prof[g_rosterN].devMeanUs=GUARD_DEV_DEFAULT_MEAN_US;
    g_prof[g_rosterN].devSpreadUs=GUARD_DEV_DEFAULT_SPREAD_US;
    g_prof[g_rosterN].devSamp=0;
    g_prof[g_rosterN].guardUs=0;
    g_quar[g_rosterN]=8;
    ksRosterInit(g_rosterN);   // v7.28.59
    g_rosterN++;
    logRec(LOG_VOTE, id, 1, (uint8_t)NODE_ID, 0, 0, g_frame);  // seeded admission record
  }
  if (g_rosterN >= SPHERE_CAP && !g_hardFull) {
    g_hardFull = true;   // v7.19.4: inherited a roster already at cap, latch immediately
    logRec(LOG_STATE, NODE_ID, g_role, 0xF1, (int16_t)g_rosterN, 0, 2);   // data 2 = latched at handover seed
  }
}

// v7.11.1: pulls a member's latency profile 1/8 of the way back toward the
// conservative default every time that member's packet fails the same-frame
// check in handleMember(), instead of leaving the profile frozen wherever it
// last landed. Same step size as the normal EWMA update in tkOnData() below,
// just pulling toward the default instead of toward a new sample. This is
// the fix for the pegged-32767 symptom traced in
// RIG_DUAL_TK_HIDDEN_NODE_2026_07_09.md: the profile only ever updated on a
// valid same-frame sample and nothing ever pulled it back down otherwise,
// so once poisoned during a frame disagreement it stayed poisoned even
// after the disagreement cleared.
void profileDecayStep(LatProfile* pr) {
  int32_t meanDiff = pr->meanUs - (int32_t)PROFILE_DEFAULT_MEAN_US;   // v7.28.25: signed, no floor at zero
  pr->meanUs = pr->meanUs - meanDiff / 8;
  int32_t spreadDiff = (int32_t)pr->spreadUs - (int32_t)PROFILE_DEFAULT_SPREAD_US;
  int32_t newSpread = (int32_t)pr->spreadUs - (spreadDiff >> 3);
  pr->spreadUs = (uint32_t)(newSpread < 0 ? 0 : newSpread);
  // v7.28.23: the deviation statistics decay toward the FLOOR, i.e. toward
  // zero measured term, not toward a nonzero conservative default. An
  // unmeasurable member therefore relaxes back to the physical floor rather
  // than drifting up to a made-up number. This is deliberately the opposite
  // direction from the delay profile above, which decays UP toward
  // PROFILE_DEFAULT_MEAN_US. The delay profile is now observational only,
  // so its direction no longer costs airtime; the deviation profile drives
  // the schedule, so it must never inflate on absence of evidence.
  //
  // PER MEMBER, and that is the whole point. A fleet-wide average lets the
  // single worst oscillator set the guard for every board, which is
  // structurally what the old rail did.
  pr->devMeanUs   = pr->devMeanUs   - (pr->devMeanUs   >> 3);
  pr->devSpreadUs = pr->devSpreadUs - (pr->devSpreadUs >> 3);
}

// Roster liveness and timing validity are different facts. A valid relayed
// report can arrive after the keeper has advanced to another frame, so its
// sequence is too old for delay/profile calibration but still proves that the
// seated member is alive. Keep this outside tkOnData's same-frame timing gate.
static bool tkNoteAlive(uint8_t id, uint8_t seq, uint8_t hops){
  int i=tkRosterFind(id); if (i<0) return false;
  uint32_t nowMs = millis();
  uint32_t ageMs = nowMs - g_lastAirMs[i];
  if (g_lastAirSeqValid[i]) {
    uint8_t delta = (uint8_t)(seq - g_lastAirSeq[i]);
    if (delta == 0) return false;
    // The ordinary half-range rule distinguishes a late copy from a wrapped
    // sequence while traffic is flowing. After a long receive gap it can no
    // longer do that: a genuine sender may have advanced by 128..255 packets,
    // and rejecting every one creates a self-sealing recovery failure. The
    // outer AES-GCM envelope has already enforced monotonic physical replay
    // protection and memberSeenCheckAndNote rejected the live duplicate, so
    // accept a non-identical logical sequence after one third of the lease.
    if (delta >= 128 && ageMs < (AIR_TIMEOUT_MS / 3U)) return false;
  }
  if (ageMs > RESURFACE_MS) g_quar[i]=4;
  if (g_quar[i]>0) g_quar[i]--;
  g_lastAirSeq[i]=seq; g_lastAirSeqValid[i]=1;
  g_lastAirFr[i]=g_frame; g_lastAirMs[i]=nowMs;
  g_missedAirOpp[i]=0;
  if (ageMs >= 30000UL)
    logRec(LOG_STATE, NODE_ID, g_role, 0xCE, (int16_t)id, (int16_t)hops, ageMs);
  return true;
}

void tkOnData(uint8_t id, uint32_t arrivalOffUs, uint32_t departOffUs, uint8_t hops, int16_t departDevUs){
  int i=tkRosterFind(id); if (i<0) return;
  // v7.21.2: SR-6 CLOSED. A relayed copy carries the relay's hold time inside
  // the arrival instant, so arrivalOffUs is inflated by a quantity that has
  // nothing to do with the member's own propagation and everything to do with
  // when the relay got its turn on air. Feeding that into the EWMA is not a
  // noisy measurement, it is a measurement of the wrong thing. hops has been
  // on the wire since v7.18.0 and the join path at the type 2 gate has always
  // read it; the measurement path never did. This is that one conditional.
  //
  // v7.29.16: liveness bookkeeping moved to tkNoteAlive at the receive site,
  // before the same-frame timing gate. A relayed copy is still proof the member
  // is alive, while only same-frame evidence can enter the timing math below.
  //
  // The relayed frame DECAYS rather than freezing, matching the same-frame
  // miss at v7.11.1 and the branch 2 path below. Decay is the standing answer
  // to an unmeasurable frame everywhere else in this function and it stays the
  // answer here. A member that is permanently relay-only therefore walks its
  // profile to the conservative default and says so continuously through
  // branch 5, rather than holding a stale number nobody can see is stale.
  //
  // WHY THIS IS EXPECTED TO FIRE. The (src, seq) dedup means the direct copy
  // usually wins the race and this gate never sees it. Usually is not always:
  // the 2026-08-26 seven board run logged 8570 relay resends (LOG_TX aux 0xFC)
  // across the fleet in 22 minutes, roughly 1400 per member board, on a bench
  // where every board sits within a metre of every other. Every member is
  // relaying nearly every other member, so the TK gets a direct copy plus up
  // to five relayed copies of the same packet and only whichever lands first
  // is processed. Branch 5 counts precisely how often the relayed copy won.
  if (hops != 0){
    skipWitness(5, id, arrivalOffUs, departOffUs);
    if (g_slotOf[i]!=0xFF) profileDecayStep(&g_prof[i]);
    return;
  }
  if (g_slotOf[i]!=0xFF){
    // v7.28.63 KEEPER ARRIVAL WITNESS, observation only. Everything already
    // logged on this path measures the member against the MEMBER's own anchor
    // (LOG_TRIM, DRIFT role 10) or arrival against departure (DRIFT role 1).
    // Nothing measures where the frame landed against the KEEPER's own slot
    // schedule, and that is the number that moves when the two anchors drift
    // apart while each board separately believes it is on time. arrivalOffUs
    // is the reconstructed packet START in the keeper frame (rx done minus
    // measured airtime, see the call site), and tkOnData only runs under the
    // sameFrame guarantee, so the anchor instant is shared. Deliberately NOT
    // gated on the departure stamp: this record survives frames whose
    // attestation failed, which the role 10 record does not. Offline analysis
    // owns the constant center (propagation plus process lag); the signal is
    // the spread, the walk over minutes, and the per frame difference against
    // the member's own departDevUs, which is the anchor skew itself.
    {
      uint32_t expUs = g_memberBaseUs + (uint32_t)g_slotOf[i] * g_slotUsLive;
      int32_t adv = (int32_t)((int64_t)arrivalOffUs - (int64_t)expUs);
      int16_t advC = (adv > 32767) ? 32767 : ((adv < -32768) ? -32768 : (int16_t)adv);
      logRecRf(LOG_DRIFT, id, 11, g_slotOf[i], advC, 0, arrivalOffUs, 0, 0, 0);
    }
    // v7.11.2: only trust the member's stated departure now. The slot
    // inference fallback this used to fall back to on a missing or failed
    // departure stamp fed the EWMA a legacy estimate no better verified
    // than the old anchor math it replaced, a second door the profile could
    // get poisoned through, separate from the same-frame door
    // profileDecayStep() already covers. No valid departure stamp this
    // frame now means no update, decay instead, same treatment as a
    // same-frame failure.
    // v7.28.23 DEVIATION SAMPLE. This is the measurement the scheduling
    // guard is built from, and it is deliberately folded in BEFORE the delay
    // block below and under a weaker gate. A valid departOffUs means the
    // departure attestation tag verified and this member holds a slot, which
    // is everything the deviation needs. It does NOT need the arrival
    // reconstruction to be sane, so it survives the same-frame and sanity
    // clamp failures that starve the delay profile, and it is not affected
    // by the unexplained 17 ms disagreement those two guard against.
    if (departOffUs != 0xFFFFFFFFu){
      uint32_t adev = (departDevUs < 0) ? (uint32_t)(-(int32_t)departDevUs)
                                        : (uint32_t)departDevUs;
      // v7.28.23: clamp the SAMPLE, not the result. A fault-scale outlier
      // must not be allowed to drag a whole board's guard up behind it. The
      // raw value is still logged below, unclamped.
      if (adev > GUARD_DEV_SAMPLE_CLAMP_US) adev = GUARD_DEV_SAMPLE_CLAMP_US;
      LatProfile* dp = &g_prof[i];
      dp->devMeanUs = dp->devMeanUs - (dp->devMeanUs>>3) + (adev>>3);
      uint32_t ddev = (adev > dp->devMeanUs) ? (adev - dp->devMeanUs)
                                             : (dp->devMeanUs - adev);
      dp->devSpreadUs = dp->devSpreadUs - (dp->devSpreadUs>>3) + (ddev>>3);
      if (dp->devSamp < 0xFFFFFFFF) dp->devSamp++;
      // RAW deviation logged every sample, independently of whatever the
      // guard is currently set to. If the formula above turns out to be the
      // wrong shape, the truth is still recoverable offline from this record
      // alone. LOG_DRIFT with role 10 is the deviation record; role 1 remains
      // the legacy delay record and decodes exactly as before. 10 sits clear
      // of the real roles 0-3 AND of role 9, already in use elsewhere as a
      // witness marker, so no decoder can misread this as a CANDIDATE record.
      //   aux = slot, e = raw signed departDevUs, n = devSpreadUs,
      //   data = devMeanUs, snrRaw = applied guard in us.
      logRecRf(LOG_DRIFT, id, 10, g_slotOf[i],
               departDevUs,
               (int16_t)(dp->devSpreadUs>32767?32767:dp->devSpreadUs),
               dp->devMeanUs, 0, 0,
               (int16_t)(dp->guardUs>32767?32767:dp->guardUs));
    }
    // v7.28.25: SIGNED. The gate arrivalOffUs >= departOffUs that stood
    // here rejected every sample where the packet arrived before its own
    // stated departure. On v7.28.24 hardware that was 460 of 514 samples,
    // because the true delay is about -300 us (both sides stamp done late,
    // see txDoneInstant). The 54 that passed were the positive tail, and the
    // decay pulled the mean toward the 15,000 default between them, so the
    // role 1 record read ~14,000 while the truth was -327. Delay is int32
    // now, clamp on magnitude only.
    if (departOffUs != 0xFFFFFFFFu){
    int32_t d = (int32_t)((int64_t)arrivalOffUs - (int64_t)departOffUs);   // OBSERVATIONAL ONLY as of v7.28.23
    if (d > -200000 && d < 200000){               // sanity clamp on magnitude
      LatProfile* pr = &g_prof[i];
      int32_t oldMean = pr->meanUs;
      // EWMA mean, 1/8 step, signed
      pr->meanUs = pr->meanUs - pr->meanUs / 8 + d / 8;
      // mean absolute deviation as the spread, same 1/8 step
      uint32_t dev = (uint32_t)((d > pr->meanUs) ? (d - pr->meanUs) : (pr->meanUs - d));
      pr->spreadUs = pr->spreadUs - (pr->spreadUs>>3) + (dev>>3);
      // signed trend: how the mean is moving, x256 fixed, slow 1/64 blend
      int32_t step = (pr->meanUs - oldMean) * 256;
      pr->trendUs = pr->trendUs - (pr->trendUs>>6) + (step>>6);
      if (pr->nSamp < 0xFFFFFFFF) pr->nSamp++;
      // v7.20.19 DRIFT FIELD CHANGE, records before this patch decode differently.
      // aux = slot, data = meanUs (full uint32, was clamped into e at 32767),
      // e = applied guard in 2 us units (guard clamps at PROFILE_MAX_US 40000,
      // which is itself above the int16 ceiling, so it is halved rather than
      // saturated), n = spreadUs (still clamped, a mean absolute deviation is
      // an order below the mean and has not been observed near the rail),
      // snrRaw = trend. The frame number is dropped: every record already
      // carries absolute ms and frame served only cross node correlation.
      // v7.28.25 DECODE CHANGE: data is the SIGNED mean, reinterpret the
      // uint32 as int32. Records before this patch are unsigned.
      logRecRf(LOG_DRIFT, id, 1, g_slotOf[i],
               (int16_t)(pr->guardUs>>1),
               (int16_t)(pr->spreadUs>32767?32767:pr->spreadUs),
               (uint32_t)pr->meanUs, 0, 0, (int16_t)(pr->trendUs>>8));
    } else {
      // v7.20.24: over the 200 ms sanity clamp. A delay this large is not a
      // propagation measurement, it is the TK and the member disagreeing about
      // the frame geometry by at least one relay tier (133016 us) or two member
      // slots (114752 us). Silent before this patch.
      skipWitness(3, id, arrivalOffUs, departOffUs);
    }
    } else {
      // v7.11.2: no valid departure stamp this frame, decay instead of
      // falling back to the legacy slot-inferred estimate.
      // v7.20.24: two different failures arrive here and only one of them was
      // ever explicable. A missing departure offset was already named at the
      // call site as branch 1 or branch 4. An arrival that reconstructs BEFORE
      // its own departure is a third thing entirely, it means the TK placed the
      // member later in the frame than the member actually transmitted, and it
      // latches for as long as the disagreement lasts. That is the leading
      // suspect for the 2026-08-26 stoppage and it gets its own branch.
      // v7.28.25: branch 2 (arrival before departure) can no longer reach
      // here, a negative delay is now a valid sample above. Retired in place,
      // the branch number is not reused.
      profileDecayStep(&g_prof[i]);
    }
  }
}

void tkBuildAndSend(){
  g_frame++;
  g_ent = entMix(g_ent ^ g_loraIrqCyc ^ g_frame);
  // v7.29.25: count missed TRANSMISSION OPPORTUNITIES, not miles and not
  // merely elapsed wall time. g_slotOf still describes the DATA frame that
  // just ended here. A JOIN frame grants no member slots and therefore cannot
  // age a member. Any authenticated direct or relayed packet has already put
  // g_lastAirFr on the preceding frame and resets the run.
  for (int i=0; i<g_rosterN; i++) {
    if (g_slotOf[i] >= V7_SLOTS_MAX) continue;
    bool aliveLastFrame = (g_lastAirFr[i] == (g_frame - 1U));
    if (aliveLastFrame) g_missedAirOpp[i] = 0;
    else if (g_missedAirOpp[i] < 255) g_missedAirOpp[i]++;
  }
  // Evict only when BOTH guards agree: at least the established 90-second
  // floor has elapsed, and the member missed enough actual grants.
  // v7.29.54: use the larger of the seat's authenticated uplink depth and the
  // active sphere depth. A newly deep seat can still have local depth zero at
  // the keeper until its first full uplink survives every relay; judging it as
  // direct in that interval is circular and caused the measured H6 eviction.
  // Sixteen extra opportunities per tier reflects multiplicative relay loss,
  // while the existing 255-opportunity cap keeps true silence bounded.
  for (int i=g_rosterN-1;i>=0;i--){
    uint8_t effectiveDepth = g_seatDepth[i] > g_schedTiers ? g_seatDepth[i] : g_schedTiers;
    uint16_t missLimit = (uint16_t)32U + (uint16_t)effectiveDepth * 16U;
    if (missLimit > 255U) missLimit = 255U;
    if (millis() - g_lastAirMs[i] > AIR_TIMEOUT_MS && g_missedAirOpp[i] >= missLimit){
      // v7.29.16: make every timeout eviction directly gradeable. e = member
      // id, n = highest observed hop depth, data = last-valid-traffic age ms.
      logRec(LOG_STATE, NODE_ID, g_role, 0xCD, (int16_t)g_roster[i],
             (int16_t)g_missedAirOpp[i], millis() - g_lastAirMs[i]);
      logRec(LOG_STATE, NODE_ID, g_role, 0xD0, (int16_t)g_roster[i],
             (int16_t)effectiveDepth, millis() - g_lastAirMs[i]);
      tkRosterDrop(i);   // v7.28.59: one compaction helper for every eviction site
    }
  }
  // v7.28.21: snapshot BEFORE the wipe. Must sit after the eviction loop
  // above, which compacts g_roster and g_slotOf together, so that
  // g_slotOfPrev[i] still describes g_roster[i].
  for (int i=0;i<g_rosterN;i++) g_slotOfPrev[i]=g_slotOf[i];
  for (int i=0;i<g_rosterN;i++) g_slotOf[i]=0xFF;
  // v7.30.0 STABLE FITTING ROSTER.  When every seated member fits in this
  // frame, keep the candidate order deterministic by node id.  The former
  // entropy shuffle moved every member to a new slot on every frame.  A
  // member acting on a one-frame-late relayed beacon could therefore transmit
  // in the previous owner's slot and collide even though there was ample
  // capacity.  Rotation is useful only when the roster exceeds the published
  // slot array and somebody must wait; retain the staleness/fairness path for
  // that oversubscribed case.
  int idx[V7_MAX_ROSTER]; int m=0;
  for (int i=0;i<g_rosterN;i++) idx[m++]=i;
  int cap = m<V7_SLOTS_MAX?m:V7_SLOTS_MAX;
  const bool allFit = (m <= (int)V7_SLOTS_MAX);
  if (allFit) {
    for (int i=0;i<m;i++) for (int j=i+1;j<m;j++)
      if (g_roster[idx[j]] < g_roster[idx[i]]) { int t=idx[i];idx[i]=idx[j];idx[j]=t; }
  } else {
    for (int i=0;i<m;i++) for (int j=i+1;j<m;j++)
      if (g_lastAirFr[idx[j]]<g_lastAirFr[idx[i]]){ int t=idx[i];idx[i]=idx[j];idx[j]=t; }
  }
#if LSM_ROTATE_GUARANTEE
  // v7.29.0 ROTATION GUARANTEE, per Stuart. The staleness sort above is by FRAME count
  // (g_lastAirFr), which does not track wall-clock age when the superframe length varies, so a
  // node near the AIR_TIMEOUT_MS eviction can sit behind a fresher one that merely missed more
  // short frames. Pull every member whose wall-clock last-heard age has passed HALF the eviction
  // window to the front, in stable order, so it is NAMED a slot before anyone fresher and cannot
  // be evicted for two bad shuffles in a row. Everyone else keeps the order and the shuffle.
  int rotGuarN = 0;
  { uint32_t nowMs = millis(); uint32_t floorMs = AIR_TIMEOUT_MS / 2U;
    static int reord[V7_MAX_ROSTER]; int w = 0;
    if (!allFit) {
      for (int i=0;i<m;i++) if ((uint32_t)(nowMs - g_lastAirMs[idx[i]]) >= floorMs) reord[w++] = idx[i];
      rotGuarN = w;
      for (int i=0;i<m;i++) if ((uint32_t)(nowMs - g_lastAirMs[idx[i]]) <  floorMs) reord[w++] = idx[i];
      for (int i=0;i<m;i++) idx[i] = reord[i];
    }
  }
#else
  const int rotGuarN = 0;
#endif
  // shuffle only the non-guaranteed tail; the guaranteed head stays named-first. With rotGuarN 0
  // this is byte-for-byte the original v7.22.0 Fisher-Yates over idx[0..cap-1].
  if (!allFit) for (int i=cap-1;i>rotGuarN;i--){ g_ent=entMix(g_ent); int j=rotGuarN + (int)(g_ent%(uint32_t)(i-rotGuarN+1)); int t=idx[i];idx[i]=idx[j];idx[j]=t; }
  // propagation-aware placement: earliest slot whose measured arrival window
  // clears every placed arrival at this antenna
  SchedBeacon s; memset(&s,0,sizeof(s));
  s.magic='K'; s.ver=WIRE_VER; s.tkId=(uint8_t)NODE_ID; s.seq=(uint8_t)g_frame; s.sphere=g_tkEpoch;   // v7.14.0: wire ver 19 (was 18), stamp-fresh anchor fix. sFlags bits 1..7 carry per-hop jitter residual for relayed-anchor recovery; TK itself writes 0 there (schedHops==0, no residual). Wire size UNCHANGED at 54B (bits 1..7 of sFlags were reserved-unused). v7.13.0: wire ver 18 (was 17). +schedTiers/resizeTiers/resizeCountdown, 51B->54B, ZERO airtime cost.
  // v7.12.5: TK-directed frequency switch, published as-is every frame while
  // pending. Members read this fresh off whatever beacon they last heard, no
  // local timer, so a missed frame or two just means a lower number next time.
  s.freqTargetMHz = g_freqTargetMHz;
  s.freqCountdown = g_freqCountdown;
  s.subFrame = SF_PACK(g_frameType, g_frameTypeTarget, g_frameTypeCountdown);   // v7.17.0 typed superframe: publish current/target/countdown in the one existing byte
  s.tkScore = electPubScore();   // v6.1: clamped score plus the tie tuple
  s.tkRssiAvg = (int8_t)(g_peerRssiAvg < -127 ? -127 : (g_peerRssiAvg > 0 ? 0 : g_peerRssiAvg));
  s.tkTie = electPackTie();
  s.nodeCount = (uint8_t)(g_rosterN > 255 ? 255 : g_rosterN);   // v6.6: sphere occupancy
  // v7.19.0 brick3: flag full at FULL_LINE (floor(CAP*0.8)), NOT the hard cap, so the
  // 20 percent cushion is reserved for returning migrants and reopen == full is self-halting.
  if (g_rosterN >= LSM_FULL_LINE) { if (g_fullSinceMs==0) g_fullSinceMs=millis(); g_belowLineSinceMs=0; }
  else { g_fullSinceMs=0; if (g_belowLineSinceMs==0) g_belowLineSinceMs=millis(); }
  // v7.19.4 two-tier full. Tier 1 above is the WARNING: roster at or over
  // FULL_LINE, debounced SPHERE_FULL_HOLD_MS, v6.6 behavior unchanged. Tier 2
  // is the HARD latch: set the instant the roster reaches SPHERE_CAP at any
  // admission site, cleared ONLY here and ONLY when the roster has fallen back
  // UNDER FULL_LINE (evictions run just before the beacon builds, so this sees
  // the post-eviction count). On at 100 percent, off under 80 percent.
  if (g_rosterN >= SPHERE_CAP) g_hardFull = true;   // covers any growth path this maintenance did not see
  else if (g_hardFull && g_rosterN < LSM_FULL_LINE) {
    g_hardFull = false;
    logRec(LOG_STATE, NODE_ID, g_role, 0xF1, (int16_t)g_rosterN, 0, 0);   // data 0 = latch released under the line
  }
  s.sFlags = (uint8_t)(((g_fullSinceMs && millis()-g_fullSinceMs >= SPHERE_FULL_HOLD_MS) || g_hardFull) ? 0x01 : 0x00);  // v6.6 debounced line flag OR v7.19.4 instantaneous hard latch
  // v7.29.45: restored standby seats are intentionally preserved for rapid
  // roster continuity, but a restored seat is not proof that the board is
  // still alive. The triple-failover bench exposed the difference: keeper 04
  // restored offline node 01, then named 01 as successor and left every live
  // survivor on the slow candidate path. Name the lowest roster member that
  // has also produced a recent authenticated peer report and is not itself a
  // keeper. If none qualifies, publish zero and let the deterministic
  // candidate fallback choose from live keepalives.
  {
    uint8_t best = 0;
    uint32_t nowMs = millis();
    uint32_t freshMs = tkSuccessorPeerMs();
    for (int i = 0; i < g_rosterN; i++) {
      uint8_t id = g_roster[i];
      if (!id) continue;
      if (!keeperEligibleId(id)) continue;
      bool freshMember = false;
      for (int p = 0; p < PEER_TABLE_SIZE; p++) {
        if (g_peers[p].id != id) continue;
        freshMember = g_peers[p].role != 3 &&
                      g_peers[p].lastMs != 0 &&
                      (uint32_t)(nowMs - g_peers[p].lastMs) <= freshMs;
        break;
      }
      if (freshMember && (best == 0 || id < best)) best = id;
    }
    s.successor = best;
  }
  s.schedHops=0;
  memcpy(g_heardPub, g_heardAccum, 8);
  memset(g_heardAccum, 0, 8);
  memcpy(s.heardMask, g_heardPub, 8);
  s.slotUs10 = membercapacity::wireUnits(g_slotUsLive);
  // v7.16.0: publish the join reservation and the join turn modulus. These are
  // the two bytes that stop a member inferring the join window from its own
  // constants, on exactly the reasoning schedTiers was published under in
  // v7.13.0: a member never infers it, it is told, so the TK and the member
  // cannot disagree about where member slots start.
  g_joinMod      = g_hardFull ? 0 : tkJoinMod();   // v7.19.4: 0 = join closed while hard-full latched; the member side already treats 0 as closed and guards the modulus
  s.joinResUs500 = (uint8_t)(g_joinResUs / 500U);
  s.joinMod      = g_joinMod;
  // v7.22.0 ROTATION. The loop below used to walk the roster from index 0 and
  // break on the first unheard member, and the schedule beacon carries exactly
  // ONE (relayForId, relayById) pair, so the first unheard entry took the only
  // assignment there is, on every single beacon, forever. Simulated over 6000
  // frames against the v7.21.3 source: with ten or more unheard members the
  // entries low in the roster were served on every frame and the entries below
  // roughly index six were served ZERO times. Not delayed, never. A member
  // that can only be reached through a relay and sits late in the roster could
  // therefore never be named, and there is no mechanism anywhere else that
  // would have surfaced that, because from the TK side it simply looks like a
  // member that stays unheard.
  // The cursor makes the single assignment round robin across everyone who
  // needs it. Same simulation with rotation: twenty unheard members each
  // served an even 300 times out of 6000 frames, spread zero.
  // The parent named is the LATCHED one rather than the most recent relayer,
  // per the latch block up with g_lastRelayer.
  s.relayForId = 0; s.relayById = 0;
  s.relayForId2 = 0; s.relayById2 = 0;   // v7.28.104
  int relayI1 = -1;                       // v7.28.104: roster index of the pair-1 member
  if (g_rosterN > 0) {
    uint32_t nowMs = millis();
    for (int k = 0; k < g_rosterN; k++) {
      int i = (int)(((uint32_t)g_relayGrantCursor + (uint32_t)k) % (uint32_t)g_rosterN);
      uint8_t sp = g_slotOfPrev[i];   // v7.28.21: previous frame's slot, matches g_heardPub
      if (sp >= V7_SLOTS_MAX) continue;
      bool heard = (g_heardPub[sp >> 3] >> (sp & 7)) & 1u;
      if (heard) continue;                      // direct copy arrived, no relay needed
      uint8_t par = g_relayParent[i];
      if (par != 0 && (uint32_t)(nowMs - g_relayParentMs[i]) >= relayParentHoldMs())
        par = 0;                                // latch expired, that path stopped working
      if (par == 0 && (uint32_t)(nowMs - g_lastRelayerMs[i]) < relayParentHoldMs()) par = g_lastRelayer[i];     // no live latch, fall back to most recent
      if (par == 0) continue;                   // nothing has ever relayed for this member
      s.relayForId = g_roster[i];
      s.relayById  = par;
      relayI1 = i;
      g_relayGrantCursor = (uint8_t)((i + 1) % g_rosterN);
      break;
    }
    // v7.28.18: nobody needed a relay this frame, so name a probe relayer instead:
    // the next directly-heard member in roster order. relayForId stays 0, which
    // the member side already reads as no data assignment. A deep board that
    // hears this member gets a schedule copy without any board guessing.
    if (s.relayById == 0) {
      for (int k = 0; k < g_rosterN; k++) {
        int i = (int)(((uint32_t)g_relayProbeCursor + (uint32_t)k) % (uint32_t)g_rosterN);
        uint8_t sp = g_slotOfPrev[i];   // v7.28.21: previous frame's slot, matches g_heardPub
        if (sp >= V7_SLOTS_MAX) continue;
        if (!((g_heardPub[sp >> 3] >> (sp & 7)) & 1u)) continue;   // not heard directly, cannot relay hop 1
        s.relayById = g_roster[i];
        g_relayProbeCursor = (uint8_t)((i + 1) % g_rosterN);
        break;
      }
    }
    // v7.28.104 SECOND NAMED PAIR, same rules as the first, never the same forwarder.
    // (a) a second known path to the pair-1 member: its most recent relayer, when that
    //     differs from the parent named in pair 1;
    // (b) else the next unheard member in the rotation with a live or recent relayer;
    // (c) else a second hop-1 probe, the next directly heard member not already named.
    {
      uint32_t nowMs2 = millis();
      if (s.relayForId != 0 && relayI1 >= 0) {
        uint8_t alt = (uint32_t)(nowMs2 - g_lastRelayerMs[relayI1]) < relayParentHoldMs() ? g_lastRelayer[relayI1] : 0;
        if (alt != 0 && alt != s.relayById && alt != s.relayForId) { s.relayForId2 = s.relayForId; s.relayById2 = alt; }
      }
      if (s.relayById2 == 0) {
        for (int k = 0; k < g_rosterN; k++) {
          int i = (int)(((uint32_t)g_relayGrantCursor + (uint32_t)k) % (uint32_t)g_rosterN);
          if (g_roster[i] == s.relayForId) continue;
          uint8_t sp = g_slotOfPrev[i];
          if (sp >= V7_SLOTS_MAX) continue;
          if ((g_heardPub[sp >> 3] >> (sp & 7)) & 1u) continue;
          uint8_t par = g_relayParent[i];
          if (par != 0 && (uint32_t)(nowMs2 - g_relayParentMs[i]) >= relayParentHoldMs()) par = 0;
          if (par == 0 && (uint32_t)(nowMs2 - g_lastRelayerMs[i]) < relayParentHoldMs()) par = g_lastRelayer[i];
          if (par == 0 || par == s.relayById) continue;
          s.relayForId2 = g_roster[i]; s.relayById2 = par;
          g_relayGrantCursor = (uint8_t)((i + 1) % g_rosterN);
          break;
        }
      }
      if (s.relayById2 == 0) {
        for (int k = 0; k < g_rosterN; k++) {
          int i = (int)(((uint32_t)g_relayProbeCursor + (uint32_t)k) % (uint32_t)g_rosterN);
          uint8_t sp = g_slotOfPrev[i];
          if (sp >= V7_SLOTS_MAX) continue;
          if (!((g_heardPub[sp >> 3] >> (sp & 7)) & 1u)) continue;
          if (g_roster[i] == s.relayById) continue;
          s.relayById2 = g_roster[i];
          g_relayProbeCursor = (uint8_t)((i + 1) % g_rosterN);
          break;
        }
      }
      if (s.relayById2 != 0) logRec(LOG_STATE, NODE_ID, g_role, 0xAD, (int16_t)s.relayForId2, (int16_t)s.relayById2, s.seq);   // v7.28.104: aux 0xAD = second pair named (0xED is the peel witness, 0xEB is pair 1), e = relayForId2, n = relayById2
    }
    g_lastRelayForId = s.relayForId; g_lastRelayById = s.relayById;   // v7.28.101: held for the LOG_MESH witness
    logRec(LOG_STATE, NODE_ID, g_role, 0xEB, (int16_t)s.relayForId, (int16_t)s.relayById, s.seq);   // v7.28.18: who was named
  }   // straight from the slot authority
  uint32_t pS[V7_SLOTS_MAX], pE[V7_SLOTS_MAX]; int pN=0;
  uint8_t taken[V7_SLOTS_MAX]; memset(taken,0,sizeof(taken));
  int maxSlot=-1;
  uint32_t lastArrEnd = g_memberBaseUs;    // v7.10.7: base shifted past the fixed join window
  uint32_t hardCap = V7_HARD_CAP_SLOTS;
  if (hardCap > V7_SLOTS_MAX) hardCap = V7_SLOTS_MAX;
#if LSM_RELAY_TIMING_V2
  const uint8_t capTiers=lsmgeometry::effectiveTiers(g_schedTiers,g_pendTiers,g_resizeCountdown,RELAY_TIERS_MAX);
  // Admit against the full frame, including worst-case granted token/aggregate
  // and maintenance tails. Never publish slots that a later short-clamp would cut.
  while(hardCap>0 && schedulerelay::frameNeed(tkSlotUsLive(hardCap),capTiers,
      relaySchedTierUsLive(hardCap),g_joinResUs,hardCap,g_slotUsLive,g_relayMemberTierUsLive,
      2*g_tokSlotUsLive+AGG_POS_SLOT_US+MAINT_TAIL_US) >
      (uint64_t)BACKHAUL_FRAME_CEIL_MS*1000ULL)hardCap--;
#endif
  if (g_frameType == SF_TYPE_JOIN) {
    // v7.28.5 BIRTH FRAME: the whole frame is join windows. No member positions
    // are scheduled this frame; members are served in the alternating DATA frame
    // (one-on-one-off, enforced by the flip logic below). Open W windows sized to
    // the waiting joiners, capped to what fits, published as EMPTY (0) so a joiner
    // picks its window straight off this beacon's own slot array. This REPLACES the
    // v7.28.0 leaf-yield, which freed only leaf slots and starved joiners when most
    // of the roster relayed: the 2026-08-29 bench saw nSlots shrink to the relay
    // count and every JOIN frame fly hollow. maxSlot is set so the frame-length math
    // below sizes the frame to hold W join transmissions; members adopt it as usual.
    // v7.28.102 CHUNK 3 ITEM 1, REVISED: demand W is now clamped exactly like
    // proactive W, not sized to the raw waiting count. The first pass let a
    // single spike in either counter publish up to hardCap (64) windows in one
    // frame, and every window costs a full g_slotUsLive whether a joiner
    // transmits into it or not: at 64 that is a 4.6 second JOIN frame, and the
    // sim run against the tree (items 2, 3, 5-8) showed that frame length, not
    // the reply-window slot count, was the real throughput limiter. A joiner
    // admitted through the aggregate tree does not consume one of these W windows
    // at all, tkOnJoinReq fires straight off the aggregate independent of W, so a
    // large W buys nothing for a multi-hop joiner and only lengthens every cycle
    // the tree needs to run its reply-window flush in. Clamping both paths to the
    // same small range keeps every JOIN frame short: more, cheaper cycles beat
    // fewer, expensive ones. Floor BIRTH_W_MIN (4): one window puts every direct
    // joiner in the same slot (the v7.28.15 sim showed that runs slower than no
    // birth frame at all). Ceiling BIRTH_W_MAX (16): a defensive bound against a
    // spike in either input counter. (g_recentJoinReqCount is a uint8_t capped at
    // 250 in this source, so the 10216 figure once attributed to it did not come
    // from this variable as it stands here; the ceiling holds regardless of where
    // a bad count would come from.)
    uint32_t waiting = (g_swarmReqCount > g_recentJoinReqCount) ? g_swarmReqCount : g_recentJoinReqCount;
    uint32_t W = waiting;
    if (W < BIRTH_W_MIN) W = BIRTH_W_MIN;
    if (W > BIRTH_W_MAX) W = BIRTH_W_MAX;
    if (W > hardCap) W = hardCap;   // belt and suspenders; hardCap (64) is never the binding limit here
    if (g_birthProactive) {
      W = g_recentJoinReqCount;
      if (W < BIRTH_W_MIN) W = BIRTH_W_MIN;
      if (W > BIRTH_W_MAX) W = BIRTH_W_MAX;
      if (W > hardCap) W = hardCap;
    }
    // v7.28.104: cold first birth. A freshly born TK owes one wide first birth so
    // the empty cold sphere opens a join window for every reachable relay tier,
    // not the BIRTH_W_MIN floor of 4. Overrides demand and proactive sizing for
    // this one frame only; the flag is cleared here as the beacon is built.
    if (g_coldBirthWindows) {
      W = COLD_BIRTH_WINDOWS;
      if (W > hardCap) W = hardCap;
      g_coldBirthWindows = false;
    }
    for (uint32_t sp = 0; sp < W; sp++) { s.slot[sp] = 0; taken[sp] = 1; }
    maxSlot = (int)W - 1;
  } else {
  for (int k=0;k<cap;k++){
    int ri=idx[k];
    // v7.28.5: leaf-yield removed. A birth frame is now handled above as a
    // dedicated all-windows frame, so this member-placement loop runs only in
    // DATA frames, where every roster member gets its position slot. The v7.28.0
    // leaf-yield (yielding leaf slots inside a JOIN frame) is gone with it.
    bool q = g_quar[ri]>0;   // convergence quarantine: shield slot behind
    for (uint32_t sp=0; sp<hardCap; sp++){
      if (taken[sp]) continue;
      if (q && sp+1<hardCap && taken[sp+1]) continue;
      uint32_t st=g_memberBaseUs+sp*g_slotUsLive;   // v7.10.7: base shifted past the fixed join window
      // per-node scheduling guard from the learned profile: characteristic
      // mean plus K*spread covers this node's own wobble, tight for steady
      // nodes, roomy for jittery ones. Clamped so it never packs too tight or
      // claims more than a slot. This is the profile driving the schedule.
      // v7.28.23: physical floor plus this member's own measured departure
      // deviation. Was meanUs + PROFILE_K*spreadUs/8, the arrival-minus-
      // departure delay, which railed every member at PROFILE_MAX_US. The
      // delay profile is still maintained and still logged, it just does not
      // size the schedule any more. PROFILE_MIN_US is gone from this path:
      // GUARD_FLOOR_US is the floor now and it is derived from physics
      // rather than being a packing convenience.
      uint32_t guardUs = GUARD_FLOOR_US
                       + g_prof[ri].devMeanUs
                       + (GUARD_DEV_K * g_prof[ri].devSpreadUs)/8;
      if (guardUs < GUARD_FLOOR_US) guardUs = GUARD_FLOOR_US;
      if (guardUs > GUARD_MAX_US)   guardUs = GUARD_MAX_US;
      g_prof[ri].guardUs = guardUs;   // v7.20.19: retained post clamp for the DRIFT record
      uint32_t ar=st+guardUs;
      uint32_t en=ar+g_memberAirUsLive + (q?g_slotUsLive:0);   // shield claim
      bool ok=true;
      for (int p=0;p<pN;p++) if (ar<pE[p] && pS[p]<en){ ok=false; break; }
      if (!ok) continue;
      // v7.10.7: the join window is fixed and sits BEFORE member data now,
      // so a late arrival here can never push it out of the frame the way
      // it could when the join window sat after the last slot. No boundary
      // check needed, hardCap already bounds sp to what fits in FRAME_US.
      s.slot[sp] = g_roster[ri]; g_slotOf[ri]=(uint8_t)sp;   // v7.28.5: DATA-frame member position (leaf-yield removed)
      taken[sp]=1;
      if (q && sp+1<hardCap){ taken[sp+1]=1; s.slot[sp+1]=0xFE; }   // v7.28.2: shield published as RESERVED (0xFE), never stale bytes, never a join window
      pS[pN]=ar; pE[pN]=en; pN++;
      if ((int)sp>maxSlot) maxSlot=(int)sp;
      if (en>lastArrEnd) lastArrEnd=en;
      break;
    }
  }
  }   // v7.28.5: end DATA-frame member placement (birth frame handled above)
  // publish the boundary: past the last slot and past the longest arrival.
  // v7.10.7: this no longer protects the join window's position, that is
  // fixed now, it still matters for sizing the frame to what was placed.
  uint32_t nSlots = (uint32_t)(maxSlot+1);
  uint32_t spill = (lastArrEnd - g_memberBaseUs + g_slotUsLive - 1)/g_slotUsLive;
  if (spill > nSlots) nSlots = spill;
  s.nSlots=(uint8_t)nSlots;
  g_frameGeometrySlots = s.nSlots;
  // v7.28.37 OPTION B: now that the real published slot count is known, re-derive
  // the relay region and member base from it. Placement above is invariant to
  // g_memberBaseUs (the base is a uniform offset, so slot assignments and the
  // overlap test are unchanged by it), so re-sizing here does not move any member
  // out of its slot; it only sets the base and the frame length to the honest
  // width for this frame's beacon. Members mirror this exactly via applyTiers(
  // tiersInForce, s->nSlots) in handleSched, so both sides agree on where member
  // slots begin at any roster size. The spill computation above used g_memberBaseUs
  // on both sides of a subtraction, so nSlots itself is unaffected by this call.
  // Zero countdown switches THIS beacon: every offset and advertised frame
  // uses the same effective geometry the receivers adopt.
  applyTiers(lsmgeometry::effectiveTiers(g_schedTiers,g_pendTiers,g_resizeCountdown,RELAY_TIERS_MAX), nSlots);
  // v11: size the frame to the roster actually placed this frame. Use nSlots
  // (the published slot count) as the member count, since that is what the
  // frame must physically hold. floor keeps a minimum for beacon+join+2 slots.
  {
    // v7.20.9: backhaul errand split (doc 41). Decide HERE which errand piece
    // this frame carries and budget the tail for it, before the frame length
    // is published. The advertise used to run inline right after the beacon
    // and froze the TK ~555 ms across the member region (53/53 stalls, bench
    // 2026-08-24). Now the transmit piece rides one frame's tail and the
    // 250 ms listen rides the next, strict alternation. The transmit
    // extension is DERIVED from the live peer count and getTimeOnAir, so it
    // tracks sphere growth on its own (O burst caps at 30 peers, 214 B).
    // v7.28.59: tail token slot. Decided here, before the frame length is published,
    // so the frame is extended by exactly one slot on the frames that carry a grant.
    s.grantId = ksTokGrantDecide((uint8_t)nSlots, s);
    uint32_t tokExtUs = (uint32_t)g_tokExtSlots * g_tokSlotUsLive;   // chunk 2: one sub-slot, or two when a relayer is named
    // v7.30.0: one aggregate grant per frame, selected by oldest outstanding
    // direct-relay demand.  A deep relay's demand is still carried inward and
    // recorded, but this first wire cut grants only a relay the keeper can hear
    // directly; multi-leg aggregate forwarding will require an explicit parent
    // field rather than silently reusing the token relay pair.
    s.aggGrantId = 0; s.aggGrantRecs = 0;
    {
      uint32_t nowMs = millis(); uint32_t bestAge = 0; uint8_t bestId = 0;
      for (int step = 0; step < g_rosterN; step++) {
        int ri = (g_aggGrantCursor + step) % (g_rosterN ? g_rosterN : 1);
        uint8_t id = g_roster[ri];
        if (!id || !g_aggDemand[id] || g_aggDemandDepth[id] != 0) continue;
        uint32_t age = nowMs - g_aggDemandMs[id];
        if (age > 8000UL) { g_aggDemand[id] = 0; continue; }
        if (!bestId || age >= bestAge) { bestId = id; bestAge = age; g_aggGrantCursor = (uint8_t)((ri + 1) % (g_rosterN ? g_rosterN : 1)); }
      }
      if (LSM_ADAPTIVE_AGGREGATE && bestId) { s.aggGrantId = bestId; s.aggGrantRecs = g_aggDemand[bestId]; }
    }
    telemetrySchedule(s);
    uint32_t aggExtUs = s.aggGrantId ? AGG_POS_SLOT_US : 0UL;
    g_bhThisFrame = 0; g_bhTailExtUs = 0;
#if LSM_LEGACY_SUBGHZ_BACKHAUL && !defined(LSM_BENCH_NO_BACKHAUL)
    // v7.28.41: define LSM_BENCH_NO_BACKHAUL in platformio.ini to pin the backhaul
    // errand OFF for a witness capture. It removes the keeper's channel-hop-away
    // (which stretches one frame in four on the bench) and the unguarded backhaul
    // transmit sites (7138/7150/7248, no g_loraIrq clear) from the experiment, so
    // any remaining deaf wraps or header aborts cannot be blamed on that path.
    // Keeps g_bhThisFrame at 0 so bhTailErrand and the tail extension never fire.
    // Config-only: remove the define to restore backhaul, no witness-suite rebuild.
    if (g_freqCountdown == 0xFF) {
      if (g_bhOwedListen) {
        g_bhThisFrame = 2;
        g_bhTailExtUs = (uint32_t)BH_ELECT_LISTEN_MS*1000UL + (uint32_t)BH_HOLD_CEIL_MS*1000UL + BH_ERRAND_OVERHEAD_US;
      } else if ((millis() - g_lastBackhaulAdvMs) >= BACKHAUL_ADV_PERIOD_MS) {
        uint8_t liveN = 0;
        for (int i = 0; i < PEER_TABLE_SIZE && liveN < BH_OFFSET_MAX_N; i++) {
          if (!g_peers[i].id) continue;
          if (millis() - g_peers[i].lastMs > AIR_TIMEOUT_MS) continue;
          liveN++;
        }
        g_bhThisFrame = 1;
        g_bhTailExtUs = (uint32_t)secureAirTime(sizeof(BackhaulBeacon))
                      + (liveN ? (uint32_t)secureAirTime((size_t)(4U + 7U*(uint32_t)liveN)) : 0UL)
                      + BH_ERRAND_OVERHEAD_US;
      }
    } else {
      g_bhOwedListen = 0;   // hop armed mid-cycle: drop the owed listen, the cycle restarts after the throttle
    }
#endif  // legacy same-radio backhaul is opt-in; dedicated LSM RX stays on channel by default
    uint32_t quietTailUs = ((g_frame % MAINT_TAIL_PERIOD) == 0U) ? MAINT_TAIL_US : DYN_JOIN_TAIL_US;
    uint32_t fUs = g_memberBaseUs + (uint32_t)nSlots*g_slotUsLive + g_relayReplySlotUs + tokExtUs + aggExtUs + quietTailUs + g_bhTailExtUs;   // v7.30.0: long maintenance tail is periodic; aggregate tail exists only when granted.
    if (fUs < g_dynFloorUs) fUs = g_dynFloorUs;
    // v11: quantize UP to the next 10 ms grid, then the TK runs its OWN
    // metronome on the SAME quantized value it advertises. This is critical:
    // if the TK ran the exact fUs while members decoded the rounded
    // frameMs10, they would disagree by up to the grid step every frame and a
    // member would walk out of its slot. Rounding UP (ceil) also guarantees
    // the frame is never SHORTER than the airtime it must hold, so a slot can
    // never be clipped by the boundary.
    // v7.13.0 CLAMP (was a silent wrap). HISTORICAL: frameMs10 WAS uint8, max 255
    // = 2550 ms; v7.28.98 widened it to uint16 and the ceiling to 10000 ms below.
    // Unclamped, nSlots >= 19 produced ms10 = 257 -> wraps to 1 -> the TK
    // advertised a 10 ms frame and the whole sphere lost slot alignment.
    // Clamping keeps the frame legal; it can only ever be SHORTER than ideal,
    // never wrapped, and the roster is bounded by V7_HARD_CAP_SLOTS anyway.
    uint32_t ms10_32 = (fUs + 9999UL) / 10000UL;            // ceil to 10 ms grid
    // v7.28.98: the clamp is now a WITNESSED ceiling, not a silent shortening.
    // A keeper must never publish a frame shorter than the slots it named: the
    // members in the slots past the boundary transmit into the next beacon.
    uint32_t ms10Cap = (uint32_t)(BACKHAUL_FRAME_CEIL_MS / 10UL);
    if (ms10Cap > 65535UL) ms10Cap = 65535UL;
    if (ms10_32 > ms10Cap) {
      // Still clamped, because the field and the ceiling are finite. But it is
      // recorded now, so a capture can see the geometry outgrow the frame
      // instead of the damage showing up as unexplained member loss.
      logRec(LOG_STATE, NODE_ID, g_role, 0xF2, (int16_t)nSlots,
             (int16_t)(ms10_32 > 32767UL ? 32767 : ms10_32), g_frame);   // aux 0xF2 = frame short-clamp
#if LSM_RELAY_TIMING_V2
      return; // Fail closed before schedule TX. Never grant slots beyond the frame.
#else
      ms10_32 = ms10Cap;
#endif
    }
    uint16_t ms10 = (uint16_t)ms10_32;
    s.frameMs10 = ms10;
    g_frameUs = (uint32_t)ms10 * 10000UL;                 // TK uses the SAME quantized length
  }
  // v7.13.0: publish the tier geometry in force this frame.
  s.schedTiers      = g_schedTiers;
  s.resizeTiers     = g_pendTiers;
  s.resizeCountdown = g_resizeCountdown;
  // ---- committed-depth policy. GROW FAST, SHRINK SLOW. ----
  // Mutual exclusion with the frequency hop: never arm one while the other is
  // pending, same guard the backhaul advert already uses.
  if (g_resizeCountdown == RESIZE_NONE && g_freqCountdown == 0xFF) {
    uint8_t want     = g_obsDepth;                         // v7.30.0: H1/direct is depth 0 and needs zero relay tiers.
    uint8_t wantWin  = g_obsDepthWin;                      // deepest relay depth seen across the hold window.
    if (want > RELAY_TIERS_MAX) want = RELAY_TIERS_MAX;
    if (wantWin > RELAY_TIERS_MAX) wantWin = RELAY_TIERS_MAX;
    // v7.28.105 TIER FLOOR. GROWTH is sized from live uplink depth above, but
    // SHRINK must not follow live depth down past a node the keeper has already
    // seated: if it does, that node loses the relayed downlink schedule, its
    // uplink is then refused at the relay gate, and it can never report back to
    // argue the tiers up again. That is the tier-collapse deadlock graded on the
    // v7.28.104 relay walk (count walked 7 down to 1 and stuck ten minutes).
    // g_seatDepth is the high-water relay-hop depth of each live roster entry;
    // the floor is the deepest seated node plus one tier, and the shrink can
    // fall to it but no lower. Empty roster floors at 1, the pre-105 behaviour.
    // A keeper cannot learn about a board beyond the relay window it already
    // publishes. Preserve five operational hops plus one discovery tier while
    // the roster is active; otherwise a shallow roster can shrink to three and
    // permanently block hop four before downstream evidence can arrive.
    uint8_t seatFloorTiers = (uint8_t)LSM_MIN_DISCOVERY_TIERS;
    for (int _i = 0; _i < g_rosterN; _i++) if ((uint8_t)(g_seatDepth[_i] + TIER_HEADROOM) > seatFloorTiers) seatFloorTiers = (uint8_t)(g_seatDepth[_i] + TIER_HEADROOM);   // v7.29.4: PLUS TWO, one spare tier above the known edge so a deeper copy can climb and raise the floor
    if (seatFloorTiers > RELAY_TIERS_MAX) seatFloorTiers = RELAY_TIERS_MAX;
    if (want < seatFloorTiers) want = seatFloorTiers;   // v7.29.4: the floor GROWS the count too; before it only blocked shrink, so a floor above the live count did nothing
    // v7.30.0: discovery is a rotating pulse, not a standing reservation.  A
    // shallow sphere therefore pays one extra tier only on the probe frame.
    // Each pulse advances one tier beyond the current committed geometry; a
    // real packet observed there raises g_obsDepth/g_seatDepth and makes that
    // depth part of the normal floor.  With no evidence, the short hold expires
    // and the geometry walks back down one tier at a time.
    if (g_rosterN && (g_frame % LSM_DISCOVERY_PROBE_FRAMES) == 0U && g_schedTiers < RELAY_TIERS_MAX) {
      uint8_t probe = (uint8_t)(g_schedTiers + 1U);
      if (probe > want) want = probe;
    }
    if (want > g_schedTiers) {
      // GROW: immediate. A deep node must have a tier ready BEFORE it needs one.
      g_pendTiers = want;
      uint32_t cd = (RESIZE_COUNTDOWN_MS * 1000UL) / (g_frameUs ? g_frameUs : 1UL);
      if (cd < RESIZE_CD_MIN) cd = RESIZE_CD_MIN;
      if (cd > RESIZE_CD_MAX) cd = RESIZE_CD_MAX;
      g_resizeCountdown = (uint8_t)cd;
      g_depthHoldUntilMs = millis() + DEPTH_HOLD_MS;
      g_obsDepthWin = 0;   // v7.28.98: fresh window with the fresh hold
    } else if (wantWin < g_schedTiers && (uint8_t)(g_schedTiers - 1) >= seatFloorTiers && (int32_t)(millis() - g_depthHoldUntilMs) >= 0) {
      // SHRINK: only past the wall-clock hold, only ONE tier, re-arming the
      // hold, and v7.28.105 never below seatFloorTiers. A single quiet frame
      // from a deep node can never collapse it, and a seated node's tier is
      // never dropped out from under it while it is still on the roster.
      g_pendTiers = (uint8_t)(g_schedTiers - 1);
      uint32_t cd = (RESIZE_COUNTDOWN_MS * 1000UL) / (g_frameUs ? g_frameUs : 1UL);
      if (cd < RESIZE_CD_MIN) cd = RESIZE_CD_MIN;
      if (cd > RESIZE_CD_MAX) cd = RESIZE_CD_MAX;
      g_resizeCountdown = (uint8_t)cd;
      g_depthHoldUntilMs = millis() + DEPTH_HOLD_MS;
      g_obsDepthWin = 0;   // v7.28.98: fresh window with the fresh hold
    }
  }
  g_obsDepth = 0;   // per-frame observation window resets after it is consumed
  // TK absolute position for the dashboard
  int32_t e32=0,n32=0;
  e32=(int32_t)g_fusE; n32=(int32_t)g_fusN;   // v6.7: fused offset for the dashboard
  s.tkEastCm=e32; s.tkNorthCm=n32;
  s.tkLatI = g_posValid ? (int32_t)llround(g_posLat * 1000000.0) : 0;
  s.tkLonI = g_posValid ? (int32_t)llround(g_posLon * 1000000.0) : 0;
  s.tkAltDm = (g_posValid && gps.altitude.isValid()) ? (int16_t)(altitudeCmNow() / 10) : 0;
  s.tkConf = g_posValid ? (uint8_t)(g_posConf & 0x3F) : 0;
  // anchor slot 0 at the instant the beacon STARTS transmitting, before the
  // blocking transmit() returns (it blocks for the ~77 ms airtime). Members
  // anchor on the ISR at the start of reception, so the TK must use the start
  // instant too, otherwise every measured arrival is skewed by the airtime and
  // the DRIFT delay rails. Bench log 25 (2026-07-04) showed DRIFT pinned at the
  // clamp; this is the fix.
  // v7.21.1: three instants bracket the stamp so the witness can separate a
  // late anchor from a slow transmit. anchPreUs is before femTx(), the stamp
  // itself is unchanged and still lands exactly where it did, and anchPostUs
  // is the moment the blocking transmit returns.
  // v7.28.31 preflight: what the chip is before the beacon call. Two short SPI reads.
  uint8_t pfStat = radio.chipStatus();
  uint8_t pfSync[2] = {0, 0}; radio.readSync(pfSync);
  uint8_t pfErrand = g_anchErrandEndUs ? 1 : 0;
  uint64_t anchPreUs = (uint64_t)esp_timer_get_time();
  femTx();
  uint64_t anchCallUs = (uint64_t)esp_timer_get_time();   // v7.28.24: the CALL instant. Was the anchor. Kept for the witness.
  g_frameAnchorUs = anchCallUs;    // provisional, so nothing that runs during the blocking transmit sees zero
  g_anchorValid = true;
  // v7.28.37: the beacon is sent at its real variable length, and the keeper's own
  // on-air airtime is the airtime of THIS beacon's slot count, not the fixed
  // reference. Both sides must reconstruct the anchor from the same number: the
  // keeper uses s.nSlots here, each member uses the s->nSlots it received.
  const uint32_t beaconTxLen = beaconWireB((uint32_t)s.nSlots);
  const uint32_t beaconTxAir = beaconAirUsLive((uint32_t)s.nSlots);
  int16_t st = LSM_TX((uint8_t*)&s, beaconTxLen);
  uint64_t anchRetUs  = (uint64_t)esp_timer_get_time();
  // v7.28.25: anchPostUs is the DONE instant from the DIO1 ISR, not the
  // return. Everything below that read the return now reads this, so the
  // anchor, the learned latency and the aux 1 witness all move together.
  uint64_t anchPostUs = txDoneInstant(anchCallUs, anchRetUs);
  txDoneWitness();
  // v7.28.24 THE ANCHOR IS THE ON-AIR START, NOT THE CALL. The comment that
  // used to sit on the stamp above said "slot-0 = transmit start". It was the
  // transmit CALL, and the radio radiates its first preamble symbol about
  // 8,400 us after the call (anchor witness, 2,798 frames, p5-p95 spread
  // 120 us). Every member reconstructs this beacon's on-air start honestly as
  // RxDone minus BEACON_AIR_US, so every member's frame baseline sat 8,400 us
  // later than the keeper's own, and that skew was one of the two halves of
  // the 17 ms the delay profile measured. Now the keeper reconstructs its own
  // on-air start the same way the members do: from the done instant minus
  // the airtime. Same arithmetic on both ends of the link, so the skew
  // collapses to the difference between TX-done-to-return and RxDone-ISR
  // latency, sub-millisecond. Falls back to the call instant on a failed
  // transmit so a radio error never produces a wild anchor.
  if (st == RADIOLIB_ERR_NONE && anchPostUs > (uint64_t)beaconTxAir)
    g_frameAnchorUs = anchPostUs - (uint64_t)beaconTxAir;   // v7.28.37: variable-length beacon airtime
  if(st==RADIOLIB_ERR_NONE)txLatSample(anchCallUs, anchPostUs, beaconTxAir); // Success-only calibration.
  rxArmAfterTx();   // TX-done IRQ must not trigger a phantom read
  g_seq++;                                // the glass T counter
  logRec(LOG_TX, NODE_ID, 3, s.nSlots, (int16_t)(e32>32767?32767:e32), (int16_t)(n32>32767?32767:n32), g_frame);
  logRecRf(LOG_ANCH, NODE_ID, g_role, 5,
           (int16_t)(((uint16_t)pfStat << 8) | pfSync[0]),
           (int16_t)(((uint16_t)pfSync[1] << 8) | pfErrand),
           (uint32_t)lround((double)g_currentFreqMHz * 1000.0), 0, 0, st);   // v7.28.31 preflight witness
  // v7.21.1 anchor witness, aux 1. Emitted after the TX record so the two sit
  // adjacent in the log and a reader can pair them on the frame counter.
  { uint32_t blkUs  = (uint32_t)(anchPostUs - anchCallUs);   // v7.28.24: call to return, as before. e = excess over airtime = the correction now applied to the anchor.
    uint32_t femUs  = (uint32_t)(anchCallUs - anchPreUs);
    int32_t  excess = (int32_t)blkUs - (int32_t)beaconTxAir;   // v7.28.37: excess over the airtime of the beacon actually sent
    int32_t  sinceEr = g_anchErrandEndUs
                     ? (int32_t)((uint32_t)((g_frameAnchorUs - g_anchErrandEndUs) / 100ULL))
                     : -1;
    int32_t  slip = 0;
    if (g_anchPrevAnchorUs && g_anchPrevFrameUs)
      slip = (int32_t)(((int64_t)(g_frameAnchorUs - g_anchPrevAnchorUs)
                        - (int64_t)g_anchPrevFrameUs) / 100);
    logRecRf(LOG_ANCH, NODE_ID, g_role, 1,
             anchClamp(excess), anchClamp(sinceEr), blkUs,
             (int8_t)g_anchErrandKind,
             (int8_t)(femUs > 127U ? 127 : (int8_t)femUs),
             anchClamp(slip));
    g_anchPrevAnchorUs = g_frameAnchorUs;
    g_anchPrevFrameUs  = g_frameUs;
    g_anchErrandEndUs  = 0;
    g_anchErrandKind   = 0;
    g_anchErrandBlkUs  = 0; }
  if (st != RADIOLIB_ERR_NONE) logRec(LOG_RF, NODE_ID, g_role, 0, 0, 0, (uint32_t)(int32_t)st);
  if (st != RADIOLIB_ERR_NONE) { if (g_missedFrames < 250) g_missedFrames++; } else if (g_missedFrames) g_missedFrames--;  // v6.6: TK beacon health
  // v7.12.5: TK-directed frequency switch, dashboard-initiated test. This
  // frame's beacon just went out with the current countdown value. If that
  // value was 0, this frame WAS the switch frame, everyone who heard it
  // switches now, including us, right here, right after our own TX. If it
  // was any other in-range value, just count down one for next frame; the
  // beacon itself carries the number, no separate timer needed on either end.
  // v7.13.0: resize countdown, same shape as the frequency hop below. This
  // frame's beacon just went out carrying the current value; if it was 0, this
  // frame WAS the switch frame and the new geometry takes effect now, on the
  // TK and on every member that heard it, at the same boundary.
  // v7.17.0 typed superframe countdown, TK side. Owns the pending type change,
  // decrements one per frame and flips the live type at zero, the identical shape
  // to the freq and resize countdowns below. No trigger moves g_frameTypeCountdown
  // off SF_CD_NONE... v7.28.0 comment fix: false since v7.19.0. The brick1
  // trigger directly below arms JOIN on g_recentJoinReqCount >= JOIN_FRAME_DEMAND
  // and brick5 returns to DATA, so this block is LIVE, not inert.
  // v7.28.5 ONE-ON-ONE-OFF birth frame (TK only; this function runs on the TK).
  // Replaces the v7.19.0 brick1/brick5 free-running interleave, which let a JOIN
  // frame persist for the whole announce window and re-fire the instant it returned
  // to DATA, so under sustained demand it could hold the sphere in JOIN and starve
  // members. A birth frame now lasts EXACTLY one live frame and cannot re-arm until
  // at least BIRTH_COOLDOWN_FRAMES DATA frames have been served. The cooldown is
  // enforced HERE at the TK, so a stuck or spoofed demand or swarm signal can never
  // keep the sphere in birth mode: members are guaranteed the off frame.
  if (g_birthCooldown > 0) g_birthCooldown--;   // each DATA frame burns the cooldown down
  if (g_frameType == SF_TYPE_DATA && g_birthMaintDataAge < 255) g_birthMaintDataAge++;
  // v7.28.15 PROACTIVE BIRTH FRAME, standing offer. Both 28.5 triggers below need
  // the keeper to HEAR a request first, and at cold boot the requests it needs are
  // the ones colliding in the join window (2026-08-31: 111 swarm requests sent,
  // node08 received none, nine boards admitted one at a time over 94 s while the
  // keeper published empty beacons). The recovery path depended on the channel it
  // was recovering. A keeper with empty windows now offers a birth frame without
  // being asked: while any rival keeper has been heard within
  // BIRTH_RIVAL_CLEAR_FRAMES (a co-elected keeper is deaf and busy, not a joiner,
  // so admissions are the wrong signal during the storm), and after that until
  // BIRTH_EMPTY_RUNS_MAX proactive birth frames in a row admit nobody. Cadence is
  // one-on-one-off below half the slots and one-on-two-off above, so the cost
  // tapers as the roster fills and stops outright when it is full. The 28.5
  // demand and swarm triggers are untouched and still arm on their own.
  {
    uint32_t nowTick = millis();
    if (g_rivalSeenMs != 0 && (int32_t)(g_rivalSeenMs - g_birthRivalTickMs) >= 0) {
      g_framesSinceRival = 0; g_birthEmptyRuns = 0;     // rival heard since the last tick
    } else if (g_framesSinceRival < 255) g_framesSinceRival++;
    g_birthRivalTickMs = nowTick;
    if (g_birthPendingEval) {                            // the proactive birth frame before this tick: did anyone key in
      if (g_rosterN > g_birthRosterAtOpen) g_birthEmptyRuns = 0;
      else if (g_birthEmptyRuns < 255) g_birthEmptyRuns++;
      g_birthPendingEval = false;
    }
  }
  uint32_t birthCap = V7_HARD_CAP_SLOTS; if (birthCap > V7_SLOTS_MAX) birthCap = V7_SLOTS_MAX;
  bool birthOffer = ((uint32_t)g_rosterN < birthCap) &&
                    (g_framesSinceRival < BIRTH_RIVAL_CLEAR_FRAMES || g_birthEmptyRuns < BIRTH_EMPTY_RUNS_MAX);
  bool birthMaintenance = ((uint32_t)g_rosterN < birthCap) &&
                          g_birthMaintDataAge >= BIRTH_MAINT_DATA_FRAMES;
  // ARM from steady DATA with nothing pending and the cooldown clear, on join demand
  // OR an explicit funnel swarm request. BIRTH_ANNOUNCE_CD is 0, so JOIN goes live at
  // the next boundary; every beacon carries the frame type so no warning frame is due.
  if (g_frameType == SF_TYPE_DATA && g_frameTypeCountdown == SF_CD_NONE &&
      g_birthCooldown == 0 &&
      (g_recentJoinReqCount >= JOIN_FRAME_DEMAND || g_swarmReqPending || birthOffer || birthMaintenance)) {
    g_birthProactive     = birthOffer || birthMaintenance; // v7.29.50: maintenance uses the same bounded 4..16 window sizing and post-frame admission check
    if (birthMaintenance) g_birthMaintDataAge = 0;
    g_frameTypeTarget    = SF_TYPE_JOIN;
    g_frameTypeCountdown = BIRTH_ANNOUNCE_CD;
    logRec(LOG_STATE, NODE_ID, g_role, SF_TYPE_JOIN, (int16_t)g_rosterN, (int16_t)(birthMaintenance ? 2 : (birthOffer ? 1 : 0)), (uint32_t)g_recentJoinReqCount);   // n: 0 demand, 1 startup standing offer, 2 v7.29.50 TK maintenance offer
  }
  // RETURN: the instant we are live in JOIN, flip back to DATA at the very next
  // boundary (one birth frame only), start the cooldown so a member frame is
  // guaranteed before the next birth, and consume the swarm request so a fresh one
  // must arrive to re-arm.
  if (g_frameType == SF_TYPE_JOIN && g_frameTypeCountdown == SF_CD_NONE) {
    g_frameTypeTarget    = SF_TYPE_DATA;
    g_frameTypeCountdown = 0;                     // flip back next boundary: birth lasts one frame
    g_birthCooldown      = BIRTH_COOLDOWN_FRAMES;  // at least one DATA frame before the next birth
    if (g_birthProactive) {                        // v7.28.15: taper, and arm the admission check for the next tick
      if ((uint32_t)g_rosterN * 2U >= birthCap && BIRTH_TAPER_COOLDOWN > BIRTH_COOLDOWN_FRAMES) g_birthCooldown = BIRTH_TAPER_COOLDOWN;
      g_birthRosterAtOpen = (uint8_t)(g_rosterN > 255 ? 255 : g_rosterN);
      g_birthPendingEval  = true;
      g_birthProactive    = false;
    }
    g_swarmReqPending    = false;
    g_swarmReqCount      = 0;                      // the ask has been served by this birth frame
    logRec(LOG_STATE, NODE_ID, g_role, SF_TYPE_DATA, (int16_t)g_rosterN, 0, (uint32_t)g_recentJoinReqCount);   // v7.20.12: e = roster size at the flip
  }
  if (g_frameTypeCountdown != SF_CD_NONE) {
    if (g_frameTypeCountdown == 0) {
      g_frameType = g_frameTypeTarget;
      logRec(LOG_STATE, NODE_ID, g_role, 0, 0, 0, (uint32_t)g_frameType);
      g_frameTypeCountdown = SF_CD_NONE;
    } else {
      g_frameTypeCountdown--;
    }
  }
  if (g_resizeCountdown != RESIZE_NONE) {
    if (g_resizeCountdown == 0) {
      // Already applied with this beacon's real nSlots BEFORE publication.
      // Do not mutate live offsets using default slots after sending it.
      logRec(LOG_STATE, NODE_ID, g_role, 0, 0, 0, (uint32_t)g_pendTiers);
      g_resizeCountdown = RESIZE_NONE;
    } else {
      g_resizeCountdown--;
    }
  }
  if (g_freqCountdown != 0xFF) {
    if (g_freqCountdown == 0) {
      int16_t fst = radio.setFrequency(g_freqTargetMHz);
      lsmRxArm();
      logRec(LOG_STATE, NODE_ID, g_role, 0, 0, 0, (uint32_t)lround(g_freqTargetMHz * 1000000.0));  // v7.12.11: actual Hz logged, not a flat marker
      if (fst != RADIOLIB_ERR_NONE) logRec(LOG_RF, NODE_ID, g_role, 1, 0, 0, (uint32_t)(int32_t)fst);
      if (fst == RADIOLIB_ERR_NONE) g_currentFreqMHz = g_freqTargetMHz;  // v7.12.12: track actual tuned freq for the glass
      g_freqCountdown = 0xFF;   // FREQ_SWITCH_NONE, done, clear pending
    } else {
      g_freqCountdown--;
    }
  }
  // v7.20.9: the backhaul errand no longer runs here (doc 41). Inline after
  // the beacon it froze the TK across the member region. It now runs
  // piecewise in the frame tail, see bhTailErrand(), decided and budgeted at
  // the frame compute above so frameMs10 already carries the widened frame.
}

// ----------------------- v7 member TX -----------------------
void memberSendData(){
  if(telemetryTxOwn())return;
  MemberPkt p; memset(&p,0,sizeof(p));
  p.src_id=(uint16_t)NODE_ID; p.type=0; p.seq=(uint8_t)g_curSchedSeq;
  int16_t e=(int16_t)g_fusE, n=(int16_t)g_fusN;   // v6.7: fused offset, cm
  int32_t xd=e/10, yd=n/10;
  p.x_dm=(int8_t)(xd>127?127:(xd<-128?-128:xd));
  p.y_dm=(int8_t)(yd>127?127:(yd<-128?-128:yd));
  p.z_floor=0;
  // v7.28.70-absposbranch: absolute lat/lon alongside the offsets above, which are
  // untouched. Zero/zero is the no-position sentinel, so a node without a fix sends
  // zeros here and the receiver leaves its stored absolute alone. Gated on the same
  // g_posValid the confidence byte below uses, so this adds no new gate to reason about.
  if (g_posValid) {
    p.latI = (int32_t)llround(g_posLat*1000000.0);
    p.lonI = (int32_t)llround(g_posLon*1000000.0);
  } else { p.latI = 0; p.lonI = 0; }
  p.flags_conf = g_posValid ? (uint8_t)(g_posConf & 0x3F) : 0;   // v6.7: graded confidence
  p.flags_conf |= 0x80;                                          // v7.28.33: KEEPALIVE. A position packet in a granted slot IS this node's keepalive; say so on the wire.
  p.relayerId = ksSideReq();   // v7.28.59: side-channel request byte on a hop-0 packet (relayerId carried nothing there)
  p.volunteerFor = g_volunteerFor;   // v7.28.97: one orphan named per frame, rotating
  // v7.11.0: relay a second TK's sighting home, stale after 3s to match the
  // rival-yield freshness window (the TK's own rivalBeatsUs check uses 3s).
  if (g_relayRivalTkId != 0 && millis() - g_relayRivalSeenMs < 3000
      && g_relayRivalTkId != (uint8_t)NODE_ID) {
    p.relayRivalTk = g_relayRivalTkId;
    p.relayRivalEpoch = g_relayRivalEpoch;
    p.relayRivalTie = g_relayRivalTie;
    p.relayRivalRssiAvg = g_relayRivalRssiAvg;
    p.relayRivalScore = g_relayRivalScore;
  } else if (g_tkId != 0 && g_seqHighTk == g_tkId) {
    p.relayRivalTk = g_tkId;
    p.relayRivalEpoch = g_tkEpoch;
    p.relayRivalTie = g_homeTkTie;
    p.relayRivalRssiAvg = g_homeTkRssiAvg;
    p.relayRivalScore = (int16_t)g_tkScore;
  }
  // v12: stamp departure offset from the shared TK baseline, as close to the
  // transmit call as possible. radio.transmit() is blocking and starts the
  // air departure immediately, so this offset plus a small constant SPI-load
  // lag (identical across nodes, absorbed into the profile) is the true
  // departure instant in the TK's reference frame.
  uint32_t dOff; uint64_t txCallUs;
  { uint64_t nowUs = (uint64_t)esp_timer_get_time();
    txCallUs = nowUs;
    // v7.10.2: raw offset, no modulo. The TK only trusts this when p->seq
    // matches its own current frame, so both sides share the same anchor
    // instant and no fold is needed; a stale reply is discarded by the TK's
    // same-frame check instead of being risked through a cross-frame value.
    // v7.28.24: dOff is the predicted ON-AIR departure, call instant plus this
    // board's own measured transmit latency. The v12 comment above this block
    // called the lag "a small constant SPI-load lag, identical across nodes,
    // absorbed into the profile". It is about 8,400 us, it is per board, and
    // absorbing it into the profile is exactly what railed the guard. The
    // member now validates its own send: it reports where the packet will
    // actually be on the air, not where the CPU asked for it.
    dOff = (uint32_t)(nowUs - g_frameAnchorUs) + g_txLatUs;
    p.departDevUs = departDevFrom(dOff);
    // v7.21.0: two separate fields, written together, never conditional on
    // each other. depAttest16 is the departure integrity tag and is always
    // present. attToken is the crystal tag and is 0 until this sender is
    // enrolled. The blind #else that used to sit here wrote departAttest
    // into attToken and is deleted; a hard #error at the top of the file
    // now catches a build without CRYSTAL_TOKEN.
    p.depAttest16 = departAttest(p.src_id, p.seq, p.departDevUs);
    p.attToken    = ctokMintOr(p.src_id, p.seq, p.departDevUs);
  }
  mpktStampOriginDepth(&p);   // v7.29.8: origin depth in graceFlags[7:1], before CRC
  p.crc = crc8((uint8_t*)&p, sizeof(p)-1);                        // CRC-8 over all prior bytes
  femTx(); int16_t txStatus = LSM_TX((uint8_t*)&p, sizeof(p));
  if(ownedWasSkipped()){rxArmAfterTx();return;}
  if(txStatus==RADIOLIB_ERR_NONE){ uint64_t txRetUs = (uint64_t)esp_timer_get_time(); // Successful TX only.
    uint64_t txDoneUs = txDoneInstant(txCallUs, txRetUs);   // v7.28.25: done from the ISR, not the return
    txLatSample(txCallUs, txDoneUs, g_airWitnessUs ? g_airWitnessUs : g_memberAirUsLive);
    txDoneWitness(); }
  rxArmAfterTx();   // no phantom read of our own packet
  g_seq++;
  if (txStatus == RADIOLIB_ERR_NONE) {
#if LSM_PAYLOAD_PROBE
    g_payloadOriginTx++;
#endif
    logRec(LOG_TX, NODE_ID, g_role, 0xF8, e, n, (uint32_t)p.seq | ((uint32_t)g_mySlot << 8));   // v7.28.33: aux 0xF8 = data packet in a granted slot (was the slot number, which collided with small aux codes in decode); slot now in data bits 8-15
  } else
    logRec(LOG_RF, NODE_ID, g_role, 0, 3, 0, (uint32_t)(int32_t)txStatus);   // scheduled member TX failed; do not count it as sent
  logSlotTrim(dOff);                      // v7.12.25 observe-only slot-time trim
}

// v7.2: one part of the absolute SEED burst. Reuses the same 9-byte
// MemberPkt shape, payload bytes reinterpreted per type: 3=lat (int32
// microdegrees), 4=lon (int32 microdegrees), 5=alt (int16 decimetres in the
// first 2 payload bytes, rest reserved). Sent in place of a regular data
// packet in a granted slot, never on top of it, so the one-packet-per-slot
// timing the TK depends on is never disturbed.
void memberSendSeedPart(uint8_t part, uint8_t seq){
  MemberPkt p; memset(&p,0,sizeof(p));
  p.src_id=(uint16_t)NODE_ID; p.seq=seq;
  if (part==1){
    // v7.28.70-absposbranch: the seed payload now rides the real int32 latI field
    // instead of being memcpy'd onto x_dm. Before this branch a 4-byte copy onto the
    // int8 x_dm ran through y_dm and z_floor and into flags_conf, silently clobbering
    // the confidence byte on every seed part. Nothing read it for types 3/4/5 so it
    // never bit, but it is not something to carry forward now a typed field exists.
    // The receive side reads from the SAME offset (offsetof MemberPkt latI), so both
    // ends moved together. x_dm, y_dm and z_floor are now left at zero on a seed part
    // rather than being overwritten, which is what they always should have been.
    p.type=3; p.latI = (int32_t)llround(lat0*1000000.0);   // v7.28.75: seed = held origin
  } else if (part==2){
    p.type=4; p.latI = (int32_t)llround(lon0*1000000.0);
  } else {
    p.type=5; int16_t v=(int16_t)(altitudeCmNow()/10); memcpy(&p.latI,&v,2);
  }
  mpktStampOriginDepth(&p);   // v7.29.8: origin depth in graceFlags[7:1], before CRC
  p.crc = crc8((uint8_t*)&p, sizeof(p)-1);                        // v7.6: CRC-8 guard
  femTx(); int16_t ownedStatus=LSM_TX((uint8_t*)&p, sizeof(p)); rxArmAfterTx();
  if(g_owned.scope&&ownedStatus!=RADIOLIB_ERR_NONE)return;
  g_seq++;
  logRec(LOG_TX, NODE_ID, g_role, 0x50+part, 0, 0, p.seq);   // aux 0x51/0x52/0x53 marks a seed part
}

// v7.18.0: flood-fallback join. A MemberPkt type 2 that the relay tree
// carries up to a TK this node cannot hear directly. hops=0 marks it as
// originating here; each relay leg bumps hops by 1 (memberFloodNote). seq
// advances every TX so relayers do not dedup-suppress a retry. All position
// fields are zero: a join says only who is asking, exactly as the 4B JoinPkt
// does, and the real position arrives on the first data packet after admission.
bool memberSendJoinFlood(){
  MemberPkt p; memset(&p,0,sizeof(p));
  p.src_id=(uint16_t)NODE_ID; p.type=2; p.seq=(uint8_t)g_seq;
  p.hops=0; p.relayerId=(uint8_t)NODE_ID;
  mpktStampOriginDepth(&p);   // v7.29.8: origin depth in graceFlags[7:1], before CRC
  p.crc = crc8((uint8_t*)&p, sizeof(p)-1);
  femTx(); int16_t txStatus = LSM_TX((uint8_t*)&p, sizeof(p)); rxArmAfterTx();
  if (txStatus != RADIOLIB_ERR_NONE) {
    logRec(LOG_RF, NODE_ID, g_role, 0, 2, 0, (uint32_t)(int32_t)txStatus);
    g_joinRadioRecoverReq = true;
    return false;
  }
  g_seq++;
  logRec(LOG_TX, NODE_ID, 0, 0xFD, 0, 0, g_seq);   // aux 0xFD marks a FLOOD join request (vs 0xFE direct)
  return true;
}

// v7.28.101: windows is the number of joiner windows this board is asking the
// keeper to open, capped to the 6-bit conf64 field. Two callers now:
//   windows == 1, hops 0  : the v7.28.6 resigned-keeper path, asking for itself.
//   windows == g_aggN     : a FUNNEL speaking for the joiners it has cached but
//                           cannot admit, which is what v7.28.5 designed the type
//                           and the conf64 count field for and what nothing ever
//                           sent. Until v7.28.101 the only caller was the failover
//                           path above, so g_swarmReqCount never exceeded 1 and a
//                           demand-armed birth frame opened exactly one window no
//                           matter how many joiners were waiting behind a relay.
// hops stays 0 on the wire: this board is the one speaking, and the keeper's
// v7.28.7 Part B direct-admit gate keys on hops==0 to re-absorb a resigned keeper.
// A funnel is already on the roster, so tkOnJoinReq de-dups its self-admit to a
// no-op and the only effect that survives is the birth arm plus the sized ask.
bool memberSendSwarmReq(uint8_t windows){
  // v7.28.6: a just-resigned TK asks the winner for a guaranteed birth-frame
  // window, exactly as a cold joiner does, by sending a type-7 swarm request.
  // The winner arms a birth frame on this ask (g_swarmReqPending) and admits us
  // before our failover timer can fire, so the resignation is absorbed instead of
  // looping back into a re-election.
  if (windows == 0) windows = 1;
  if (windows > 63) windows = 63;                  // conf64 is 6 bits, flags_conf[5..0]
  MemberPkt p; memset(&p,0,sizeof(p));
  p.src_id=(uint16_t)NODE_ID; p.type=MEMBER_TYPE_SWARM_REQ; p.seq=(uint8_t)g_seq;
  // v7.28.103 CUT 2: real hop count when an admit is riding, not a hardcoded 0.
  // Under v7.28.102 this line always claimed hops=0, so a climbed admit looked
  // identical to a direct one and never actually climbed past the first board
  // that received it. g_anchorHops here is THIS board's own real depth at the
  // moment it transmits, correct by construction; each retransmitting hop
  // computes its own hops the same way, so the chain climbs honestly one hop
  // at a time without needing the keeper to re-derive or verify it centrally,
  // the same trust model aggReaggregate already uses for the other path.
  // v7.29.21: start at zero like every original MemberPkt. Each relay adds
  // one; immutable origin depth in graceFlags proves strictly uphill progress.
  p.hops=0;
  p.relayerId=(uint8_t)NODE_ID;
  p.flags_conf=windows;                            // conf64 = joiner windows requested
  // v7.28.102 CHUNK 4: fold the first-hand admit onto this existing transmission
  // rather than a new packet. volunteerFor already exists on the wire for the
  // v7.28.97 orphan-report mechanism (an ALREADY-SEATED roster member the keeper
  // has not heard directly); this reuses the same field for an UNSEATED joiner.
  // No collision: the v7.28.97 receive handler gates on tkRosterFind(orph) >= 0,
  // which is false for an unseated id, so it silently no-ops on this packet and
  // never fires twice. The new admission logic lives inside the MEMBER_TYPE_
  // SWARM_REQ receive block specifically, downstream of that generic handler in
  // the same function, so there is exactly one place that acts on it.
  p.volunteerFor=g_admitId;                        // 0 = ask only, nonzero = first-hand joiner riding along
  g_lastSwarmAsk = windows;                        // v7.28.101: surfaced in the LOG_MESH witness
  mpktStampOriginDepth(&p);   // v7.29.8: origin depth in graceFlags[7:1], before CRC
  p.crc = crc8((uint8_t*)&p, sizeof(p)-1);
  femTx(); int16_t txStatus = LSM_TX((uint8_t*)&p, sizeof(p)); rxArmAfterTx();
  if (txStatus != RADIOLIB_ERR_NONE) return false;
  g_seq++;
  logRec(LOG_TX, NODE_ID, 0, 0xFB, (int16_t)windows, (int16_t)g_admitId, g_seq);   // v7.28.102: aux 0xFB = swarm request, e = windows asked, n = admit id riding along (0 = none)
  return true;
}

#if LSM_RELAY_PLEA
// v7.29.1 RELAY PLEA. See MEMBER_TYPE_RELAY_PLEA at the define for the whole rationale.
static bool pleaSeenHas(uint8_t src, uint8_t seq){
  for (uint8_t i = 0; i < g_pleaSeenN; i++)
    if (g_pleaSeenSrc[i] == src && g_pleaSeenSeq[i] == seq) return true;
  return false;
}
static void pleaSeenAdd(uint8_t src, uint8_t seq){
  if (g_pleaSeenN < PLEA_SEEN_N){ g_pleaSeenSrc[g_pleaSeenN] = src; g_pleaSeenSeq[g_pleaSeenN] = seq; g_pleaSeenN++; return; }
  for (uint8_t i = 1; i < PLEA_SEEN_N; i++){ g_pleaSeenSrc[i-1] = g_pleaSeenSrc[i]; g_pleaSeenSeq[i-1] = g_pleaSeenSeq[i]; }   // ring full: drop oldest
  g_pleaSeenSrc[PLEA_SEEN_N-1] = src; g_pleaSeenSeq[PLEA_SEEN_N-1] = seq;
}
// Forward a first-hand plea ONCE toward the keeper. A relayed member copy: bump hops to 1
// and stamp our own id as relayerId, exactly as the schedule/data relay path does, but do
// NOT touch depAttest16 or attToken (a relay must not, per the MemberPkt field notes) so the
// keeper still verifies the PLEADER's crystal tag on the copy, the same as a relayed data
// packet it already accepts. Nothing else in the packet changes.
static void pleaForward(const MemberPkt* in){
  MemberPkt p = *in;
  p.hops        = 1;
  p.relayerId   = (uint8_t)NODE_ID;
  p.volunteerFor = 0;
  // v7.29.8: do NOT restamp origin depth - this is a forwarded copy; graceFlags[7:1]
  // already carries the pleader's depth from the hop-0 packet.
  p.crc = crc8((uint8_t*)&p, sizeof(p)-1);
  femTx(); LSM_TX((uint8_t*)&p, sizeof(p)); rxArmAfterTx();   // v7.28.37: the relay TxDone must not phantom-trigger the next radioPoll
}
// Send our own plea, hops=0, our own id in relayerId (a forwarder overwrites it). Carries
// our crystal tag so the relayed copy is accepted at the keeper. Modelled on memberSendSwarmReq.
void memberSendPlea(){
  MemberPkt p; memset(&p, 0, sizeof(p));
  p.src_id    = (uint16_t)NODE_ID;
  p.type      = MEMBER_TYPE_RELAY_PLEA;
  p.seq       = (uint8_t)g_seq;
  p.hops      = 0;
  p.relayerId = (uint8_t)NODE_ID;
  p.departDevUs = departDevFrom((uint32_t)((uint64_t)esp_timer_get_time() - g_frameAnchorUs) + g_txLatUs);
#if LSM_PLEA_MINT
  p.depAttest16 = departAttest(p.src_id, p.seq, p.departDevUs);
  p.attToken    = ctokMintOr(p.src_id, p.seq, p.departDevUs);
#endif   // v7.29.3: default off, see LSM_PLEA_MINT. Fields stay zero from the memset; ctokTkVerify never reads them for type 8.
  mpktStampOriginDepth(&p);   // v7.29.8: origin depth in graceFlags[7:1], before CRC
  p.crc = crc8((uint8_t*)&p, sizeof(p)-1);
  femTx(); int16_t ownedStatus=LSM_TX((uint8_t*)&p, sizeof(p)); rxArmAfterTx();
  if(g_owned.scope&&ownedStatus!=RADIOLIB_ERR_NONE)return;
  g_seq++;
  logRec(LOG_TX, NODE_ID, 0, 0xD8, (int16_t)g_pleaTries, (int16_t)g_pleaSinceHeardFr, g_seq);   // aux 0xD8 = relay plea sent, e = ladder try, n = frames stranded
}
// Ladder: first plea at PLEA_UNNAMED_FRAMES stranded, second at +PLEA_WAIT1_FRAMES, then a
// steady +PLEA_WAIT2_FRAMES cadence. No drop to LISTEN: a board that hears NOTHING is caught
// by the cold-listen / dead-TK re-walk path already; a board that hears the keeper's relayed
// beacon but is not named just keeps pleading until the leg is granted.
static bool pleaWantThisFrame(){
  if (g_role != 1 || g_anchorHops == 255) return false;
  if (g_pleaSinceHeardFr < PLEA_UNNAMED_FRAMES) return false;
  uint16_t ctr = g_relayFrameCtr;
  if (g_pleaTries == 0){ g_pleaTries = 1; g_pleaNextFr = (uint16_t)(ctr + PLEA_WAIT1_FRAMES); return true; }
  if ((int16_t)(ctr - g_pleaNextFr) < 0) return false;                       // not due yet
  if (g_pleaTries == 1){ g_pleaTries = 2; g_pleaNextFr = (uint16_t)(ctr + PLEA_WAIT2_FRAMES); return true; }
  g_pleaNextFr = (uint16_t)(ctr + PLEA_WAIT2_FRAMES);                        // steady slow re-plea
  return true;
}
#endif

bool memberSendJoin(){
  // v7.16.0: sends a 4 byte JoinPkt, not a MemberPkt. See the struct comment
  // for why the altitude and floor hint the v7.2 join carried is gone: it was
  // read nowhere on the receive path and arrives on the first data packet one
  // frame after admission anyway. Airtime 30976 us against 56576 us, which is
  // most of what made the old join overrun member slot 0.
  JoinPkt j;
  j.magic='J'; j.ver=WIRE_VER; j.src_id=(uint8_t)NODE_ID;
  j.crc = crc8((uint8_t*)&j, sizeof(j)-1);                        // v7.6: CRC-8 guard
  femTx(); int16_t txStatus = LSM_TX((uint8_t*)&j, sizeof(j)); rxArmAfterTx();
  if (txStatus != RADIOLIB_ERR_NONE) {
    logRec(LOG_RF, NODE_ID, g_role, 0, 1, 0, (uint32_t)(int32_t)txStatus);
    g_joinRadioRecoverReq = true;
    return false;
  }
  g_seq++;                                          // joins show on the glass T counter
  logRec(LOG_TX, NODE_ID, 0, 0xFE, 0, 0, g_seq);   // aux 0xFE marks a join request
  return true;
}

// v7.11.6: type=6, timing-only keepalive. Sent instead of memberSendData()
// when this node has no valid position to report (g_posValid false, cold
// start or a lost fix), so the TK still gets a fresh timing sample and this
// node's roster entry (g_lastAirMs) stays alive without claiming a position
// it does not actually have. Same MemberPkt shape and same size on air as
// real data, only the position fields are left zero and the type marks it
// distinct, so nothing downstream ever mistakes stale zeros for a real fix.
void memberSendPresent(){
  // Explicit no-fix snapshots use the same cadence; never invent a position.
  if(telemetryTxOwn())return;
  MemberPkt p; memset(&p,0,sizeof(p));
  p.src_id=(uint16_t)NODE_ID; p.type=6; p.seq=(uint8_t)g_curSchedSeq;
  p.flags_conf = 0x80;                                           // v7.28.33: KEEPALIVE bit, same as the data packet
  p.relayerId = ksSideReq();   // v7.28.59: same byte on the present ping
  p.volunteerFor = g_volunteerFor;   // v7.28.97: same report on the present ping
  if (g_relayRivalTkId != 0 && millis() - g_relayRivalSeenMs < 3000
      && g_relayRivalTkId != (uint8_t)NODE_ID) {
    p.relayRivalTk = g_relayRivalTkId;
    p.relayRivalEpoch = g_relayRivalEpoch;
    p.relayRivalTie = g_relayRivalTie;
    p.relayRivalRssiAvg = g_relayRivalRssiAvg;
    p.relayRivalScore = g_relayRivalScore;
  } else if (g_tkId != 0 && g_seqHighTk == g_tkId) {
    p.relayRivalTk = g_tkId;
    p.relayRivalEpoch = g_tkEpoch;
    p.relayRivalTie = g_homeTkTie;
    p.relayRivalRssiAvg = g_homeTkRssiAvg;
    p.relayRivalScore = (int16_t)g_tkScore;
  }
  uint32_t dOff; uint64_t txCallUs;
  { uint64_t nowUs = (uint64_t)esp_timer_get_time();
    txCallUs = nowUs;
    dOff = (uint32_t)(nowUs - g_frameAnchorUs) + g_txLatUs;   // v7.28.24: predicted on-air departure, see memberSendData
    p.departDevUs = departDevFrom(dOff);
    // v7.21.0: two separate fields, written together, never conditional on
    // each other. depAttest16 is the departure integrity tag and is always
    // present. attToken is the crystal tag and is 0 until this sender is
    // enrolled. The blind #else that used to sit here wrote departAttest
    // into attToken and is deleted; a hard #error at the top of the file
    // now catches a build without CRYSTAL_TOKEN.
    p.depAttest16 = departAttest(p.src_id, p.seq, p.departDevUs);
    p.attToken    = ctokMintOr(p.src_id, p.seq, p.departDevUs);
  }
  mpktStampOriginDepth(&p);   // v7.29.8: origin depth in graceFlags[7:1], before CRC
  p.crc = crc8((uint8_t*)&p, sizeof(p)-1);
  femTx(); int16_t txStatus = LSM_TX((uint8_t*)&p, sizeof(p));
  if(ownedWasSkipped()){rxArmAfterTx();return;}
  if(txStatus==RADIOLIB_ERR_NONE){ uint64_t txRetUs = (uint64_t)esp_timer_get_time(); // Successful TX only.
    uint64_t txDoneUs = txDoneInstant(txCallUs, txRetUs);   // v7.28.25: done from the ISR, not the return
    txLatSample(txCallUs, txDoneUs, g_airWitnessUs ? g_airWitnessUs : g_memberAirUsLive);
    txDoneWitness(); }
  rxArmAfterTx();
  g_seq++;
  if (txStatus == RADIOLIB_ERR_NONE) {
#if LSM_PAYLOAD_PROBE
    g_payloadOriginTx++;
#endif
    logRec(LOG_TX, NODE_ID, g_role, 0xF9, 0, 0, (uint32_t)p.seq | ((uint32_t)g_mySlot << 8));   // v7.28.33: slot in data bits 8-15. v7.28.21: aux 0xF9 = present/keepalive ping. Was 0xFD, which is the FLOOD JOIN request code; the two were separable only by the role field and a decode of the v7.28.20 capture initially read ~6500 keepalives as a flood-join storm. Distinct code now.
  } else
    logRec(LOG_RF, NODE_ID, g_role, 0, 3, 6, (uint32_t)(int32_t)txStatus);   // scheduled present TX failed; do not count it as sent
  logSlotTrim(dOff);                      // v7.12.25 observe-only slot-time trim
}

// v7.30.0: request an aggregate tail using this relay's ordinary owned slot.
// One request every four schedule sequences is enough to keep a backlog moving
// while preserving three out of four slots for the relay's own position.
void memberSendAggDemand(uint8_t records){
  if (!records) return;
  if (records > AGG_POS_MAX_REC) records = AGG_POS_MAX_REC;
  MemberPkt p; memset(&p, 0, sizeof(p));
  p.src_id = (uint16_t)NODE_ID; p.type = MEMBER_TYPE_AGG_DEMAND;
  p.seq = (uint8_t)g_curSchedSeq; p.flags_conf = (uint8_t)(0x80U | records);
  p.z_floor = (int8_t)(g_anchorHops == 255 ? 0 : g_anchorHops);
  p.relayerId = ksSideReq();
  uint64_t nowUs = (uint64_t)esp_timer_get_time();
  uint32_t dOff = (uint32_t)(nowUs - g_frameAnchorUs) + g_txLatUs;
  p.departDevUs = departDevFrom(dOff);
  p.depAttest16 = departAttest(p.src_id, p.seq, p.departDevUs);
  p.attToken = ctokMintOr(p.src_id, p.seq, p.departDevUs);
  mpktStampOriginDepth(&p);
  p.crc = crc8((uint8_t*)&p, sizeof(p)-1);
  femTx(); int16_t ownedStatus=LSM_TX((uint8_t*)&p, sizeof(p)); rxArmAfterTx();
  if(g_owned.scope&&ownedStatus!=RADIOLIB_ERR_NONE)return;
  g_seq++;
  logRec(LOG_TX, NODE_ID, g_role, 0xA1, records, p.z_floor, p.seq);
}

// ----------------------- v7 once-a-second housekeeping -----------------------
// Carries the non-MAC duties the old meshTick held: the receiver watchdog and
// the batched log flush. Election lives in frameEngine now.
void houseTick(){
  uint32_t now = millis();
  static uint32_t lastRxKick = 0;
  // v7.28.35: NON-DESTRUCTIVE RECEIVER WATCHDOG. On c11 (v7.28.34) this fired
  // 11 to 12 times per board per run, on every board, many exactly 30.5 s
  // apart. radio.begin is a full SX1262 reset plus recalibration (SX1262.cpp
  // 8-30), which takes the receiver down and fires on the very condition it
  // is meant to cure: hearing nothing. The chip was never found wedged; every
  // miss was a header error on a modem that was otherwise responding. So the
  // soft path first: standby, clear the IRQ register, re-arm receive on the
  // CURRENT channel, FEM back to RX. Nothing is torn down. The full begin is
  // kept as the fallback and only runs after two consecutive soft kicks have
  // not produced a reception. Witness: LOG_RF aux 1, e = 1 soft, e = 2 hard,
  // n = consecutive kicks so far, data = status.
  static uint8_t  rxKicks = 0;
  // v7.30.3: a failed command proves the local radio path unhealthy. Rebuild
  // it at this safe once-per-second boundary instead of waiting through the
  // 30/60/90-second silence ladder. LOG_RF aux 23 records recovery outcome.
  if (g_radioOk && g_radioRecoverRequested) {
    int16_t st = lsmRadioBegin();
    if (st == RADIOLIB_ERR_NONE) st = radioConfig();
    if (st == RADIOLIB_ERR_NONE) st = radio.setFrequency(g_currentFreqMHz);
    lsmIrqAttach();
    femRx();
    if (st == RADIOLIB_ERR_NONE) st = lsmRxArm();
    logRec(LOG_RF, NODE_ID, g_role, 23, g_radioFirstFaultStage, st,
           ((uint32_t)(uint16_t)g_radioFirstFaultStatus << 16) |
           (digitalRead(PIN_LORA_BUSY) == HIGH ? 1U : 0U));
    if (st == RADIOLIB_ERR_NONE) {
      g_radioRecoverRequested = false;
      g_radioFirstFaultStage = 0;
      g_radioFirstFaultStatus = 0;
      rxKicks = 0;
      lastRxKick = now;
      radioElectionGateSet(true, now);
    }
  }
  if (g_radioOk && now - g_lastRxMs > 30000 && now - lastRxKick > 30000) {
    lastRxKick = now;
    int16_t st;
    if (rxKicks < 2) {
      rxKicks++;
      st = radio.standby();
      if (st != RADIOLIB_ERR_NONE) radioFaultNote(3, st);
      if (st == RADIOLIB_ERR_NONE) {
        st = radio.clearIrq();
        if (st != RADIOLIB_ERR_NONE) radioFaultNote(4, st);
      }
      lsmIrqAttach();
      femRx();        // v7.28.41: LNA to full gain BEFORE the arm. CTX (GPIO5) is
      if (st == RADIOLIB_ERR_NONE) {
        st = lsmRxArm();
        if (st != RADIOLIB_ERR_NONE) radioFaultNote(5, st);
      }
                      // the LNA bypass/gain select, not the path select; arming
                      // first left the receiver in bypass for a beat, arming deaf.
      logRec(LOG_RF, NODE_ID, g_role, 1, 1, rxKicks, (uint32_t)(int32_t)st);
    } else {
      rxKicks = 0;
      st = lsmRadioBegin();   // v7.28.47: per-family begin (TCXO volts, LR1121 switch table)
      if (st == RADIOLIB_ERR_NONE) st = radioConfig();
      if (st == RADIOLIB_ERR_NONE) st = radio.setFrequency(g_currentFreqMHz);   // begin and radioConfig leave the chip on channel A
      lsmIrqAttach();
      femRx();        // v7.28.41: LNA to full gain before the arm, same as the soft branch.
      if (st == RADIOLIB_ERR_NONE) st = lsmRxArm();
      if (st == RADIOLIB_ERR_NONE) radioElectionGateSet(true, now);
      else radioFaultNote(9, st);
      logRec(LOG_RF, NODE_ID, g_role, 1, 2, 0, (uint32_t)(int32_t)st);
    }
  } else if (now - g_lastRxMs <= 30000) {
    rxKicks = 0;   // a reception clears the ladder
  }
  // v7.29.26: keeper-specific receiver health.  V25 proved that the generic
  // watchdog can keep seeing traffic while all seated member reports vanish
  // together for 100-200 seconds.  Four full superframes (bounded to 15-30 s)
  // without one authenticated MemberPkt is a receiver fault, not ten unrelated
  // member failures.  Rebuild the modem on the current working channel before
  // the 90 s roster lease can expire.  LOG_RF aux 20: e=roster size,
  // n=radio status, data=member-silence milliseconds.
  static uint32_t lastMemberRecoverMs = 0;
  if (g_radioOk && g_role == 3 && g_rosterN > 0) {
    uint32_t memberSilenceMs = now - g_lastMemberRxMs;
    uint32_t memberLimitMs = (g_frameUs / 1000UL) * 4UL;
    if (memberLimitMs < 15000UL) memberLimitMs = 15000UL;
    if (memberLimitMs > 30000UL) memberLimitMs = 30000UL;
    if (memberSilenceMs > memberLimitMs && now - lastMemberRecoverMs > memberLimitMs) {
      lastMemberRecoverMs = now;
      int16_t st = lsmRadioBegin();
      if (st == RADIOLIB_ERR_NONE) st = radioConfig();
      if (st == RADIOLIB_ERR_NONE) st = radio.setFrequency(g_currentFreqMHz);
      lsmIrqAttach();
      g_loraIrq = false;
      femRx();
      lsmRxArm();
      logRec(LOG_RF, NODE_ID, g_role, 20, (int16_t)g_rosterN, st, memberSilenceMs);
    }
  } else {
    lastMemberRecoverMs = now;
  }
  // v7.20.12: pre-erase the spare log half OFF the hot path, members and
  // listeners only. The erase can block for whole seconds (the log wrap
  // freeze), which a TK cannot afford mid-reign: ten seconds of beacon
  // silence is the failover line. A TK keeps the timed inline path until
  // the FSOP witness data settles the role-aware handoff design. Fires
  // once per half-fill at the 90 percent line, so any board that spends
  // time as member or listener between wraps gets the instant swap.
  if (g_fsOk && !g_spareClean && g_role != 3 && g_logActiveSz >= (LOG_CAP*9)/10) {
    uint32_t t0 = millis();
    const char* spare = (g_logActive == LOG_FA) ? LOG_FB : LOG_FA;
    FS_LOCK();                     // v7.28.71: serialize against the core-0 writer
    LittleFS.remove(spare);
    FS_UNLOCK();
    g_spareClean = true;
    logRec(LOG_FSOP, NODE_ID, g_role, 2, (int16_t)(g_logActiveSz/1024), 0, millis() - t0);
  }
  bool locked = g_haveRealFix && gps.location.isValid();   // v7.28.64: a provisional origin is not a lock
  static bool wasLocked = false;
  if (locked != wasLocked) {
    wasLocked = locked;
    logRec(LOG_LOCK, NODE_ID, g_role, (uint8_t)gps.satellites.value(), 0, 0, locked ? 1 : 0);
  }
  { // v7.28.64: LOG_POS witness, once a second while a position is held and on every state change
    static uint8_t lastState = 0xFF;
    if (g_posState != lastState || g_posValid){
      lastState = g_posState;
      uint32_t sv = gps.satellites.isValid() ? gps.satellites.value() : 0; if (sv > 255) sv = 255;
      uint32_t hd = gps.hdop.isValid() ? (uint32_t)gps.hdop.value() : 0; if (hd > 32767) hd = 32767;
      int32_t xd = (int32_t)g_fusE/10, yd = (int32_t)g_fusN/10;
      uint8_t x8 = (uint8_t)(int8_t)(xd>127?127:(xd<-128?-128:xd)), y8 = (uint8_t)(int8_t)(yd>127?127:(yd<-128?-128:yd));
      logRec(LOG_POS, NODE_ID, g_role, g_posState, (int16_t)(g_posValid ? g_posConf : 0), (int16_t)hd,
             (uint32_t)sv | ((uint32_t)x8 << 8) | ((uint32_t)y8 << 16) | ((uint32_t)g_posLogJumpM << 24));
      g_posLogJumpM = 0;
      // v7.29.6 ABSOLUTE POSITION WITNESS, LOG_POSABS. The LOG_POS record above
      // carries position ONLY as x_dm/y_dm, plain int8 decimetres, range plus or
      // minus 12.7 m. On the 2026-09-24 walk those pinned at the clamp rail on
      // 97 to 98 percent of records for every board that actually moved, so no
      // walk could be graded for distance and no RSSI versus range curve could be
      // built. The absolute fix is already available here in microdegrees and
      // already rides the wire in MemberPkt.latI/lonI since v7.28.70-absposbranch,
      // so nothing new is measured or transmitted: this is a logging gap, not a
      // wire gap. Emitted alongside LOG_POS, never replacing it, because the
      // offsets are the indoor ultra wideband path (officer to officer relative
      // position including floor) and must not be removed per Stuart 2026-09-16.
      //
      // FULL microdegree precision, deliberately NOT the LOG_RXABS coarse format.
      // RXABS stores 0.1 deg in e/n plus a 0.001 deg remainder byte, about 110 m
      // resolution, which was fine for watching a mile-apart node on a drive but
      // would collapse a 230 m range walk into two buckets. Instead all eight
      // integer bytes carry the fix: latI (int32 microdeg) whole in data, lonI
      // (int32 microdeg) split high/low across the e and n int16 fields. That is
      // about 0.1 m on the ground, far finer than the fix itself. Satellite count
      // rides in aux; confidence, state and HDOP are in the sibling LOG_POS record
      // at the same millisecond, so nothing is lost by not repeating them here.
      // Sentinel-gated: a zero pair is not logged.
      if (g_posValid) {
        int32_t plat = (int32_t)llround(g_posLat*1000000.0);
        int32_t plon = (int32_t)llround(g_posLon*1000000.0);
        if (plat != 0 || plon != 0) {
          logRec(LOG_POSABS, NODE_ID, g_role, (uint8_t)sv,
                 (int16_t)(uint16_t)((uint32_t)plon >> 16),
                 (int16_t)(uint16_t)((uint32_t)plon & 0xFFFFu),
                 (uint32_t)plat);
        }
      }
    }
  }
  static uint32_t lastFlush = 0;
  if (millis() - lastFlush > 8000 && !uiTailLogDeferred()) { lastFlush = millis(); logFlush(); }
  // v7.10.8: decay the overheard-join-request counter that drives adaptive
  // backoff, so a burst of contention a while back does not keep a board
  // backed off forever once things quiet down.
  static uint32_t lastJoinDecayMs = 0;
  if (now - lastJoinDecayMs > JOIN_BACKOFF_DECAY_MS) {
    lastJoinDecayMs = now;
    if (g_recentJoinReqCount > 0) g_recentJoinReqCount--;
  }
}

// v7.10.8: dynamic join modulus from roster size, see the comment above
// JOIN_SLOT_MOD_MAX for the reasoning and the thresholds.
// v7.16.0 WARNING, READ BEFORE REUSING THIS: sizing the join modulus off the
// ROSTER COUNT is backwards, and this function is the reason board 08 needed
// seven attempts to join on 2026-07-28. The roster is the population already
// IN. The modulus has to separate the population still OUTSIDE. At cold start
// the roster is near zero and every node is contending, and this returns 4,
// its smallest value, at the moment contention is highest. The TK now sizes
// the modulus from the observed node ID SPAN in tkJoinMod() and publishes it.
// What survives here feeds joinModEffective(), which tkJoinMod() consults ONLY
// as a raiser: it can widen the modulus under heavy join traffic, it can never
// pull it below the span derived floor of 8.
static uint32_t joinModBase(uint8_t nodeCount){
  if (nodeCount < 30) return 4;
  if (nodeCount < 80) return 8;
  return 16;
}
// v7.10.8: adaptive backoff on top of the base modulus. Heavier overheard
// join-request traffic than the base modulus was sized for means more
// simultaneous candidates than the base expected, so widen out until it
// quiets, same idea as WiFi's own congestion backoff.
static uint32_t joinModEffective(){
  uint32_t base = joinModBase((uint8_t)g_sphereCount);
  // v7.28.0: inside a JOIN superframe the burst windows absorb what the
  // multiplier was protecting the single window against, so the modulus sits
  // at base and roughly base-fraction of the backlog attempts per burst,
  // spread across the yielded slots. The multiplier below still governs DATA
  // frames, where the single fixed window is all there is.
  if (g_frameType == SF_TYPE_JOIN) return base;
  uint32_t mult = 1;
  if (g_recentJoinReqCount >= 6) mult = 4;
  else if (g_recentJoinReqCount >= 3) mult = 2;
  uint32_t eff = base * mult;
  return eff > JOIN_SLOT_MOD_MAX ? JOIN_SLOT_MOD_MAX : eff;
}

// v7.11.10: member-side flood tracking, mirrors the schedule-side logic in
// handleSched but keyed per (src_id, seq) in a small table since several
// distant nodes can each need forwarding in the same frame. Called for
// every type 0 or 6 packet heard from someone else, regardless of the
// dedup-for-processing outcome above, since a duplicate-for-processing
// packet can still carry a better hop count worth relaying further.
// v7.29.5 OPEN RELAY VOLUNTEER. The exclusive named-leg grant (v7.25.0) left node 04
// stranded at hop 3 on the 2026-09-24 walk while node 08 heard it at -74 dBm and was
// forbidden to carry it. A seated board that is NOT the named leg may now carry a
// stranded neighbour's uplink, guarded by schedule rather than by exclusivity:
//  OBSERVE   one adopted schedule sequence (g_seqHigh) after first hearing the src
//            unheard-by-keeper; the named leg fires in the SAME frame's reply window
//            (deadline = this frame's tierStart), so one sequence is enough to see it.
//  STAND DOWN the instant ANY forward (hops >= 1) of that src is heard, named or
//            volunteered, at no airtime cost; the claim clears and re-observes.
//  DEFER     across boards by a 5 dB bucket of the per-source averaged RSSI
//            (g_directDataRssi EMA, alpha 1/8, not the raw packet), stacked in whole
//            sequences after the observe window, cap +2, so the board hearing the
//            node loudest moves first and the rest hear its forward and stand down.
//            Inside a bucket the forward sits in the 12 ms relay jitter band at the
//            RSSI-biased base with a deterministic lowest-node-ID tiebreak.
//  GRACE     the volunteered forward carries MPKT_GRACE. Volunteering keys on
//            hops == 0 only, so a grace copy is never volunteered again; a named leg
//            carries it onward under GUARD 2. One hop of grace by construction.
//  SEATED    only a JOINED board holding a slot in the last adopted beacon with a
//            live depth may volunteer. LISTEN has no slot and no schedule trust.
//  LIFETIME  VOL_CLAIM_SEQS sequences, or dissolve when a beacon names a real leg
//            for the src (volCarryDissolve from handleSched). Keeper grant wins.
//  TARGET    an id the keeper did NOT hear last frame (g_volOrphanMap, read at the
//            skew-corrected slot) or a join request from an id holding no slot this
//            frame (a fallen node re-entering). Anything the keeper already hears is
//            never carried, which is what keeps this from doubling every uplink.
#define VOL_CARRY_N       8
#define VOL_CLAIM_SEQS    8
#define VOL_BUCKET_DB     5
#define VOL_BUCKET_CAP    2
#define VOL_BUCKET_REF_DBM DIRECT_RSSI_RECOVER_DBM   // -65: at or above this the volunteer waits 0 extra sequences
struct VolCarry { uint8_t src; uint8_t seenSeq; uint8_t dueSeq; uint8_t claimSeq; bool claimed; bool active; };
static VolCarry g_volCarry[VOL_CARRY_N];
static int16_t volRssiEma(uint8_t src, int16_t fallback){
  for (int i = 0; i < DIRECT_RSSI_TRACK_N; i++)
    if (g_directDataRssi[i].active && g_directDataRssi[i].srcId == src) return g_directDataRssi[i].ema;
  return fallback;
}
static uint8_t volBucket(int16_t ema){
  if (ema >= VOL_BUCKET_REF_DBM) return 0;
  int b = (VOL_BUCKET_REF_DBM - ema + VOL_BUCKET_DB - 1) / VOL_BUCKET_DB;
  return (uint8_t)(b > VOL_BUCKET_CAP ? VOL_BUCKET_CAP : b);
}
static VolCarry* volCarryFind(uint8_t src){
  for (int i = 0; i < VOL_CARRY_N; i++) if (g_volCarry[i].active && g_volCarry[i].src == src) return &g_volCarry[i];
  return nullptr;
}
// v7.29.13 EVIDENCE-GATED DISSOLVE. Through v7.29.12 a beacon that merely NAMED a leg for
// src killed this board's volunteer claim, with no witness, whether or not the named leg
// was alive. A leg the keeper latched under the parent-hold rule can be named for frames
// after it has walked out of range, so the claim died on the name alone and the carry
// never fired, and the kill left no record. Now the
// claim dissolves only when this board has evidence the named leg is alive: it IS the
// named leg, or it heard the named relayer's own traffic within VOL_LEG_HEARD_FRAMES
// adopted frames (peer table lastMs, refreshed by the first copy of that board's own
// type 0 packet, direct or relayed). This proves the leg is alive on the air, not that
// it can hear src; that second question stays with the keeper's heardMask. A name with
// no relayer, or a relayer this board has not heard, keeps the claim; the claim still
// ends by stand-down on a heard uphill forward (0xD4) or by TTL (0xD3).
// Tradeoff on record: if the named leg is alive but out of THIS board's earshot, both
// may carry the same uplink until the claim's TTL. A duplicate grace copy costs one
// reply-tier transmit; a dead leg costs the node. -D LSM_VOL_DISSOLVE_EVIDENCE=0
// compiles the v7.29.12 name-only dissolve back, witness kept.
// Witness LOG_STATE 0xCF: e = src, n = named relayer, data = seq | outcome << 24
// (1 dissolved on evidence, 0 kept: named but unheard, 2 kept: no relayer named).
#ifndef LSM_VOL_DISSOLVE_EVIDENCE
#define LSM_VOL_DISSOLVE_EVIDENCE 1
#endif
// v7.29.14: volLegHeard read g_peers[].lastMs, but peerMarkGateway (reached
// through peerNoteGranted, called on every beacon that names a relayer) writes
// that same field on the naming alone, with no packet received. A keeper that
// keeps naming a relayer who has walked off this board's air kept that field
// looking fresh, so the "evidence" gate dissolved the claim on the name alone,
// exactly like v7.29.12, just with a witness now attached. Fixed: read the
// first-hand table volNoteHeard fills, hop-0 sightings only, the same table and
// the same TTL test volPick already trusts for the same purpose.
static void volCarryDissolve(uint8_t src, uint8_t namedRelayer){
  if (!src || !volCarryFind(src)) return;
  // v7.29.15: a grant or unrelated traffic is not forwarding evidence.
  // Keep the rescue until a useful source forward, successful TX, or TTL.
  logRec(LOG_STATE, NODE_ID, g_role, 0xCF, src, namedRelayer,
         (uint32_t)g_seqHigh | ((namedRelayer ? 0UL : 2UL) << 24));
}
// v7.29.8: overheard-depth cache is the FALLBACK, not the source of truth.
// Hop-0 origins now stamp depth in graceFlags[7:1]. Relayed copies still stamp
// volunteerFor = forwarder_depth+1. The cache only holds what a live volunteer
// claim needs (src + overheard relayers) so a mixed-fleet hop-0 with no stamp
// can still be judged after that id has been seen as a relayer.
// VOL_DEPTH_N = 24: VOL_CARRY_N (8) sources plus two relayers each. Not a
// roster and not the production 14k id space. Evicted by age, not only by fill:
// VOL_DEPTH_TTL_SEQS (16) schedule sequences, two claim lifetimes.
#define VOL_DEPTH_N 24
#define VOL_DEPTH_TTL_SEQS 16
struct VolDepth { uint8_t id; uint8_t depth; uint8_t seq; bool active; };
static VolDepth g_volDepth[VOL_DEPTH_N];
static uint8_t volDepthOf(uint8_t id){
  if (id == 0) return 255;
  if (g_tkId != 0 && id == g_tkId) return 0;
  if (id == (uint8_t)NODE_ID) return g_anchorHops;
  for (int i = 0; i < VOL_DEPTH_N; i++){
    if (!g_volDepth[i].active || g_volDepth[i].id != id) continue;
    if ((int8_t)(g_seqHigh - g_volDepth[i].seq) >= VOL_DEPTH_TTL_SEQS) { g_volDepth[i].active = false; return 255; }
    return g_volDepth[i].depth;
  }
  return 255;
}
static void volDepthNote(uint8_t id, uint8_t depth){
  if (id == 0 || depth == 255) return;
  if (id == (uint8_t)NODE_ID || (g_tkId != 0 && id == g_tkId)) return;
  int k = -1;
  for (int i = 0; i < VOL_DEPTH_N; i++){
    if (g_volDepth[i].active && (int8_t)(g_seqHigh - g_volDepth[i].seq) >= VOL_DEPTH_TTL_SEQS) g_volDepth[i].active = false;
    if (g_volDepth[i].active && g_volDepth[i].id == id) { g_volDepth[i].depth = depth; g_volDepth[i].seq = g_seqHigh; return; }
    if (k < 0 && !g_volDepth[i].active) k = i;
  }
  if (k < 0) { k = 0; for (int i = 1; i < VOL_DEPTH_N; i++) if ((int8_t)(g_volDepth[i].seq - g_volDepth[k].seq) < 0) k = i; }
  g_volDepth[k].active = true; g_volDepth[k].id = id; g_volDepth[k].depth = depth; g_volDepth[k].seq = g_seqHigh;
}
static void volCarryNoteFwd(uint8_t src, uint8_t relayer){
  VolCarry* c = volCarryFind(src);
  if (!c) return;
  logRec(LOG_STATE, NODE_ID, g_role, 0xD4, (int16_t)src, (int16_t)relayer, (uint32_t)g_seqHigh);   // v7.29.5: stand-down, somebody carried it
  
  // v7.29.9: When we hear a forward of src, kill the g_volClaim and record cooldown
  volClaimKillAndCooldown(src);
  
  c->active = false;
}
// v7.29.8: stand down only if the overheard forward is making uphill progress.
// Relayer depth: volunteerFor-1 on a hops>=1 copy. Source depth: origin nibble
// on this packet first, then the fallback cache. Same-depth or deeper echoes
// are lateral traps and must not dissolve the claim. Unknown either side:
// keep the claim (fail-open). 0xD1 grades the suppress.
static bool volFwdIsUseful(const MemberPkt* p){
  if (p->hops < 1) return false;
  uint8_t rDep = 255;
  if (p->volunteerFor != 0) {
    rDep = (uint8_t)(p->volunteerFor - 1);
    volDepthNote(p->relayerId, rDep);
  } else {
    rDep = volDepthOf(p->relayerId);
  }
  uint8_t sDep = mpktOriginDepth(p);
  if (sDep != 255) volDepthNote((uint8_t)p->src_id, sDep);
  else             sDep = volDepthOf((uint8_t)p->src_id);
  return (rDep != 255 && sDep != 255 && rDep < sDep);
}
// Returns the jitter offset into the reply tier if this board should fire a grace
// forward for src on this frame, or 0xFFFFFFFF if not.
static uint32_t volCarryDecide(uint8_t src, int16_t rssi){
  int16_t ema = volRssiEma(src, rssi);
  uint8_t bucket = volBucket(ema);
  VolCarry* c = volCarryFind(src);
  if (!c) {
    int k = -1;
    for (int i = 0; i < VOL_CARRY_N; i++) if (!g_volCarry[i].active) { k = i; break; }
    if (k < 0) { k = 0; for (int i = 1; i < VOL_CARRY_N; i++) if ((int8_t)(g_volCarry[i].seenSeq - g_volCarry[k].seenSeq) < 0) k = i; }   // evict the oldest claim
    c = &g_volCarry[k];
    c->active = true; c->src = src; c->claimed = false;
    c->seenSeq = g_seqHigh;
    c->dueSeq  = (uint8_t)(g_seqHigh + 1 + bucket);   // one sequence of observation, then the bucket stack
    c->claimSeq = 0;
    logRec(LOG_STATE, NODE_ID, g_role, 0xD5, (int16_t)src, (int16_t)bucket, (uint32_t)g_seqHigh | ((uint32_t)(uint8_t)ema << 24));   // v7.29.5: volunteer armed
    return 0xFFFFFFFFUL;
  }
  if ((int8_t)(g_seqHigh - c->dueSeq) < 0) return 0xFFFFFFFFUL;   // still observing or still deferring
  if (c->claimed && (int8_t)(g_seqHigh - c->claimSeq) >= VOL_CLAIM_SEQS) {
    // v7.29.9 GATE 3 CHECK: before re-arming, check that cooldown has expired
    // v7.29.12: look the cooldown up by source. v7.29.11 passed the cooldown table to the
    // claim-table free-slot finder (type error), and a free slot is never this src's entry.
    uint8_t cooldown_idx = volCooldownFindBySource(g_volCooldowns, src);
    
    // GATE 3: both cooldown AND TTL must pass (wraparound-safe signed int8 math)
    bool cooldown_expired = true;
    if (cooldown_idx < VOL_CARRY_N && g_volCooldowns[cooldown_idx].srcId == src) {
      int8_t cooldown_age = (int8_t)(g_seqHigh - g_volCooldowns[cooldown_idx].expiry_seq);
      if (cooldown_age < 0) cooldown_expired = false;  // cooldown not yet expired
    }
    
    if (!cooldown_expired) {
      // Cooldown still active, cannot re-arm yet
      return 0xFFFFFFFFUL;
    }
    
    logRec(LOG_STATE, NODE_ID, g_role, 0xD3, (int16_t)src, 0, (uint32_t)g_seqHigh);   // v7.29.5: claim expired, re-observe from scratch
    
    // v7.29.9 HARDENING 2: record cooldown when claim expires by TTL
    // If table is full, evict oldest by expiry_seq. Never silently drop a new entry.
    uint8_t new_cooldown_idx = volCooldownFindFree(g_volCooldowns);
    if (new_cooldown_idx >= VOL_CARRY_N) {
      new_cooldown_idx = volCooldownFindOldest(g_volCooldowns, g_seqHigh);
    }
    if (new_cooldown_idx < VOL_CARRY_N) {
      g_volCooldowns[new_cooldown_idx].srcId = src;
      g_volCooldowns[new_cooldown_idx].expiry_seq = (int8_t)(g_seqHigh + VOL_REARM_COOLDOWN_SEQS);
    }
    
    c->active = false;
    return 0xFFFFFFFFUL;
  }
  if (!c->claimed) { 
    // v7.29.9 GATE 3 + HARDENING 2: AND-guard before arming
    // Check 1: Is there an active cooldown for this src?
    for (uint8_t i = 0; i < VOL_CARRY_N; i++) {
      if (g_volCooldowns[i].srcId == src && volCooldownActive(&g_volCooldowns[i], g_seqHigh)) {
        // Cooldown still active, cannot re-arm yet
        return 0xFFFFFFFFUL;
      }
    }
    
    c->claimed = true; 
    c->claimSeq = g_seqHigh;
    
    // v7.29.9 MERGE: ARM INTO g_volClaims WITH IDEMPOTENT ALLOCATION
    // Before calling volClaimArm, check if we'll evict someone (table full + no existing slot for src)
    uint8_t victim_src = 0;
    if (volClaimFindBySource(g_volClaims, src) >= VOL_CARRY_N &&  // src doesn't already have a claim
        volClaimFindFree(g_volClaims) >= VOL_CARRY_N) {            // table is full
      // volClaimArm will evict the oldest claim; find it now to record cooldown
      uint8_t evict_idx = volClaimFindOldest(g_volClaims, g_seqHigh);
      if (evict_idx < VOL_CARRY_N && volClaimIsAlive(&g_volClaims[evict_idx])) {
        victim_src = g_volClaims[evict_idx].srcId;
      }
    }
    
    // Arm the claim (idempotent: refreshes if src already exists, allocates or evicts if new)
    uint8_t claim_idx = volClaimArmTable(g_volClaims, src, (uint8_t)NODE_ID, 0, (int8_t)g_seqHigh);   // v7.29.12: table-level arm returns the slot; volClaimArm is the single-slot primitive
    
    // If we evicted someone, record cooldown for the victim
    if (victim_src != 0) {
      uint8_t cooldown_idx = volCooldownFindFree(g_volCooldowns);
      if (cooldown_idx >= VOL_CARRY_N) {
        cooldown_idx = volCooldownFindOldest(g_volCooldowns, g_seqHigh);
      }
      if (cooldown_idx < VOL_CARRY_N) {
        g_volCooldowns[cooldown_idx].srcId = victim_src;
        g_volCooldowns[cooldown_idx].expiry_seq = (int8_t)(g_seqHigh + VOL_REARM_COOLDOWN_SEQS);
      }
      // Decrement count since a claim was evicted
      if (g_volClaimCount > 0) g_volClaimCount--;
    }
    
    // Recount live claims to keep g_volClaimCount in sync
    if (claim_idx < VOL_CARRY_N) {
      g_volClaimCount = 0;
      for (uint8_t i = 0; i < VOL_CARRY_N; i++) {
        if (volClaimIsAlive(&g_volClaims[i])) {
          g_volClaimCount++;
        }
      }
    }
  }
  // inside the bucket: RSSI-biased base of the relay jitter, node-ID tiebreak instead of esp_random
  uint32_t j = relayJitterBaseUs(ema);   // RSSI-biased base, no random draw
  j += (uint32_t)((uint8_t)NODE_ID & 15u) * (RELAY_JITTER_TIEBREAK_US / 16UL);   // lowest node ID first, deterministic on every board
  if (j >= RELAY_JITTER_MAX_US) j = RELAY_JITTER_MAX_US - 1;
  return j;
}
static void memberFloodNote(const MemberPkt* p, const uint8_t* raw, int len, int16_t rssi){
  if ((size_t)len != sizeof(MemberPkt)) return;
  if (p->hops >= 1 && g_role != 3) {
    // v7.29.9 PEER UPLINK: latch every hop-1 relay for gateway discovery confirmation
    peerNoteRelayHeard((uint8_t)p->relayerId, (uint8_t)p->src_id, rssi);
    // Type 7 keeps volunteerFor as the admitted joiner id all the way to the
    // keeper. Do not reinterpret it as the generic relay-depth stamp.
    if (p->type != MEMBER_TYPE_SWARM_REQ && volFwdIsUseful(p)) {
      volCarryNoteFwd((uint8_t)p->src_id, p->relayerId);
    } else if (p->type != MEMBER_TYPE_SWARM_REQ && volCarryFind((uint8_t)p->src_id)) {
      logRec(LOG_STATE, NODE_ID, g_role, 0xD1, (int16_t)p->src_id, (int16_t)p->relayerId,
             (uint32_t)g_seqHigh | ((uint32_t)mpktOriginDepth(p) << 16) | ((uint32_t)((p->volunteerFor != 0) ? (uint8_t)(p->volunteerFor - 1) : 255) << 24));   // v7.29.8: hops>=1 heard, NOT uphill, claim kept
    }
  }
  if (p->hops >= RELAY_MAX_HOPS - 1) return;   // already at or past the depth cap
  int slot = -1;
  for (int i=0;i<RELAY_MEMBER_TRACK_N;i++){
    if (g_memberFlood[i].active && g_memberFlood[i].srcId==p->src_id && g_memberFlood[i].seq==p->seq){ slot=i; break; }
  }
  if (slot < 0){
    for (int i=0;i<RELAY_MEMBER_TRACK_N;i++){ if (!g_memberFlood[i].active){ slot=i; break; } }
  }
  if (slot < 0) {
    // Never overwrite a queued forward. Reclaim completed entries only.
    for (int i=0;i<RELAY_MEMBER_TRACK_N;i++) {
      if (g_memberFlood[i].relayed || g_memberFlood[i].deadlineUs == RELAY_NO_DEADLINE) { slot=i; break; }
    }
    if (slot < 0) { ++g_relayQueueFull; return; }
  }
  MemberFloodEntry &e = g_memberFlood[slot];
  if (!e.active || e.srcId != p->src_id || e.seq != p->seq){
    e.active = true; e.srcId = p->src_id; e.seq = p->seq;
    e.bestHop = 255; e.outHop = 255; e.relayed = false; e.deadlineUs = RELAY_NO_DEADLINE;
  }
  if (p->hops < e.bestHop){
    e.bestHop = p->hops;
    uint8_t outHop = (uint8_t)(p->hops + 1);
    // v7.25.0 EXCLUSIVE REQUESTER-DRIVEN RELAY GRANT. Only the board the TK named
    // as relayById for this member (relayForId, read into g_relayAssignedFor off the
    // last beacon) schedules a forward. Every other board still tracks bestHop above
    // for dedup but never transmits: the roughly 97 percent cut. On a bench where the
    // TK hears every member directly the beacon builder assigns no relay,
    // g_relayAssignedFor is 0, and nobody relays. No flood fallback: a dead relay is
    // replaced by the TK reassigning relayById within a few frames under the v7.22.0
    // parent-hold latch. RSSI-weighted jitter is retired on this path, since exactly
    // one board forwards and there is nothing to order.
    bool leg1 = (g_relayAssignedFor  != 0 && (uint8_t)p->src_id == g_relayAssignedFor);
    bool leg2 = (g_relayAssignedFor2 != 0 && (uint8_t)p->src_id == g_relayAssignedFor2);   // v7.28.104: second named leg
    bool iAmRelay = leg1 || leg2;
    // v7.29.21: type-7 admission traffic must climb farther than one named
    // leg. originDepth-hops is the previous sender's depth; a joined receiver
    // may forward only when it is strictly shallower. Jitter plus the existing
    // same-hop suppression selects one of several eligible receivers.
    bool swarmDepthRelay = false;
    uint32_t swarmJitter = 0;
    if (p->type == MEMBER_TYPE_SWARM_REQ && g_role == 1 && g_anchorHops != 255) {
      uint8_t originDepth = mpktOriginDepth(p);
      if (originDepth != 255 && p->hops <= originDepth) {
        uint8_t priorDepth = (uint8_t)(originDepth - p->hops);
        if (g_anchorHops < priorDepth) {
          swarmDepthRelay = true;
          swarmJitter = relayJitterBaseUs(rssi) +
                        (uint32_t)((uint8_t)NODE_ID & 15u) * (RELAY_JITTER_TIEBREAK_US / 16UL);
          if (swarmJitter >= RELAY_JITTER_MAX_US) swarmJitter = RELAY_JITTER_MAX_US - 1;
        }
      }
    }
    // v7.29.28: deterministic depth-path relay.  Hardware logs proved that the
    // immutable origin-depth field can be zero on a deep origin, so v27 refused
    // the first return leg even while the same board was anchored at H2..H5.
    // For an origin copy, a joined receiver anchored beyond direct keeper range
    // (H1+) is an eligible first-leg backup.  Every forward stamps that relay's
    // actual adopted schedule depth in volunteerFor; all subsequent receivers
    // must be STRICTLY shallower than that previous relay.  Thus a packet can
    // only climb H5->H4->...->H0, never move sideways or away from the keeper.
    // Natural all-H0 fleets produce no backup relays. Named legs still win at
    // the tier start; deterministic jitter and existing dedup choose one backup.
    bool continuationRelay = false;
    uint32_t continuationJitter = 0;
    if (p->type != MEMBER_TYPE_SWARM_REQ && g_role == 1 && g_anchorHops != 255) {
      bool towardKeeper = false;
      if (p->hops == 0) {
        // v7.29.53: the old anchor>0 test admitted BOTH neighbours of a deep
        // origin.  The outward neighbour then stamped and bounced a competing
        // copy back toward the source, consuming the same relay tiers as the
        // valid inward path.  Every current-wire origin stamps its adopted
        // depth in graceFlags, so the first leg can apply the same monotonic
        // rule as every continuation: receiver depth must be strictly lower.
        // Unknown/legacy depth fails closed; this fleet is coordinated on the
        // current wire and an unstamped copy must not manufacture direction.
        uint8_t originDepth = mpktOriginDepth(p);
        towardKeeper = ((uint8_t)p->src_id != (uint8_t)NODE_ID) &&
                       (originDepth != 255) &&
                       (g_anchorHops < originDepth);
      } else {
        uint8_t previousDepthStamp = p->volunteerFor;
        towardKeeper = (previousDepthStamp != 0) &&
                       (g_anchorHops < (uint8_t)(previousDepthStamp - 1));
      }
      if (towardKeeper) {
        continuationRelay = true;
        continuationJitter = relayJitterBaseUs(rssi) +
                             (uint32_t)((uint8_t)NODE_ID & 15u) * (RELAY_JITTER_TIEBREAK_US / 16UL);
        if (continuationJitter >= RELAY_JITTER_MAX_US) continuationJitter = RELAY_JITTER_MAX_US - 1;
      }
    }
    // v7.29.5: volunteer carry. Not the named leg, hop-0 copy, seated with a live depth,
    // and the sender is one the keeper did not hear last frame (skew-corrected mask) or
    // an unseated node asking to join. observe -> defer -> fire is inside volCarryDecide.
    uint32_t volJitter = 0xFFFFFFFFUL;
    if (!iAmRelay && p->hops == 0 && g_role == 1 && g_anchorHops != 255 && g_mySlotLastFrame < V7_SLOTS_MAX
        && (uint8_t)p->src_id != (uint8_t)NODE_ID && p->src_id < 256
        && (volMapGet(g_volOrphanMap, (uint8_t)p->src_id) || (p->type == 2 && !volMapGet(g_volSlottedMap, (uint8_t)p->src_id)))) {
      volJitter = volCarryDecide((uint8_t)p->src_id, rssi);
    }
    bool volFire = (volJitter != 0xFFFFFFFFUL);
    // v7.28.104 GUARD 2, decreasing hop before arm. A forward must move toward the TK.
    // The origin copy (hops 0) is forwarded by the board the keeper named for it, and
    // only if this board holds a live depth. A relayed copy (hops >= 1) carries its
    // sender's depth + 1 in volunteerFor (stamped by relayMemberTx), and is forwarded
    // only if this board is STRICTLY shallower than that sender. Unstamped: refused.
    bool hopDown = false;
    if (iAmRelay && g_anchorHops != 255) {
      if (p->hops == 0) hopDown = true;
      else { uint8_t st = p->volunteerFor; hopDown = (st != 0) && (g_anchorHops < (uint8_t)(st - 1)); }
    }
    if (volFire) hopDown = true;   // v7.29.5: a volunteer only ever carries a hop-0 copy, which is downhill by definition
    if (swarmDepthRelay) hopDown = true;   // v7.29.21: strict depth check already passed above
    if (continuationRelay) hopDown = true;   // v7.29.22: strict depth check already passed above
    bool relayEligible = iAmRelay || volFire || swarmDepthRelay || continuationRelay;
    bool dupFwd = relayEligible && relayFwdSeen((uint8_t)p->src_id, outHop);   // v7.28.104 GUARD 3
    
    // v7.29.9 GATE 2: per-neighbor dedup (srcId, relayerId, hop) - kill ping-pong on repeat arrivals
    bool dedup_hit = false;
    if (relayEligible && hopDown && !dupFwd) {
      uint8_t dedup_idx = volDedupFind(g_volDedup, (uint8_t)p->src_id, (p->relayerId != 0) ? p->relayerId : (uint8_t)p->src_id, (uint8_t)p->hops);
      if (dedup_idx < VOL_DEDUP_N) {
        // entry found: check if it's still fresh (within one frame's sequence range)
        dedup_hit = ((int8_t)(g_seqHigh - g_volDedup[dedup_idx].seq_seen) < 2);  // same or previous sequence
      }
    }
    
    if (relayEligible && hopDown && !dupFwd && !dedup_hit && outHop < RELAY_MAX_HOPS && outHop <= g_schedTiers){   // v7.19.0 brick6: runtime-tier clamp
      // Record this forward in the dedup table for future checks
      uint8_t free_idx = volDedupFindFree(g_volDedup);
      if (free_idx >= VOL_DEDUP_N) {
        // table full: evict the oldest entry
        free_idx = volDedupFindOldest(g_volDedup, g_seqHigh);
      }
      if (free_idx < VOL_DEDUP_N) {
        g_volDedup[free_idx].srcId = (uint8_t)p->src_id;
        g_volDedup[free_idx].relayerId = (p->relayerId != 0) ? p->relayerId : (uint8_t)p->src_id;
        g_volDedup[free_idx].hop = (uint8_t)p->hops;  // Key on received hops, not forwarded hops
        g_volDedup[free_idx].seq_seen = g_seqHigh;
      }
      relayFwdNote((uint8_t)p->src_id, outHop);
      e.relayed = false;
      e.outHop = outHop;
      e.grace = (!iAmRelay && volFire);   // v7.29.5: a named leg never marks grace; a volunteer always does
      memcpy(e.raw, raw, sizeof(MemberPkt));
      e.raw[offsetof(MemberPkt, hops)] = outHop;
      if (e.grace) e.raw[offsetof(MemberPkt, graceFlags)] |= MPKT_GRACE;
      e.rxUs = (uint32_t)esp_timer_get_time();
      uint32_t replyBase = g_memberBaseUs + (uint32_t)g_nSlotsThisFrame*g_slotUsLive;
      uint32_t tierStart = replyBase + (uint32_t)(outHop-1) * (RELAY_MEMBER_HOP_US + RELAY_JITTER_MAX_US);
      if (e.grace) {
        e.deadlineUs = tierStart + volJitter;   // v7.29.5: RSSI-biased base plus node-ID tiebreak, inside the 12 ms band
        logRec(LOG_STATE, NODE_ID, g_role, 0xD6, (int16_t)p->src_id, (int16_t)outHop, (uint32_t)p->seq | ((uint32_t)g_seqHigh << 16));   // v7.29.5: volunteer fired
      } else if (swarmDepthRelay && !iAmRelay) {
        e.deadlineUs = tierStart + swarmJitter;
      } else if (continuationRelay && !iAmRelay) {
        e.deadlineUs = tierStart + continuationJitter;
      } else {
        e.deadlineUs = tierStart + (leg1 ? 0UL : RELAY_LEG2_JITTER_US);   // v7.28.104 GUARD 1: leg 1 at the tier start, leg 2 11 ms later, inside the 12 ms band
      }
    } else {
      e.deadlineUs = RELAY_NO_DEADLINE;
    }
  } else if (p->hops == (uint8_t)(e.bestHop + 1) && !e.relayed){
    // someone else already completed the exact tier this node was about to produce
    e.deadlineUs = RELAY_NO_DEADLINE;
    e.relayed = true;
  }
}

static void telemetryRelayQueue(const telemetry::Snapshot& value){
  static_assert(sizeof(telemetry::Snapshot)==sizeof(MemberPkt), "Typed relay must fit the existing member slot");
  if(g_role!=1||g_anchorHops==255||g_frameType!=SF_TYPE_DATA||g_schedTiers<1||!g_frameAnchorUs)return;
  const bool leg1=g_relayAssignedFor==value.node,leg2=g_relayAssignedFor2==value.node;
  if(!leg1&&!leg2)return;
  if(relayFwdSeen(value.node,1))return;
  int slot=-1;
  for(int i=0;i<RELAY_MEMBER_TRACK_N;i++)if(g_memberFlood[i].active&&g_memberFlood[i].srcId==value.node&&g_memberFlood[i].seq==g_curSchedSeq){slot=i;break;}
  if(slot<0)for(int i=0;i<RELAY_MEMBER_TRACK_N;i++)if(!g_memberFlood[i].active||g_memberFlood[i].relayed||g_memberFlood[i].deadlineUs==RELAY_NO_DEADLINE){slot=i;break;}
  if(slot<0){g_relayQueueFull++;return;}
  auto &e=g_memberFlood[slot];e=MemberFloodEntry{};e.active=true;e.srcId=value.node;e.seq=g_curSchedSeq;e.bestHop=0;e.outHop=1;e.relayed=false;e.grace=false;
  e.rxUs=(uint32_t)esp_timer_get_time();memcpy(e.raw,&value,sizeof(value));
  const uint32_t replyBase=g_memberBaseUs+(uint32_t)g_nSlotsThisFrame*g_slotUsLive;
  e.deadlineUs=replyBase+(leg1?0UL:RELAY_LEG2_JITTER_US);
  relayFwdNote(value.node,1);
}

// v7.19.0 brick2: add one join record to the relay accumulator. Dedup on srcId
// (a joiner heard twice before forwarding is one record). Refresh token/age on a
// repeat. Drop silently only if the buffer is full AND every entry is fresh, which
// cannot happen in practice because aggFlush() drains at AGG_PKT_MAX_REC every frame.
static void aggBufAdd(uint8_t srcId, uint32_t token, uint32_t frame, bool firstHand){
  if (srcId == 0) return;
  if (g_pubMapValid && pubIdHas(srcId)) return;   // v7.28.102 item 6: a seated id is not a joiner, never cache it
  for (uint8_t i=0;i<g_aggN;i++){
    if (g_aggBuf[i].srcId == srcId){ g_aggBuf[i].token = token; g_aggBuf[i].rxFrame = frame; return; }   // refresh: NOT a fresh sighting, do not retake the latch
  }
  // v7.28.103 CORRECTION: the v7.28.102 comment that stood here claimed this
  // was a first-hand-only marker because "aggReaggregate re-adds an id already
  // in some OTHER board's cache, never this board's own fresh sighting twice."
  // That reasoning was wrong. The dedup loop above only checks whether THIS
  // board's own buffer already holds srcId, not whether this board heard it
  // directly. The FIRST time an intermediate board re-aggregates a joiner it
  // has never locally cached before, secondhand from a magic-B receive via
  // aggReaggregate, that is also a fresh insert from this board's own buffer's
  // point of view, and the latch fired exactly as if the sighting were direct.
  // memberSendSwarmReq hardcoded hops=0 on every transmission regardless of
  // how the id reached the latch, so the keeper's hop-0 check could not tell
  // the difference. Not an attack path: an honest relay manufactured a false
  // first-hand claim as ordinary traffic. Fixed by threading firstHand through
  // explicitly rather than inferring it from which insert happened to be fresh.
  // true only from the type-2/hops==0 receipt; false from both aggReaggregate
  // call sites, which are secondhand by construction.
  if (firstHand && g_admitId == 0) g_admitId = srcId;
  if (g_aggN >= AGG_BUF_N){
    // buffer saturated: overwrite the oldest rather than drop the newest joiner
    uint8_t oldest = 0; uint32_t of = g_aggBuf[0].rxFrame;
    for (uint8_t i=1;i<g_aggN;i++) if (g_aggBuf[i].rxFrame < of){ of = g_aggBuf[i].rxFrame; oldest = i; }
    g_aggBuf[oldest].srcId = srcId; g_aggBuf[oldest].token = token; g_aggBuf[oldest].rxFrame = frame;
    return;
  }
  g_aggBuf[g_aggN].srcId = srcId; g_aggBuf[g_aggN].token = token; g_aggBuf[g_aggN].rxFrame = frame;
  g_aggN++;
}
// v7.29.0 RIG_PHANTOM_CARRIER, node 12 ONLY. Injects a fixed set of synthetic
// UNSEATED joiner ids into this board's own aggregate cache, once per frame, so
// the keeper is driven to admit a batch through the EXISTING v7.28.5 birth path
// at a scale no real bench walk has produced. The phantoms enter through the
// front door exactly as a real distant joiner would: aggBufAdd here, then the
// unchanged per-frame flush and swarm ask read g_aggN and size the ask off it.
// No keeper-side special case exists; the keeper cannot tell a phantom from a
// real joiner, which is the whole point of the test.
//
// Window 210..225 (PHANTOM_ID_BASE .. +PHANTOM_N-1). v7.29.3: moved up from 201..216, which sat
// on C2..C4: 200..203 is the LSM_CMDCTR_CASCADE band and this comment only knew about C1 (200).
// 210 clears the whole band and leaves a visible gap in a dump. Still above every
// v2/v4/lilygo block, inside the 8-bit id fields. Nothing on the roster or the
// allow-list is ever in this window, so a phantom can never be confused with a seat.
//
// firstHand=true: node 12 claims to have heard these strangers itself, which is
// what drives the sized swarm ask and the g_admitId first-hand admit, the real load.
// Each id gets a distinct synthetic token so they look like sixteen fingerprints.
//
// NO RADIO LIMIT: a phantom never transmits a member slot once seated, so the
// keeper will peel it for silence exactly like the node 13 witness. That is
// expected. Do NOT grade steady-state occupancy or the seated-depth floor off
// phantom seats; this exercises the birth and admission path only.
#if defined(RIG_PHANTOM_CARRIER) && (NODE_ID == 12)
#ifndef PHANTOM_ID_BASE
#define PHANTOM_ID_BASE RIG_PHANTOM_ID_BASE
#endif
#ifndef PHANTOM_N
#define PHANTOM_N RIG_PHANTOM_ID_COUNT
#endif
static uint64_t g_phantomLastAnchor = 0;   // once-per-frame latch, same shape as g_lastAggFlushAnchor
static void phantomCarrierTick(){
  // Only while this board has adopted a schedule (a real depth to climb from) and
  // is acting as a member. Latched on the frame anchor so a phantom set is injected
  // at most once per frame, not once per loop pass: a per-loop blast of sixteen
  // adds would manufacture a storm on node 12, not a birth-frame test.
  if (g_role != 1 || g_anchorHops == 255) return;
  if (g_frameAnchorUs == 0 || g_frameAnchorUs == g_phantomLastAnchor) return;
  g_phantomLastAnchor = g_frameAnchorUs;
  uint8_t injected = 0, seated = 0, held = 0;
  for (uint8_t k = 0; k < (uint8_t)PHANTOM_N; k++){
    uint8_t pid = (uint8_t)(PHANTOM_ID_BASE + k);
    // seated already: the birth path admitted it. Stop re-injecting; aggBufPurgeSeated
    // has already dropped it from the cache. This is the clean-pass drain.
    if (g_pubMapValid && pubIdHas(pid)) { seated++; continue; }
    // already in our own cache this frame or a prior one, not yet seated: leave it,
    // aggBufAdd would only refresh the token. Counts as held (still climbing).
    bool inBuf = false;
    for (uint8_t i = 0; i < g_aggN; i++) if (g_aggBuf[i].srcId == pid){ inBuf = true; break; }
    if (inBuf) { held++; continue; }
    // fresh inject: a distinct synthetic token per id so the keeper sees sixteen
    // separate fingerprints, not one board echoed. firstHand true: node 12 speaks
    // for it as a stranger it heard directly.
    uint32_t tok = 0xF0000000UL | ((uint32_t)pid << 8) | (uint32_t)(g_frame & 0xFF);
    aggBufAdd(pid, tok, g_frame, true);
    injected++;
  }
  // aux 0xDE = phantom carrier tick. e = injected this frame, n = already seated,
  // data = held in cache | cached-total << 8 | roster size << 16.
  logRec(LOG_STATE, NODE_ID, g_role, 0xDE, (int16_t)injected, (int16_t)seated,
         (uint32_t)held | ((uint32_t)g_aggN << 8) | ((uint32_t)g_rosterN << 16));
}
#endif
static bool aggReaggregate(uint8_t sid, uint32_t tok, uint8_t inHops){
  if (g_anchorHops == 255) return false;
  const uint16_t outHops = (uint16_t)g_anchorHops + 1U;
  if (!(inHops + 1 < RELAY_MAX_HOPS && outHops < RELAY_MAX_HOPS && outHops <= g_schedTiers)) return false;   // ceiling, v7.19.0 brick6
  if (g_pubMapValid && pubIdHas(sid)) return false;   // item 6: already seated, discovery is over for this id
  if (inHops > (uint8_t)(g_anchorHops + 1)) { aggBufAdd(sid, tok, g_frame, false); return true; }   // deeper: climb. v7.28.103: secondhand, never latches g_admitId
  if (inHops == (uint8_t)(g_anchorHops + 1)) {                                                // equal: once
    if (aggEqOnceHas(sid)) return false;
    aggEqOnceSet(sid);
    aggBufAdd(sid, tok, g_frame, false);   // v7.28.103: secondhand, never latches g_admitId
    logRec(LOG_STATE, NODE_ID, g_role, 0xAC, (int16_t)sid, (int16_t)inHops, (uint32_t)g_anchorHops);   // v7.28.102: aux 0xAC = equal-depth one-shot taken
    return true;
  }
  return false;   // shallower than us: it is already closer to the keeper than we are
}
// v7.28.102 CHUNK 3 ITEM 6: the discovery-to-exclusive boundary on the HEARER side.
// An id is in discovery while it is cached here and absent from the published slot
// array; the moment a beacon publishes it, discovery for that id is over: drop the
// cached record so this board stops flushing it, and clear its one-shot bit so a
// later rejoin starts clean. Called after every adopted beacon rebuilds g_pubIdMap.
// The keeper side of the same boundary is the seat itself, which is the one event
// that flips an id from aggregate-admitted to exclusive-grant.
static void aggBufPurgeSeated(){
  if (!g_pubMapValid) return;
  uint8_t w = 0;
  for (uint8_t i=0;i<g_aggN;i++){
    uint8_t id = g_aggBuf[i].srcId;
    if (pubIdHas(id)) {
      aggEqOnceClr(id);
      if (g_admitId == id) g_admitId = 0;   // v7.28.102 CHUNK 4: seated, so this board's admit claim for it is retired; a missed type-7 does not linger
      continue;
    }
    if (w != i) g_aggBuf[w] = g_aggBuf[i];
    w++;
  }
  g_aggN = w;
}

// v7.19.0 brick2: emit ONE aggregated join packet carrying up to AGG_PKT_MAX_REC (50)
// records, then remove those from the buffer (remainder rides the next packet). hops
// is the relay depth, bumped by the caller's tree position exactly like MemberPkt.hops.
// Called once per frame from the relay TX window, so a busy relay drains at 50/frame.
static uint64_t g_swarmAskAnchor = 0;   // v7.28.101: frame anchor of the last funnel swarm ask, latches it to once per frame like the aggregate drain
static uint64_t g_lastAggFlushAnchor = 0;   // v7.28.12: frame anchor of the last aggregate emit; latches aggFlush to once per frame, same shape as tailFlush's g_lastFlushAnchor
static void aggFlush(uint8_t hops){
  if (g_aggN == 0) return;
  // v7.19.0 brick2 guard: never emit at an invalid depth. A node only buffers while
  // relaying (it has heard a schedule, so g_anchorHops is small), but if hops arrives
  // as 0 or past the hop cap, hold the records rather than transmit a malformed depth.
  if (hops == 0 || hops >= RELAY_MAX_HOPS) return;
  uint8_t k = g_aggN < AGG_PKT_MAX_REC ? g_aggN : AGG_PKT_MAX_REC;
  if (k > (uint8_t)AGG_FLUSH_MAX_REC) k = (uint8_t)AGG_FLUSH_MAX_REC;   // v7.28.102 item 3: per-flush cap, packet fits its slot
  uint8_t buf[AGG_HDR2_BYTES + AGG_PKT_MAX_REC*AGG_REC_WIRE + AGG_CRC_BYTES];
  buf[0] = AGG_JOIN_MAGIC2; buf[1] = WIRE_VER; buf[2] = hops; buf[3] = k;
  buf[4] = (uint8_t)NODE_ID;   // v7.28.102 item 5: the sender, so the keeper can name a parent in the same step it seats
  int o = AGG_HDR2_BYTES;
  for (uint8_t i=0;i<k;i++){
    buf[o++] = g_aggBuf[i].srcId;
    uint32_t t = g_aggBuf[i].token;
    buf[o++] = (uint8_t)(t & 0xFF); buf[o++] = (uint8_t)((t>>8)&0xFF);
    buf[o++] = (uint8_t)((t>>16)&0xFF); buf[o++] = (uint8_t)((t>>24)&0xFF);
  }
  buf[o] = crc8(buf, o); o++;
  femTx(); LSM_TX(buf, o); rxArmAfterTx();   // v7.28.37: this site had no clear at all; the aggregate TxDone must not phantom-trigger the next radioPoll
  logRec(LOG_TX, NODE_ID, g_role, 0xAA, k, 0, (uint32_t)hops);   // 0xAA = aggregated-join TX witness
  // shift the remainder (records k..g_aggN-1) down to the front
  uint8_t rem = (uint8_t)(g_aggN - k);
  for (uint8_t i=0;i<rem;i++) g_aggBuf[i] = g_aggBuf[k+i];
  g_aggN = rem;
}

static bool scheduleRelayMustDefer(uint32_t offUs){
#if LSM_RELAY_TIMING_V2
  if(!g_anchorValid || g_relaySchedLen<BEACON_WIRE_FIXED_B)return false;
  const auto *s=(const SchedBeacon*)g_relaySchedRaw;
  if(!lsmgeometry::relayTierAllowed(s->schedHops,g_schedTiers))return false;
  const uint64_t end=tkSlotUsLive(s->nSlots)+(uint64_t)s->schedHops*relaySchedTierUsLive(s->nSlots);
  if(offUs>=end)return false;
  // Do not interrupt an already-started reception to send a competing copy.
  // radioPoll will validate it and apply the existing same-tier suppression.
  const uint32_t irq=lsmIrqRead();
  return schedulerelay::receiveInProgress(irq,
      RADIOLIB_SX126X_IRQ_PREAMBLE_DETECTED|RADIOLIB_SX126X_IRQ_HEADER_VALID,
      RADIOLIB_SX126X_IRQ_RX_DONE|RADIOLIB_SX126X_IRQ_HEADER_ERR|RADIOLIB_SX126X_IRQ_TIMEOUT);
#else
  (void)offUs;return false;
#endif
}
static void relaySchedTx(){
#ifdef LSM_LISTEN_ONLY
  return; // The passive witness must never count a shim return as an RF transmission.
#else
  g_schedRelayStats.calls++;
  RadioFlashGuard flashGuard;
  if(!flashGuard.ok()){g_schedRelayStats.flashBlocked++;logRec(LOG_TRIM,NODE_ID,g_role,0xEF,14,0,(uint32_t)(g_frameAnchorUs/1000));return;}

  const SchedBeacon* s=(const SchedBeacon*)g_relaySchedRaw;
  const uint64_t now=(uint64_t)esp_timer_get_time();
  const bool current=g_anchorValid&&g_frameAnchorUs&&g_frameUs&&now>=g_frameAnchorUs&&now-g_frameAnchorUs<g_frameUs&&
    g_relaySchedLen>=BEACON_WIRE_FIXED_B&&g_relaySchedLen==beaconWireB(s->nSlots)&&
    s->tkId==g_tkId&&s->sphere==g_tkEpoch&&s->seq==g_curSchedSeq&&s->nSlots==g_frameGeometrySlots&&
    s->schedHops==g_schedFloodOutHop&&lsmgeometry::relayTierAllowed(s->schedHops,g_schedTiers);
  if(!current){g_schedRelayStats.geometryBlocked++;logRec(LOG_TRIM,NODE_ID,g_role,0xEF,8,(int16_t)g_schedFloodOutHop,(uint32_t)(g_frameAnchorUs/1000));return;}
  const uint64_t tierStart=g_frameAnchorUs+tkSlotUsLive(s->nSlots)+(uint64_t)(s->schedHops-1)*relaySchedTierUsLive(s->nSlots);
  const uint64_t tierEnd=tierStart+relaySchedTierUsLive(s->nSlots);
  if(tierEnd>g_frameAnchorUs+(uint64_t)g_frameUs){g_schedRelayStats.geometryBlocked++;logRec(LOG_TRIM,NODE_ID,g_role,0xEF,8,(int16_t)g_schedFloodOutHop,(uint32_t)(g_frameAnchorUs/1000));return;}

  const uint32_t air=(uint32_t)radio.getTimeOnAir(g_relaySchedLen+MESH_SEC_OVERHEAD);
  const uint32_t rx=g_rxArmUs+100U>SLOT_GUARD_US?g_rxArmUs+100U:SLOT_GUARD_US;
  if(now<tierStart||ownedslot::fits(true,now,tierEnd,air,g_txLatUs,rx)!=ownedslot::FIT){
    g_schedRelayStats.budgetBlocked++;
    const int64_t spare=(int64_t)tierEnd-(int64_t)now-(int64_t)air-g_txLatUs-rx-(int64_t)ownedslot::UNCERTAINTY_US;
    logRec(LOG_TRIM,NODE_ID,g_role,0xEF,9,(int16_t)(spare < -32768 ? -32768 : spare > 32767 ? 32767 : spare),(uint32_t)(g_frameAnchorUs/1000));return;
  }
  const uint64_t call=(uint64_t)esp_timer_get_time();
  femTx();const int16_t status=LSM_TX(g_relaySchedRaw,g_relaySchedLen);
  const uint64_t txEnd=(uint64_t)esp_timer_get_time();rxArmAfterTx();
  const uint64_t finish=(uint64_t)esp_timer_get_time();
  g_schedRelayTiming.lastTxUs=(uint32_t)(txEnd-call);g_schedRelayTiming.lastRxUs=(uint32_t)(finish-txEnd);
  g_schedRelayTiming.lastAirUs=air;g_schedRelayTiming.lastPredictedEngageUs=g_txLatUs;
  const uint32_t excessTx=g_schedRelayTiming.lastTxUs>air?g_schedRelayTiming.lastTxUs-air:0;
  if(excessTx>g_schedRelayTiming.maxTxOverAirUs)g_schedRelayTiming.maxTxOverAirUs=excessTx;
  if(g_schedRelayTiming.lastRxUs>g_schedRelayTiming.maxRxUs)g_schedRelayTiming.maxRxUs=g_schedRelayTiming.lastRxUs;

  if(status==RADIOLIB_ERR_NONE)g_schedRelayStats.success++;else g_schedRelayStats.failed++;
  if(finish>tierEnd){
    g_schedRelayStats.overruns++;const uint32_t excess=(uint32_t)(finish-tierEnd);
    if(excess>g_schedRelayStats.maxOverrunUs)g_schedRelayStats.maxOverrunUs=excess;
    logRec(LOG_TRIM,NODE_ID,g_role,0xEF,10,(int16_t)(excess>32767?32767:excess),(uint32_t)(g_frameAnchorUs/1000));
    logRec(LOG_TRIM,NODE_ID,g_role,0xEF,11,(int16_t)(excessTx>32767?32767:excessTx),(uint32_t)(g_frameAnchorUs/1000));
    logRec(LOG_TRIM,NODE_ID,g_role,0xEF,12,(int16_t)(g_schedRelayTiming.lastRxUs>32767?32767:g_schedRelayTiming.lastRxUs),(uint32_t)(g_frameAnchorUs/1000));
    logRec(LOG_TRIM,NODE_ID,g_role,0xEF,13,(int16_t)(call-now>32767?32767:call-now),(uint32_t)(g_frameAnchorUs/1000));

  }
  // Preserve the legacy call witnesses; counters above distinguish actual driver outcome.
  logRec(LOG_RSYNC,NODE_ID,g_role,s->tkId,0,0,g_schedFloodOutHop);
  logRec(LOG_TX,NODE_ID,g_role,0xFA,(int16_t)g_relayArmNeed,(int16_t)g_relayArmProbe,g_schedFloodOutHop);
#endif
}
static bool relayMemberTx(MemberFloodEntry &e){
  if(e.raw[0]==telemetry::MAGIC&&e.raw[1]==telemetry::VERSION&&e.raw[2]==telemetry::KIND)
    return telemetryRelayTransmit(e.raw,e.rxUs);
  uint8_t buf[sizeof(MemberPkt)];
  memcpy(buf, e.raw, sizeof(MemberPkt));
  buf[offsetof(MemberPkt, flags_conf)] |= 0x40;   // v7.11.10: still marks "has been relayed" for logging, hop count is now the real depth record
  buf[offsetof(MemberPkt, relayerId)] = (uint8_t)NODE_ID;
  // Generic reports use volunteerFor as the forwarder's depth stamp. Type 7
  // must preserve it because it carries the admitted joiner id; that path uses
  // immutable origin depth plus hop count for its monotonic guard.
  if (buf[offsetof(MemberPkt, type)] != MEMBER_TYPE_SWARM_REQ)
    buf[offsetof(MemberPkt, volunteerFor)] = (g_anchorHops == 255) ? 0 : (uint8_t)(g_anchorHops + 1);
  // v7.21.0: the cumulative relay-hold accumulator that lived in bytes 19-20 is
  // GONE. Those bytes now carry depAttest16, the original sender's departure
  // integrity tag, and a relay MUST leave them exactly as received or the TK
  // will reject the relayed copy. The tag covers src, seq and departDevUs, none
  // of which this function touches, so a relayed copy still verifies. The three
  // fields below are the only ones a relay may rewrite, and the CRC is recomputed
  // over the result because of them.
  buf[offsetof(MemberPkt, crc)] = crc8(buf, sizeof(MemberPkt)-1);
  femTx(); int16_t txStatus = LSM_TX(buf, sizeof(MemberPkt)); rxArmAfterTx();
  if (txStatus != RADIOLIB_ERR_NONE) return false;
#if LSM_PAYLOAD_PROBE
  g_payloadRelayTx++;
#endif
  logRec(LOG_TX, NODE_ID, g_role, 0xFC, (int16_t)(e.grace ? 1 : 0), (int16_t)e.outHop, e.seq);   // aux 0xFC marks a data relay resend; v7.29.5: e = 1 on a grace (volunteered) forward, n = outHop
  return true;
}

// ----------------------- v7 frame engine -----------------------
// TK: send the schedule every FRAME_MS on the metronome. Member: act inside the
// frame anchored by the schedule ISR stamp; transmit ONLY in the granted slot,
// join request only from LISTEN in the join window; a missed schedule leaves
// g_mySlot at 0xFF so the whole frame stays silent.
void frameEngine(){
  uint32_t nowMs = millis();

  // ---- v6.0 election, every frame, every node ----
  g_myScore = electMyScore();
  if (g_role == 3 && g_rosterN == 0 && g_lastTkHeardMs != 0 && !g_spillReq && (nowMs - g_tkSinceMs) > EMPTY_TK_REWALK_MS){
    // v7.28.60: a keeper that elected FROM member and has held an empty roster for EMPTY_TK_REWALK_MS is a
    // board nobody can hear or that can hear nobody (sim scenario S6). Re-walk off this rung, excluding it.
    // A cold-boot first keeper (g_lastTkHeardMs 0, never heard a keeper) is exempt, so a solo bake is untouched.
    logRec(LOG_STATE, NODE_ID, g_role, 0xE6, (int16_t)((nowMs - g_tkSinceMs) / 1000UL), 0, g_frame);   // aux 0xE6 = empty keeper re-walk
    g_spillReq = true; g_spillFromFull = true;
  }
  if (g_role == 3){
    // we are the TK. Yield only if a rival TK legitimately outranks us by the
    // production margin (its beacon set g_tkScore), sustained. Otherwise hold.
    static uint32_t rivalBetterSince = 0;
    // v6.1: two live TKs is an ANOMALY, not a normal challenge. The dwell
    // guard does not apply and the hold is short. The comparator is decisive
    // on every input pair: score margin first, then RSSI health, rosterCount,
    // battery, lowest id, all self-reported wire fields, so both TKs reach
    // the same verdict and exactly one yields, in about TK_RIVAL_HOLD_MS.
    // v7.28.98 STORM FIX 2 of 2, frame gate. Keeper branch ONLY: g_frame is
    // advanced at exactly one site, the first line of tkBuildAndSend(), so only a
    // keeper has a frame clock. A member gating on g_frame would evaluate its
    // takeover path once per power cycle and never fail over again.
    bool rivalFresh = (g_rivalSeenMs!=0) && (nowMs - g_rivalSeenMs < 3000);
    static uint32_t rivalEvalFrame = 0xFFFFFFFFu;
    static bool     rivalOutranksLatch = false;
    if (!rivalFresh) { rivalOutranksLatch = false; rivalEvalFrame = 0xFFFFFFFFu; g_rivalDirect = false; }
    else if (rivalEvalFrame != g_frame) {
      rivalEvalFrame = g_frame;
      rivalOutranksLatch = electRivalOutranks();
    }
    bool rivalBeatsUs = rivalFresh && rivalOutranksLatch;
    if (rivalBeatsUs){
      if (rivalBetterSince==0) rivalBetterSince=nowMs;
      // v7.29.38: a strictly newer authority epoch proves that the named
      // successor has committed. Keeping the ordinary two-second merit-rival
      // debounce here creates a real dual-TK interval after failover. Stand
      // down on the first authenticated newer epoch. Equal-epoch rivals still
      // use the full debounce because that is the cold-start race it protects.
      bool rivalHasNewerEpoch =
          ((int8_t)((uint8_t)g_rivalEpoch - (uint8_t)g_tkEpoch) > 0);
      // v7.29.44: only a rival schedule received by this keeper may trigger the
      // immediate newer-epoch stand-down. An indirect rival has already met
      // the distinct-member confirmation threshold, but still holds for at
      // least three live frames (and twelve seconds) before the incumbent
      // stops serving its roster. This prevents a bridge report from creating
      // a schedule vacuum while preserving deterministic partition merge.
      uint32_t indirectHoldMs = (g_frameUs / 1000UL) * 3UL;
      if (indirectHoldMs < HIDDEN_RIVAL_CONFIRM_MS) indirectHoldMs = HIDDEN_RIVAL_CONFIRM_MS;
      uint32_t rivalHoldMs = g_rivalDirect ? TK_RIVAL_HOLD_MS : indirectHoldMs;
      if ((rivalHasNewerEpoch && g_rivalDirect) || nowMs - rivalBetterSince > rivalHoldMs){
        // v6.2: the winner never ADMITTED us, so a yielded TK holds no slot
        // in the new schedule; yielding to member left the ex-TK silent
        // forever (bench log 31, 2026-07-04: yield at 126.7 s, instant
        // CANDIDATE off a 120 s stale lastSchedMs, re-election, dual TK).
        // Yield to LISTEN, refresh the member-side freshness clocks the TK
        // reign starved, and re-join the winner through the normal window.
        // v7.12.3: g_lastSchedMs alone was not enough. electShouldTakeOver()
        // checks g_lastTkHeardMs, which is only ever refreshed by directly
        // hearing a schedule beacon over the air, and this yield can fire on
        // a rival known ONLY through another member's relay, a hidden-node
        // case where we have never directly heard the rival ourselves. That
        // left g_lastTkHeardMs stale from whenever we last heard any real
        // beacon, sometimes long enough to already exceed TK_FAILOVER_MS, so the
        // very next frameEngine() pass read tkDead true and re-self-elected
        // in the same tick, undoing the yield before it ever took hold.
        // Root caused 2026-07-11 against board 05's flash log, rival 9 and
        // rival 10 both showed the identical same-millisecond yield-then-
        // reclaim. Refreshing it here means a fresh yield is never mistaken
        // for a dead TK on the very next pass, regardless of how we learned
        // about the rival.
        { uint8_t prRole = g_role;
        g_role = 0; g_tkId = g_tkId_rival; g_tkEpoch = g_rivalEpoch; g_tkSinceMs=0; rivalBetterSince=0;
        g_coldCommitSinceMs = 0;
        g_schedFloodDeadlineUs = RELAY_NO_DEADLINE; g_schedFloodRelayed = false;
        g_schedFloodBestHop = 255; g_schedFloodOutHop = 255; g_relaySchedLen = 0;
        g_hiddenRivalTk = 0; g_hiddenRivalEpoch = 0; g_hiddenRivalWitnessMask = 0;
        g_hiddenRivalFirstMs = 0; g_hiddenRivalLastMs = 0; g_rivalDirect = false;
        g_anchorValid=false;
        g_lastSchedMs = millis(); g_lastTkHeardMs = millis(); g_framesSilent = 0; g_relistenAttempts = 0;   // v7.28.10: schedule heard clears the re-walk counter
        // v7.28.22: the v7.12.3 fix this block exists for refreshed the liveness
        // clock so a fresh yield could not be read as a dead TK on the next pass.
        // That clock is now g_seqAdvMs, so it is the one that has to be refreshed
        // or the yield-then-reclaim loop of 2026-07-11 comes straight back. The
        // seq space belongs to the rival we just yielded to and we may never have
        // heard it, so reseed rather than carry: g_seqHighTk 0 makes the first
        // adopted copy from the new keeper initialise the pair.
        g_seqAdvMs = millis(); g_seqHigh = 0; g_seqHighTk = 0;
        g_peerSeqAdvMs = 0; g_peerSeqHigh = 0; g_peerSeqTk = 0;
        g_lastTkStandDownMs = nowMs;   // v7.10.4: start the roster-keep window
        g_resignSwarmReq = true; g_resignSwarmTarget = g_tkId_rival; g_resignSwarmTries = 0;   // v7.28.6: owe the winner a swarm request so we are absorbed, not re-elected
        logRec(LOG_STATE, NODE_ID, g_role, g_tkId, 0, 0, 0);
        logRec(LOG_STATE, NODE_ID, g_role, 0xEE, (int16_t)prRole, 0, 1); }   // v7.28.101: resignation moved 0xEC -> 0xEE. reason 1 = rival outranked, e = role held before the yield
      }
    } else rivalBetterSince=0;
  } else {
    // we are not the TK. If the TK has gone silent (dead) or we should take
    // over per the production hysteresis, become the TK now. Exactly one node
    // wins because the score has a strict lowest-id-free ordering and the
    // margin/hold guards prevent two nodes flipping in the same window.
    if (electShouldTakeOver(nowMs)){
      bool warmTakeover = g_warmTakeoverPending;
      g_warmTakeoverPending = false;
      uint8_t priorTk = g_tkId;
      // v7.10.4: only clear our roster if we either have never been TK this
      // power cycle, or it has been longer than ROSTER_KEEP_MS since we last
      // stood down. A quick rivalry bounce back to ourselves keeps the real
      // roster, including learned slot timing, instead of being wiped like a
      // brand new TK. Either way, top up from currently known peers after.
      bool resumingRecent = (g_lastTkStandDownMs != 0) &&
                            (nowMs - g_lastTkStandDownMs <= ROSTER_KEEP_MS);
      g_role = 3; g_tkId = (uint8_t)NODE_ID; g_tkSinceMs = nowMs; g_relistenAttempts = 0;
      g_coldCommitSinceMs = 0;
      // v7.29.47: authority changed. A pending relay copy belongs to the old
      // authority and must never radiate after this board begins its own tenure.
      g_schedFloodSeq = 0xFF; g_schedFloodBestHop = 255; g_schedFloodOutHop = 255;
      g_schedFloodRelayed = false; g_schedFloodDeadlineUs = RELAY_NO_DEADLINE;
      g_relaySchedLen = 0;
      g_meshLease.keeper = 0; g_meshLease.epoch = 0; g_meshLease.seq = 0;
      g_meshLease.steps = 0; g_meshLease.advancedAt = 0; g_meshLease.witnesses = 0;
      g_hiddenRivalTk = 0; g_hiddenRivalEpoch = 0; g_hiddenRivalWitnessMask = 0;
      g_hiddenRivalFirstMs = 0; g_hiddenRivalLastMs = 0; g_rivalDirect = false;
      // Only a cold network with no prior authority, or the authenticated
      // keeper-named warm successor, may advance the authority generation.
      // An ordinary isolated fallback keeps the last observed generation. On
      // partition merge the equal-generation, lowest-id rule then makes that
      // provisional island yield to the surviving established sphere instead
      // of forcing the whole healthy fleet through an epoch cascade.
      if (warmTakeover || priorTk == 0) {
        g_tkEpoch = (uint8_t)(g_tkEpoch + 1U);
      }
      if (warmTakeover) g_frame = (uint32_t)g_seqHigh; // tkBuildAndSend increments to the next sequence
   // v7.28.10: becoming TK clears the re-walk counter
      // v7.28.95: a keeper is zero hops from itself. Without this, the depth carried
      // in from member life persists: the glass keeps showing it, and the election
      // score keeps subtracting 25 per stale hop while this board sits as TK.
      g_anchorHops = 0; g_hopsToCmd = 0;
      // v7.28.97 TIER COLD START. Open at full relay width on taking the role and
      // let the existing shrink path narrow it. The grow path reads g_obsDepth,
      // which only rises when a deep member's packet ARRIVES, and that arrival is
      // clamped by the very tier count being sized. A keeper elected before any
      // depth exists computed want = 0 + 1 = 1, published one tier, and one tier
      // blocked every packet that would have raised it: bench capture 2026-09-20,
      // node 01 keeper, 1527 consecutive frames pinned at g_schedTiers == 1 with
      // zero depth rejects and not one real relay grant issued in 1699 beacons.
      // Grow-fast cannot bootstrap on evidence its own width suppresses. Starting
      // wide costs reserved airtime on a shallow fleet for one shrink ladder and
      // nothing after; starting narrow costs every node past hop one, forever.
      applyTiers(1);   // v7.30.0: first birth reaches one relay; later depth grows from evidence/probes.
      g_pendTiers = 0; g_resizeCountdown = RESIZE_NONE;
      g_depthHoldUntilMs = nowMs + DEPTH_HOLD_MS;
      g_birthEmptyRuns = 0; g_framesSinceRival = 255; g_birthRivalTickMs = nowMs;            // v7.28.15: fresh tenure, fresh standing offer; only rivals heard from now on count
      g_birthProactive = false; g_birthPendingEval = false;
      g_birthMaintDataAge = 0; // v7.29.50: startup offer owns the first frames; maintenance cadence begins afterward
      g_coldBirthWindows = true;   // v7.28.104: fresh tenure owes one seven-window cold birth so the empty sphere opens a join window per relay tier
      g_betterSinceMs = 0; g_framesSilent = 0;
      if (!resumingRecent) g_rosterN = 0;
      // A board that was keeper earlier in this power cycle may retain that
      // old roster through ROSTER_KEEP_MS. During a warm takeover it can still
      // contain priorTk before either seed function runs. Leaving that seat in
      // place made the replacement advertise the already-failed predecessor
      // as its own lowest-id successor, so a second keeper loss had no live
      // warm backup. Remove it from every roster source, including this one.
      if (warmTakeover) {
        int failedIdx = tkRosterFind(priorTk);
        if (failedIdx >= 0) tkRosterDrop(failedIdx);
      }
#ifdef CRYSTAL_TOKEN
      g_ctTkAnnFr = 0; g_tokLastGrantId = 0; g_tokHeardGrantee = false; g_tokGrantSelf = false;   // v7.28.59: fresh tenure, announce first
#endif
      if (warmTakeover) seedRosterFromStandby(priorTk);
      seedRosterFromPeers(warmTakeover ? priorTk : 0);
      if (warmTakeover) logRec(LOG_STATE, NODE_ID, g_role, 0xF4,
                               (int16_t)priorTk, (int16_t)g_tkEpoch,
                               (uint32_t)g_standbyRosterN);
      logRec(LOG_STATE, NODE_ID, g_role, g_tkId, 0, 0, g_myScore);
    }
  }

  if (g_role == 3){
    // v7.28.32: the keeper runs its frame from its own on-air anchor, the
    // same rule the members run from the same instant. This was an absolute
    // millis metronome (nextFrameMs += frame) that predated the transmit:
    // when the backhaul errand blocked the tail the beacon went out late but
    // the next boundary was still the old boundary plus one frame, so the
    // following frame was shortened to make up the time and the beacon
    // landed in the members' keepalive slot (c06 2026-09-04: 25 beacons
    // under 300 ms spacing carried 9 of the 31 clean shared misses). Now the
    // next beacon is CALLED at anchor + frame - learned latency so it
    // RADIATES at anchor + frame; a stretched frame stays stretched and
    // never steals from the next one.
    static uint64_t nextBeaconUs = 0;
    // v7.30.0 AUTHORITY MERGE SCAN. Variable frame lengths can phase-lock two
    // co-channel keepers so that each transmits over the other's schedule and
    // neither ever receives the authenticated rival tuple needed by the
    // deterministic epoch/id comparator above. Give every keeper one RX-only
    // opportunity in a 64-frame cycle, with the opportunity selected by its
    // provisioned id. Keepers that began together therefore go quiet on
    // different frames; a lower/newer authority is heard directly and the
    // loser yields through the existing comparator. The opportunity counter is
    // separate from g_frame because a skipped transmission must still advance
    // the scan cycle. Members already tolerate isolated missed beacons, so this
    // costs 1/16 of keeper beacons without reserving airtime in every frame.
    static uint32_t mergeScanOpportunity = 0;
    uint64_t tkNowUs = (uint64_t)esp_timer_get_time();
    if (nextBeaconUs == 0) nextBeaconUs = tkNowUs;
    if (tkNowUs >= nextBeaconUs){
      mergeScanOpportunity++;
      bool mergeScanQuiet =
          ((mergeScanOpportunity & 0x3FU) == ((uint32_t)NODE_ID & 0x3FU));
      if (mergeScanQuiet) {
        // Stay in receive for the whole opportunity. No frame sequence is
        // consumed because no schedule carrying that sequence went on air.
        logRec(LOG_STATE, NODE_ID, g_role, 0xC9,
               (int16_t)(mergeScanOpportunity & 0xFFFFU), 0, g_frame);
      } else {
        tkBuildAndSend();
      }
      uint64_t lead = (g_txLatUs < 20000UL) ? (uint64_t)g_txLatUs : 20000ULL;
      // A transmitted frame owns a fresh radio anchor. A quiet scan does not;
      // scheduling it from the preceding transmit anchor would put the next
      // deadline in the past and collapse the intended receive window to one
      // loop pass. Start the skipped frame at the actual quiet instant.
      uint64_t base = mergeScanQuiet ? tkNowUs
                     : ((g_anchorValid && g_frameAnchorUs) ? g_frameAnchorUs : tkNowUs);
      uint64_t span = (uint64_t)g_frameUs;
      nextBeaconUs = base + (span > lead ? span - lead : span);
    }
  } else {
  // v7.29.6 CANDIDATE STRANDING FIX, backstop timer. Sits ahead of the anchor
  // split so it covers BOTH ways into candidate: the never-anchored isolation
  // entry (which returns early and never reaches the dead-keeper re-walk) and
  // the anchored lost-keeper entry. Candidate had no timer of its own: the only
  // exits were hearing a beacon (impossible on a silent rung, which is the
  // only way this state is entered) or winning the election (blockable by a
  // rival, the dwell guard, or the peer quorum). On a rung with no keeper at
  // all that is an unbounded wait by construction. Stand down to LISTEN after
  // CAND_STRAND_MS and request a ladder re-walk, so the board goes looking on
  // other rungs. Spawning is still gated by RELISTEN_MAX_ATTEMPTS: the walk
  // has to come up empty before this board ever takes TK, so a one-board
  // island is never spawned straight off a silent rung.
  if (g_role==2 && g_candSinceMs!=0 && nowMs - g_candSinceMs > CAND_STRAND_MS){
    uint32_t candDwell = nowMs - g_candSinceMs;   // captured before the reset so the witness carries the real dwell
    g_role = 0;
    g_candSinceMs = 0;
    g_lastSchedMs = nowMs;            // fresh grace on the rung we walk to
    g_relistenSinceMs = 0; g_relistenJitterMs = 0;
    g_spillReq = true;                // main loop retunes and re-walks the ladder
    logRec(LOG_STATE, NODE_ID, g_role, 0xE4, (int16_t)quorumFresh(nowMs), 0, candDwell);   // aux 0xE4 = candidate stranded, stood down to LISTEN and re-walking; data = ms spent in CANDIDATE. 0xE6 is the empty-keeper re-walk witness, do not reuse
  }
  if (!g_anchorValid){
    // never heard a schedule yet: pure listen, except the grace-based election
    if (g_lastSchedMs==0) g_lastSchedMs=nowMs;
    if (g_role!=2 && nowMs - g_lastSchedMs > aloneGraceMs()){
      g_role = 2;                                  // CANDIDATE after true isolation only
      g_candSinceMs = nowMs;                       // v7.29.6: start the stranding timer
      logRec(LOG_STATE, NODE_ID, g_role, 0, 0, 0, nowMs - g_lastSchedMs);
    }
    return;
  }
  uint64_t nowUs = (uint64_t)esp_timer_get_time();
  uint32_t offUs = (uint32_t)((nowUs - g_frameAnchorUs) % (uint64_t)g_frameUs);   // v11: dynamic frame period
  // v7.28.31 beacon-instant sample, aux 4. Reads the IRQ status and the
  // instantaneous RSSI 30 ms after a wrap, while the expected beacon should be
  // on the air. Reads only, clears nothing, feeds back nothing.
  if (g_role != 3 && g_wrapSampleDueUs && nowUs >= g_wrapSampleDueUs) {
    uint16_t sIrq = (uint16_t)lsmIrqRead();
    float sr = radio.getRSSI(false);
    int16_t sR = rnd16(sr);
    uint64_t sinceWrap = nowUs - (g_wrapSampleDueUs - 30000ULL);
    logRecRf(LOG_MANCH, NODE_ID, g_role, 4,
             (int16_t)sIrq,
             (int16_t)(sinceWrap / 100ULL > 32767ULL ? 32767 : sinceWrap / 100ULL),
             (uint32_t)(nowUs / 1000ULL),
             (int8_t)(sR < -127 ? -127 : (sR > 127 ? 127 : sR)),
             (int8_t)(g_anchorAdoptSeq != g_wrapSampleSeq ? 1 : 0),
             (int16_t)g_anchorAdoptSeq);
    g_wrapSampleDueUs = 0;
  }
  static uint32_t lastOff = 0;
  if (g_anchorFresh){
    // the schedule beacon IS the frame boundary; grant for the new frame is
    // whatever handleSched just set. Do not clear it here.
    g_anchorFresh = false;
    g_txSinceAnchor = false;   // v7.28.38: heard a beacon, so the next miss is not a first-receive-after-transmit case until we transmit again
    lastOff = offUs;
  } else if (offUs < lastOff){
    // wrapped with NO schedule heard: a missed frame. Grant died with the old
    // frame; stay silent, count the silence, and only the full grace elects.
    // v11.2: do NOT clear g_schedThisFrame here. Under the dynamic frame a
    // cold joiner runs its modulo on an imperfect g_frameUs, so this wrap can
    // fire at the wrong instant and slam the join window shut before offUs
    // ever climbs to it, which stranded board 10 in LISTEN for tens of
    // seconds on the bench. Join eligibility is instead gated below by
    // wall-clock time since the last real beacon, which does not depend on
    // the joiner guessing the frame length right.
    g_mySlot = 0xFF;
    g_framesSilent++;
    // v7.28.30 missed-frame witness, aux 2. The receiver's own count: the frame
    // wrapped and no schedule was heard. Members only; the keeper anchors itself.
    if (g_role != 3) {
      float wr = radio.getRSSI(false);
      int16_t wrR = rnd16(wr);
      logRecRf(LOG_MANCH, NODE_ID, g_role, 2,
               (int16_t)(g_framesSilent > 32767UL ? 32767 : g_framesSilent),
               (int16_t)g_anchorAdoptSeq,
               (uint32_t)((nowUs - (uint64_t)offUs) / 1000ULL),
               (int8_t)(wrR < -127 ? -127 : (wrR > 127 ? 127 : wrR)), 0,
               (int16_t)(g_frameUs / 100UL > 32767UL ? 32767 : g_frameUs / 100UL));
      g_wrapSampleDueUs = nowUs + 30000ULL;   // v7.28.31: sample the chip while the expected beacon is on the air
      g_wrapSampleSeq   = g_anchorAdoptSeq;
      // v7.28.38: misfire check. This missed beacon followed a transmit by this
      // board, so it is a first-receive-after-transmit candidate. e = services
      // seen since that transmit: 0 means the beacon never fired an IRQ at all
      // (deaf receiver), >= 1 means it fired and aux 12 holds why it was not
      // adopted. Counts services of any kind since the transmit; on the bench
      // between a keepalive and the next beacon that is the beacon.
      if (g_txSinceAnchor) {
        logRecRf(LOG_RF, NODE_ID, g_role, 13,
                 (int16_t)g_svcSinceTx,
                 (int16_t)g_anchorAdoptSeq,
                 (uint32_t)(g_framesSilent > 0xFFFFUL ? 0xFFFFUL : g_framesSilent),
                 (int8_t)(wrR < -127 ? -127 : (wrR > 127 ? 127 : wrR)), 0,
                 (int16_t)(g_frameUs / 100UL > 32767UL ? 32767 : g_frameUs / 100UL));
        // v7.28.41: DEAF-WRAP SNAPSHOT, aux 14, beside every post-transmit miss.
        // Reads the chip at the wrap and pairs it with the arm-time mode so the
        // deaf case (aux 13 e=0) can be split: armed-deaf (arm mode not RX =>
        // the turnaround arms wrong, a fallback/command fix) vs drifted-deaf
        // (arm mode RX but wrap mode not RX, or preamble never set => transient).
        //   e   = arm-time GetStatus (low 8) | wrap-time GetStatus (high 8)
        //         mode = bits 6:4 of each byte (2 STBY_RC, 3 STBY_XOSC, 4 FS,
        //         5 RX, 6 TX per SX126x). arm byte valid only if g_armStatusOk.
        //   n   = wrap-time sync word: reg 0x0740 (low 8) | reg 0x0741 (high 8);
        //         corrupt here = config corruption, not a turnaround fault.
        //   data= wrap-time IRQ status word (low 16): the PREAMBLE-DETECT witness
        //         (0x04 preamble, 0x10 hdr valid, 0x20 hdr err, 0x02 rx done).
        //         g_armStatusOk in bit 16.
        //   rssi= instantaneous RSSI at the wrap (same wrR as aux 13).
        uint8_t  wrapStatus = radio.chipStatus();
        uint16_t wrapIrq    = (uint16_t)lsmIrqRead();
        uint8_t  sync[2]    = {0, 0};
        radio.readSync(sync);   // reg 0x0740/0x0741, config-corruption check
        logRecRf(LOG_RF, NODE_ID, g_role, 14,
                 (int16_t)((uint16_t)g_armStatus | ((uint16_t)wrapStatus << 8)),
                 (int16_t)((uint16_t)sync[0] | ((uint16_t)sync[1] << 8)),
                 (uint32_t)wrapIrq | ((uint32_t)(g_armStatusOk ? 1u : 0u) << 16),
                 (int8_t)(wrR < -127 ? -127 : (wrR > 127 ? 127 : wrR)), 0, 0);
      }
    }
    if ((g_role==1 || g_role==0) && (millis() - g_lastSchedMs) > aloneGraceMs()){   // v11: wall-clock, frame-length independent; v7.12.16: grace itself is frame-length scaled again
      g_role = 2;
      g_candSinceMs = millis();                    // v7.29.6: arm the stranding backstop on the anchored entry too
      logRec(LOG_STATE, NODE_ID, g_role, g_tkId, 0, 0, g_framesSilent);
    }
  }
  lastOff = offUs;
  // v7.2: arm a SEED burst only when this node's own confidence is high,
  // never otherwise. First arm the moment confidence crosses the line,
  // then again every SEED_RESEND_MS as a keep-alive verify. If confidence
  // is low when the timer comes due, skip silently, try again next check,
  // so a node that regains confidence sends on the next opportunity rather
  // than waiting out a missed window.
  if (g_haveRealFix && g_posConf >= SEED_CONF_HIGH && g_satsNow >= MIN_SATS_TX && g_seedBurstPart == 0){   // v7.28.68: sat gate on the absolute seed burst
    if (!g_seedSentOnce || g_reseedAir || (millis() - g_lastSeedMs >= SEED_RESEND_MS)){ g_seedBurstPart = 1; g_reseedAir = false; }   // v7.28.75: re-center forces a fresh burst
  }
  // granted slot: engage the radio TX_ENGAGE_US early, be on air at the boundary
  ownedGrantObserve();
  if (g_role==1 && g_mySlot!=0xFF && g_framesSilent >= SLOT_MUTE_FRAMES && !g_slotMuted) {
    g_slotMuted = true; logRec(LOG_STATE, NODE_ID, g_role, 0xE9, (int16_t)g_framesSilent, 0, 1);   // v7.28.60: aux 0xE9 data 1 = slot muted on silence
  } else if (g_slotMuted && g_framesSilent < SLOT_MUTE_FRAMES) {
    g_slotMuted = false; logRec(LOG_STATE, NODE_ID, g_role, 0xE9, (int16_t)g_framesSilent, 0, 0);   // data 0 = slot back in use
  }
  if (g_role==1 && g_mySlot!=0xFF && g_framesSilent < SLOT_MUTE_FRAMES){   // v7.28.60: a muted member keeps its slot but does not transmit in it, so a keepalive on the air means anchored
    uint32_t slotStart = g_memberBaseUs + (uint32_t)g_mySlot*g_slotUsLive;   // v7.10.7: base shifted past the fixed join window
    static uint8_t sentInSlot = 0xFF;
    // v7.28.24: engage early by this board's MEASURED latency so the packet
    // radiates at the slot boundary rather than 8,400 us after it. TX_ENGAGE_US
    // (300, "refine on a scope") was the guess; g_txLatUs is the measurement.
    // v7.28.25: TX_ENGAGE_US is 0. Left at 300 on top of the measurement it
    // put every member 300 us early (role 10 median -279 on cap8).
    // The trim tuner keeps working on the residual, which is now the
    // prediction error rather than the whole latency it could never see.
    int32_t engLeadS = (int32_t)g_txLatUs + (int32_t)TX_ENGAGE_US + (int32_t)g_trimAdjUs;
    uint32_t engLead = engLeadS > 0 ? (uint32_t)engLeadS : 0;
    if (offUs >= (slotStart>engLead?slotStart-engLead:0) && offUs < slotStart+AIRTIME8_US){
      if (sentInSlot != g_curSchedSeq && !g_owned.outcome){
        sentInSlot = g_curSchedSeq;                 // once per grant
        OwnedScope ownedScope;
        static_assert(sizeof(MemberPkt)==sizeof(telemetry::Snapshot)&&sizeof(MemberPkt)==membercapacity::MAX_PLAIN_BYTES&&sizeof(MemberPkt)+MESH_SEC_OVERHEAD==membercapacity::MAX_SECURED_BYTES,"Owned size must remain 35/67 bytes");
        // All owned alternatives use the pinned 35-byte member/snapshot size.
        // Reject before dispatch so a late skip never switches the FEM to TX.
        if(ownedTxFits(sizeof(MemberPkt))){
        // v7.2: a pending SEED part takes this slot instead of the regular
        // offset packet, one part per granted slot, never both in one slot.
        // The regular offset update is skipped for the 3 slots a burst
        // takes, once per lock and then every 2.5 minutes, a negligible gap.
        if (g_seedBurstPart){
          memberSendSeedPart(g_seedBurstPart, (uint8_t)(g_ent & 0xFF));
          if (g_owned.success && g_seedBurstPart >= 3){
            g_seedBurstPart = 0; g_seedSentOnce = true; g_lastSeedMs = millis();
            queueSelfSeedBle();   // v7.28.75: seed = held origin, same builder as lock and re-center
          } else if(g_owned.success)g_seedBurstPart++;
#if LSM_RELAY_PLEA
        } else if (pleaWantThisFrame()) {
          // v7.29.1: we are seated but stranded (keeper not hearing us, no relay named for
          // us). Spend this slot pleading for a leg instead of the swarm ask; the ladder in
          // pleaWantThisFrame() fires only on due frames, so the swarm still rides every
          // other frame. A hop-0 plea the keeper hears directly still marks its heardMask
          // (v7.29.2 hoisted the heard-accum above the plea handler's return to make this
          // hold; before that the plea path returned first), so liveness is kept on a plea.
          memberSendPlea();
#endif
        } else if (g_aggN > 0 && g_swarmAskAnchor != g_frameAnchorUs) {
          // v7.28.102 CHUNK 3: the funnel ask now rides THIS BOARD'S OWN SLOT as a
          // type-7 swarm request in place of the report, once per frame while joiners
          // are cached. v7.28.101 fired it unslotted on the tail of the schedule flood,
          // the same placement defect the aggregate flush had. A member only holds a
          // slot in a DATA frame, so this is naturally the DATA-frame ask that arms the
          // JOIN frame in which the aggregate itself flushes. Any hop-0 MemberPkt marks
          // the keeper's heardMask regardless of type, so liveness is kept the frame
          // the report is skipped. A seed part still wins the slot ahead of this.
          memberSendSwarmReq(g_aggN);
          if(g_owned.success)g_swarmAskAnchor = g_frameAnchorUs;
        } else if (LSM_ADAPTIVE_AGGREGATE && ((g_curSchedSeq + (uint8_t)NODE_ID) & 0x03U) == 0U && aggFreshPeerCount() > 0) {
          // v7.30.0: the relay raises demand; the keeper decides whether and
          // how much aggregate capacity to grant in a later frame.
          memberSendAggDemand(aggFreshPeerCount());
        } else if (g_haveRealFix && g_posValid) {
          // v7.29.6 HOLD LAST KNOWN, per Stuart. Once this board has ever had a
          // real lock it keeps sending its last known position in every granted
          // slot, and NEVER drops to a zeroed present ping just because current
          // satellites fell below MIN_SATS_TX (walked indoors, under cover, or a
          // brief GPS glitch). memberSendData already packs the held g_posLat and
          // g_posLon and the confidence posFusionUpdate is already decaying by age,
          // 63 down to a floor of 4, so the mesh and the map keep a position that
          // fades in trust instead of blinking to nothing. The receiver reads the
          // confidence and decides what to trust. MIN_SATS_TX is now an acquisition
          // gate (whether a FRESH fix refreshes the held one), not a transmit gate.
          memberSendData();
        } else if (g_posValid && g_satsNow >= MIN_SATS_TX) {
          // v7.28.64 raw provisional only (never had a real lock yet): send it
          // while the current fix still clears the sat bar, else fall through.
          memberSendData();
        } else {
          // v7.11.6: no usable position at all (truly cold, never any fix), send
          // the timing-only present ping so the slot still refreshes the TK's
          // latency profile and this node's roster liveness, without claiming a
          // position it does not have. A board that has HELD a real fix never
          // reaches here in v7.29.6.
          memberSendPresent();
        }
        }
        g_mySlot = 0xFF;                            // grant consumed, including predictive skip
      }
    }
  }
  ksTailTxMember(offUs);   // v7.28.59: answer a tail token slot grant, after all member slots
  aggPosTailTx(offUs);     // v7.30.0: granted compact subtree update, after token tails
  ksTailRelayTx(offUs);    // chunk 2: forward it if we are this frame's named relayer
  // v7.11.10: real flood relay, fire any pending jittered relay attempts
  // whose deadline has arrived and were not suppressed in the meantime.
  // Skipped while this board is itself the TK, relaying stale captured
  // data would make no sense if it ever wins the election.
  if (g_role != 3) {
    if (g_schedFloodDeadlineUs != RELAY_NO_DEADLINE && offUs >= g_schedFloodDeadlineUs && !g_schedFloodRelayed && !scheduleRelayMustDefer(offUs)) {
      g_schedFloodRelayed = true;
      g_schedFloodDeadlineUs = RELAY_NO_DEADLINE;
      relaySchedTx();
    }
    for (int i=0;i<RELAY_MEMBER_TRACK_N;i++){
      MemberFloodEntry &e = g_memberFlood[i];
      if (e.active && e.deadlineUs != RELAY_NO_DEADLINE && offUs >= e.deadlineUs && !e.relayed){
        e.relayed = true;
        e.deadlineUs = RELAY_NO_DEADLINE;
        if (!relayMemberTx(e)) {
          // A failed attempt must not consume the rescue or mark a TX success.
          e.active=false;
          continue;
        }
        
        // v7.29.9 MERGE: ON SUCCESSFUL FIRE, KILL THE CLAIM WITH COOLDOWN
        // The source that just volunteered and fired successfully is the most likely
        // to be hit by a repeat packet at the same hop from the same relayer.
        // A short cooldown here blocks immediate re-volunteering (ping-pong defense).
        volClaimKillAndCooldown((uint8_t)e.srcId);
        // v7.29.14: the line above only killed the g_volClaims overlay. g_volCarry's
        // own claimed state was left standing, and volCarryDecide falls through to a
        // fresh jitter return on every call while claimed is true and its own eight-
        // sequence TTL has not yet elapsed, so a repeat hop-0 copy of this same source
        // inside that window re-armed and fired again before the cooldown just set
        // above ever got checked. Clear it here, at the actual transmit, not at the
        // arm-time log or the TTL sweep.
        if (e.grace) {
          VolCarry* vc = volCarryFind((uint8_t)e.srcId);
          if (vc) vc->active = false;
        }
      }
    }
#if defined(RIG_PHANTOM_CARRIER) && (NODE_ID == 12)
    // v7.29.0: fill the cache with the phantom set BEFORE the flush and swarm ask
    // below read g_aggN, so the phantoms ride the unchanged machinery. Once per
    // frame via its own anchor latch; the call is a no-op on any other board or
    // build because the whole function is compiled out.
    phantomCarrierTick();
#endif
    // v7.19.0 brick2: drain the aggregated join buffer once per frame while relaying.
    // Fires when full (>=50) OR whenever anything is buffered and this node relayed the
    // schedule this frame (it is in the tree). hops = this node's schedule depth + 1.
    // v7.28.12: latched on the frame anchor so this emits at most once per frame no
    // matter how often the remainder and new joins refill the buffer between frames.
    // Without the latch it re-fired every pass while the relay window was open, a
    // busy relay transmitted for the rest of the frame, went deaf to its keeper, and
    // self-elected on a false tkDead. srcId dedup in aggBufAdd bounds the records.
    // v7.28.102 CHUNK 3 ITEM 2: the flush is now GATED ON offUs and fires only inside
    // its jitter slot in the reply window of a JOIN frame. Three things changed from
    // the v7.19.0 / v7.28.12 site that stood here:
    //  (a) g_schedFloodRelayed is no longer a prerequisite. That gate made the one
    //      board named relayById the only board that could ever flush, which is the
    //      single funnel the join-tree design replaces. Any JOINED board that has
    //      adopted a schedule and holds cached joiners may flush. The keeper admits
    //      every record it receives, so extra copies cost airtime, never correctness.
    //  (b) The g_aggN >= AGG_PKT_MAX_REC early trigger is gone with it: a fat buffer
    //      no longer justifies an unslotted transmit, it drains one record per JOIN
    //      frame like everything else.
    //  (c) The slot is a deterministic hash of (NODE_ID, seq) into N, the same shape
    //      as the join-window pick at handleSched, so the same board lands on the
    //      same slot for the same beacon and different boards spread. The once-per-
    //      frame anchor latch is kept.
    // A DATA frame's reply window belongs to member data relays and is not used.
    if (g_aggN > 0 && g_role == 1 && g_anchorHops != 255
        && g_frameType == SF_TYPE_JOIN
        && g_frameAnchorUs != g_lastAggFlushAnchor) {
      uint32_t nSl   = aggFlushSlotsNow();
      uint32_t pick  = aggSlotMix((uint32_t)NODE_ID, (uint32_t)g_curSchedSeq, nSl);
      uint32_t rBase = g_memberBaseUs + (uint32_t)g_nSlotsThisFrame * g_slotUsLive;   // same replyBase memberFloodNote uses
      uint32_t sSt   = rBase + pick * g_aggSlotUsLive;
      if (offUs >= sSt && offUs < sSt + g_aggSlotUsLive) {
      uint8_t cached = g_aggN;   // read BEFORE aggFlush drains it
      aggFlush((uint8_t)(g_anchorHops + 1));
      g_lastAggFlushAnchor = g_frameAnchorUs;
      logRec(LOG_STATE, NODE_ID, g_role, 0xAB, (int16_t)pick, (int16_t)nSl, (uint32_t)cached);   // v7.28.102: aux 0xAB = aggregate flush slot witness, e = pick, n = N, data = cached before
      // v7.28.101 FUNNEL ASK. aggFlush hands the keeper the joiner records and the
      // keeper seats them, but seating is not the same as giving them somewhere to
      // transmit: the join windows come from a birth frame, and the keeper sizes
      // that frame from the LARGER of g_recentJoinReqCount and g_swarmReqCount.
      // A joiner behind a relay is heard by the funnel, not by the keeper, so it
      // never lands in g_recentJoinReqCount and the keeper had no count to size on.
      // This is the ask the v7.28.5 design describes and that nothing ever sent.
      // Rate: at most once per frame, and only while this board actually relayed
      // the schedule this frame, which is the same gate aggFlush already passed.
      // The keeper still owns every limit: BIRTH_COOLDOWN_FRAMES, BIRTH_TAPER_
      // COOLDOWN and BIRTH_EMPTY_RUNS_MAX all sit on the TK side, so a stuck or
      // spoofed funnel cannot hold the sphere in birth mode however often it asks.
      // v7.28.102: the v7.28.101 funnel ask no longer fires here. It was an unslotted
      // transmit at this same site, which is the same placement defect as the flush.
      // It now rides this board's OWN member slot as a type-7 packet in place of the
      // type-0 report, once per frame while joiners are cached, see the slot TX below.
      }
    }
  }
  // join window: LISTEN nodes only, ONCE per frame, only if THIS frame's
  // schedule was heard (a node that cannot hear the TK must stay silent, not
  // jam). v7.10.7: FIXED position now, right after the TK's own slot, same
  // spot every frame regardless of roster size. A cold joiner no longer
  // needs its own frame-length estimate to find the window at all, only to
  // know when the next beacon is due.
  uint32_t joinWin = g_memberBaseUs - g_joinResUs;   // v7.28.37: front of the join region = tkSlotUsLive(nSlots) + g_relaySchedSlotUs, taken from the same runtime base the keeper and members agree on, so it tracks the per-frame keeper slot instead of the fixed 22-slot TK_SLOT_US. v7.11.10: shifted past the relay-schedule window
  // v7.16.0: the latest instant this node may START transmitting is the end of
  // the TK's published reservation, minus THIS node's own measured join airtime,
  // minus the guard. Before this release the test was joinWin + JOIN_KEYWIN_US,
  // which treated the keying window as if it were the whole transmission and let
  // a joiner start 31576 us before it could possibly finish inside the space
  // reserved for it. The keying window says when you may START. The airtime is a
  // separate, additive quantity, and conflating the two is what caused the
  // 2026-07-28 defect. No compile time airtime figure is involved here any more.
  // If the reservation were ever too small to hold this node's own packet, the
  // window collapses to empty and this node stays silent rather than jamming
  // member slot 0. That is the deliberate fail-safe direction.
  uint32_t joinTail   = g_joinAirUs + SLOT_GUARD_US;
  uint32_t joinWinEnd = (g_joinResUs > joinTail) ? (joinWin + g_joinResUs - joinTail) : joinWin;
  // v7.28.0: on a JOIN superframe this node's join window is its picked leaf
  // slot, not the fixed reservation. Same fail-safe shape as v7.16.0: if the
  // slot cannot hold this node's own measured join airtime plus guard, the
  // window collapses to empty and the node stays silent rather than jamming.
  if (g_frameType == SF_TYPE_JOIN && g_burstSlotPick != 0xFF && g_slotUsLive > joinTail){
    joinWin    = g_memberBaseUs + (uint32_t)g_burstSlotPick * g_slotUsLive;
    joinWinEnd = joinWin + g_slotUsLive - joinTail;
  }
  // v11.2: eligible to join only if a real beacon was heard within the last
  // frame-length of wall-clock time (robust to the joiner's frame estimate).
  bool schedFresh = g_schedThisFrame && (millis() - g_lastSchedMs) <= (g_frameUs/1000UL + 20UL);
  // v7.12.1: no random backoff window, no any-roster-growth reset. Every
  // eligible frame, this node just checks its own deterministic modulus
  // turn and attempts if it is up, exactly like it would on the very first
  // beacon it ever heard. See the FW_PATCH comment above for why: the old
  // random-window-plus-reset design could starve a node indefinitely during
  // sustained roster churn, confirmed on the bench.
  if (g_role==0 && schedFresh
      && offUs >= joinWin && offUs < joinWinEnd){
    // The entry offset is only a hint: blocking work may have advanced real
    // time. Scope the exact advertised region and check actual secured packet
    // airtime immediately before the radio call, including after encryption.
    uint32_t joinRegionEnd = (g_frameType == SF_TYPE_JOIN && g_burstSlotPick != 0xFF)
                            ? joinWin + g_slotUsLive : joinWin + g_joinResUs;
    struct JoinDeadlineScope {
      explicit JoinDeadlineScope(uint64_t end) { g_joinTxDeadlineUs = end; }
      ~JoinDeadlineScope() { g_joinTxDeadlineUs = 0; }
    } joinDeadline(g_frameAnchorUs + joinRegionEnd);
    static uint8_t joinedSeq = 0xFF;
    bool directKeeperRecent = g_lastDirectSchedMs != 0 &&
                              (millis() - g_lastDirectSchedMs) < JOIN_DIRECT_WINDOW_MS;
    // v7.28.7 Part A: the swarm request is an urgent escalation and must not ride
    // the join-modulus turn, which climbs to 16 or more under load and so misses
    // the 10s failover. Fire it once per fresh schedule while the board owes a
    // request and still hears a token keeper. Part B at the consume path admits the
    // sender directly, so a request that reaches a live TK gets this board in and
    // the admit path refreshes it; the flag clears when the board sees itself
    // admitted, normally after one or two sends.
    static uint8_t swarmReqSeq = 0xFF;
    if (g_resignSwarmReq && g_resignSwarmTarget != 0
        && g_lastTkHeardMs != 0 && (millis() - g_lastTkHeardMs) < 3000
        && g_resignSwarmTries < RESIGN_SWARM_MAX_TRIES
        && swarmReqSeq != g_curSchedSeq && joinedSeq != g_curSchedSeq
        && !directKeeperRecent // a cheap direct join has priority when audible
        && joinTxBudgetFits(sizeof(MemberPkt))) {
      if (memberSendSwarmReq(1)) {
        swarmReqSeq = g_curSchedSeq;
        joinedSeq = g_curSchedSeq; // exactly one successful TX in this schedule
        g_resignSwarmTries++;
      }
    }
    if (joinedSeq != g_curSchedSeq){
      // v7.10.1: deterministic turn instead of a coin flip. Every node sees
      // the same seq from the same beacon, so this is the same decision on
      // every candidate, no collision by construction instead of by luck.
      // v7.12.1: this is now the ONLY gate on when a join is attempted, the
      // adaptive widening in joinModEffective() (driven by overheard join
      // traffic) is what spreads attempts out mesh-wide when churn is heavy.
      // v7.16.0: the modulus is the TK's, read off the beacon, not this node's
      // own guess from a roster count it can only estimate. joinMod == 0 means
      // the TK has closed the join window and no node may key in.
      bool fastJoinTurn = g_joinFastFrames != 0 &&
                          (((uint32_t)g_curSchedSeq + NODE_ID) % JOIN_FAST_MOD) == 0;
      bool normalJoinTurn = g_joinMod != 0 &&
                            (((uint32_t)g_curSchedSeq + NODE_ID) % (uint32_t)g_joinMod) == 0;
      if (fastJoinTurn || normalJoinTurn){
        // v7.18.0: evidence-based escalation. If this node only ever hears
        // the schedule RELAYED (g_anchorHops in 1..254), the TK cannot hear
        // its direct JoinPkt, so skip the doomed direct phase and flood from
        // the first turn. A node in direct range (anchorHops==0) tries the
        // cheap direct JoinPkt first and only escalates on give-up. 255 means
        // no schedule heard yet, so stay direct until we know our depth.
        // v7.28.19: decide on a window, not on the latest copy. The latest adopted
        // copy is relayed whenever this board booted after that frame's direct
        // beacon or missed it once; that is not evidence the keeper cannot hear us.
        { bool directRecent = g_lastDirectSchedMs != 0 && (millis() - g_lastDirectSchedMs) < JOIN_DIRECT_WINDOW_MS;
          // v7.28.20: decide fresh every join turn instead of one-way latching. Flood
          // while the keeper is not heard directly within the window (anchorHops != 255
          // means a schedule has been heard, just relayed), or once direct has been
          // given up for good. If the keeper becomes directly audible again after
          // election churn or a handover, drop straight back to the cheap direct join.
          g_joinFloodMode = g_joinGiveUp || (g_anchorHops != 255 && !directRecent); }
        // v7.18.0: escalate to the floodable join once direct has been
        // exhausted. A node still in LISTEN after JOIN_MAX_ATTEMPTS direct
        // tries is one the TK cannot hear; keep trying via the relay tree
        // instead of logging give-up and looping on a path that cannot work.
        // v7.28.7: the swarm request moved up to the top of the join window so it
        // fires every frame, not on this one-in-joinMod turn. Back to the ordinary
        // join choice here: flood if direct has been exhausted or the node only
        // hears the schedule relayed, otherwise the cheap direct join.
        bool armFastAfterFirst = (g_joinFastFrames == 0 && g_joinAttemptCount == 0);
        bool flood = !directKeeperRecent && (g_joinFloodMode || (g_joinFastFrames != 0 && g_joinAttemptCount >= JOIN_FAST_DIRECT_ATTEMPTS));
        // Full MemberPkt requests wait for a member-sized JOIN window when
        // they do not fit the direct JoinPkt reservation. No attempt is counted.
        if (!joinTxBudgetFits(flood ? sizeof(MemberPkt) : sizeof(JoinPkt))) return;
        bool sent = flood ? memberSendJoinFlood() : memberSendJoin();
        if (!sent) return;
        joinedSeq = g_curSchedSeq;
        g_joinAttemptCount++;
        // v7.29.49: preserve the normal distributed first-attempt turn. If it
        // goes unanswered, enter the bounded retry cadence instead of waiting
        // another full (possibly eight-frame) normal modulus. This also covers
        // a rebooted late starter, which has no prior roster-eviction event to
        // arm the v47 path.
        if (armFastAfterFirst) g_joinFastFrames = JOIN_FAST_FRAMES;
        else if (g_joinFastFrames != 0) g_joinFastFrames--;
        // v7.29.47: after two unanswered fast direct attempts, rebuild the
        // modem once and use the floodable path on subsequent fast turns. The
        // ordinary five-attempt guard below remains as the long-tail fallback.
        if (g_joinFastFrames != 0 && g_joinAttemptCount == JOIN_FAST_DIRECT_ATTEMPTS && !g_joinRadioRecovered) {
          g_joinRadioRecoverReq = true;
          g_joinRadioRecovered = true;
          g_joinFloodMode = true;
        }
        if (g_joinAttemptCount >= JOIN_MAX_ATTEMPTS){
          // v7.12.1: five attempts at its own turn and still not admitted is
          // a genuinely broken condition (dead RF, corrupted request, full
          // roster), not something worth retrying forever. Log it distinctly
          // and reset the counter so the next eligible frame is tried fresh,
          // cold-boot style, no special state carried forward.
          // v7.18.0: direct join exhausted. Log the transition ONCE (the
          // same 0xC1 sentinel, so existing decoders still mark it) and
          // switch to flood mode; the next eligible turn floods instead of
          // repeating a direct request the TK will never hear.
          if (!g_joinGiveUp)
            logRec(LOG_STATE, NODE_ID, g_role, g_tkId, 0, 0, JOIN_GIVEUP_SENTINEL);
          g_joinGiveUp    = true;   // v7.28.20: give-up is now the only latch that forces flood
          g_joinFloodMode = true;
          g_joinAttemptCount = 0;
          // v7.29.43: receiving schedules while every outbound join disappears
          // is exactly the one-way state captured on node 04. The generic RX
          // watchdog never fires because reception is healthy. Request one full
          // modem/FEM rebuild per LISTEN episode before retrying the flood path.
          if (!g_joinRadioRecovered) {
            g_joinRadioRecoverReq = true;
            g_joinRadioRecovered = true;
          }
        }
      }
    }
  }
  }  // end member branch
}
#if LSM_PAYLOAD_PROBE
static uint8_t payloadProbeCoverage(const uint8_t bitmap[10]) {
  uint8_t n = 0;
  for (uint8_t i=0; i<10; ++i) {
    uint8_t b = bitmap[i];
    while (b) { n += (uint8_t)(b & 1u); b >>= 1; }
  }
  return n;
}

static void payloadProbePrint() {
  Serial.printf("PAYLOAD node=%u role=%u keeper=%u lean=%u origin_tx=%lu relay_tx=%lu log_suppressed=%lu\n",
                (unsigned)NODE_ID, (unsigned)g_role, (unsigned)g_tkId,
                (unsigned)LSM_PAYLOAD_TEST_LEAN,
                (unsigned long)g_payloadOriginTx, (unsigned long)g_payloadRelayTx,
                (unsigned long)g_payloadLogSuppressed);
  Serial.printf("PAYLOAD_RADIO rx=%lu secure_rejected=%lu hdr_abort=%lu read_fail=%lu last_err=%d\n",
                (unsigned long)g_rxCount, (unsigned long)securemesh::rejected(),
                (unsigned long)g_hdrAbort, (unsigned long)g_rdFail, (int)g_rdLastErr);
  Serial.printf("PAYLOAD_READ len_fail=%lu chip_fail=%lu open_fail=%lu filter_fail=%lu\n",
                (unsigned long)g_secLenFail, (unsigned long)g_secReadFail,
                (unsigned long)g_secOpenFail, (unsigned long)g_secFilterFail);
  static const char hex[] = "0123456789ABCDEF";
  for (uint8_t i=0; i<PAYLOAD_PROBE_SOURCES; ++i) {
    const PayloadProbeSource& s = g_payloadProbe[i];
    if (s.id == 0) continue;
    char map[21];
    for (uint8_t j=0; j<10; ++j) {
      map[j*2] = hex[s.bitmap[j] >> 4];
      map[j*2+1] = hex[s.bitmap[j] & 0x0F];
    }
    map[20] = 0;
    Serial.printf("PAYLOAD_SRC id=%u unique=%lu duplicate=%lu reordered=%lu gaps=%lu coverage80=%u bitmap=%s\n",
                  (unsigned)s.id, (unsigned long)s.unique,
                  (unsigned long)s.duplicate, (unsigned long)s.reordered,
                  (unsigned long)s.gaps, (unsigned)payloadProbeCoverage(s.bitmap), map);
  }
}
#endif

#include "telemetry_runtime.h"

static void irqPolicyPrint(){
  Serial.printf("RADIO_IRQ_POLICY node=%u config_iram=%u requested_flags=%u install_rc=%ld verified=%u\n",
      (unsigned)NODE_ID,(unsigned)CONFIG_ARDUINO_ISR_IRAM,(unsigned)ESP_INTR_FLAG_IRAM,
      (long)g_irqPolicyInstall,(unsigned)g_irqPolicyVerified);
}
static void irqPolicySerialOnly(){
  while(Serial.available()){
    const char c=(char)Serial.read();
    if(!irqpolicy::diagnosticAllowed(c))continue;
    if(c=='u')irqPolicyPrint();
    else if(c=='I')Serial.printf("ID LSMESH-%02u node_id=%u V%u.%u.%u\n",
        (unsigned)NODE_ID,(unsigned)NODE_ID,(unsigned)FW_MAJOR,(unsigned)FW_MINOR,(unsigned)FW_PATCH);
    else if(c=='Z'){Serial.println("RESTART requested");Serial.flush();delay(75);ESP.restart();}
  }
}
void serialCmdPoll() {
  if(!g_irqPolicyVerified){irqPolicySerialOnly();return;}
  if(g_telemetryUsbPrefixBusy.load(std::memory_order_acquire))return;
  SerialOutputTry output;if(!output.held)return;
  while (Serial.available()) {
    char c = (char)Serial.read();
    if(c=='u'){
      irqPolicyPrint();
  Serial.printf("GPIO_BOOT_STACK node=%u core=%d pinned_core=%d remaining_bytes=%u\n",(unsigned)NODE_ID,xPortGetCoreID(),xTaskGetCoreID(nullptr),(unsigned)uxTaskGetStackHighWaterMark(nullptr));
      uiStatusPrint();
      telemetryExportPrint();
      Serial.printf("RF_FLASH node=%u attempts=%lu acquired=%lu busy=%lu released=%lu active=%lu bypass_sync=%lu overlaps=%lu max_hold_us=%lu async=%u fs_last_io_us=%lu fs_max_io_us=%lu fs_last_wait_us=%lu fs_max_wait_us=%lu\n",(unsigned)NODE_ID,(unsigned long)g_rfFlashAttempts,(unsigned long)g_rfFlashAcquired,(unsigned long)g_rfFlashBusy,(unsigned long)g_rfFlashReleased,(unsigned long)g_rfFlashActive.load(std::memory_order_acquire),(unsigned long)g_rfFlashBypass,(unsigned long)g_rfFlashOverlap.load(std::memory_order_acquire),(unsigned long)g_rfFlashMaxHoldUs,(unsigned)radioFlashAsync(),(unsigned long)g_fsLastIoUs,(unsigned long)g_fsMaxIoUs,(unsigned long)g_fsLastWaitUs,(unsigned long)g_fsMaxWaitUs);
      Serial.printf("SCHED_RELAY_TIMING node=%u last_tx_us=%lu last_rx_us=%lu max_tx_over_air_us=%lu max_rx_us=%lu last_air_us=%lu last_predicted_engage_us=%lu\n",(unsigned)NODE_ID,(unsigned long)g_schedRelayTiming.lastTxUs,(unsigned long)g_schedRelayTiming.lastRxUs,(unsigned long)g_schedRelayTiming.maxTxOverAirUs,(unsigned long)g_schedRelayTiming.maxRxUs,(unsigned long)g_schedRelayTiming.lastAirUs,(unsigned long)g_schedRelayTiming.lastPredictedEngageUs);
      Serial.printf("SCHED_RELAY node=%u calls=%lu driver_success=%lu driver_fail=%lu geometry_blocked=%lu budget_blocked=%lu overruns=%lu max_overrun_us=%lu flash_blocked=%lu\n",(unsigned)NODE_ID,(unsigned long)g_schedRelayStats.calls,(unsigned long)g_schedRelayStats.success,(unsigned long)g_schedRelayStats.failed,(unsigned long)g_schedRelayStats.geometryBlocked,(unsigned long)g_schedRelayStats.budgetBlocked,(unsigned long)g_schedRelayStats.overruns,(unsigned long)g_schedRelayStats.maxOverrunUs,(unsigned long)g_schedRelayStats.flashBlocked);
      Serial.printf("OWNED_BUDGET node=%u checks=%lu rejected=%lu last_remaining_us=%lu last_required_us=%lu\n",(unsigned)NODE_ID,(unsigned long)g_ownedBudgetChecks,(unsigned long)g_ownedBudgetRejects,(unsigned long)g_ownedLastRemaining,(unsigned long)g_ownedLastRequired);
      Serial.printf("OWNED_TIMING node=%u engage_us=%lu engage_samples=%lu rx_arm_us=%lu rx_samples=%lu trim_us=%ld slot_us=%lu air_us=%lu reserve_us=6000\n",(unsigned)NODE_ID,(unsigned long)g_txLatUs,(unsigned long)g_txLatSamp,(unsigned long)g_rxArmUs,(unsigned long)g_rxArmSamples,(long)g_trimAdjUs,(unsigned long)g_slotUsLive,(unsigned long)radio.getTimeOnAir(sizeof(MemberPkt)+MESH_SEC_OVERHEAD));
      Serial.printf("OWNED_SLOT node=%u opportunities=%lu attempts=%lu driver_success=%lu skips=%lu driver_fail=%lu observed_overruns=%lu uncalibrated_attempts=%lu predictive=1 uncertainty_us=6000\n",(unsigned)NODE_ID,(unsigned long)g_ownedOpportunities,(unsigned long)g_ownedAttempts,(unsigned long)g_ownedSuccess,(unsigned long)g_ownedSkips,(unsigned long)g_ownedDriverFail,(unsigned long)g_ownedOverruns,(unsigned long)g_ownedUncalibrated);
      const uint32_t tokenStart=g_role==3 ? g_tokSlotStartUs : g_memberBaseUs+(uint32_t)g_frameGeometrySlots*g_slotUsLive+g_relayReplySlotUs;
      Serial.printf("FRAME_GEOMETRY node=%u seq=%u tiers=%u nslots=%u member_us=%lu member_slot_us=%lu reply_us=%lu token_us=%lu token_slot_us=%lu aggregate_us=%lu aggregate_slot_us=%lu frame_us=%lu\n",(unsigned)NODE_ID,(unsigned)(g_role==3?(uint8_t)g_frame:g_curSchedSeq),(unsigned)g_schedTiers,(unsigned)g_frameGeometrySlots,(unsigned long)g_memberBaseUs,(unsigned long)g_slotUsLive,(unsigned long)g_relayReplySlotUs,(unsigned long)tokenStart,(unsigned long)g_tokSlotUsLive,(unsigned long)g_aggPosSlotStartUs,(unsigned long)AGG_POS_SLOT_US,(unsigned long)g_frameUs);
      Serial.printf("OBS_CLOCK node=%u uptime_ms=%lu\n",(unsigned)NODE_ID,(unsigned long)millis());
      const securemesh::EpochMetadata e=securemesh::epochMetadata();
      Serial.printf("OWN_EPOCH node=%u active=%lu durable=%lu durable_valid=%u ready=%u\n",(unsigned)e.selfId,(unsigned long)e.bootEpoch,(unsigned long)e.ownDurableEpoch,(unsigned)e.ownDurableValid,(unsigned)securemesh::ready());
      Serial.printf("MESH_EPOCH_META node=%u boot_epoch=%lu authenticated09_epoch=%lu rx09_current_epoch=%lu rx09_saved_epoch=%lu rx09_durable_epoch=%lu rx09_loaded=%u rx09_durable_present=%u rx09_durable_valid=%u\n", (unsigned)e.selfId, (unsigned long)e.bootEpoch, (unsigned long)e.lastAuthenticated09Epoch, (unsigned long)e.rx09CurrentEpoch, (unsigned long)e.rx09SavedEpoch, (unsigned long)e.rx09DurableEpoch, (unsigned)e.rx09Loaded, (unsigned)e.rx09DurablePresent, (unsigned)e.rx09DurableValid);
    }
    if(c=='v'){g_telemetryUsb=true;telemetryReplay();Serial.println("TELEMETRY v1 USB tag=5 snapshot=35 enabled");}
    else if(c=='n'){g_telemetryUsb=false;Serial.println("TELEMETRY USB disabled");}
    else if(c=='r'){telemetryReplay();}
    else if (c == 'k') provisionMeshUSB();
    else if (c == 'T') benchLinkUSB();
    else if (c == 'Y') { g_benchDropSched = true;  Serial.println("BENCH schedule drop=1; volatile, reset restores normal reception"); }
    else if (c == 'y') { g_benchDropSched = false; Serial.println("BENCH schedule drop=0"); }
    else if(c=='t') {Serial.printf("POSITION_TIMING node=%u role=%u keeper=%u sf=%u bw=%lu frame_us=%lu member_base_us=%lu member_air_us=%lu member_slot_us=%lu tiers=%u roster=%u aggregate_slot_us=%lu telemetry_accepted=%lu telemetry_rejected=%lu usb_frames=%lu\n",(unsigned)NODE_ID,g_role,g_tkId,g_workingSf,(unsigned long)g_workingBw,(unsigned long)g_frameUs,(unsigned long)g_memberBaseUs,(unsigned long)g_memberAirUsLive,(unsigned long)g_slotUsLive,g_schedTiers,g_rosterN,(unsigned long)AGG_POS_SLOT_US,(unsigned long)g_telemetryAccepted,(unsigned long)g_telemetryRejected,(unsigned long)g_telemetryUsbFrames); Serial.printf("PHY_READ_DIAG node=%u chip_crc=%lu chip_header=%lu chip_other=%lu last_chip_error=%d secure_length=%lu secure_read=%lu secure_open=%lu filter=%lu header_aborts=%lu\n",(unsigned)NODE_ID,(unsigned long)g_secChipCrc,(unsigned long)g_secChipHeader,(unsigned long)g_secChipOther,g_secChipLastError,(unsigned long)g_secLenFail,(unsigned long)g_secReadFail,(unsigned long)g_secOpenFail,(unsigned long)g_secFilterFail,(unsigned long)g_hdrAbort); }
    else if (c == 'u') Serial.printf("JOIN_BUDGET node=%u blocked=%lu direct_air_us=%lu flood_air_us=%lu reservation_us=%lu\n", (unsigned)NODE_ID, (unsigned long)g_joinBudgetBlocked, (unsigned long)secureAirTime(sizeof(JoinPkt)), (unsigned long)secureAirTime(sizeof(MemberPkt)), (unsigned long)g_joinResUs);
    else if (c == 'h') Serial.printf("HOP node=%u role=%u keeper=%u anchor_hops=%u filter=%04X successor=%u epoch=%u roster=%u\n", (unsigned)NODE_ID, g_role, g_tkId, g_anchorHops, g_benchLinkMask, g_successor, g_tkEpoch, g_rosterN);
    else if (c == 's') Serial.printf("SEC ready=%u rejected=%lu sender_bind_rejected=%lu max_persist_us=%lu relay_queue_full=%lu\n", securemesh::ready(), (unsigned long)securemesh::rejected(), (unsigned long)g_senderBindReject, (unsigned long)securemesh::maxStoreUs(), (unsigned long)g_relayQueueFull);
    else if (c == 'D') logDumpSerial();
    else if (c == 'B') logDumpSerialBin();
    else if (c == 'E') logErase();
#if LSM_PAYLOAD_PROBE
    else if (c == 'p') payloadProbePrint();
    else if (c == 'P') { payloadProbeReset(); Serial.println("PAYLOAD reset"); }
#endif
    else if (c == 'Z') {
      // v7.30.0 bench acceptance: native USB control-line toggles do not reset
      // every V2 board consistently.  A one-byte explicit restart lets the
      // harness cold-start every connected badge within the same radio window.
      // It changes no persistent mesh, key, roster, or identity state.
      Serial.println("RESTART requested");
      Serial.flush();
      delay(75);
      ESP.restart();
    }
    else if (c == 'I') {   // v7.20.8: identity on demand, for the fleet logger
      Serial.printf("ID LSMESH-%02u node_id=%u V%u.%u.%u\n",
                    (unsigned)NODE_ID, (unsigned)NODE_ID,
                    (unsigned)FW_MAJOR, (unsigned)FW_MINOR, (unsigned)FW_PATCH);
    }
    else if (c == 'R') ksSerialRevoke();   // v7.28.59: inject a signed revocation record, 146 hex chars then newline
    else if (c == 'W') ksSerialStatus();   // v7.28.59: identity gate and token status
    else if (c == 'Q') Serial.println("Revocation reset disabled in this release"); // v7.28.59: bench only, clear this board's deny list
    else if (c == 'J') {
      // v7.11.5: bench-only manual join trigger, bypasses the modulus turn
      // and the random backoff entirely. Only fires from LISTEN, same
      // memberSendJoin() the normal path calls, so the TX itself is
      // identical to a real join, only the timing gate is skipped. For
      // watching tkOnJoinReq on demand instead of waiting for a natural turn.
      if (g_role == 0) {
        memberSendJoin();
        Serial.println("J: forced join TX sent (bench test, bypassed modulus/backoff)");
      } else {
        Serial.printf("J: not sent, role is %s not LSTN\n", roleStr());
      }
    }
  }
}

class LogCB : public NimBLECharacteristicCallbacks {
  // v7.20.17: the acknowledgement the sliced dump paces on. NimBLE-Arduino
  // 1.4.3 returns void from indicate(), so this callback is the only place
  // the peer's confirmation is visible. COMPILE NOTE: if 1.4.3 disagrees on
  // this signature, that is the one line to adjust, everything else is ours.
  void onStatus(NimBLECharacteristic* c, Status s, int code) {
    if (c != chLog) return;
    g_indLast = (int8_t)s;
    if (s == SUCCESS_INDICATE || s == SUCCESS_NOTIFY) g_indAck = true;
    else if (s == ERROR_INDICATE_DISABLED || s == ERROR_NOTIFY_DISABLED) {
      g_indNoInd = true; g_indErr = true;
    }
    else if (s == ERROR_INDICATE_TIMEOUT || s == ERROR_INDICATE_FAILURE) g_indErr = true;
  }
  void onWrite(NimBLECharacteristic* c) {
    std::string v = c->getValue();
    if (v.size() < 1) return;
    if (v[0] == 0x01) g_dumpReq = true;
    else if (v[0] == 0x02) g_eraseReq = true;
    else if(v[0]==0x04)g_telemetryReplayRequested.store(true,std::memory_order_release);
    else if (v[0] == 0x03 && v.size() >= 5) {
      // v7.12.5: dashboard-initiated TK frequency switch test. Payload is a
      // 4-byte little-endian float, target frequency in MHz. This only does
      // anything once THIS board is actually TK and calls tkBuildAndSend();
      // if you are paired to a member right now, it just sits here. Pair to
      // the current TK for this to take effect, same as any other dashboard
      // action this session.
      float freq; memcpy(&freq, v.data() + 1, 4);
      g_freqTargetMHz = freq;
      g_freqCountdown = FREQ_SWITCH_COUNTDOWN_FRAMES;
    }
  }
};

// ----------------------- BLE server callbacks -----------------------
class TelemetryExportCB : public NimBLECharacteristicCallbacks {
  void onStatus(NimBLECharacteristic* c,Status status,int code) override {
    if(xTaskGetCurrentTaskHandle()!=g_bleNotifyOwner.load(std::memory_order_acquire))return;
    if(c==g_bleNotifyCharacteristic)telemetryBleNotifyStatus(status==SUCCESS_NOTIFY,code);
  }
  void onSubscribe(NimBLECharacteristic* c,ble_gap_conn_desc*,uint16_t) override {
    if(c!=chTelemetry)return; // Legacy subscriptions never reset the V1 export queue.
    // NimBLE1.4.3 invokes this after updating its subscriber map.
    g_exportBleSubscribed.store(c->getSubscribedCount()>0,std::memory_order_release);
    g_exportBleGeneration.fetch_add(1,std::memory_order_acq_rel);
  }
};
class SrvCB : public NimBLEServerCallbacks {
  void onConnect(NimBLEServer* s) {
    g_connected = true;
    g_exportBleConnected.store(true,std::memory_order_release);
    if(serialAsyncBegin()){Serial.println("BLE client connected");serialAsyncEnd();}
  }
  // v6.8: two-arg form gives the connection descriptor so we can tune the link.
  // Request 30-60 ms interval, 0 latency, 4 s supervision timeout so a brief stall
  // or a picky Windows/Chrome BLE stack cannot drop the connection.
  void onConnect(NimBLEServer* s, ble_gap_conn_desc* desc) {
    g_connected = true;
    g_exportBleConnected.store(true,std::memory_order_release);
    s->updateConnParams(desc->conn_handle, 24, 48, 0, 400);
    if(serialAsyncBegin()){Serial.println("BLE client connected, conn params tuned");serialAsyncEnd();}
  }
  // v7.20.17: capture the negotiated MTU so the dump can size its frame.
  void onMTUChange(uint16_t MTU, ble_gap_conn_desc* desc) {
    g_bleMtu = MTU;
    if(serialAsyncBegin()){Serial.printf("BLE MTU negotiated: %u\n", (unsigned)MTU);serialAsyncEnd();}
  }
  void onDisconnect(NimBLEServer* s) {
    g_connected = false;
    g_exportBleConnected.store(false,std::memory_order_release);
    g_exportBleSubscribed.store(false,std::memory_order_release);
    g_exportBleGeneration.fetch_add(1,std::memory_order_acq_rel);
    g_bleMtu = 23;
    if(serialAsyncBegin()){Serial.println("BLE client disconnected, advertising again");serialAsyncEnd();}
    NimBLEDevice::startAdvertising();
  }
};

void sendPosition() {
  if (!g_connected) return;
  // v7.12.4: this used to also require originSet, so the paired board
  // itself never sent a self-report at all until its own first real GPS
  // fix, same class of bug as peerTouch before this. g_posConf already
  // defaults to and stays 0 until a real fix lands, unrelated to
  // originSet, so dropping this gate costs nothing, a no-fix self-report
  // now goes out with the same conf 0 sentinel a no-fix peer already
  // carries, and the dashboard's existing roster/no-dot handling applies
  // to the paired board exactly the same as any other node. Root caused
  // 2026-07-11, Stu paired to 05 with no fix, 05 never appeared in the
  // roster panel at all.
  int16_t e = (int16_t)g_fusE, n = (int16_t)g_fusN;   // v6.7: fused offset
  uint8_t b[16];
  memset(b, 0, sizeof(b));
  put_u32(b + 0, NODE_ID);
  put_i16(b + 4, e);            // x = east
  put_i16(b + 6, n);            // y = north
  b[10] = (uint8_t)FLOOR_LEVEL; // floor
  b[12] = 0x00;                 // flags, bit0 = mark
  b[11] = g_posConf;            // v6.7: own position confidence
  put_i16(b + 8, altitudeCmNow() / 10);   // v6.10: own GPS altitude over BLE only, decimetres, no LoRa slot cost
  b[13] = 0x00;                 // age, 0 = fresh
  chPos->setValue(b, sizeof(b));
  chPos->notify();
}

void sendDiagnostics() {
  if (!g_connected) return;
  bool locked = g_haveRealFix && gps.location.isValid();   // v7.28.64
  uint16_t tkStable = locked ? (uint16_t)((millis() - fixSinceMs) / 1000) : 0;
  // v7.12.9: packet grown 16 to 24 bytes to carry the RAW GPS feed, no fix
  // gate, no origin math, straight off gps.location, same as it sits in
  // TinyGPS++ right now. This is deliberately separate from the fused/
  // projected position the dashboard already draws on the map (CPOS plus
  // the CSEED anchor), so Stu can watch the raw feed and the drift
  // correction side by side instead of only ever seeing the corrected
  // number. BLE-only addition, does not touch the LoRa wire version, only
  // firmware and the dashboard need to agree on this layout.
  // v7.12.13: packet grown 24 to 28 bytes to carry gps.charsProcessed(),
  // the one number that tells whether NMEA bytes are actually reaching the
  // parser at all. Previously only visible over USB serial, meaning "raw
  // GPS lat/lon reads 0,0" was ambiguous on the dashboard between "no fix
  // yet, module alive" and "nothing reaching the parser at all, wiring or
  // baud problem". This field removes that ambiguity without needing a USB
  // connection. BLE-only, does not touch the LoRa wire version.
  uint8_t b[28];
  memset(b, 0, sizeof(b));
  b[0] = battPct();
  b[1] = g_role;
  put_u32(b + 2, g_tkId);           // current elected timekeeper id
  b[6] = locked ? 1 : 0;            // nonzero = HEALTHY and time locked
  b[7] = g_peersHeard;              // peers heard on the 915 MHz mesh
  b[8] = locked ? 100 : 0;          // link quality placeholder
  b[9] = (g_role == 3) ? 0 : g_mySlot;  // superframe slot in use
  b[10] = 0;                        // drops per minute
  put_u16(b + 11, tkStable);
  put_u16(b + 14, ((uint16_t)FW_MAJOR << 8) | FW_MINOR);
  bool rawOk = gps.location.isValid() && g_satsNow >= MIN_SATS_TX;   // v7.28.68: zeros to the phone when there is no usable fix
  int32_t rawLatI = rawOk ? (int32_t)lround(gps.location.lat() * 1000000.0) : 0;
  int32_t rawLonI = rawOk ? (int32_t)lround(gps.location.lng() * 1000000.0) : 0;
  put_u32(b + 16, (uint32_t)rawLatI);   // raw GPS lat, microdegrees, no fix gate, reinterpret cast, two's complement round-trips fine through getInt32 on the dashboard side
  put_u32(b + 20, (uint32_t)rawLonI);   // raw GPS lon, microdegrees, no fix gate
  put_u32(b + 24, (uint32_t)gps.charsProcessed());  // v7.12.13: total NMEA bytes seen since boot, climbing means the UART link is alive regardless of fix state
  chDia->setValue(b, sizeof(b));
  chDia->notify();
}

void sendMark() {
  if (!g_connected || !originSet) return;
  int16_t e = (int16_t)g_fusE, n = (int16_t)g_fusN;   // v6.7: fused offset
  uint8_t b[12];
  memset(b, 0, sizeof(b));
  put_u32(b + 0, NODE_ID);
  put_i16(b + 4, e);
  put_i16(b + 6, n);
  b[10] = (uint8_t)FLOOR_LEVEL;
  b[11] = 0x00;                 // flags, bit1 = auto/shot. manual press = 0
  chMrk->setValue(b, sizeof(b));
  chMrk->notify();
  if(!serQuiet())Serial.println("MARK sent");
}

void setupBLE() {
  char bleName[16];
  snprintf(bleName, sizeof(bleName), "LSMESH-%02u", (unsigned)NODE_ID); // ctok 2026-07-21 identity fix
  NimBLEDevice::init(bleName);
  // v7.20.17: 247 is the common phone ceiling and gives a 240 byte payload,
  // ten records per frame against the old four. The peer decides; if it
  // refuses, onMTUChange never raises g_bleMtu and the frame stays at 96.
  NimBLEDevice::setMTU(247);
  NimBLEServer* server = NimBLEDevice::createServer();
  server->setCallbacks(new SrvCB());

  NimBLEService* svc = server->createService(SVC_UUID);

  chPos = svc->createCharacteristic(CPOS_UUID, NIMBLE_PROPERTY::NOTIFY);
  chTelemetry=svc->createCharacteristic("4b41000a-5253-4849-454c-440000000000",NIMBLE_PROPERTY::NOTIFY);
  static TelemetryExportCB exportCallbacks;chTelemetry->setCallbacks(&exportCallbacks);chPos->setCallbacks(&exportCallbacks);
  chSeed = svc->createCharacteristic(CSEED_UUID, NIMBLE_PROPERTY::NOTIFY);   // v7.2
  chMrk = svc->createCharacteristic(CMRK_UUID, NIMBLE_PROPERTY::NOTIFY);
  chDia = svc->createCharacteristic(CDIA_UUID, NIMBLE_PROPERTY::NOTIFY);
  chLog = svc->createCharacteristic(CLOG_UUID, NIMBLE_PROPERTY::NOTIFY | NIMBLE_PROPERTY::INDICATE | NIMBLE_PROPERTY::WRITE);
  chLog->setCallbacks(new LogCB());

  NimBLECharacteristic* chInf =
      svc->createCharacteristic(CINF_UUID, NIMBLE_PROPERTY::READ);
  uint8_t inf[4];
  put_u32(inf, SELF_ID);
  chInf->setValue(inf, sizeof(inf));

  svc->start();

  // Web Bluetooth filters on the service UUID, so it must be in the advertising
  // packet. A 128-bit UUID plus the name overflows the 31-byte advert, so the
  // name goes in the scan response.
  NimBLEAdvertising* adv = NimBLEDevice::getAdvertising();
  NimBLEAdvertisementData advData;
  advData.setFlags(0x06);
  advData.setCompleteServices(NimBLEUUID(SVC_UUID));
  adv->setAdvertisementData(advData);

  NimBLEAdvertisementData scanData;
  scanData.setName(bleName);
  adv->setScanResponseData(scanData);

  NimBLEDevice::startAdvertising();
  if (!serQuiet()) Serial.printf("BLE advertising as %s\n", bleName);
}

// ----------------------- soft power off -----------------------
// The board has no power switch, so off is ESP32-S3 deep sleep with every
// peripheral shut down first. Hold USER for POWEROFF_HOLD_MS to enter it,
// hold USER for WAKE_HOLD_MS to leave it. Cold boot behavior is unchanged,
// including the hold at boot log wipe, which runs on cold boot only.
static const uint32_t POWEROFF_HOLD_MS = 5000;
static const uint32_t WAKE_HOLD_MS     = 1500;

void powerOff() {
  if(!serQuiet())Serial.println("USER held, soft power off");
  logRec(LOG_PWR, NODE_ID, g_role, 0, 0, 0, g_seq);
  // v7.28.71: SYNCHRONOUS on purpose. The board is about to deep sleep, so a
  // queued job on core 0 might never be scheduled. Drain inline and take the
  // blocking cost: there is no frame left to protect.
  fsDrainForShutdown();
  trimSave();                          // v7.12.26 persist current slot lead for next boot

  tft.fillScreen(ST77XX_BLACK);        // big OFF so the wearer sees it took
  tft.setTextSize(4);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.setCursor(4, 2);
  tft.print("OFF");
  delay(500);

  NimBLEDevice::deinit(true);          // drop BLE cleanly
  radio.sleep();                       // SX1262 sleep mode
  if (PIN_FEM_CSD >= 0) digitalWrite(PIN_FEM_CSD, LOW);      // FEM chip disable (V2 only)
  if (PIN_FEM_CTX >= 0) digitalWrite(PIN_FEM_CTX, LOW);
  digitalWrite(PIN_FEM_POWER, LOW);    // FEM rail off (V2) / RT9080 radio rail off (LilyGO)
#ifdef LSM_BOARD_LILYGO
  ledcWrite(PIN_TFT_BL, 0); ledcDetach(PIN_TFT_BL); pinMode(PIN_TFT_BL, OUTPUT);   // v7.28.51: hand the backlight pin back to GPIO before the hold
#endif
  digitalWrite(PIN_TFT_BL, LOW);       // backlight off
  if (PIN_VEXT >= 0) digitalWrite(PIN_VEXT, LOW);   // GNSS and TFT rail off (no VEXT on the LilyGO)

  // latch the rails low for the whole sleep
  if (PIN_VEXT >= 0) gpio_hold_en((gpio_num_t)PIN_VEXT);
  gpio_hold_en((gpio_num_t)PIN_TFT_BL);
  gpio_hold_en((gpio_num_t)PIN_FEM_POWER);
  if (PIN_FEM_CSD >= 0) gpio_hold_en((gpio_num_t)PIN_FEM_CSD);
  gpio_deep_sleep_hold_en();

  // wake on USER, pressed = LOW. GPIO 0 is RTC capable on the S3.
  rtc_gpio_pullup_en((gpio_num_t)PIN_USER_BTN);
  rtc_gpio_pulldown_dis((gpio_num_t)PIN_USER_BTN);
  esp_sleep_enable_ext0_wakeup((gpio_num_t)PIN_USER_BTN, 0);

  while (digitalRead(PIN_USER_BTN) == LOW) delay(10);  // release first or we wake instantly
  delay(50);
  esp_deep_sleep_start();              // does not return
}

// ============================================================================
// ctok 2026-07-21: throughput sampler + token status page (5th toggle screen)
// tputService samples the cumulative rx counter once per second, derives packets
// and goodput bytes per second, and logs a LOG_TPUT record so the rate lands in
// the published flash dump, not just the glass. Defined here so sizeof(MemberPkt)
// is already known.
static void tputService(uint32_t nowMs) {
  if (g_tputLastMs == 0) { g_tputLastMs = nowMs; g_tputLastRx = g_rxCount; return; }
  uint32_t dt = nowMs - g_tputLastMs;
  if (dt < 1000) return;
  g_tputLastMs = nowMs;
  uint32_t rx = g_rxCount;
  uint32_t drx = rx - g_tputLastRx;
  g_tputLastRx = rx;
  g_rxPps = (uint16_t)((drx * 1000UL) / dt);
  g_rxBps = (uint32_t)((drx * (uint32_t)sizeof(MemberPkt) * 1000UL) / dt);
  int16_t bpsClamp = (g_rxBps > 32767) ? 32767 : (int16_t)g_rxBps;
  // v7.28.96: topology and reject witness, emitted on the same one-second tick.
  {
    static uint32_t s_lastRejDepth = 0, s_lastRejStale = 0, s_lastRejWorse = 0;
    uint32_t dD = g_schedRejDepth - s_lastRejDepth;
    uint32_t dS = g_schedRejStale - s_lastRejStale;
    uint32_t dW = g_schedRejWorse - s_lastRejWorse;
    s_lastRejDepth = g_schedRejDepth; s_lastRejStale = g_schedRejStale; s_lastRejWorse = g_schedRejWorse;
    if (dD > 1023UL) dD = 1023UL;
    if (dS > 1023UL) dS = 1023UL;
    if (dW > 1023UL) dW = 1023UL;
    uint32_t packed = (dD & 0x3FFUL) | ((dS & 0x3FFUL) << 10) | ((dW & 0x3FFUL) << 20);
    int16_t nField = (int16_t)((uint16_t)g_peersHeard | (uint16_t)(g_joinFloodMode ? 0x100U : 0U));
    logRec(LOG_TOPO, (uint8_t)NODE_ID, g_role, g_anchorHops,
           (int16_t)g_schedTiers, nField, packed);
  }
  {
    // v7.28.101 LOG_MESH: the relay-and-funnel witness. See the type comment for the
    // field map. g_meshDeepHops is a high-water mark cleared HERE and nowhere else, so
    // a single relayed packet anywhere in the second is still visible; reusing
    // g_obsDepth would have shown zero on most seconds because the tier policy zeroes
    // it every frame after consuming it.
    uint32_t meshData = (uint32_t)g_orphanSeen
                      | ((uint32_t)g_aggN << 8)
                      | ((uint32_t)g_lastSwarmAsk << 16)
                      | ((uint32_t)g_anchorHops << 24);
    logRec(LOG_MESH, (uint8_t)NODE_ID, g_role, g_meshDeepHops,
           (int16_t)g_lastRelayForId, (int16_t)g_lastRelayById, meshData);
    g_meshDeepHops = 0;
  }
#ifndef LSM_LEAN_LOG   // v7.20.3: -D LSM_LEAN_LOG drops LOG_TPUT (frees ~18% of the log budget)
  logRec(LOG_TPUT, (uint8_t)NODE_ID, g_role,
         (uint8_t)(g_rxPps > 255 ? 255 : g_rxPps),
         bpsClamp, (int16_t)g_peersHeard, rx);
#endif
}

// v7.13.0: drawStatusBase, 6th page on the USER-tap cycle. The crystal
// baseline bake is CTOK_LEARN_SECS (480 s = 8 min) and until now ran with no
// indication at all, so there was no way to tell a board mid-bake from a board
// that had finished. This is just another face in the same rotation the USER
// button already cycles: one more tap to reach it, one more to leave. It adds
// no new interaction and no new state.
void drawStatusBase() {
#ifdef CRYSTAL_TOKEN
  bool base = pairtok::haveBaseline();
  uint32_t rem = pairtok::learnRemainSecs();
  uint32_t tot = pairtok::learnTotalSecs();
  tft.setTextSize(2);
  tft.setTextColor(base ? ST77XX_GREEN : ST77XX_YELLOW, ST77XX_BLACK);
  tft.setCursor(2, 4);
  tft.print(base ? "BASE READY " : "BASE BAKE  ");
  char l2[28];
  if (base) snprintf(l2, sizeof(l2), "baseline held, %us bake", (unsigned)tot);
  else      snprintf(l2, sizeof(l2), "%u:%02u left of %u:%02u",
                     (unsigned)(rem/60), (unsigned)(rem%60),
                     (unsigned)(tot/60), (unsigned)(tot%60));
  char l2p[28]; snprintf(l2p, sizeof(l2p), "%-23.23s", l2);
  tft.setTextSize(1);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.setCursor(2, 32);
  tft.print(l2p);
  // coarse progress bar, 120 px wide
  if (!base && tot) {
    uint32_t done = (tot > rem) ? (tot - rem) : 0;
    int w = (int)((done * 120UL) / tot);
    if (w > 120) w = 120;
    tft.drawRect(lsmTs(2), lsmTs(48), lsmTs(122), lsmTs(10), ST77XX_WHITE);   // v7.28.51: scaled on the LilyGO
    tft.fillRect(lsmTs(3), lsmTs(49), lsmTs(w), lsmTs(8), ST77XX_YELLOW);
    if (w < 120) tft.fillRect(lsmTs(3 + w), lsmTs(49), lsmTs(120 - w), lsmTs(8), ST77XX_BLACK);
  } else {
    tft.setTextSize(2);
    tft.setTextColor(ST77XX_GREEN, ST77XX_BLACK);
    tft.setCursor(2, 48);
    tft.print("DONE       ");
  }
#else
  tft.setTextSize(2);
  tft.setTextColor(ST77XX_RED, ST77XX_BLACK);
  tft.setCursor(2, 4);
  tft.print("BASE BLIND ");
  tft.setTextSize(1);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.setCursor(2, 32);
  tft.print("no bake (control board)");
#endif
}

// drawStatusTok: 5th page on the USER-tap cycle. Token boards show crystal-gate
// state (baseline, role, session ACCEPT/REJECT tally, peer count) plus live
// throughput. Blind boards state the honest "no token code" and still show
// throughput, which is useful on every board.
void drawStatusTok() {
#ifdef CRYSTAL_TOKEN
  bool base = pairtok::haveBaseline();
  char l1[24];
  if (base) snprintf(l1, sizeof(l1), "TOK %s", (g_role==3) ? "TK" : "MEM");
  else      snprintf(l1, sizeof(l1), "TOK LEARN");
  char l1p[24]; snprintf(l1p, sizeof(l1p), "%-11.11s", l1);
  tft.setTextSize(2);
  tft.setTextColor(base ? ST77XX_GREEN : ST77XX_YELLOW, ST77XX_BLACK);
  tft.setCursor(2, 4);
  tft.print(l1p);

  char l2[28];
  if (g_tokHadVerdict)
    snprintf(l2, sizeof(l2), "A%lu R%lu %s%u p%u",
             (unsigned long)g_tokAccept, (unsigned long)g_tokReject,
             g_tokLastOk ? "ok" : "no", (unsigned)g_tokLastSrc,
             (unsigned)pairtok::peerCount());
  else
    snprintf(l2, sizeof(l2), "no verdict yet p%u", (unsigned)pairtok::peerCount());
  char l2p[28]; snprintf(l2p, sizeof(l2p), "%-23.23s", l2);
  tft.setTextSize(1);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.setCursor(2, 32);
  tft.print(l2p);

  char l3[24];
  snprintf(l3, sizeof(l3), "%up/s %luB/s", (unsigned)g_rxPps, (unsigned long)g_rxBps);
  char l3p[24]; snprintf(l3p, sizeof(l3p), "%-11.11s", l3);
  tft.setTextSize(2);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.setCursor(2, 48);
  tft.print(l3p);
#else
  tft.setTextSize(2);
  tft.setTextColor(ST77XX_RED, ST77XX_BLACK);
  tft.setCursor(2, 4);
  tft.print("TOK BLIND  ");
  tft.setTextSize(1);
  tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);
  tft.setCursor(2, 32);
  tft.print("no baseline (by design)");
  char l3[24];
  snprintf(l3, sizeof(l3), "%up/s %luB/s", (unsigned)g_rxPps, (unsigned long)g_rxBps);
  char l3p[24]; snprintf(l3p, sizeof(l3p), "%-11.11s", l3);
  tft.setTextSize(2);
  tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);
  tft.setCursor(2, 48);
  tft.print(l3p);
#endif
}

// v7.19.2: shared backhaul listen + ladder walk. Extracted verbatim from the
// v7.12.14/v7.19.0 cold-boot block in setup() so the on-channel spill path
// (electShouldTakeOver full-lockout, via g_spillReq) reuses the exact same
// walk instead of growing a second one. Retunes to the backhaul discovery
// v7.28.26: size the backhaul listen from the advert cadence. The keeper's
// advert rides a frame tail gated on BACKHAUL_ADV_PERIOD_MS and alternates
// with the listen piece, so consecutive adverts are up to the period plus
// two frames apart. Listening that long guarantees one attempt; the 5000
// floor keeps the v7.19.2 margin. A cold boot cannot know the sphere's frame
// and assumes BACKHAUL_FRAME_CEIL_MS; a re-walk or spill uses the frame it
// just left.
static uint32_t backhaulListenMs(bool coldBoot) {
  uint32_t frameMs = coldBoot ? BACKHAUL_FRAME_CEIL_MS : (g_frameUs / 1000UL);
  if (frameMs < 1UL) frameMs = 1UL;
  uint32_t w = BACKHAUL_ADV_PERIOD_MS + 2UL * frameMs;
  return (w < BACKHAUL_LISTEN_MS) ? BACKHAUL_LISTEN_MS : w;
}
// channel, listens BACKHAUL_LISTEN_MS for 'B' adverts, gathers per-rung
// status, then walks the ladder channel A upward: JOIN the first rung with
// room, else SPAWN on the first empty rung (the vacuum election makes this
// node that rung's TK). knownFullMHz: 0 on cold boot; on a spill, the channel
// this board just heard flag full, pre-seeded as heard-and-full from
// firsthand knowledge, so a missed advert can never route the board back onto
// the rung that locked it out. Blocks for the full listen window (~3.5 s):
// call only from a top-level safe point (setup, or the loop hook), NEVER from
// inside the election predicate.
static void spillWalkLadder(float knownFullMHz, bool coldBoot=false) {
  // v7.20.2: LADDER-WALK ORIGIN STAMP. This helper serves BOTH callers: cold
  // boot passes 0.0f, the full-lockout spill passes its current rung. Until
  // now both exits logged an identical LOG_STATE record with aux 0, so a board
  // that walked the ladder at power-on and a board that was refused admission
  // and fled down the ladder were indistinguishable in the flash log. That
  // single ambiguity is what let the 2026-07-29 convoy logs be read as a
  // one-way channel walk-off defect for four turns; the records were correct
  // and complete, they just could not answer "why did you leave". aux is now
  // 0x00 for a cold-boot walk and 0xE1 for a spill walk, on BOTH the entry
  // (backhaul listen) and exit (picked rung) records so the pair agrees.
  // 0xE1 chosen clear of the LOG_STATE aux codes already in use (0xB4 relay
  // state, 0xF1 hard-full latch). No LogRec layout change: aux is an existing
  // field that was carrying a constant zero here.
  const uint8_t spillOrigin = (knownFullMHz > 0.0f) ? 0xE1 : 0x00;
  int16_t bst = radioApplyDiscoveryProfile();
  if (bst == RADIOLIB_ERR_NONE) bst = radio.setFrequency(BACKHAUL_FREQ_MHZ);
  delay(200);  // LR1121 RX warm-up: PLL lock and calibration after frequency change
  if (bst == RADIOLIB_ERR_NONE) g_currentFreqMHz = BACKHAUL_FREQ_MHZ;
  femRx();
  { int16_t armSt = lsmRxArm();
    if (armSt != RADIOLIB_ERR_NONE) radioFaultNote(12, armSt); }
  logRec(LOG_STATE, NODE_ID, g_role, spillOrigin, 0, 0, (uint32_t)lround(BACKHAUL_FREQ_MHZ * 1000000.0));
  if (!serQuiet()) Serial.printf("backhaul listen %ums on %.1f, then ladder walk from %.1f MHz\n",
                (unsigned)backhaulListenMs(coldBoot), (double)BACKHAUL_FREQ_MHZ, (double)LORA_FREQ_MHZ);
  uint32_t bt0 = millis();
  // backhaul advertise v1: parse during the listen window. On a valid 'B'
  // beacon (CRC good, bhver match) mark the advertised working channel's rung
  // heard, and joinable when not flagged full. If nothing is heard, fall
  // through to channel A exactly as before.
  // v7.19.0 brick3: SPILL. Gather per-ladder-rung status during the listen
  // window, then JOIN the first channel with room walking A upward. If an
  // empty rung (no sphere heard) is reached before any joinable one, tune
  // there and the vacuum election makes this node that rung's TK (spawn).
  // Reaching an empty rung means every lower rung was flagged full, which is
  // exactly the spill condition.
  bool  rungHeard[LSM_CHAN_LADDER_N]   = { false };
  bool  rungHasRoom[LSM_CHAN_LADDER_N] = { false };
  uint8_t rungProfile[LSM_CHAN_LADDER_N] = { 0 };
  bool  bhHeard = false;
  if (knownFullMHz > 0.0f) {
    // v7.19.2: firsthand seeding. We are here because THIS rung told us it is
    // full over its own schedule beacon, which is fresher and more reliable
    // than the backhaul advert. Mark it heard with no room before listening.
    for (int i=0;i<LSM_CHAN_LADDER_N;i++){
      if (knownFullMHz > LSM_CHAN_LADDER[i]-0.25f && knownFullMHz < LSM_CHAN_LADDER[i]+0.25f){
        rungHeard[i] = true;   // rungHasRoom[i] stays false: it just locked us out
        break;
      }
    }
  }
  const uint32_t bhWinMs = backhaulListenMs(coldBoot);   // v7.28.26: one guaranteed advert attempt at any frame length up to the ceiling
  while (millis() - bt0 < bhWinMs) {
    if (g_loraIrq) {
      g_loraIrq = false;
      uint8_t rb[128];
      size_t rn = securePacketLength();
      if (rn == sizeof(BackhaulBeacon) && secureRead(rb, rn) == RADIOLIB_ERR_NONE) {
        BackhaulBeacon* bb = (BackhaulBeacon*)rb;
        if (bb->magic == BACKHAUL_BEACON_MAGIC && bb->bhver == BACKHAUL_BEACON_VER
            && bb->tkId == g_secureRxSender
            && lsm_dual_phy::valid(bb->phyProfile)
            && bb->crc == crc8(rb, sizeof(BackhaulBeacon)-1) && !ksDenied(bb->tkId)) {   // v7.28.59: a revoked keeper's rung does not exist
          for (int i=0;i<LSM_CHAN_LADDER_N;i++){
            if (bb->workingMHz > LSM_CHAN_LADDER[i]-0.25f && bb->workingMHz < LSM_CHAN_LADDER[i]+0.25f){
              rungHeard[i] = true; bhHeard = true;
              rungProfile[i] = bb->phyProfile;
              if (!(bb->bhFlags & 0x01)) rungHasRoom[i] = true;   // not flagged full -> joinable
              break;
            }
          }
        }
      }
      femRx();
#if LSM_RX_STAY
      // v7.30.5: secureRead/readData already clears the completed IRQ and the
      // SX1262 remains in continuous receive. Reissuing startReceive here was
      // the deterministic first -705 on every board at ~8.3 s of cold discovery.
      // Match radioPoll's proven continuous-RX path: only ensure DIO1 is low.
      // readData has already cleared the completed IRQ. The radio remains in
      // continuous RX; issuing either clearIrq or startReceive here merely
      // performs a second command against an already-completed event.
#else
      { int16_t armSt = lsmRxArm();
        if (armSt != RADIOLIB_ERR_NONE) radioFaultNote(13, armSt); }
#endif
    }
    delay(2);
  }
  float bhPickMHz = LSM_CHAN_LADDER[0];   // default: channel A
  bool  bhSpawn   = true;                 // default: nothing joinable heard -> become a TK
  uint8_t bhPickProfile = lsm_dual_phy::idFor(LORA_SF, LSM_ACTIVE_BW);
  for (int i=0;i<LSM_CHAN_LADDER_N;i++){
    if (rungHasRoom[i]) { bhPickMHz = LSM_CHAN_LADDER[i]; bhPickProfile = rungProfile[i]; bhSpawn = false; break; }  // join first sphere with room
    if (!rungHeard[i])  { bhPickMHz = LSM_CHAN_LADDER[i]; bhSpawn = true;  break; }  // spawn on first empty rung
    // rung flagged full -> walk up to the next ladder channel
  }
  // v7.30.8: both TX-capable trial boards return -705 from standby here while
  // BUSY is LOW. The subsequent hard-recovery path (begin + config + profile
  // + frequency + arm) succeeds immediately and receives normally, proving a
  // stale SX1262 command state at the end of discovery rather than a stuck PA
  // or BUSY wire. Make that clean reset the boundary itself instead of first
  // entering a known fault and waiting one house tick to recover.
  int16_t ast = lsmRadioBegin();
  if (ast == RADIOLIB_ERR_NONE) ast = radioConfig();
  if (ast == RADIOLIB_ERR_NONE) ast = radioApplyWorkingProfile(bhPickProfile);
  if (ast == RADIOLIB_ERR_NONE) ast = radio.setFrequency(bhPickMHz);
  if (ast != RADIOLIB_ERR_NONE) radioFaultNote(18, ast);
  if (ast == RADIOLIB_ERR_NONE) g_currentFreqMHz = bhPickMHz;
  if (!serQuiet()) Serial.printf("backhaul %s: %s %.1f MHz\n", bhHeard ? "spheres heard" : "silent", bhSpawn ? "spawn on" : "join", (double)bhPickMHz);
  lsmIrqAttach();
  femRx(); g_loraIrq = false;
  { int16_t armSt = (ast == RADIOLIB_ERR_NONE) ? lsmRxArm() : ast;
    if (armSt != RADIOLIB_ERR_NONE) radioFaultNote(14, armSt);
    else g_lastRxMs = millis(); }   // v7.30.4: the 30 s watchdog starts when working-channel listening starts, not at MCU boot before the long discovery walk
  // v7.19.2: log the PICKED channel. The old block logged LORA_FREQ_MHZ here
  // unconditionally, so the flash log claimed 924.0 even when the walk picked
  // a lower rung. On the spill bench the frequency provenance of this record
  // is the whole point.
  logRec(LOG_STATE, NODE_ID, g_role, spillOrigin, 0, 0, (uint32_t)lround((double)bhPickMHz * 1000000.0));
  // v7.19.2: arrive on the picked rung in true cold state so the normal
  // machinery takes over from here: adopt the TK heard on this rung, or
  // vacuum-elect after TK_COLD_LISTEN_MS on an empty one. Every value below
  // is already 0/false on a real cold boot, so boot behavior is unchanged.
  // v7.28.58: TK-side roster, peer table and stand-down stamp are WIPED at the
  // bottom of this block (see the zero-roster re-walk comment there). The
  // 2026-07-28 decision to keep them across the walk is reversed; its own
  // comment said wipe later if the bench shows it hurts, and it did.
  if (bhSpawn && !coldBoot) {
    // v7.28.57: the commit is honoured ONLY on a dead-TK re-walk or a full-lockout
    // spill, never on a first boot. Those two paths have already listened on the
    // working channel; a first boot has not, so on a cold boot one missed backhaul
    // advert (the bench case in the v7.28.26 note: node02 landed at 16 s and was
    // keeper 1.2 s later while node01 was advertising) became an instant rival
    // keeper. A cold-boot spawn now falls through to the plain TK_COLD_LISTEN_MS
    // working-channel listen below and vacuum-elects only if that stays silent.
    // v7.28.10: the walk proved an empty rung. Commit that proof instead of
    // discarding it: set the election clock already-satisfied so the ordinary
    // vacuum predicate elects on the very next pass, one walk, rather than
    // restarting the 12 s cold listen that livelocks under a mass resignation.
    // g_lastTkHeardMs stays 0 so the vacuum branch, not the failover branch, fires.
    uint32_t nowSp = millis();
    // v7.28.60 SPAWN LISTEN: not the whole clock. Leave SPAWN_LISTEN_MS of listening
    // ON THIS RUNG before the vacuum predicate can fire. The walk proved one backhaul
    // window silent, not that the rung is empty: on the 2026-09-13 cold boots node 11
    // missed 08's advert, landed on 924.0 and was keeper the same second, and 08
    // resigned with five members (06 did the same to 01 in the earlier boot). A beacon
    // heard in this window sets g_lastTkHeardMs, the vacuum branch cannot fire, and the
    // board joins that keeper or, if it is full, spills again with the rung excluded.
    uint32_t backSp = TK_COLD_LISTEN_MS + STAG_JITTER_MS + 1U - SPAWN_LISTEN_MS;
    g_electBootMs = (nowSp > backSp) ? (nowSp - backSp) : 1U;   // guard early-boot underflow
  } else {
    g_electBootMs = 0;   // join exit unchanged: arrive cold and adopt the rung's TK
  }
  g_lastTkHeardMs = 0;
  g_coldCommitSinceMs = 0;
  g_seqAdvMs = 0; g_seqHigh = 0; g_seqHighTk = 0;
  g_meshLease = {};   // v7.28.22: liveness state is per sphere, it does not follow the board to a new rung
  g_peerSeqAdvMs = 0; g_peerSeqHigh = 0; g_peerSeqTk = 0;   // v7.29.39: indirect liveness is per sphere too
  g_fullBlockedSinceMs = 0;
  g_sphereFull = false;
  g_anchorValid = false;
  // v7.19.3: also clear the scheduling IDENTITY carried from the sphere we
  // just left. Without this the board sits on the new rung still naming its
  // old TK (bench 2026-07-28: board 10 on 920.5 still showed TK 06 from 924).
  // These are the power-on defaults; a spill must arrive as blank as a cold
  // boot so it adopts the new rung's TK or vacuum-elects cleanly. Not merely
  // cosmetic: ctokService mints a pair token to g_tkId, so a stale id mints
  // to a board that is not on this channel.
  if (g_role == 3) logRec(LOG_STATE, NODE_ID, 3, 0xEE, 3, 0, 2);   // v7.28.101: resignation moved 0xEC -> 0xEE. reason 2 = ladder walk off the rung
  g_role          = 0;      // LISTEN; drop any TK/member role from the old rung
  g_tkId          = 0;      // no timekeeper known on the new rung yet
  g_hopsToCmd     = 255;    // hop distance unknown until a schedule is heard here
  g_relayRivalTkId = 0;     // forget the old rung's rival TK pointer
  g_lastSchedMs   = 0;      // no schedule heard on the new rung yet
  g_framesSilent  = 0;
  g_sphereCount   = 0;
  g_curSchedSeq   = 0;
  g_hardFull      = false;  // v7.19.4: the TK-side latch does not follow the board to a new rung
  // v7.28.58: ZERO-ROSTER RE-WALK, per Stuart 2026-09-13. Any board that goes to
  // the backhaul and walks the ladder arrives with nothing from the old sphere:
  // roster zeroed, peer table wiped, stand-down stamp cleared so ROSTER_KEEP_MS
  // cannot carry a recent roster along as resumingRecent, and seedRosterFromPeers
  // has nothing to draw on. Unconditional on role and on the rung picked, the
  // same rung included; the board relearns every member from a real join.
  // Cause, seven-board v7.28.57 capture 2026-09-13: node 02 spilled from a full
  // 924.0, spawned 920.5, and seedRosterFromPeers filled its roster with the five
  // boards it had heard on 924.0 inside PEER_SEED_FRESH_MS, latched hard-full at
  // the seed (LOG_STATE 0xF1 data 2), and its first advert said full, so 01 and 04
  // walked past an empty rung to 917.0 and 04 did the same there with a roster it
  // had kept as resumingRecent. Each spill burned a rung and every rung stayed
  // falsely full until the ghosts aged out at AIR_TIMEOUT_MS. The keeper's
  // advertise errand (bhTailErrand) hops to 927.5 and straight home without
  // passing through this function, so a backhaul broadcast never wipes.
  memset(g_peers, 0, sizeof(g_peers));
  g_peersHeard    = 0;      // refreshed from peerCount() at the next tick anyway
  g_rosterN       = 0;
  g_lastTkStandDownMs = 0;
}

void setup() {
  // Must precede every application attachment; never replace an unknown owner.
  g_irqPolicyInstall=gpio_install_isr_service(ESP_INTR_FLAG_IRAM);
  g_irqPolicyVerified=irqpolicy::verified(CONFIG_ARDUINO_ISR_IRAM==1,g_irqPolicyInstall);
  g_exportSerialMutex=xSemaphoreCreateRecursiveMutexStatic(&g_exportSerialMutexStorage);
  g_bleNotifyOwner.store(xTaskGetCurrentTaskHandle(),std::memory_order_release);
  snprintf(BADGE_NUM, sizeof(BADGE_NUM), "%02u", (unsigned)NODE_ID); // ctok 2026-07-21 identity fix: badge label from NODE_ID
  Serial.begin(115200);
  delay(300);
  Serial.println();
  Serial.println("LSMESH badge firmware starting");
  irqPolicyPrint();
  if(!g_irqPolicyVerified)return;

  // Coming back from soft power off the wake cause is EXT0 and the gpio
  // holds are still latched. Require a real hold on USER so a pocket bump
  // does not boot the badge. The log wipe path stays a cold boot rule.
  bool wokeFromOff = (esp_sleep_get_wakeup_cause() == ESP_SLEEP_WAKEUP_EXT0);
  gpio_deep_sleep_hold_dis();
  if (PIN_VEXT >= 0) gpio_hold_dis((gpio_num_t)PIN_VEXT);
  gpio_hold_dis((gpio_num_t)PIN_TFT_BL);
  gpio_hold_dis((gpio_num_t)PIN_FEM_POWER);
  if (PIN_FEM_CSD >= 0) gpio_hold_dis((gpio_num_t)PIN_FEM_CSD);
  if (wokeFromOff) {
    pinMode(PIN_USER_BTN, INPUT_PULLUP);
    uint32_t t0 = millis();
    while (digitalRead(PIN_USER_BTN) == LOW && millis() - t0 < WAKE_HOLD_MS) delay(10);
    if (millis() - t0 < WAKE_HOLD_MS) {          // released early, stay off
      rtc_gpio_pullup_en((gpio_num_t)PIN_USER_BTN);
      rtc_gpio_pulldown_dis((gpio_num_t)PIN_USER_BTN);
      esp_sleep_enable_ext0_wakeup((gpio_num_t)PIN_USER_BTN, 0);
      while (digitalRead(PIN_USER_BTN) == LOW) delay(10);
      esp_deep_sleep_start();
    }
    while (digitalRead(PIN_USER_BTN) == LOW) delay(10);  // release before the
                                                         // wipe check or mark
                                                         // handler can see it
    Serial.println("woke from soft off, USER held");
  }

#if defined(LSM_BOARD_V4)
  if (PIN_VEXT >= 0) { pinMode(PIN_VEXT, OUTPUT); digitalWrite(PIN_VEXT, LOW); }    // v7.28.86: V4 VEXT GPIO36 is active LOW, drive LOW to power the OLED
#else
  if (PIN_VEXT >= 0) { pinMode(PIN_VEXT, OUTPUT); digitalWrite(PIN_VEXT, HIGH); }   // power the GNSS module (V2); no VEXT on the LilyGO
#endif
  delay(50);

  pinMode(PIN_USER_BTN, INPUT_PULLUP);

#ifdef LSM_BOARD_LILYGO
  Serial.println("no GNSS on this board; position fields stay invalid");   // v7.28.47: GNSS UART never opened, TinyGPSPlus never fed
  if (false) {
#else
  GNSS.begin(GNSS_BAUD, SERIAL_8N1, PIN_GNSS_RX, PIN_GNSS_TX);
  Serial.printf("GNSS UART up at %lu baud on RX=%d TX=%d\n",
                (unsigned long)GNSS_BAUD, PIN_GNSS_RX, PIN_GNSS_TX);
  {
#endif
  // v7.11.9: UC6580 rate config, sent fresh every boot rather than relying
  // on CFGSAVE persisting in the module's own flash. Checksum is optional
  // on Unicore input commands per the UFirebirdII protocol spec, an
  // unchecksummed command executes directly, so no checksum routine is
  // needed here. 200 is the message class for NMEA at UART1.
  delay(100);   // let the module finish its own boot before sending config
  GNSS.print("$CFGNAV,100,100,0\r\n");   // 10Hz positioning (100ms)
  GNSS.print("$CFGMSG,200,0,1\r\n");     // GGA at 10Hz
  GNSS.print("$CFGMSG,200,4,1\r\n");     // RMC at 10Hz
  GNSS.print("$CFGMSG,200,1,0\r\n");     // GLL off
  GNSS.print("$CFGMSG,200,2,0\r\n");     // GSA off
  GNSS.print("$CFGMSG,200,3,0\r\n");     // GSV off
  GNSS.print("$CFGMSG,200,5,0\r\n");     // VTG off
  }   // v7.28.47: end of the GNSS bring-up block (skipped on the LilyGO)
  Serial.println("UC6580 configured for 10Hz GGA+RMC only");

  setupTFT();
#ifdef LSM_BOARD_V4
  Serial.println("OLED up, SSD1306 128x64");
#else
  Serial.println("TFT up, ST7735 160x80");
#endif

  logInit();
#if LSM_ASYNC_FLUSH
  // v7.28.71: bring the core-0 writer up after the filesystem is mounted. If
  // anything here fails the board keeps running on the proven synchronous
  // path rather than half-initialized, and says so once on serial.
  if (g_fsOk) {
    g_fsAsync = fsWriterStart();
    Serial.printf("FS writer: %s (core %d)\n", g_fsAsync ? "async" : "SYNC FALLBACK", FS_TASK_CORE);
  }
#endif
  trimLoad();                          // v7.12.26 restore self-tuned slot lead from flash
  { // v7.8: no warm-start seed lock at boot, per Stu 2026-07-07. Origin
    // stays unset until the first real GPS fix. The warm-start seed
    // and its flash file were removed entirely in v7.28.4.
    originSet = false; lat0 = 0; lon0 = 0; altOriginSet = false; alt0 = 0;
    g_fusE = 0; g_fusN = 0; g_fusBaseE = 0; g_fusBaseN = 0; g_posValid = false; g_posConf = 0; g_haveRealFix = false;
    g_rawOrigin = false; g_posState = 0; g_posLogJumpM = 0;   // v7.28.64
    Serial.println("no warm-start seed, raw position reports until the first real GPS fix"); }
  // Preserve the flash journal across all resets, including USB and USER boot.
  // Erasure requires the explicit serial E or BLE opcode 02 command.
  esp_reset_reason_t resetReason = esp_reset_reason();
  Serial.printf("reset reason %d, flash journal retained; erase requires explicit E/opcode02\n",(int)resetReason);
  if (!wokeFromOff) logRec(LOG_PWR, NODE_ID, g_role, (uint8_t)(20 + resetReason), 0, 0, 0);   // v7.11.11: aux 20+N, N = esp_reset_reason_t
  // v7.10.1: boot record carries major, minor, and patch (3 bytes packed into
  // the 4 byte data field), local flash log only, no wire change.
  logRec(LOG_BOOT, NODE_ID, g_role, 0, 0, 0,
         ((uint32_t)FW_MAJOR << 16) | ((uint32_t)FW_MINOR << 8) | FW_PATCH);
  if (wokeFromOff) logRec(LOG_PWR, NODE_ID, g_role, 1, 0, 0, 0);  // aux 1 = wake

  ksBegin();
  if (!securemesh::begin((uint8_t)NODE_ID)) Serial.println("SEC: radio traffic blocked; provision fleet key over USB");
  femInit();   // Existing V2 hardware configuration retained.
  loraSPI.begin(PIN_LORA_SCK, PIN_LORA_MISO, PIN_LORA_MOSI, PIN_LORA_NSS);
  int16_t rst = -999;
  for (int attempt = 1; attempt <= 3; attempt++) {
    rst = lsmRadioBegin();   // v7.28.47: per-family begin (TCXO volts, LR1121 switch table)
    Serial.printf(LSM_RADIO_NAME " begin attempt %d: %d\n", attempt, (int)rst);
    if (rst == RADIOLIB_ERR_NONE) break;
    delay(250);
  }
  if (rst == RADIOLIB_ERR_NONE) rst = radioConfig();
  g_radioRc = rst;
  // v7.28.100: BOOT RADIO WITNESS, LOG_RF aux 15. Until now a failed begin or
  // radioConfig printed one serial line and nothing reached the flash log, so
  // a board with a dead radio was indistinguishable in a dump from a board
  // that simply never heard a keeper: same LISTEN role, same housekeeping
  // records, no radio records at all. That ambiguity is what made the
  // v7.28.99 bench session unreadable. e = the return code, n = 1 if armed,
  // data = the packed firmware version, so one record says which build's
  // radio path this was. aux 15 was the only free LOG_RF code.
  logRec(LOG_RF, NODE_ID, g_role, 15, (int16_t)rst,
         (int16_t)(rst == RADIOLIB_ERR_NONE ? 1 : 0),
         ((uint32_t)FW_MAJOR << 16) | ((uint32_t)FW_MINOR << 8) | FW_PATCH);
  if (rst == RADIOLIB_ERR_NONE) {
    // v7.10.6: bench log showed a clean 8+ second total reception gap on
    // board 5 right after cold boot, two clean beacons heard then silence
    // past ALONE_GRACE_MS, triggering an unnecessary self election. Give
    // the SX1262 a full second to settle before starting receive.
    rst = radioApplyDiscoveryProfile();
    if (rst == RADIOLIB_ERR_NONE) rst = radio.setFrequency(BACKHAUL_FREQ_MHZ);   // V7.31: fixed SF7 discovery backhaul.
  delay(200);  // LR1121 RX warm-up: PLL lock and calibration after frequency change
    if (rst == RADIOLIB_ERR_NONE) g_currentFreqMHz = BACKHAUL_FREQ_MHZ;    // radioConfig left the radio on channel A; retune to 927.5 before the first receive so cold boot and wake-from-off both come up on backhaul with no channel-A transient. spillWalkLadder's own setFrequency(927.5) is then a confirming no-op.
    delay(1000);
    lsmIrqAttach();
    if (rst == RADIOLIB_ERR_NONE) rst = lsmRxArm();
    femRx();
    g_radioOk = (rst == RADIOLIB_ERR_NONE);
    if (g_radioOk) radioElectionGateSet(true, millis());
    Serial.printf("backhaul wake 927.5, SF%u BW%.0f sync 0x%02X\n",
                  (unsigned)LORA_SF, LORA_BW_KHZ, (unsigned)LORA_SYNC);
    // v7.19.2: cold-boot backhaul listen + ladder walk, extracted verbatim to
    // spillWalkLadder so the on-channel full-lockout spill path reuses the
    // exact same walk. Passing 0 = no firsthand-full rung; byte-for-byte the
    // old boot behavior.
    if (securemesh::ready()) spillWalkLadder(0.0f, true);
  } else {
    Serial.println("Radio init FAILED, badge runs without mesh");
  }
  g_candSinceMs = millis();

#ifdef CRYSTAL_TOKEN
  pairtok::setBaselineSeconds(CTOK_LEARN_SECS);
  pairtok::begin((uint16_t)NODE_ID, ctokLog);
  Serial.println("CTOK,INIT,member-to-TK crystal token active (sub-GHz v0.1)");
#endif
  // Trust/revocation and envelope initialization occur before radio startup.
  setupBLE();
}

// v7.20.8: log flush phase gate. logFlush() is a blocking LittleFS append, so
// calling it at an arbitrary point in the frame lands the write mid-slot or
// right on the TK beacon. Drain once per frame in the quiet tail instead, the
// last DYN_JOIN_TAIL_US window where nothing is scheduled to speak to us. Works
// for the TK and members alike: both stamp g_frameAnchorUs once per frame (TK
// at beacon TX, members from the schedule ISR), so the same phase math and a
// latch keyed on that anchor give exactly one drain per frame either way. A
// LISTEN board with no live frame never enters the tail here and still drains
// on the houseTick 8s fallback, where an unphased flush is harmless since it
// holds no slot. The buffer-full force-flush in logRec stays as the safety net.
static uint64_t g_lastFlushAnchor = 0;
static uint64_t g_lastSecurityAnchor = 0;
static void securityTail() {
  if (!g_frameAnchorUs) { securemesh::service(); return; }
  if (g_role==3 && g_bhThisFrame) return;
  uint64_t now=(uint64_t)esp_timer_get_time();
  if(now<g_frameAnchorUs || !g_frameUs) return;
  uint64_t cycle=g_frameAnchorUs+((now-g_frameAnchorUs)/g_frameUs)*g_frameUs;
  if(cycle==g_lastSecurityAnchor) return;
  uint32_t off=(uint32_t)(now-cycle);
  // Service one reservation in every ordinary quiet tail. This must not be
  // gated by the last accepted schedule sequence: when the first packet past
  // a reservation is deliberately dropped, that sequence cannot advance
  // until this write succeeds. Prefer the active keeper so authority cannot
  // expire behind ordinary member reservations.
  if(g_frameUs>=DYN_JOIN_TAIL_US &&
     off>=g_frameUs-DYN_JOIN_TAIL_US && off<=g_frameUs-5000UL) {
    g_lastSecurityAnchor=cycle;
    bool wrote = g_tkId && g_tkId!=(uint8_t)NODE_ID
      ? securemesh::serviceSender(g_tkId) : false;
    if(!wrote) securemesh::service();
  }
}
void tailFlush() {
  if (!g_fsOk || g_logBufN == 0) return;                  // nothing to write
  if (g_frameAnchorUs == 0 || g_frameUs == 0) return;     // no frame yet
  if (g_frameAnchorUs == g_lastFlushAnchor) return;       // already drained this frame
  if (uiTailLogDeferred()) return; // UI owns this actual frame tail; logger gets the alternate frame.
  if (g_role == 3 && g_bhThisFrame) return;               // v7.20.9: errand frames, the backhaul piece owns the tail (doc 41); the 8 s houseTick fallback still drains
  uint64_t nowUs = (uint64_t)esp_timer_get_time();
  uint32_t offUs = (uint32_t)((nowUs - g_frameAnchorUs) % (uint64_t)g_frameUs);
  uint32_t tailStart = (g_frameUs > DYN_JOIN_TAIL_US) ? (g_frameUs - DYN_JOIN_TAIL_US) : 0;
  if (offUs >= tailStart) {
    g_flushWhy = 1;                                        // v7.28.33: tail caller
    logFlush();
    g_lastFlushAnchor = g_frameAnchorUs;
  }
}

// v7.28.47: PERIODIC AGC RESET. Two independent codebases found and fixed the
// same SX1262 fault this fleet has been chasing since v7.28.27. Meshtastic
// (src/mesh/SX126xInterface.cpp resetAGC, called from main.cpp loop every
// AGC_RESET_INTERVAL_MS = 60 s on every SX1262 node) and MeshCore
// (src/helpers/radiolib/SX126xReset.h sx126xResetAGC, shipped in v1.14.0 with
// Heltec Tracker V2 fixes) both do: warm sleep, wake to RC standby,
// Calibrate(0x7F) all blocks, wait BUSY, calibrateImage at the operating
// frequency, then reapply DIO2-as-switch, gain mode and the 0x8B5 patch.
// The Meshtastic comment is the point: a plain standby then startReceive
// cycle does NOT reset the AGC; only sleep powers down the analog front end.
// This file's v7.28.35 soft watchdog is standby plus re-arm, and its hard
// path (radio.begin, which would clear the AGC) fires only after 30 s of
// silence, which never happens at 45 percent delivery, so no capture since
// the AGC was ever reset within a session. The v7.28.28 finding, a -38 dBm
// signal damaged per receiver with CRC and header errors independent of
// timing, slot and load, is what a stuck front-end gain looks like.
// SCHEDULING: once per AGC_RESET_INTERVAL_MS, in the frame's quiet tail
// (same window tailFlush uses), only in a frame tailFlush did not use, never
// with a completion pending or a header latched, keeper skips errand frames.
// The whole sequence blocks about 10 to 20 ms against a 40 ms tail. The first
// reset lands 60 s after boot, so every capture carries its own one-minute
// pre-reset control. WITNESS: LOG_RF aux 16, one per reset: e = calibrate
// status (0 ok), n = 1 if BUSY did not clear within 50 ms else 0, data =
// blocked microseconds low 16 | reset count high 16. LOG_LOOP errand id 9.
#define AGC_RESET_INTERVAL_MS 60000UL
static uint32_t g_agcLastMs = 0;
static uint16_t g_agcCount  = 0;
static void lsmAgcReset() {
  int64_t t0 = esp_timer_get_time();
  int16_t st = RADIOLIB_ERR_NONE; int16_t busyTimeout = 0;
#ifdef LSM_BOARD_LILYGO
  radio.sleep();                                          // warm sleep, config retained
  radio.standby();                                        // NSS wake
  st = radio.calibrateAll();
  { uint32_t w0 = millis(); while (digitalRead(PIN_LORA_BUSY)) { if (millis() - w0 > 50) { busyTimeout = 1; break; } yield(); } }
  radio.calibrateImageRejection(900.0f, 930.0f);          // covers the 903 to 927.5 ladder plus backhaul
  radio.setRxBoostedGainMode(LSM_RX_BOOSTED != 0);
#else
  radio.sleep(true);                                      // warm sleep, config retained: powers down the analog front end
  radio.standby();                                        // RC standby, NSS wake
  st = radio.calibrateAll();                              // Calibrate(0x7F)
  delay(5);
  { uint32_t w0 = millis(); while (digitalRead(PIN_LORA_BUSY)) { if (millis() - w0 > 50) { busyTimeout = 1; break; } yield(); } }
  radio.calibrateImageRejection(900.0f, 930.0f);          // 0x7F defaults image cal to 902 to 928; redo over the whole 903 to 927.5 ladder plus backhaul
  radio.setDio2AsRfSwitch(true);
  radio.setRxBoostedGainMode(LSM_RX_BOOSTED != 0);
  femPatch8B5();                                          // calibration clears bit 0 of 0x8B5
#endif
  lsmIrqAttach();
  g_loraIrq = false;
  femRx();
  lsmRxArm();
  g_agcCount++;
  uint32_t blockedUs = (uint32_t)(esp_timer_get_time() - t0);
  logRec(LOG_RF, NODE_ID, g_role, 16, st, busyTimeout, (blockedUs & 0xFFFFu) | ((uint32_t)g_agcCount << 16));
}
static void agcTail() {
#ifdef LSM_AGC_OFF
  return;   // v7.28.52: periodic AGC reset disarmed, see FW_PATCH note
#endif
  if (!g_radioOk) return;
  if (g_frameAnchorUs == 0 || g_frameUs == 0) return;
  if (millis() - g_agcLastMs < AGC_RESET_INTERVAL_MS) return;
  if (g_role == 3 && g_bhThisFrame) return;               // errand frames: the backhaul piece owns the tail
  if (g_frameAnchorUs == g_lastFlushAnchor) return;       // tailFlush used this tail; take the next one
  uint64_t nowUs = (uint64_t)esp_timer_get_time();
  uint32_t offUs = (uint32_t)((nowUs - g_frameAnchorUs) % (uint64_t)g_frameUs);
  uint32_t tailStart = (g_frameUs > DYN_JOIN_TAIL_US) ? (g_frameUs - DYN_JOIN_TAIL_US) : 0;
  if (offUs < tailStart) return;
  if (g_loraIrq) return;                                  // a completion is waiting for service
  uint32_t irq = lsmIrqRead();
  if (irq & (RADIOLIB_SX126X_IRQ_PREAMBLE_DETECTED | RADIOLIB_SX126X_IRQ_HEADER_VALID)) return;   // mid-packet
  g_agcLastMs = millis();
  lsmAgcReset();
}

// v7.20.9: backhaul errand, split and tail-gated (doc 41). Runs from loop()
// like tailFlush, TK only, phase-gated into the tail region the frame compute
// budgeted for it, latched once per frame on the frame anchor. Piece 1 is the
// transmit visit (B beacon + O offset burst). Piece 2 is the 250 ms listen
// with hold-to-complete and the pull-gated G reply. If the loop misses the
// window, the next frame compute simply re-decides: an owed listen survives,
// a missed transmit re-arms off the untouched throttle. Self-healing.
static uint64_t g_lastErrandAnchor = 0;
static inline void bhListenArm() {
#if defined(RADIOLIB_SX126X_IRQ_PREAMBLE_DETECTED) && defined(RADIOLIB_SX126X_IRQ_HEADER_VALID) && defined(RADIOLIB_SX126X_IRQ_RX_DEFAULT) && defined(RADIOLIB_SX126X_RX_TIMEOUT_INF)
  // latch preamble/header in the IRQ register for the hold-to-complete poll;
  // DIO1 stays RX_DONE only so g_loraIrq semantics are untouched.
  // setDioIrqParams is protected in RadioLib 6.6.0 (compile-verified on the
  // bench 2026-08-24), so the latch rides startReceive's public irqFlags and
  // irqMask parameters, which program the same registers. The plain
  // startReceive at retune-back restores the default mask on channel A.
  radio.startReceive(RADIOLIB_SX126X_RX_TIMEOUT_INF,
                     (uint16_t)(RADIOLIB_SX126X_IRQ_RX_DEFAULT | RADIOLIB_SX126X_IRQ_PREAMBLE_DETECTED | RADIOLIB_SX126X_IRQ_HEADER_VALID),
                     (uint16_t)RADIOLIB_SX126X_IRQ_RX_DONE, 0);
#else
  radio.startReceive();
#endif
  g_loraIrq = false;
}
void bhTailErrand() {
  if (g_role != 3 || g_bhThisFrame == 0) return;
  if (g_frameAnchorUs == 0 || g_frameUs == 0) return;
  if (g_frameAnchorUs == g_lastErrandAnchor) return;        // once per frame
  uint64_t nowUs = (uint64_t)esp_timer_get_time();
  uint32_t offUs = (uint32_t)((nowUs - g_frameAnchorUs) % (uint64_t)g_frameUs);
  uint32_t errandStart = (g_frameUs > (DYN_JOIN_TAIL_US + g_bhTailExtUs)) ? (g_frameUs - DYN_JOIN_TAIL_US - g_bhTailExtUs) : 0;
  if (offUs < errandStart) return;                          // not in the tail yet
  g_lastErrandAnchor = g_frameAnchorUs;
  uint64_t anchErrT0 = (uint64_t)esp_timer_get_time();   // v7.21.1 witness
  const float workingFreqMHz = g_currentFreqMHz;
  const uint8_t workingProfileId = g_workingProfileId;
  int16_t bfs = radioApplyDiscoveryProfile();
  if (bfs == RADIOLIB_ERR_NONE) bfs = radio.setFrequency(BACKHAUL_FREQ_MHZ);
  delay(200);  // LR1121 RX warm-up: PLL lock and calibration after frequency change
  if (g_bhThisFrame == 1) {
    // ---- transmit piece: B beacon + O offset burst, then straight home ----
    BackhaulBeacon bb; memset(&bb, 0, sizeof(bb));
    bb.magic = BACKHAUL_BEACON_MAGIC; bb.bhver = BACKHAUL_BEACON_VER;
    bb.tkId = (uint8_t)NODE_ID;
    bb.phyProfile = workingProfileId;
    bb.sphereSize = (uint8_t)(g_rosterN > 255 ? 255 : g_rosterN);
    bb.workingMHz = workingFreqMHz;
    { uint32_t upMs = (g_tkSinceMs && millis() >= g_tkSinceMs) ? (millis() - g_tkSinceMs) : 0;
      uint32_t upS = upMs / 1000UL; bb.bhUptimeS = (uint16_t)(upS > 65535UL ? 65535UL : upS); }
    if (g_bhRefTkId == 0) { g_bhRefTkId = (uint8_t)NODE_ID; g_bhRefUptimeS = bb.bhUptimeS; }
    if (g_bhRefTkId == (uint8_t)NODE_ID) g_bhRefUptimeS = bb.bhUptimeS;
    { bool full = (g_fullSinceMs && millis()-g_fullSinceMs >= SPHERE_FULL_HOLD_MS) || g_hardFull;
      uint8_t bhf = 0;
      if (full) bhf |= 0x01;
      else if (g_belowLineSinceMs && millis()-g_belowLineSinceMs >= SPHERE_FULL_HOLD_MS) bhf |= 0x02;
      bb.bhFlags = bhf; }
    bb.bhTxUs = (uint32_t)esp_timer_get_time();
    bb.crc = crc8((uint8_t*)&bb, sizeof(bb)-1);
    femTx(); LSM_TX((uint8_t*)&bb, sizeof(bb)); femRx();
    g_loraIrq = false; lsmRxArm();
    { uint8_t ob[4 + 7*BH_OFFSET_MAX_N]; uint8_t on = 0;
      for (int i = 0; i < PEER_TABLE_SIZE && on < BH_OFFSET_MAX_N; i++) {
        if (!g_peers[i].id) continue;
        if (millis() - g_peers[i].lastMs > AIR_TIMEOUT_MS) continue;
        BhOffsetRec r; r.id = g_peers[i].id; r.eCm = g_peers[i].e; r.nCm = g_peers[i].n;
        r.conf = g_peers[i].conf; r.selfHops = g_peers[i].selfHops;
        memcpy(&ob[4 + 7*on], &r, 7); on++;
      }
      if (on) {
        ob[0] = BH_OFFSET_MAGIC; ob[1] = BH_TLM_VER; ob[2] = (uint8_t)NODE_ID; ob[3] = on;
        femTx(); LSM_TX(ob, (uint8_t)(4 + 7*on)); femRx();
        g_loraIrq = false; lsmRxArm();
        logRec(LOG_TX, NODE_ID, 9, on, 0, 0, (uint32_t)'O');   // offset-burst witness
      }
    }
    g_lastBackhaulAdvMs = millis();   // throttle anchors on the advertise, as before
    g_bhOwedListen = 1;               // next TK frame carries the listen piece
    int16_t brs = radioApplyWorkingProfile(workingProfileId);
    if (brs == RADIOLIB_ERR_NONE) brs = radio.setFrequency(workingFreqMHz);
    g_loraIrq = false; lsmRxArm();
    if (bfs != RADIOLIB_ERR_NONE || brs != RADIOLIB_ERR_NONE) logRec(LOG_RF, NODE_ID, g_role, 2, 0, 0, (uint32_t)(int32_t)(bfs ? bfs : brs));
    logRec(LOG_TX, NODE_ID, 9, bb.sphereSize, 0, 0, (uint32_t)lround((double)workingFreqMHz * 1000000.0));
    // v7.21.1 anchor witness, aux 2, transmit piece.
    g_anchErrandEndUs = (uint64_t)esp_timer_get_time();
    g_anchErrandBlkUs = (uint32_t)(g_anchErrandEndUs - anchErrT0);
    g_anchErrandKind  = 1;
    logRecRf(LOG_ANCH, NODE_ID, g_role, 2, 1, 0, g_anchErrandBlkUs, 0, 0, 0);
    return;
  }
  // ---- listen piece: bounded survey + reference election + pull-gated G ----
  g_bhOwedListen = 0;
  bhListenArm();
  logRec(LOG_TX, NODE_ID, 9, 0, 0, 0, (uint32_t)'L');   // v7.20.9: listen-piece witness for cadence scoring
  bool sawAnchorPull = false;
  { uint32_t lst = millis();
    uint32_t winMs = (uint32_t)BH_ELECT_LISTEN_MS;
    bool held = false; (void)held;
    while (millis() - lst < winMs) {
      if (g_loraIrq) {
        g_loraIrq = false;
        uint8_t rb[64]; size_t rn = securePacketLength();
        if (rn == sizeof(BhPullReq) && secureRead(rb, rn) == RADIOLIB_ERR_NONE) {
          BhPullReq* q = (BhPullReq*)rb;
          if (q->magic == BH_PULL_MAGIC && q->ver == BH_TLM_VER
              && (q->dstTk == 0 || q->dstTk == (uint8_t)NODE_ID)
              && q->crc == crc8(rb, sizeof(BhPullReq)-1)) sawAnchorPull = true;
        } else if (rn == sizeof(BackhaulBeacon) && secureRead(rb, rn) == RADIOLIB_ERR_NONE) {
          uint32_t rxUs = (uint32_t)esp_timer_get_time();
          BackhaulBeacon* pb = (BackhaulBeacon*)rb;
          if (pb->magic == BACKHAUL_BEACON_MAGIC && pb->bhver == BACKHAUL_BEACON_VER
              && pb->tkId == g_secureRxSender
              && lsm_dual_phy::valid(pb->phyProfile)
              && pb->crc == crc8(rb, sizeof(BackhaulBeacon)-1) && pb->tkId != (uint8_t)NODE_ID && !ksDenied(pb->tkId)) {   // v7.28.59
            bool peerWins = (pb->bhUptimeS > g_bhRefUptimeS) ||
                            (pb->bhUptimeS == g_bhRefUptimeS && pb->tkId < g_bhRefTkId);
            if (peerWins) {
              g_bhRefTkId = pb->tkId; g_bhRefUptimeS = pb->bhUptimeS;
              uint32_t air = (uint32_t)secureAirTime(sizeof(BackhaulBeacon));
              g_bhRefOffsetUs = (int32_t)(rxUs - pb->bhTxUs - air);   // coarse, ToF-uncompensated, diagnostic only
              g_bhRefHeardMs = millis();
              logRec(LOG_STATE, NODE_ID, g_role, 0xB4, pb->tkId, (int16_t)pb->bhUptimeS, (uint32_t)g_bhRefOffsetUs);
            } else if (pb->tkId == g_bhRefTkId) {
              g_bhRefHeardMs = millis();   // current reference still alive
            }
          }
        }
        femRx(); bhListenArm();
      }
#if defined(RADIOLIB_SX126X_IRQ_PREAMBLE_DETECTED) && defined(RADIOLIB_SX126X_IRQ_HEADER_VALID) && defined(RADIOLIB_SX126X_IRQ_RX_DEFAULT)
      // v7.20.9 hold-to-complete (doc 41): a reception in flight at window
      // expiry is held to the 70 ms ceiling instead of truncated. The TK can
      // afford to be late; it cannot afford to miss messages.
      if (!held && (millis() - lst) >= winMs - 4UL) {
        uint32_t irq = (uint32_t)lsmIrqRead();
        if (irq & (uint32_t)(RADIOLIB_SX126X_IRQ_PREAMBLE_DETECTED | RADIOLIB_SX126X_IRQ_HEADER_VALID)) {
          held = true; winMs = (uint32_t)BH_ELECT_LISTEN_MS + (uint32_t)BH_HOLD_CEIL_MS;
          logRec(LOG_STATE, NODE_ID, g_role, 0xB5, 0, 0, irq);   // hold witness
        }
      }
#endif
      delay(2);
    }
    // failover: a non-self reference gone quiet past TK_FAILOVER_MS -> revert to self
    if (g_bhRefTkId != (uint8_t)NODE_ID && g_bhRefHeardMs && millis()-g_bhRefHeardMs > TK_FAILOVER_MS) {
      uint32_t upMs = (g_tkSinceMs && millis() >= g_tkSinceMs) ? (millis() - g_tkSinceMs) : 0;
      uint32_t upS = upMs / 1000UL;
      g_bhRefTkId = (uint8_t)NODE_ID; g_bhRefUptimeS = (uint16_t)(upS > 65535UL ? 65535UL : upS); g_bhRefOffsetUs = 0;
      logRec(LOG_STATE, NODE_ID, g_role, 0xB4, (uint8_t)NODE_ID, 0, 0);
    }
  }
  if (sawAnchorPull) {
    uint8_t pick[ANCHOR_PULL_N]; uint8_t pn = 0;
    for (int i = 0; i < PEER_TABLE_SIZE; i++) {
      if (!g_peers[i].id || g_peers[i].seedMask != 0x07) continue;
      if (millis() - g_peers[i].lastMs > AIR_TIMEOUT_MS) continue;
      uint8_t j;
      if (pn < ANCHOR_PULL_N) { pick[pn] = (uint8_t)i; j = pn; pn++; }
      else if (g_peers[i].conf > g_peers[pick[ANCHOR_PULL_N-1]].conf) { pick[ANCHOR_PULL_N-1] = (uint8_t)i; j = ANCHOR_PULL_N-1; }
      else continue;
      while (j > 0 && g_peers[pick[j]].conf > g_peers[pick[j-1]].conf) {
        uint8_t t = pick[j]; pick[j] = pick[j-1]; pick[j-1] = t; j--;
      }
    }
    if (pn) {
      uint8_t gb[4 + 12*ANCHOR_PULL_N];
      gb[0] = BH_ANCHOR_MAGIC; gb[1] = BH_TLM_VER; gb[2] = (uint8_t)NODE_ID; gb[3] = pn;
      for (uint8_t k = 0; k < pn; k++) {
        BhAnchorRec a; Peer* p = &g_peers[pick[k]];
        a.id = p->id; a.latI = p->seedLatI; a.lonI = p->seedLonI; a.altDm = p->seedAltDm; a.conf = p->conf;
        memcpy(&gb[4 + 12*k], &a, 12);
      }
      femTx(); LSM_TX(gb, (uint8_t)(4 + 12*pn)); femRx();
      g_loraIrq = false; lsmRxArm();
      logRec(LOG_TX, NODE_ID, 9, pn, 0, 0, (uint32_t)'G');   // anchor-reply witness
    }
  }
  int16_t brs = radioApplyWorkingProfile(workingProfileId);
  if (brs == RADIOLIB_ERR_NONE) brs = radio.setFrequency(workingFreqMHz);
  g_loraIrq = false; lsmRxArm();
  if (bfs != RADIOLIB_ERR_NONE || brs != RADIOLIB_ERR_NONE) logRec(LOG_RF, NODE_ID, g_role, 2, 0, 0, (uint32_t)(int32_t)(bfs ? bfs : brs));
  // v7.21.1 anchor witness, aux 2, listen piece.
  g_anchErrandEndUs = (uint64_t)esp_timer_get_time();
  g_anchErrandBlkUs = (uint32_t)(g_anchErrandEndUs - anchErrT0);
  g_anchErrandKind  = 2;
  logRecRf(LOG_ANCH, NODE_ID, g_role, 2, 2, 0, g_anchErrandBlkUs, 0, 0, 0);
}

// v7.28.51: one repaint routine for the selected page (was the same if-chain
// at the tick and at the button). Counts paints for the LilyGO witness.
static void lsmTftRepaint() {
  if (g_screenIdx == 1) drawStatusInfo(); else if (g_screenIdx == 2) drawStatusFreq(); else if (g_screenIdx == 3) drawStatusTrim(); else if (g_screenIdx == 4) drawStatusTok(); else if (g_screenIdx == 5) drawStatusBase(); else if (g_screenIdx == 6) drawStatusBatt(); else drawStatus();
#if defined(LSM_BOARD_V4)
  tft.display();   // v7.28.87: SSD1306 is buffered, push the frame after each repaint
#endif
#ifdef LSM_BOARD_LILYGO
  g_tftDraws = g_tftDraws + 1;
#endif
}

#include "maintenance_ui_gate.h"
#include "maintenance_tail_share.h"
struct UiWorkState {
 uint32_t requested=0,executed=0,anchored=0,coalesced=0,deferred=0,overBudget=0,late=0,maxUs=0;
 uint64_t lastAnchor=0;bool pending=false,deferCounted=false,clear=false,bleNext=false;
 uint32_t displayJobs=0,bleJobs=0;
 uint32_t displayMaxUs=0,bleMaxUs=0,clearMaxUs=0,displayOver=0,bleOver=0,clearJobs=0;
 uint32_t stateWaits=0,writerWaits=0,windowWaits=0,turnWaits=0;
};
static UiWorkState g_uiWork{};
static maintenanceui::TailShare g_uiTailShare{};
static uint32_t uiTailKey(){
 const uint8_t seq=g_role==3?(uint8_t)g_frame:(uint8_t)g_seqHigh;
 return ((uint32_t)g_tkEpoch<<16)|((uint32_t)g_tkId<<8)|seq;
}
static bool uiTailLogDeferred(){return g_uiTailShare.deferFlush(uiTailKey(),(uint64_t)esp_timer_get_time());}
static void uiPrepareTail(){
 if(g_dumpState!=DUMP_IDLE||g_serQuiet||g_radioRecoverRequested||(g_role==3&&g_bhThisFrame))return;
 g_uiTailShare.prepare(uiTailKey(),(uint64_t)esp_timer_get_time(),g_frameAnchorUs,g_frameUs,DYN_JOIN_TAIL_US,g_uiWork.lastAnchor,g_uiWork.pending);
}

static void uiRequest(bool clear){
 g_uiWork.requested++;if(g_uiWork.pending)g_uiWork.coalesced++;
 else {g_uiWork.pending=true;g_uiWork.deferCounted=false;}
 g_uiWork.clear=g_uiWork.clear||clear;
}
static void uiStatusPrint(){
 Serial.printf("UI_TAIL node=%u reservations=%lu flush_defers=%lu writer_waits=%lu state_waits=%lu window_waits=%lu turn_waits=%lu reserved=%u used=%u\n",(unsigned)NODE_ID,(unsigned long)g_uiTailShare.reservations,(unsigned long)g_uiTailShare.flushDefers,(unsigned long)g_uiWork.writerWaits,(unsigned long)g_uiWork.stateWaits,(unsigned long)g_uiWork.windowWaits,(unsigned long)g_uiWork.turnWaits,(unsigned)g_uiTailShare.owns(uiTailKey(),(uint64_t)esp_timer_get_time()),(unsigned)g_uiTailShare.used);

 Serial.printf("UI_PHASE node=%u display_jobs=%lu ble_jobs=%lu next_ble=%u\n",(unsigned)NODE_ID,(unsigned long)g_uiWork.displayJobs,(unsigned long)g_uiWork.bleJobs,(unsigned)g_uiWork.bleNext);
 Serial.printf("UI_COMPONENT node=%u display_max_us=%lu ble_max_us=%lu clear_max_us=%lu display_over=%lu ble_over=%lu clear_jobs=%lu\n",(unsigned)NODE_ID,(unsigned long)g_uiWork.displayMaxUs,(unsigned long)g_uiWork.bleMaxUs,(unsigned long)g_uiWork.clearMaxUs,(unsigned long)g_uiWork.displayOver,(unsigned long)g_uiWork.bleOver,(unsigned long)g_uiWork.clearJobs);
 Serial.printf("UI_WORK node=%u requested=%lu executed=%lu anchored=%lu coalesced=%lu pending=%u deferred=%lu over_budget=%lu late=%lu max_us=%lu budget_us=35000 guard_us=3000\n",(unsigned)NODE_ID,(unsigned long)g_uiWork.requested,(unsigned long)g_uiWork.executed,(unsigned long)g_uiWork.anchored,(unsigned long)g_uiWork.coalesced,(unsigned)g_uiWork.pending,(unsigned long)g_uiWork.deferred,(unsigned long)g_uiWork.overBudget,(unsigned long)g_uiWork.late,(unsigned long)g_uiWork.maxUs);
}
static void uiDefer(){if(!g_uiWork.deferCounted){g_uiWork.deferred++;g_uiWork.deferCounted=true;}}
static void uiService(){
 if(!g_uiWork.pending)return;
 if(g_dumpState!=DUMP_IDLE||g_serQuiet||g_radioRecoverRequested||(g_role==3&&g_bhThisFrame)){g_uiWork.stateWaits++;uiDefer();return;}
#if LSM_ASYNC_FLUSH
 // Let submitted flash jobs finish first. Never hold or delay the writer/security service for UI.
 if(g_fsAsync&&g_fsQueued!=g_fsWritten){g_uiWork.writerWaits++;uiDefer();return;}
#endif
 const uint64_t start=(uint64_t)esp_timer_get_time(),anchor=g_frameAnchorUs;
 const uint32_t frame=g_frameUs;
 const auto allowed=maintenanceui::window(start,anchor,frame,DYN_JOIN_TAIL_US,g_uiWork.lastAnchor);
 if(allowed==maintenanceui::WAIT){g_uiWork.windowWaits++;uiDefer();return;}
 if(allowed==maintenanceui::QUIET_TAIL&&!g_uiTailShare.canRun(uiTailKey(),start)){g_uiWork.turnWaits++;uiDefer();return;}
 g_uiWork.pending=false;g_uiWork.deferCounted=false;g_uiWork.executed++;
 if(allowed==maintenanceui::QUIET_TAIL){g_uiWork.lastAnchor=anchor;g_uiWork.anchored++;g_uiTailShare.complete(uiTailKey(),start);}
 // Display (~28ms) and connected legacy BLE (~10ms) must not share a job.
 // Each is still limited to the same 35ms budget and one job per actual frame.
 const bool displayJob=g_uiWork.clear||!g_uiWork.bleNext;
 const bool didClear=g_uiWork.clear;
 if(displayJob){
 if(g_uiWork.clear){
#ifdef LSM_BOARD_LILYGO
  lsmTftReinit();
#else
  tft.fillScreen(ST77XX_BLACK);
#endif
  g_uiWork.clear=false;
 }
    lsmTftRepaint();
#ifdef LSM_BOARD_LILYGO
    // v7.28.51: glass witness. If this line keeps counting while the panel
    // stays frozen, the ESP32 is drawing and the panel is not listening.
    if(false && !serQuiet())Serial.printf("tft page %u draws %lu reinits %lu\n", (unsigned)g_screenIdx, (unsigned long)g_tftDraws, (unsigned long)g_tftReinits);
#if defined(LSM_TFT_REINIT_S) && (LSM_TFT_REINIT_S > 0)
    { static uint32_t lastReinit = 0;
      if (millis() - lastReinit >= (uint32_t)LSM_TFT_REINIT_S * 1000UL) { lastReinit = millis(); lsmTftReinit(); lsmTftRepaint(); } }
#endif
#endif
  g_uiWork.displayJobs++;g_uiWork.bleNext=true;
 }else{
    sendDiagnostics();
    sendPosition();
    { static uint32_t lastSelfSeed = 0;   // v7.28.75: own seed to the paired dashboard every 10 s, any role, covers reconnects and timekeepers
      if (g_haveRealFix && g_connected && millis() - lastSelfSeed >= BLE_SELF_SEED_MS){ lastSelfSeed = millis(); queueSelfSeedBle(); } }
    flushPendingSeeds();          // v7.2 fix: drain queued seeds on the safe BLE cadence
#if IS_COMMAND_CENTER
    sendPeerPositions(start+maintenanceui::BUDGET_US-3000UL);
#endif
  g_uiWork.bleJobs++;g_uiWork.bleNext=false;
 }
#if defined(LSM_PERIODIC_CONSOLE) && LSM_PERIODIC_CONSOLE
    if (gps.location.isValid()) {
      int16_t e = 0, n = 0;
      if (originSet) offsetCm(gps.location.lat(), gps.location.lng(), e, n);
      if (!serQuiet()) Serial.printf("fix lat=%.6f lon=%.6f sats=%lu hdop=%.1f east_cm=%d north_cm=%d ble=%s\n",
                    gps.location.lat(), gps.location.lng(),
                    (unsigned long)gps.satellites.value(), gps.hdop.hdop(),
                    e, n, g_connected ? "yes" : "no");
    } else {
      if (!serQuiet()) Serial.printf("acquiring fix, chars=%lu sats=%lu nmea ok=%u bad=%u cut=%u ble=%s\n",
                    (unsigned long)gps.charsProcessed(),
                    (unsigned long)gps.satellites.value(),
                    (unsigned)g_nmShowPass, (unsigned)g_nmShowFail, (unsigned)g_nmShowTrunc,
                    g_connected ? "yes" : "no");

    // v7.20.23: one sample of a failing sentence, slowly. The counters above
    // say how often it breaks; this says how. Rate limited to one line every
    // 30 s so it cannot flood the port, and serQuiet gated like every other
    // recurring print so it can never land inside a dump payload.
    { static uint32_t lastBadPrintMs = 0;
      if (g_nmHaveBad && !serQuiet() && millis() - lastBadPrintMs >= 30000) {
        lastBadPrintMs = millis();
        Serial.printf("nmea bad sentence: %s\n", g_nmLastBad);
        g_nmHaveBad = false;
      }
    }
    }

#endif // Optional console diagnostics are outside the qualified configuration.
 const uint64_t finish=(uint64_t)esp_timer_get_time();
 const uint32_t elapsed=(uint32_t)(finish-start);
 if(allowed==maintenanceui::QUIET_TAIL&&elapsed>g_uiWork.maxUs)g_uiWork.maxUs=elapsed;
 const bool over=allowed==maintenanceui::QUIET_TAIL&&elapsed>maintenanceui::BUDGET_US;
 const bool late=allowed==maintenanceui::QUIET_TAIL&&finish>anchor+frame-maintenanceui::END_GUARD_US;
 if(allowed==maintenanceui::QUIET_TAIL){
  uint32_t &maximum=displayJob?g_uiWork.displayMaxUs:g_uiWork.bleMaxUs;
  if(elapsed>maximum)maximum=elapsed;
  if(over){if(displayJob)g_uiWork.displayOver++;else g_uiWork.bleOver++;}
  if(didClear){g_uiWork.clearJobs++;if(elapsed>g_uiWork.clearMaxUs)g_uiWork.clearMaxUs=elapsed;}
 }
 if(over)g_uiWork.overBudget++;if(late)g_uiWork.late++;
 if(over||late)logRec(LOG_LOOP,NODE_ID,g_role,displayJob?(didClear?0xF3:0xF1):0xF2,(int16_t)(frame/1000UL),(int16_t)((start-anchor)/1000ULL),elapsed);
 if(over||late)logRec(LOG_LOOP,NODE_ID,g_role,0xF0,(int16_t)(frame/1000UL),(int16_t)((start-anchor)/1000ULL),elapsed);
 secNote(6,(int64_t)start);
}

void loop() {
  if(!g_irqPolicyVerified){irqPolicySerialOnly();delay(10);return;}
  if (!securemesh::ready()) { serialCmdPoll(); delay(10); return; }

#if LSM_SF5_RX_LEAN
  // SF5 receive-critical experiment: DIO1 is level-held while the SX1262 has
  // only one packet buffer.  Service a completed packet before GPS, BLE,
  // display, serial or filesystem work can delay the loop long enough for the
  // next short SF5 packet to overwrite it.  The normal radioPoll below remains
  // as the idle-path poll and is harmless after this clears the IRQ.
  if (g_loraIrq) radioPoll();
#endif
  securityTail();
  tputService(millis()); // ctok 2026-07-21 throughput sampler (self-throttles to 1 s)
  // feed the parser
  // v7.20.23: the same byte is graded on the way past, see nmeaTally
  { int64_t s0 = esp_timer_get_time();
#if LSM_SF5_RX_LEAN
    uint16_t gnssBudget = 32;  // bounded work; UART drains over several fast loop passes
    while (GNSS.available() && gnssBudget-- && !g_loraIrq) {
#else
    while (GNSS.available()) {
#endif
      uint8_t gc = (uint8_t)GNSS.read(); nmeaTally(gc); gps.encode((char)gc);
#if LSM_NMEA_ECHO
      if(!serQuiet())Serial.write(gc);   // Raw diagnostic must not splice a snapshot prefix.
#endif
    }
    secNote(1, s0); }   // v7.28.27

  // stall detector: if anything froze the loop, put the evidence in the log
  static uint32_t lastLoopMs = 0;
  uint32_t nowMs = millis();
  if (lastLoopMs != 0 && nowMs - lastLoopMs > 500)
    logRec(LOG_STALL, NODE_ID, g_role, 0, 0, 0, nowMs - lastLoopMs);
  lastLoopMs = nowMs;
#if LSM_DISPLAY_TIMEOUT
  displayTimeoutTick(nowMs);   // v7.29.13: node 11 role flag, restored from v7.29.6
#endif

  // v7.13.1: passive loop-period sample, us resolution. LOG_STALL above only
  // catches freezes over 500 ms; this catches the 1-20 ms excursions that a
  // 300 us trim band actually cares about. Observation only.
  { static uint64_t lastLoopUs = 0;
    uint64_t lpNow = (uint64_t)esp_timer_get_time();
    if (lastLoopUs != 0) {
      uint32_t dt = (uint32_t)(lpNow - lastLoopUs);
      if (dt > g_lpMaxUs) g_lpMaxUs = dt;
      g_lpSumUs += dt;
      g_lpCnt++;
    }
    lastLoopUs = lpNow; }

  { int64_t s0 = esp_timer_get_time(); radioPoll(); secNote(2, s0); }   // v7.28.27
#ifdef CRYSTAL_TOKEN
  ctokService(nowMs);
#endif
  serialCmdPoll();
  if(!g_telemetryUsbPrefixBusy.load(std::memory_order_acquire)){
    SerialOutputTry output;
    if(output.held){
      if(g_eraseReq){g_eraseReq=false;logErase();}
      if(g_dumpReq&&g_connected){g_dumpReq=false;logDumpBLE();}
    }
  }
  { int64_t s0 = esp_timer_get_time(); dumpService(); secNote(7, s0); }   // v7.20.17: one bounded slice per pass, never blocks a frame. v7.28.27: bracketed

  // v7.29.43: LISTEN-side transmit recovery. A board can keep receiving valid
  // schedules while its transmit/FEM state is wedged, so the RX watchdog has no
  // reason to fire. Join senders request this rebuild after a driver error or
  // after a full unanswered direct-attempt set. Run it at this loop-level safe
  // point, never from inside the join window itself.
  if (g_joinRadioRecoverReq && g_role == 0) {
    g_joinRadioRecoverReq = false;
    int16_t st = lsmRadioBegin();
    if (st == RADIOLIB_ERR_NONE) st = radioConfig();
    if (st == RADIOLIB_ERR_NONE) st = radio.setFrequency(g_currentFreqMHz);
    lsmIrqAttach();
    g_loraIrq = false;
    femRx();
    lsmRxArm();
    g_radioOk = (st == RADIOLIB_ERR_NONE);
    logRec(LOG_RF, NODE_ID, g_role, 21, (int16_t)g_joinGiveUp,
           (int16_t)g_joinAttemptCount, (uint32_t)(int32_t)st);
  }

  // v6.7: GPS-only fusion, hold last-known otherwise
  { uint32_t sats = gps.satellites.isValid() ? gps.satellites.value() : 0;
    g_satsNow = sats;
    // v7.28.68: location.isValid() latches true after the first fix and never clears, so a
    // module that lost lock keeps presenting the last coordinates. Gate on satellites used.
    bool haveFix = gps.location.isValid() && sats >= MIN_SATS_TX;
    // v7.28.64: quality, not validity, decides real versus raw
    bool highQual = haveFix;  // v7.28.67-fixed: simplified for testing - accept any valid fix regardless of sat count or HDOP
    posFusionUpdate(haveFix, highQual, haveFix?gps.location.lat():0.0, haveFix?gps.location.lng():0.0, millis(), sats);
    }   // v7.28.4: warm-start seed removed, no periodic flash write

  // v7.19.2: deferred spill. electShouldTakeOver requested a ladder re-walk
  // (sphere full past the hold while unrostered). Run it here, the same
  // top-level safe point class as the cold-boot walk, never inside the
  // election predicate: the listen blocks ~3.5 s. Pre-seed the current
  // channel as heard-and-full from firsthand knowledge.
  if (g_spillReq && g_radioOk) { int64_t s0 = esp_timer_get_time(); g_spillReq = false; float kf = g_spillFromFull ? g_currentFreqMHz : 0.0f; g_spillFromFull = false; spillWalkLadder(kf); secNote(8, s0); }   // v7.28.8: full-lockout spill passes the current (full) rung; the dead-TK re-walk passes 0.0f so it re-lists the current rung and stays on channel A

  // v7 frame engine: TK metronome schedule, member granted-slot discipline
  if (g_radioOk) { int64_t s0 = esp_timer_get_time(); frameEngine(); secNote(3, s0); }   // v7.28.27: bracketed
  telemetryKeeperTail();
  telemetryHostService();
  uiPrepareTail(); // Reserve eligible UI tails before background logger submission.
  { int64_t s0 = esp_timer_get_time(); tailFlush(); secNote(4, s0); }   // v7.20.8: drain the log in the frame's quiet tail, never mid-slot
  { int64_t s0 = esp_timer_get_time(); agcTail();   secNote(9, s0); }   // v7.28.47: periodic AGC reset in a quiet tail, errand id 9
  { int64_t s0 = esp_timer_get_time(); peelService(); secNote(10, s0); }   // v7.28.50: edge peel knock, errand id 10
  ksTailTxKeeper();   // v7.28.59: the keeper's own tail slot sits before the errand
  { int64_t s0 = esp_timer_get_time(); bhTailErrand(); secNote(5, s0); }   // v7.20.9: backhaul errand piece rides the tail it was budgeted at frame compute (doc 41)

  // one second tick: notify position and diagnostics, print status
  // v7.12.21: screen no longer auto-flips on a timer. A short USER tap
  // advances g_screenIdx (see the button handler below); the 1 s tick
  // redraws whatever screen is currently selected.
  static uint32_t lastTick = 0;
  bool housekeepingWindow = true;
#if LSM_SF5_RX_LEAN
  // Keep periodic BLE, display, temperature and diagnostic work out of the
  // scheduled packet region.  If no frame is established yet, allow it so
  // discovery and diagnostics remain usable.  Once anchored, the existing
  // quiet tail is the only safe place for this non-radio work.
  if (g_frameAnchorUs != 0 && g_frameUs != 0) {
    uint64_t hkNow = (uint64_t)esp_timer_get_time();
    uint32_t hkOff = (uint32_t)((hkNow - g_frameAnchorUs) % (uint64_t)g_frameUs);
    uint32_t hkTail = (g_frameUs > DYN_JOIN_TAIL_US) ? (g_frameUs - DYN_JOIN_TAIL_US) : 0;
    housekeepingWindow = hkOff >= hkTail && hkOff <= g_frameUs - 5000UL;
  }
#endif
  if (millis() - lastTick >= 1000 && housekeepingWindow) {
    lastTick = millis();
    int64_t tick0 = esp_timer_get_time();   // v7.28.27: the tick is errand 6
    g_peersHeard = peerCount();   // v6.5: refresh distinct peers heard in the last 5 s, was never wired
    battService();                // v7.20.4: refresh the BATT-page readout
    g_dieTempC = (int16_t)(temperatureRead() * 100.0f);   // v7.20.6: ESP32-S3 die temp, centi-deg
    logRec(LOG_HEALTH, NODE_ID, g_role, (uint8_t)LORA_DBM, g_dieTempC, (int16_t)g_battRaw, (uint32_t)g_battMv);   // v7.20.6: 1/s thermal+power baseline
    logRecRf(LOG_MANCH, NODE_ID, g_role, 5,
             (int16_t)(ESP.getFreeHeap() / 1024UL),
             (int16_t)(ESP.getMaxAllocHeap() / 1024UL),
             ctokStateWord(), 0, 0,
             (int16_t)(ESP.getMinFreeHeap() / 1024UL));   // v7.28.31: heap and token state, 1/s

    // v7.20.23: 1/s NMEA link health. aux = sentence type bitmask
    // (1 GGA, 2 RMC, 4 GSA, 8 GSV, 0x10 VTG, 0x20 GLL, 0x40 ZDA, 0x80 other),
    // e = sentences that passed checksum this window, n = sentences that
    // failed checksum, data = bytes in the low 16 bits, truncated sentence
    // count in bits 16 to 23, satellites in view in bits 24 to 31.
    { uint16_t nmP, nmF, nmT, nmB; uint8_t nmTy;
      gpsTallyTake(nmP, nmF, nmT, nmB, nmTy);
      g_nmShowPass = nmP; g_nmShowFail = nmF; g_nmShowTrunc = nmT;
      uint32_t sv = (uint32_t)gps.satellites.value(); if (sv > 255) sv = 255;
      uint32_t pk = (uint32_t)nmB
                  | ((uint32_t)(nmT > 255 ? 255 : nmT) << 16)
                  | (sv << 24);
      logRec(LOG_GPS, NODE_ID, g_role, nmTy,
             (int16_t)(nmP > 32767 ? 32767 : nmP),
             (int16_t)(nmF > 32767 ? 32767 : nmF), pk);
    }
    uiRequest(false); // Coalesce discretionary work; keep radio recovery/watchdog below at their original cadence.
    houseTick();
    secNote(6, tick0);   // v7.28.27: display draw, BLE and houseTick, bracketed as one errand
    // v7.28.27: receive-loss witnesses, once per second. Decode in FW_PATCH note.
    { uint32_t ov = g_irqOverrun;
      logRec(LOG_RF, NODE_ID, g_role, 8,
             (int16_t)(ov > 32767UL ? 32767 : ov),
             (int16_t)(g_rdFail > 32767UL ? 32767 : g_rdFail),
             (uint32_t)((g_crcFail & 0xFFFFUL) | ((uint32_t)g_irqLatOver << 16)));
      logRec(LOG_RF, NODE_ID, g_role, 9,
             (int16_t)((g_secMaxUs / 100UL) > 32767UL ? 32767 : (g_secMaxUs / 100UL)),   // v7.28.28: 100 us units, was raw us and pinned at the clamp every window
             (int16_t)(g_irqLatMaxUs > 32767UL ? 32767 : g_irqLatMaxUs),
             (uint32_t)(uint16_t)g_rdLastErr);
      g_irqLatMaxUs = 0; g_irqLatOver = 0; }
    // v7.28.72-symbvalid: aux 18 = receiver validation, once per second.
    // e = TIMEOUT services this second (validation fell through and the chip
    // left receive; expected 0 or near it on the B build, always 0 on the A
    // build), n = header aborts serviced without a re-arm this second,
    // data = cumulative timeouts. Static holds carry the previous cumulative
    // so the deltas need no extra globals.
    { static uint32_t lastTo = 0, lastAb = 0;
      uint32_t dTo = g_rxSymbTimeout - lastTo, dAb = g_abortNoRearm - lastAb;
      lastTo = g_rxSymbTimeout; lastAb = g_abortNoRearm;
      logRec(LOG_RF, NODE_ID, g_role, 18,
             (int16_t)(dTo > 32767UL ? 32767 : dTo),
             (int16_t)(dAb > 32767UL ? 32767 : dAb),
             g_rxSymbTimeout); }
    // V7.30.20 diagnostic only: raw chip read error categories, one record/sec.
    // aux24 e=CRC delta,n=header delta,data high16=other delta,low16=last error.
    { static uint32_t c=0,h=0,o=0;uint32_t dc=g_secChipCrc-c,dh=g_secChipHeader-h,doo=g_secChipOther-o;c=g_secChipCrc;h=g_secChipHeader;o=g_secChipOther;
      logRec(LOG_RF,NODE_ID,g_role,24,(int16_t)(dc>32767?32767:dc),(int16_t)(dh>32767?32767:dh),((doo>65535?65535:doo)<<16)|(uint16_t)g_secChipLastError); }
    // v7.28.77-stayonlisten: aux 19 = stay-on-listen execution witness, once per
    // second. e = clean receives serviced without a re-arm this second, n =
    // header aborts serviced without a re-arm this second, data = cumulative
    // clean no-rearm count. e at zero all run means the path never executed.
    { static uint32_t lastRs = 0, lastAb19 = 0;
      uint32_t dRs = g_rxNoRearm - lastRs, dAb = g_abortNoRearm - lastAb19;
      lastRs = g_rxNoRearm; lastAb19 = g_abortNoRearm;
      logRec(LOG_RF, NODE_ID, g_role, 19,
             (int16_t)(dRs > 32767UL ? 32767 : dRs),
             (int16_t)(dAb > 32767UL ? 32767 : dAb),
             g_rxNoRearm); }

    // v7.13.1: emit the passive loop-period window, then reset. Placed after
    // houseTick so the sample covers a full second of real duty including the
    // housekeeping burst itself.
    if (g_lpCnt) {
      uint32_t mean = (uint32_t)(g_lpSumUs / g_lpCnt);
      // v7.20.19 LOOP FIELD CHANGE, records before this patch decode differently.
      // data = max loop period in us (full uint32, was clamped into e at 32767
      // and read 497 of 497 railed on node 04, so the size of the excursion has
      // never once been reported), n = mean (unchanged, runs 24 to 61 us),
      // e = iteration count divided by 16 (observed up to 38157/s, which
      // overflows a signed 16 bit field outright; 16 iteration resolution on a
      // five figure number costs nothing).
      int16_t mn  = (mean > 32767u) ? 32767 : (int16_t)mean;
      int16_t cnt = (int16_t)((g_lpCnt >> 4) > 32767u ? 32767u : (g_lpCnt >> 4));
#ifndef LSM_LEAN_LOG   // v7.20.3: -D LSM_LEAN_LOG drops LOG_LOOP (frees ~18% of the log budget)
      logRec(LOG_LOOP, NODE_ID, g_role, g_secMaxId, cnt, mn, g_lpMaxUs);   // v7.28.27: aux = id of the longest errand this window (was 0)
#endif
      g_lpMaxUs = 0; g_lpSumUs = 0; g_lpCnt = 0;
      g_secMaxUs = 0; g_secMaxId = 0;   // v7.28.27
    }

  }

  // USER button. v7.12.21: a short tap advances the screen on release.
  // Holding for POWEROFF_HOLD_MS soft powers off. The action is on release
  // so a power-off hold does not also fire a screen advance.
  static uint32_t btnDownMs = 0;
  static uint32_t lastMark  = 0;
  static bool     btnDown   = false;
  bool down = (digitalRead(PIN_USER_BTN) == LOW);
  if (down && !btnDown) { btnDown = true; btnDownMs = millis(); }
  if (down && btnDown && millis() - btnDownMs >= POWEROFF_HOLD_MS) {
    powerOff();                                   // never returns
  }
  if (!down && btnDown) {
    btnDown = false;
    uint32_t held = millis() - btnDownMs;
    if (held >= 30 && millis() - lastMark > 600) {
      lastMark = millis();
      // v7.12.21: short tap advances the screen (was a manual map mark)
      g_screenIdx = (uint8_t)((g_screenIdx + 1) % 7); // v7.13.0: +BASE bake page
      uiRequest(true); // Page clear/repaint also obeys the published quiet window.
    }
  }
  uiService();
}
