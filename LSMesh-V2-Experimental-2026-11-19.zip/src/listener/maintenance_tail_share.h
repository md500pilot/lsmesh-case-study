#pragma once
#include "maintenance_ui_gate.h"
namespace maintenanceui {
// Local fairness only; never changes the secured schedule or tail length.
// Sequence/authority identify a frame even if its received anchor is refined.
struct TailShare {
 uint32_t key=0,reservations=0,flushDefers=0;
 uint64_t until=0;
 bool initialized=false,nextUi=true,uiFrame=false,reserved=false,used=false,counted=false;
 constexpr void observe(uint32_t current){
  if(initialized&&key==current)return;
  key=current;initialized=true;uiFrame=nextUi;nextUi=!nextUi;
  reserved=false;used=false;counted=false;until=0;
 }
 constexpr bool prepare(uint32_t current,uint64_t now,uint64_t anchor,uint32_t frame,
                        uint32_t tail,uint64_t lastUiAnchor,bool pending){
  if(!anchor||!frame)return false;
  observe(current);
  if(uiFrame&&!used&&pending&&window(now,anchor,frame,tail,lastUiAnchor)==QUIET_TAIL){
   if(!reserved){reserved=true;reservations++;until=anchor+frame;}
  }
  return owns(current,now);
 }
 constexpr bool owns(uint32_t current,uint64_t now)const{return initialized&&key==current&&reserved&&now<until;}
 constexpr bool canRun(uint32_t current,uint64_t now)const{return owns(current,now)&&!used;}
 constexpr void complete(uint32_t current,uint64_t now){if(canRun(current,now))used=true;}
 constexpr bool deferFlush(uint32_t current,uint64_t now){
  if(!owns(current,now))return false;
  if(!counted){flushDefers++;counted=true;}
  return true;
 }
};
static_assert(sizeof(TailShare)<=64,"Tail fairness state must stay bounded");
}
