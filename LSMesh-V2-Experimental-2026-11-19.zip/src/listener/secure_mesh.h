#pragma once
#include <stddef.h>
#include <stdint.h>

// 16-byte authenticated header and full 16-byte GCM tag.
static constexpr size_t MESH_SEC_OVERHEAD=32;
static constexpr size_t MESH_SEC_MAX_PLAIN=255-MESH_SEC_OVERHEAD;
namespace securemesh {
struct EpochMetadata {
  uint8_t selfId; uint32_t bootEpoch, lastAuthenticated09Epoch;
  uint32_t rx09CurrentEpoch, rx09SavedEpoch, rx09DurableEpoch;
  bool rx09Loaded, rx09DurablePresent, rx09DurableValid;
  uint32_t ownDurableEpoch; bool ownDurableValid;
};
EpochMetadata epochMetadata(); // read-only public nonce epochs, no keys/data
struct OpenDiag09 {
  uint32_t headerInvalid, nonceInvalid, keyFail, authFail, storageLoadBad;
  uint32_t oldEpoch, oldSeq, reservationPending, accepted;
};
OpenDiag09 openDiag09(); // counters only; does not reset state or expose keys/data
bool begin(uint8_t self);
bool ready();
bool provision(const uint8_t key[32]); // physical USB provisioning, reboot required
bool seal(const uint8_t *plain,size_t len,uint8_t *wire,size_t &wireLen);
bool open(const uint8_t *wire,size_t len,uint8_t *plain,size_t &plainLen,uint8_t &sender);
uint32_t rejected();
uint32_t maxStoreUs();
void service(); // Persist one pending replay reservation in a scheduled idle window.
bool serviceSender(uint8_t sender); // True when this time-critical sender was persisted.
}
