#pragma once
#include <stdint.h>
namespace membercapacity {
constexpr uint32_t GAP_US=16000; // Operational candidate, not a worst-case latency bound.
constexpr uint32_t MAX_PLAIN_BYTES=35,MAX_SECURED_BYTES=67;
constexpr uint32_t slotUs(uint32_t conservativeAirUs){return ((conservativeAirUs+GAP_US+9U)/10U)*10U;}
constexpr uint32_t adoptUs(uint16_t units){return (uint32_t)units*10U;}
constexpr bool wireFits(uint32_t width){return width!=0&&width%10U==0&&width/10U<=65535U;}
constexpr uint16_t wireUnits(uint32_t width){return (uint16_t)(width/10U);}
}
