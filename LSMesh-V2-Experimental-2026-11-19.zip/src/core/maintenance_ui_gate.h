#pragma once
#include <stdint.h>
namespace maintenanceui {
enum Window:uint8_t { WAIT=0, BOOTSTRAP=1, QUIET_TAIL=2 };
constexpr uint32_t BUDGET_US=35000;
constexpr uint32_t END_GUARD_US=3000;
constexpr Window window(uint64_t now,uint64_t anchor,uint32_t frame,
                        uint32_t tail,uint64_t lastAnchor,
                        uint32_t budget=BUDGET_US,uint32_t guard=END_GUARD_US){
 if(!anchor||!frame)return BOOTSTRAP;
 if(now<anchor||frame<=tail||(uint64_t)budget+guard>tail||lastAnchor==anchor)return WAIT;
 const uint64_t off=now-anchor;
 if(off>=frame||off<frame-tail||(uint64_t)frame-off<(uint64_t)budget+guard)return WAIT;
 return QUIET_TAIL;
}
}
