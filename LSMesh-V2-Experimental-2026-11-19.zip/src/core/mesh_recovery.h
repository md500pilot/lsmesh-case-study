#pragma once
#include <stdint.h>

// Require two successive schedule values at a plausible frame cadence.
// Call only after the current keeper's sequence has stalled. Authentication
// and replay checks must precede this helper; duplicates never advance it.
struct MeshRecovery {
  uint8_t keeper=0, seq=0;
  uint32_t at=0;
  bool pending=false;
  bool observe(uint8_t k, uint8_t s, uint32_t now, uint32_t frameMs) {
    if (!frameMs || !k) return false;
    const uint32_t elapsed=now-at;
    const bool ok=pending && keeper==k && (uint8_t)(s-seq)==1 &&
      elapsed>=frameMs/2 && (uint64_t)elapsed<=(uint64_t)frameMs*3;
    if (pending && keeper==k && seq==s) return false;
    keeper=k; seq=s; at=now; pending=!ok;
    return ok;
  }
};
