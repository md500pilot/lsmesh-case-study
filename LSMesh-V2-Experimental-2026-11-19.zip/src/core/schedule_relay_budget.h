#pragma once
#include <stdint.h>
#include "member_capacity.h"

namespace schedulerelay {
// Reuse the qualified owned-slot operational reserve, in addition to the
// schedule jitter band. Wire 41 makes this geometry change explicit.
constexpr uint32_t LEGACY_GUARD_US=3000;
constexpr uint32_t PROCESS_RESERVE_US=membercapacity::GAP_US;
constexpr uint32_t overhead(bool extended) {
  return LEGACY_GUARD_US+(extended ? PROCESS_RESERVE_US : 0U);
}
constexpr uint32_t tier(uint32_t air, uint32_t jitter, bool extended) {
  return air+jitter+overhead(extended);
}
constexpr bool receiveInProgress(uint32_t irq, uint32_t startBits, uint32_t terminalBits) {
  return (irq&startBits)!=0 && (irq&terminalBits)==0;
}
constexpr uint64_t frameNeed(uint32_t keeperWidth, uint8_t tiers, uint32_t relayWidth,
                             uint32_t joinWidth, uint32_t slots, uint32_t memberWidth,
                             uint32_t replyWidth, uint32_t tails) {
  return (uint64_t)keeperWidth+(uint64_t)tiers*relayWidth+joinWidth+
         (uint64_t)slots*memberWidth+(uint64_t)tiers*replyWidth+tails;
}
}
