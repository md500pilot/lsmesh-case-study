#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
namespace telemetry {
constexpr uint8_t MAGIC='G', VERSION=1, KIND=0xFE;
enum Flag : uint8_t { ORIGIN=1, POSITION=2, ALTITUDE=4, FLOOR=8, HELD=16, AGE_SATURATED=32 };
enum Datum : uint8_t { UNKNOWN=0, RECEIVER_UNVERIFIED=1 };
// Exactly one legacy member-sized payload. Byte 2 is deliberately outside every
// legacy MemberPkt type, so old receivers cannot reinterpret it as a position.
#pragma pack(push,1)
struct Snapshot {
 uint8_t magic,version,kind,node,flags;
 uint32_t boot;
 uint16_t frame,sequence,ageMs;
 int16_t eastCm,northCm;
 int32_t originLatMicro,originLonMicro,altitudeCm;
 uint8_t datum;
 int8_t floor;
 uint8_t confidence,crc;
};
#pragma pack(pop)
static_assert(sizeof(Snapshot)==35,"Telemetry must fit the existing member slot");
static_assert(offsetof(Snapshot,kind)==2,"Legacy type rejection byte moved");
// Same trust boundary as existing authenticated/granted aggregates, narrowed
// to the source/relay pair explicitly named by the current secured schedule.
constexpr bool namedRelay(uint8_t source,uint8_t sender,uint8_t f1,uint8_t b1,uint8_t f2,uint8_t b2){
 return source&&sender&&source!=sender&&((source==f1&&sender==b1)||(source==f2&&sender==b2));
}
static_assert(namedRelay(9,12,9,12,0,0),"named relay accepted");
static_assert(!namedRelay(9,7,9,12,0,0),"wrong relay rejected");
static_assert(!namedRelay(9,9,9,9,0,0),"direct origin is not relayed");
static_assert(!namedRelay(0,12,0,12,0,0),"empty source rejected");
constexpr bool phaseMember(bool join,bool current,bool previous,bool sameAuthority,uint32_t age,uint32_t bound){
 return join?(sameAuthority&&previous&&age<=bound):current;
}
static_assert(phaseMember(true,false,true,true,3000,5000),"JOIN preserves previous authenticated DATA membership");
static_assert(!phaseMember(false,false,true,true,100,5000),"DATA removal takes effect immediately");
static_assert(!phaseMember(true,false,true,false,100,5000),"old keeper context rejected");
static_assert(!phaseMember(true,false,true,true,6000,5000),"expired JOIN cache rejected");
constexpr size_t AGG_MAX=2, AGG_BYTES=7+AGG_MAX*sizeof(Snapshot);
static_assert(AGG_BYTES<=91,"Telemetry aggregate exceeds the existing slot budget");
inline uint8_t crc8(const uint8_t* b,size_t n){uint8_t c=0;while(n--){c^=*b++;for(unsigned i=0;i<8;i++)c=(uint8_t)((c&0x80)?(c<<1)^0x07:c<<1);}return c;}
inline void seal(Snapshot& s){s.magic=MAGIC;s.version=VERSION;s.kind=KIND;s.crc=crc8((const uint8_t*)&s,sizeof(s)-1);}
inline bool valid(const Snapshot& s){
 if(s.magic!=MAGIC||s.version!=VERSION||s.kind!=KIND||s.node<1||s.node>254||!s.boot||s.confidence>63||(s.flags&0xC0)||s.crc!=crc8((const uint8_t*)&s,sizeof(s)-1))return false;
 if((s.flags&POSITION)&&!(s.flags&ORIGIN))return false;
 if((s.flags&ORIGIN)&&(s.originLatMicro < -90000000||s.originLatMicro > 90000000||s.originLonMicro < -180000000||s.originLonMicro > 180000000))return false;
 if((s.flags&ALTITUDE)&&s.datum!=RECEIVER_UNVERIFIED)return false;
 if(s.ageMs>5000&&(s.flags&(POSITION|ALTITUDE)))return false;
 if((s.flags&AGE_SATURATED)&&(s.flags&(POSITION|ALTITUDE)))return false;
 return true;
}
inline Snapshot aged(Snapshot s,uint32_t residenceMs){
 uint32_t age=(uint32_t)s.ageMs+residenceMs;
 if(age>=65535){s.ageMs=65535;s.flags|=AGE_SATURATED;s.flags&=(uint8_t)~(POSITION|ALTITUDE);}
 else{s.ageMs=(uint16_t)age;if(age>5000){s.flags|=HELD;s.flags&=(uint8_t)~(POSITION|ALTITUDE);}}
 seal(s);return s;
}
inline bool newerSequence(uint16_t candidate,uint16_t previous){return (int16_t)(candidate-previous)>0;}
// Only a directly authenticated origin may introduce a different boot. Relays
// may update the established boot, never roll it back using an old cache.
inline bool acceptable(const Snapshot& s,const Snapshot* previous,bool direct){
 if(!valid(s))return false;if(!previous)return true;
 if(s.boot!=previous->boot)return direct;
 return newerSequence(s.sequence,previous->sequence);
}
}
