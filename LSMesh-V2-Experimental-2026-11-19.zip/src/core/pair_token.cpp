// pair_token.cpp  -  implementation of the pairwise crystal token.
// UNVERIFIED. Not bench-compiled. Does not touch radio, wire, or election.
//
// Key derivation, the one design point that matters:
//
//   vecS = enrollmentVector(sender_baseline)   // 16 bytes, quantized crystal id
//   vecR = enrollmentVector(recip_baseline)    // 16 bytes
//   pairKey = SHA256( "KSPAIR" || vecS || vecR )
//   tag(seq) = HMAC_SHA256( pairKey, "KAIROSHIELD_PAIR_V1" || seq )  truncated 16
//
// vecS is built from the sender's ratio_mean, temp_mean and id. vecR from the
// recipient's. Both sides must agree on both vectors, so the recipient must hold
// its OWN real baseline (vecR) and know the sender's fingerprint (vecS). Drop
// either and the tag will not match. That is the mutual, crystal-bound gate.

#include "pair_token.h"
#include "mbedtls/sha256.h"
#include "mbedtls/md.h"
#include <Preferences.h>

extern "C" {
  #include "soc/rtc.h"     // rtc_clk_cal, rtc_cal_sel_t, RTC_CAL_RTC_MUX
}

#ifndef RC_CAL_SEL
#define RC_CAL_SEL RTC_CAL_RTC_MUX
#endif

namespace pairtok {

// ------------------------- config / state --------------------------------
static uint16_t s_nodeId         = 0;
static LogFn    s_log            = nullptr;
static double   s_tolN           = 4.0;
static uint32_t s_calCycles      = 1024;
static uint32_t s_samplePeriodMs = 1000;
static uint32_t s_baselineSecs   = 480;     // 8 minute bake-in, Stuart 2026-07-21

struct Baseline {
  uint16_t node_id;
  uint32_t learned_s;
  double   ratio_mean, allan_dev;
  float    temp_mean;
  uint32_t cal_cycles, magic;
};
static const uint32_t BASE_MAGIC = 0x4B415250;   // 'KARP'

static Baseline s_base;
static bool     s_haveBase   = false;
static bool     s_learning   = true;
static uint32_t s_lastSample = 0, s_startMs = 0;
static double   s_lastRatio  = 0; static float s_lastTemp = 0;

// learning accumulators
static double a_sum, a_prev, a_allanSum; static bool a_prevSet;
static uint32_t a_allanN; static float a_tsum; static uint32_t a_n;

static Preferences s_nvs;

// ---- whitelist of peer fingerprints ----
static const uint8_t MAX_PEERS_FP = 24;   // v7.28.59: was 8. The keeper must hold every roster member and every board hears the whole sphere; 14 boards plus headroom.
struct PeerFp { bool used; Fingerprint fp; };
static PeerFp s_peers[MAX_PEERS_FP];

// ------------------------- helpers ---------------------------------------
static void logline(const String& s) { if (s_log) s_log(String("PTOK,") + s); }

static double measureRcRatio() {
  uint32_t cal = rtc_clk_cal((rtc_cal_sel_t)RC_CAL_SEL, s_calCycles);
  return (double)cal / (double)(1 << 19);
}
static float measureTempC() { return temperatureRead(); }

static void sha256(const uint8_t* in, size_t n, uint8_t out[32]) { mbedtls_sha256(in, n, out, 0); }
static void hmac256(const uint8_t* key, size_t klen, const uint8_t* msg, size_t mlen, uint8_t out[32]) {
  const mbedtls_md_info_t* info = mbedtls_md_info_from_type(MBEDTLS_MD_SHA256);
  mbedtls_md_hmac(info, key, klen, msg, mlen, out);
}

// Quantization bucket for a given (ratio_mean, allan_dev). Same math the local
// build uses: half-window = tolN * allan, guarded away from zero.
static double windowHalf(double allan) { double w = s_tolN * allan; return w > 0 ? w : 1e-9; }

// Build a 16 byte enrollment vector from any (id, ratio_mean, allan, temp).
// This is the ONE function both sender and recipient must compute identically
// for a given board, so it takes explicit fields, not the local baseline.
static void enrollmentVectorFrom(uint16_t id, double ratio_mean, double allan, float temp_mean,
                                 uint8_t out[16]) {
  double bucket = windowHalf(allan);
  int64_t rbucket = (int64_t)llround(ratio_mean / bucket);
  int32_t tbucket = (int32_t)lround(temp_mean / 2.0);
  uint32_t id32 = id;
  memset(out, 0, 16);
  memcpy(out + 0,  &rbucket, 8);
  memcpy(out + 8,  &tbucket, 4);
  memcpy(out + 12, &id32,    4);
}

static void enrollmentVectorLocal(uint8_t out[16]) {
  enrollmentVectorFrom(s_base.node_id, s_base.ratio_mean, s_base.allan_dev, s_base.temp_mean, out);
}

// pairKey = SHA256("KSPAIR" || vecSender || vecRecipient)
static void pairKey(const uint8_t vecS[16], const uint8_t vecR[16], uint8_t key[32]) {
  uint8_t buf[6 + 16 + 16];
  memcpy(buf, "KSPAIR", 6);
  memcpy(buf + 6, vecS, 16);
  memcpy(buf + 22, vecR, 16);
  sha256(buf, sizeof(buf), key);
}

static const char* PAIR_PLAINTEXT = "KAIROSHIELD_PAIR_V1";
static void sealPair(const uint8_t key[32], uint32_t seq, uint8_t tag[32]) {
  uint8_t msg[19 + 4];
  memcpy(msg, PAIR_PLAINTEXT, 19);
  memcpy(msg + 19, &seq, 4);
  hmac256(key, 32, msg, sizeof(msg), tag);
}

// ---- CTOK_FLAP_PROBE, v7.14.1 --------------------------------------------
// Shadow quantizer for the planned baseline-derived key unwrap. DEFAULT OFF.
// Today's token is minted from the STORED baseline on both sides, so a live
// reading that wanders across a bucket edge costs nothing. The moment a
// wrapped secret is gated by the LIVE reading (baseline as key input, the
// derivation design), a bucket flap becomes a garbage key and a hard lockout.
// This probe measures that exact failure channel before any secret rides on
// it: every 1 Hz sample after the bake is quantized on the ENROLLED grid with
// the SAME math as enrollmentVectorFrom (llround(ratio / W), W = tolN * allan)
// and compared to the enrolled bucket. Output is ctokLog serial text only.
// Nothing on air, nothing in the 24-byte flash records, no protocol input.
//   PTOK,PROBE_INIT,...  once: W, B0, enrolled in-bucket offset, tolN
//   PTOK,FLAP,...        on any bucket transition, rate-limited to 5 s
//   PTOK,PROBE,...       every 30 s: counters and excursion extremes
// The enrolled offset ("off") is the number to watch: an enrollment landing
// near plus or minus 0.5 sits on a bucket edge and will flap on noise alone.
// off and the flap rate together size the helper data for the fuzzy-extractor
// step. This block compiles out entirely without -D CTOK_FLAP_PROBE.
#ifdef CTOK_FLAP_PROBE
static bool     p_init = false;
static int64_t  p_lastDR = 0;
static int32_t  p_lastDT = 0;
static uint32_t p_n = 0, p_outR = 0, p_outT = 0, p_flapR = 0, p_flapT = 0;
static double   p_eMin = 0, p_eMax = 0;
static uint32_t p_lastRepMs = 0, p_lastFlapLogMs = 0;

// ---- v7.14.2 overlapping multi-tau allan, OBSERVABILITY ONLY ------------
// Ring of the raw 1 Hz post-bake ratio samples, grouped UPWARD into
// tau = 1/2/4/8/16/32 s with the overlapping estimator. Faster informs
// slower, never the reverse: no extra rtc_clk_cal calls, so the ~7 ms
// per-sample blocking budget is unchanged at 1 Hz. Serial text only.
// The canonical 1 s allan_dev stored in s_base is untouched and remains
// the SOLE input to windowHalf and the enrolled grid: no bucket moves,
// no key moves, no re-enrollment. A production mint-rate change is a
// deliberate separate grid-rebuild step, explicitly not this release.
//   PTOK,TAU_INIT,... once: ring size and tau list
//   PTOK,TAU,...      every 30 s: n, a1/a2/a4/a8/a16/a32 in ratio units
//                     (na until 2m+1 samples exist), base = enrolled allan
// Reading the curve: falling with tau = white-noise limited, averaging
// helps; flat or rising = flicker/drift floor reached. The tau where the
// deviation bottoms out is the measured optimal mint cadence for the
// PQ interlock derivation design (IP note 2026-07-26).
#ifndef CTOK_TAU_BUFN
#define CTOK_TAU_BUFN 128
#endif
static const uint32_t Q_TAUS[] = { 1, 2, 4, 8, 16, 32 };
static const uint32_t Q_NTAU   = sizeof(Q_TAUS) / sizeof(Q_TAUS[0]);
static double   q_ring[CTOK_TAU_BUFN];
static double   q_pfx[CTOK_TAU_BUFN + 1];   // prefix-sum scratch, static not stack
static uint32_t q_head = 0, q_count = 0;
static uint32_t q_lastRepMs = 0;
static bool     q_init = false;

static void tauPush(double r) {
  q_ring[q_head] = r;
  q_head = (q_head + 1) % CTOK_TAU_BUFN;
  if (q_count < CTOK_TAU_BUFN) q_count++;
}

// Overlapping Allan deviation at tau = m * 1 s over the ring contents.
// sigma^2(m) = sum_j (S(j+m,m) - S(j,m))^2 / (2 m^2 (N - 2m + 1)),
// S(a,m) = sum of m consecutive samples starting at a, j = 0 .. N-2m.
// Returns -1 until the ring holds 2m+1 samples (>= 2 difference terms).
static double tauAllan(uint32_t m) {
  uint32_t N = q_count;
  if (N < 2 * m + 1) return -1.0;
  uint32_t start = (q_head + CTOK_TAU_BUFN - q_count) % CTOK_TAU_BUFN;
  q_pfx[0] = 0.0;
  for (uint32_t i = 0; i < N; i++)
    q_pfx[i + 1] = q_pfx[i] + q_ring[(start + i) % CTOK_TAU_BUFN];
  double acc = 0.0;
  uint32_t terms = N - 2 * m + 1;
  for (uint32_t j = 0; j < terms; j++) {
    double d = (q_pfx[j + 2 * m] - q_pfx[j + m]) - (q_pfx[j + m] - q_pfx[j]);
    acc += d * d;
  }
  double var = acc / (2.0 * (double)m * (double)m * (double)terms);
  return sqrt(var);
}

static void tauReport(uint32_t nowMs) {
  if (!q_init) {
    q_init = true;
    String s = String("TAU_INIT,bufN=") + String((unsigned long)CTOK_TAU_BUFN) + ",taus=";
    for (uint32_t k = 0; k < Q_NTAU; k++) {
      if (k) s += "/";
      s += String((unsigned long)Q_TAUS[k]);
    }
    logline(s);
  }
  if (nowMs - q_lastRepMs < 30000UL) return;
  q_lastRepMs = nowMs;
  String s = String("TAU,n=") + String((unsigned long)q_count);
  for (uint32_t k = 0; k < Q_NTAU; k++) {
    double a = tauAllan(Q_TAUS[k]);
    s += String(",a") + String((unsigned long)Q_TAUS[k]) + "=";
    s += (a < 0.0) ? String("na") : String(a, 12);
  }
  s += String(",base=") + String(s_base.allan_dev, 12);
  logline(s);
}

static void probeSample(uint32_t nowMs) {
  double  W  = windowHalf(s_base.allan_dev);      // live s_tolN tracked each call
  int64_t B0 = (int64_t)llround(s_base.ratio_mean / W);
  int64_t B  = (int64_t)llround(s_lastRatio      / W);
  int32_t T0 = (int32_t)lround(s_base.temp_mean / 2.0);
  int32_t T  = (int32_t)lround((double)s_lastTemp / 2.0);
  double  e  = s_lastRatio / W - (double)B0;      // live position vs enrolled bucket index
  int64_t dR = B - B0;
  int32_t dT = T - T0;
  if (!p_init) {
    p_init = true; p_lastDR = dR; p_lastDT = dT; p_eMin = e; p_eMax = e;
    double off = s_base.ratio_mean / W - (double)B0;   // enrolled offset inside its own bucket
    logline(String("PROBE_INIT,W=") + String(W, 12) + ",B0=" + String((double)B0, 0)
      + ",off=" + String(off, 4) + ",tolN=" + String(s_tolN, 2));
  }
  tauPush(s_lastRatio);
  tauReport(nowMs);
  p_n++;
  if (dR != 0) p_outR++;
  if (dT != 0) p_outT++;
  if (e < p_eMin) p_eMin = e;
  if (e > p_eMax) p_eMax = e;
  bool flR = (dR != p_lastDR), flT = (dT != p_lastDT);
  if (flR) p_flapR++;
  if (flT) p_flapT++;
  p_lastDR = dR; p_lastDT = dT;
  if ((flR || flT) && (nowMs - p_lastFlapLogMs >= 5000UL)) {
    p_lastFlapLogMs = nowMs;
    logline(String("FLAP,dR=") + String((long)dR) + ",dT=" + String((long)dT) + ",e=" + String(e, 4));
  }
  if (nowMs - p_lastRepMs >= 30000UL) {
    p_lastRepMs = nowMs;
    logline(String("PROBE,n=") + p_n + ",outR=" + p_outR + ",outT=" + p_outT
      + ",flapR=" + p_flapR + ",flapT=" + p_flapT + ",e=" + String(e, 4)
      + ",eMin=" + String(p_eMin, 4) + ",eMax=" + String(p_eMax, 4));
  }
}
#endif

// ---- v7.14.3 characterization logger, RAW STREAM ONLY -------------------
// Standalone build mode for the temperature-profiling run. When
// -D CTOK_CHAR_LOG is set it REPLACES the probe: no bake, no baseline,
// no bucketing, no judgement. Every 1 Hz sample it prints one raw
// (ratio, temp, t) triple over ctokLog and does nothing else. begin()
// deliberately does NOT load or learn a baseline in this mode, so
// haveBaseline() stays false and the pairtok token layer stays silent
// (no announce, no mint). The base LSMESH mesh still runs, so a solo
// board self-heats slightly as TK, but that heat is CAPTURED in the
// die temp logged every sample, so the ratio = f(temp) fit accounts
// for it. Drive the temperature span externally (chamber, fridge,
// ambient day/night). Fit ratio = f(temp) OFFLINE from the capture;
// that fit is the compensation coefficient temp-compensated
// enrollment needs. Serial
// text only, nothing on air, nothing in the flash log.
#if defined(CTOK_CHAR_LOG) && defined(CTOK_FLAP_PROBE)
#error "CTOK_CHAR_LOG and CTOK_FLAP_PROBE are mutually exclusive; build one mode."
#endif
#if defined(CTOK_CHAR_ENROLL) && (defined(CTOK_CHAR_LOG) || defined(CTOK_FLAP_PROBE))
#error "CTOK_CHAR_ENROLL is mutually exclusive with CTOK_CHAR_LOG and CTOK_FLAP_PROBE; build one mode."
#endif

// v7.14.4 shared 1 Hz CHAR data line, used by both the raw logger
// (CTOK_CHAR_LOG) and the bake-enroll-then-stream mode (CTOK_CHAR_ENROLL).
// Identical format in both modes so the same offline fit_char.py parses
// either capture. Counter is monotonic within a boot.
#if defined(CTOK_CHAR_LOG) || defined(CTOK_CHAR_ENROLL)
static uint32_t c_n = 0;
static void charLine(uint32_t nowMs) {
  c_n++;
  logline(String("CHAR,n=") + String((unsigned long)c_n)
    + ",t="     + String((unsigned long)nowMs)
    + ",ratio=" + String(s_lastRatio, 12)
    + ",temp="  + String((double)s_lastTemp, 4));
}
#endif
#ifdef CTOK_CHAR_LOG
static bool     c_init = false;
static void charSample(uint32_t nowMs) {
  if (!c_init) {
    c_init = true;
    logline(String("CHAR_INIT,node=") + s_nodeId
      + ",calCyc="   + String((unsigned long)s_calCycles)
      + ",periodMs=" + String((unsigned long)s_samplePeriodMs));
  }
  charLine(nowMs);
}
#endif

// ------------------------- persistence -----------------------------------
static void saveNvs() {
  s_nvs.begin("ctokp", false);
  s_nvs.putBytes("base", &s_base, sizeof(s_base));
  s_nvs.end();
}
static bool loadNvs() {
  s_nvs.begin("ctokp", true);
  size_t bn = s_nvs.getBytesLength("base");
  bool ok = false;
  if (bn == sizeof(s_base)) {
    s_nvs.getBytes("base", &s_base, sizeof(s_base));
    if (s_base.magic == BASE_MAGIC && s_base.node_id == s_nodeId) ok = true;
  }
  s_nvs.end();
  return ok;
}

// ------------------------- learn -----------------------------------------
static void resetLearning() {
  a_sum = a_allanSum = 0; a_prevSet = false; a_allanN = 0;
  a_tsum = 0; a_n = 0; s_startMs = millis();
}
static void accumulate(double r, float t) {
  a_sum += r;
  if (a_prevSet) { double d = r - a_prev; a_allanSum += d*d; a_allanN++; }
  a_prev = r; a_prevSet = true; a_tsum += t; a_n++;
}
static void finishBaseline() {
  s_base.node_id   = s_nodeId; s_base.learned_s = a_n;
  s_base.ratio_mean = a_n ? a_sum / a_n : 0;
  s_base.allan_dev  = a_allanN >= 2 ? sqrt(a_allanSum / (2.0 * a_allanN)) : 0;
  s_base.temp_mean  = a_n ? a_tsum / a_n : 0;
  s_base.cal_cycles = s_calCycles; s_base.magic = BASE_MAGIC;
  s_haveBase = true;
  saveNvs();
  logline(String("ENROLL,node=") + s_nodeId
    + ",ratio_mean=" + String(s_base.ratio_mean, 8)
    + ",allan="      + String(s_base.allan_dev, 8)
    + ",temp="       + String(s_base.temp_mean, 2)
    + ",secs="       + a_n);
}

// ------------------------- public API ------------------------------------
void begin(uint16_t nodeId, LogFn logger) {
  s_nodeId = nodeId; s_log = logger;
  for (uint8_t i = 0; i < MAX_PEERS_FP; i++) s_peers[i].used = false;
#ifdef CTOK_CHAR_ENROLL
  // v7.14.4 bake -> enroll -> characterize. Force a FRESH bake every flash so
  // the enrolled baseline is anchored at the current (stable) bench temp,
  // ignoring any stored baseline. finishBaseline() then saves the real
  // enrollment; tick() emits CHAR_INIT with the measured W and streams.
  s_learning = true; resetLearning();
  logline(String("CHARENROLL_MODE,node=") + nodeId + ",bakeSecs=" + s_baselineSecs);
  return;
#endif
#ifdef CTOK_CHAR_LOG
  s_haveBase = false; s_learning = false;   // characterization: token layer off (no announce/mint); mesh still runs
  logline(String("CHAR_MODE,node=") + nodeId + ",secs=raw-stream");
  return;
#endif
  if (loadNvs()) {
    s_haveBase = true; s_learning = false;
    s_calCycles = s_base.cal_cycles ? s_base.cal_cycles : s_calCycles;
    logline(String("LOADED,node=") + nodeId + ",ratio_mean=" + String(s_base.ratio_mean, 8));
  } else {
    s_learning = true; resetLearning();
    logline(String("LEARN_START,node=") + nodeId + ",secs=" + s_baselineSecs);
  }
}

void tick(uint32_t nowMs) {
  if (nowMs - s_lastSample < s_samplePeriodMs) return;
  s_lastSample = nowMs;
  s_lastRatio = measureRcRatio(); s_lastTemp = measureTempC();
#ifdef CTOK_CHAR_LOG
  charSample(nowMs);
  return;                       // characterization mode: raw stream only
#endif
#ifdef CTOK_CHAR_ENROLL
  if (s_learning) {
    accumulate(s_lastRatio, s_lastTemp);
    if ((nowMs - s_startMs) >= s_baselineSecs * 1000UL) {
      finishBaseline();               // computes + SAVES baseline, prints ENROLL
      s_learning = false;
      double W = windowHalf(s_base.allan_dev);
      logline(String("CHAR_INIT,node=") + s_nodeId
        + ",W="      + String(W, 12)
        + ",allan="  + String(s_base.allan_dev, 12)
        + ",tolN="   + String(s_tolN, 2)
        + ",ratio0=" + String(s_base.ratio_mean, 12)
        + ",temp0="  + String((double)s_base.temp_mean, 4));
    }
  } else {
    charLine(nowMs);                  // post-enroll: stream the temperature sweep
  }
  return;
#endif
  if (s_learning) {
    accumulate(s_lastRatio, s_lastTemp);
    if ((nowMs - s_startMs) >= s_baselineSecs * 1000UL) { finishBaseline(); s_learning = false; }
  }
#ifdef CTOK_FLAP_PROBE
  if (s_haveBase && !s_learning) probeSample(nowMs);
#endif
}

bool   haveBaseline() { return s_haveBase; }
// v7.13.0: bake progress accessors for the glass. Derived from the same
// s_startMs / s_baselineSecs the learn window itself uses, so the countdown on
// the screen can never disagree with the actual finish instant.
bool     learning()        { return s_learning; }
uint32_t learnTotalSecs()  { return s_baselineSecs; }
uint32_t learnRemainSecs() {
  if (!s_learning) return 0;
  uint32_t el = (millis() - s_startMs) / 1000UL;
  return (el >= s_baselineSecs) ? 0 : (s_baselineSecs - el);
}
double lastRatio()    { return s_lastRatio; }
double sepUnits()     { if (!s_haveBase || s_base.allan_dev <= 0) return 0;
                        return fabs(s_lastRatio - s_base.ratio_mean) / s_base.allan_dev; }

bool announceBytes(Fingerprint* out) {
  if (!s_haveBase || !out) return false;
  out->magic      = 0x4B54464E;   // 'KTFN'
  out->node_id    = s_base.node_id;
  out->rsv        = 0;
  out->ratio_mean = s_base.ratio_mean;   // exact double
  out->allan_dev  = s_base.allan_dev;    // exact double
  out->temp_mean  = s_base.temp_mean;
  return true;
}

bool absorbPeer(const Fingerprint* fp) {
  if (!fp || fp->magic != 0x4B54464E) return false;
  if (fp->node_id == s_nodeId) return false;
  if (!(fp->allan_dev > 0.0f)) return false;      // guard bad announcements
  int freeIdx = -1;
  for (uint8_t i = 0; i < MAX_PEERS_FP; i++) {
    if (s_peers[i].used && s_peers[i].fp.node_id == fp->node_id) { s_peers[i].fp = *fp; return true; }
    if (!s_peers[i].used && freeIdx < 0) freeIdx = i;
  }
  if (freeIdx < 0) return false;
  s_peers[freeIdx].used = true; s_peers[freeIdx].fp = *fp;
  logline(String("PEER_ADD,node=") + fp->node_id + ",ratio_mean=" + String(fp->ratio_mean, 6));
  return true;
}

static PeerFp* findPeer(uint16_t nodeId) {
  for (uint8_t i = 0; i < MAX_PEERS_FP; i++)
    if (s_peers[i].used && s_peers[i].fp.node_id == nodeId) return &s_peers[i];
  return nullptr;
}
bool peerKnown(uint16_t nodeId) { return findPeer(nodeId) != nullptr; }
bool forgetPeer(uint16_t nodeId) { PeerFp* p = findPeer(nodeId); if (!p) return false; p->used = false; memset(&p->fp, 0, sizeof(p->fp)); logline(String("PEER_DROP,node=") + nodeId); return true; }   // v7.28.59
uint8_t peerCount() { uint8_t n = 0; for (uint8_t i = 0; i < MAX_PEERS_FP; i++) if (s_peers[i].used) n++; return n; }
uint8_t peerList(uint16_t* out, uint8_t maxOut) {
  uint8_t n = 0;
  for (uint8_t i = 0; i < MAX_PEERS_FP && n < maxOut; i++)
    if (s_peers[i].used) out[n++] = s_peers[i].fp.node_id;
  return n;
}

bool mintTag(uint16_t dstId, uint32_t seq, uint8_t tag16[16]) {
  if (!s_haveBase) return false;
  PeerFp* p = findPeer(dstId);
  if (!p) return false;
  uint8_t vecS[16], vecR[16], key[32], full[32];
  enrollmentVectorLocal(vecS);
  enrollmentVectorFrom(p->fp.node_id, p->fp.ratio_mean, p->fp.allan_dev, p->fp.temp_mean, vecR);
  pairKey(vecS, vecR, key);
  sealPair(key, seq, full);
  memcpy(tag16, full, 16);
  return true;
}

bool validateTag(uint16_t srcId, uint32_t seq, const uint8_t tag16[16]) {
  if (!s_haveBase) return false;          // a blind node has no vecR, can never validate
  PeerFp* p = findPeer(srcId);
  if (!p) return false;                   // unknown sender
  uint8_t vecS[16], vecR[16], key[32], full[32];
  enrollmentVectorFrom(p->fp.node_id, p->fp.ratio_mean, p->fp.allan_dev, p->fp.temp_mean, vecS);
  enrollmentVectorLocal(vecR);            // OUR own crystal is the recipient half
  pairKey(vecS, vecR, key);
  sealPair(key, seq, full);
  return memcmp(full, tag16, 16) == 0;
}

bool mintTagN(uint16_t dstId, uint32_t seq, uint8_t* out, uint8_t n) {
  if (!out || n == 0 || n > 16) return false;
  uint8_t full[16];
  if (!mintTag(dstId, seq, full)) return false;
  memcpy(out, full, n);
  return true;
}

bool validateTagN(uint16_t srcId, uint32_t seq, const uint8_t* in, uint8_t n) {
  if (!in || n == 0 || n > 16) return false;
  if (!s_haveBase) return false;
  PeerFp* p = findPeer(srcId);
  if (!p) return false;
  uint8_t vecS[16], vecR[16], key[32], full[32];
  enrollmentVectorFrom(p->fp.node_id, p->fp.ratio_mean, p->fp.allan_dev, p->fp.temp_mean, vecS);
  enrollmentVectorLocal(vecR);
  pairKey(vecS, vecR, key);
  sealPair(key, seq, full);
  return memcmp(full, in, n) == 0;
}

void setTolN(double n) { if (n > 0) s_tolN = n; }
void setBaselineSeconds(uint32_t s) { if (s >= 10) s_baselineSecs = s; }
void reset() {
  s_nvs.begin("ctokp", false); s_nvs.clear(); s_nvs.end();
  s_haveBase = false; s_learning = true; resetLearning();
  for (uint8_t i = 0; i < MAX_PEERS_FP; i++) s_peers[i].used = false;
}

} // namespace pairtok
