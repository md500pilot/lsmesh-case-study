#pragma once

#include <stdint.h>

// V7.31 mixed-sphere discovery profile. Discovery itself is always SF7/125.
// The authenticated backhaul advert selects one of these complete working
// profiles; callers must apply the radio and timing values as one transaction.
namespace lsm_dual_phy {

enum : uint8_t {
  PROFILE_INVALID = 0,
  PROFILE_SF5_125 = 1,
  PROFILE_SF6_125 = 2,
  PROFILE_SF7_125 = 3,
  PROFILE_SF5_250 = 4,
  PROFILE_SF6_250 = 5,
  PROFILE_SF7_250 = 6,
  PROFILE_SF5_500 = 7,
  PROFILE_SF6_500 = 8,
  PROFILE_SF7_500 = 9,
};

static constexpr uint8_t DISCOVERY_SF = 7;
static constexpr uint32_t DISCOVERY_BW_HZ = 125000u;

struct Profile {
  uint8_t id;
  uint8_t sf;
  uint32_t bandwidthHz;
  uint16_t preambleSymbols;
  uint8_t receiverValidationSymbols;
};

static constexpr Profile profileForId(uint8_t id) {
  return id == PROFILE_SF5_125 ? Profile{id, 5, 125000u, 12, 2}
       : id == PROFILE_SF6_125 ? Profile{id, 6, 125000u, 12, 2}
       : id == PROFILE_SF7_125 ? Profile{id, 7, 125000u, 8,  2}
       : id == PROFILE_SF5_250 ? Profile{id, 5, 250000u, 24, 2}
       : id == PROFILE_SF6_250 ? Profile{id, 6, 250000u, 12, 2}
       : id == PROFILE_SF7_250 ? Profile{id, 7, 250000u, 8,  2}
       : id == PROFILE_SF5_500 ? Profile{id, 5, 500000u, 47, 2}
       : id == PROFILE_SF6_500 ? Profile{id, 6, 500000u, 24, 2}
       : id == PROFILE_SF7_500 ? Profile{id, 7, 500000u, 12, 2}
                               : Profile{PROFILE_INVALID, 0, 0, 0, 0};
}

static constexpr uint8_t idFor(uint8_t sf, uint32_t bandwidthHz) {
  return bandwidthHz == 125000u ? (sf == 5 ? PROFILE_SF5_125 : sf == 6 ? PROFILE_SF6_125 : sf == 7 ? PROFILE_SF7_125 : PROFILE_INVALID)
       : bandwidthHz == 250000u ? (sf == 5 ? PROFILE_SF5_250 : sf == 6 ? PROFILE_SF6_250 : sf == 7 ? PROFILE_SF7_250 : PROFILE_INVALID)
       : bandwidthHz == 500000u ? (sf == 5 ? PROFILE_SF5_500 : sf == 6 ? PROFILE_SF6_500 : sf == 7 ? PROFILE_SF7_500 : PROFILE_INVALID)
                                : PROFILE_INVALID;
}

static constexpr bool valid(uint8_t id) {
  return id >= PROFILE_SF5_125 && id <= PROFILE_SF7_500;
}

}  // namespace lsm_dual_phy
