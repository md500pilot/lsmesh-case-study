#pragma once
#include <stdint.h>

// Observe only logically new authenticated type-0/type-6 keepalives.
// Peer progress is liveness evidence, never a timing anchor or a slot grant.
struct AuthorityProgress {
  uint8_t keeper=0, epoch=0, seq=0, steps=0;
  uint32_t advancedAt=0, witnesses=0;

  bool observe(uint8_t k, uint8_t generation, uint8_t sequence,
               uint8_t sender, uint32_t now, uint8_t maxStep) {
    if (!k) return false;
    const bool same=keeper==k && epoch==generation;
    const uint8_t epochStep=(uint8_t)(generation-epoch);
    if (!same) {
      if (keeper && !(epochStep>0 && epochStep<128)) return false;
      keeper=k; epoch=generation; seq=sequence;
      steps=0; advancedAt=0; witnesses=0;
      return false;
    }
    const uint8_t step=(uint8_t)(sequence-seq);
    if (!step || step>maxStep || step>=128) return false;
    seq=sequence;
    if (steps<255) steps++;
    if (sender<32) witnesses|=(uint32_t)1U<<sender;
    if (steps<2) return false;
    advancedAt=now ? now : 1U;
    return true;
  }

  bool holds(uint8_t currentKeeper, uint8_t currentEpoch,
             uint32_t lastScheduleAdvance, uint32_t now,
             uint32_t freshMs, uint32_t maxHoldMs) const {
    return currentKeeper && keeper==currentKeeper && epoch==currentEpoch &&
      lastScheduleAdvance && advancedAt && steps>=2 &&
      (int32_t)(advancedAt-lastScheduleAdvance)>=0 &&
      (uint32_t)(now-advancedAt)<=freshMs &&
      (uint32_t)(now-lastScheduleAdvance)<maxHoldMs;
  }
};

namespace authorityrecovery {
constexpr uint32_t holdCap(uint32_t stallMs, uint32_t commitMs,
                            uint32_t isolatedGraceMs, uint32_t candidateLimitMs) {
  const uint64_t sum=(uint64_t)stallMs+commitMs;
  const uint64_t preferred=sum>isolatedGraceMs ? sum : isolatedGraceMs;
  return preferred>candidateLimitMs ? candidateLimitMs : (uint32_t)preferred;
}
}
