#pragma once
#include <stdint.h>
namespace lsmgeometry {
constexpr bool relayTierAllowed(uint8_t hop,uint8_t tiers){return hop>0&&hop<=tiers;}
// Zero selects THIS beacon's target, even if prior advertisements were missed.
// Nonzero (including NONE) retains the advertised current geometry.
constexpr uint8_t effectiveTiers(uint8_t current, uint8_t target,
                                 uint8_t countdown, uint8_t maximum) {
  return (countdown==0 ? target : current)>maximum ? maximum :
         (countdown==0 ? target : current);
}
}
