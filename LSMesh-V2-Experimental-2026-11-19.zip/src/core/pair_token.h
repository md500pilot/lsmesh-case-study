// pair_token.h  -  Kairoshield PAIRWISE crystal token, LSM24 cross-node build.
//
// Extends the local crystal token (crystal_token.cpp, QTrust local-only proof)
// with a cross-node binding for the mesh rejection test. The change that matters
// is in the key: a token is derived from BOTH baselines, the sender's crystal
// AND the intended recipient's crystal. A recipient can only open a token if it
// holds its OWN valid baseline and knows the sender's fingerprint. A node with
// no baseline of its own (blind, standard firmware) can never be a recipient.
//
// This module owns:
//   1. the 8 minute learn of the local crystal baseline, saved to NVS ("ctokp"),
//   2. building the local fingerprint announcement bytes to put on the mesh,
//   3. absorbing peers' fingerprint announcements into a small whitelist,
//   4. minting a per-recipient token tag for a whitelisted peer (sender side),
//   5. validating an incoming token tag addressed to us (recipient side).
//
// It does NOT touch the radio, the wire format, the election, or the superframe.
// The mesh firmware calls announceBytes()/mintTag()/validateTag() from its own
// send and recv paths. Every verdict is logged through the caller's logger.
//
// HONEST SCOPE, read the README test plan. The fingerprint announcement carries
// ratio_mean, allan_dev and temp_mean in clear, so a node that hears two
// announcements can reconstruct both vectors. This build PROVES mutual-baseline
// binding and physical-crystal identity (a blind node is locked out, a foreign
// crystal fails to open), it does NOT prove eavesdropper resistance. The
// challenge-response commitment upgrade is a separate, later crypto layer.
//
// UNVERIFIED. Not bench-compiled. V2 boards only (Heltec Wireless Tracker V2).
#pragma once
#include <Arduino.h>

namespace pairtok {

typedef void (*LogFn)(const String& line);

// ---- fingerprint announcement, the bytes that go on the mesh --------------
// This is exactly the public part of a baseline: enough for a peer to rebuild
// our enrollment vector, and nothing else. 20 bytes on the wire.
#pragma pack(push, 1)
struct Fingerprint {
  uint32_t magic;        // 0x4B54464E 'KTFN', marks a valid fingerprint
  uint16_t node_id;      // full node id (6..11 in this test)
  uint16_t rsv;          // reserved, zero
  double   ratio_mean;   // crystal envelope center, EXACT double so a legit pair
  double   allan_dev;    // stability; both quantize identically to the sender
  float    temp_mean;    // enrollment temperature (float matches the baseline field)
};
#pragma pack(pop)

// Call once in setup(), after the board clocks are up. nodeId is the full id.
// Loads a saved baseline from NVS if present, else starts an 8 minute learn.
void begin(uint16_t nodeId, LogFn logger = nullptr);

// Call every loop iteration. Non-blocking between samples. When the learn
// window finishes it derives and saves the baseline; from then on haveBaseline()
// is true and announceBytes() returns our fingerprint.
void tick(uint32_t nowMs);

bool  haveBaseline();          // local baseline learned or loaded
double lastRatio();
double sepUnits();             // live distance from our own center, stability units

// ---- fingerprint exchange -------------------------------------------------
// Fill out with our fingerprint for the mesh to broadcast. Returns false until
// the baseline exists. out must be sizeof(Fingerprint).
bool announceBytes(Fingerprint* out);

// Absorb a peer's fingerprint heard on the mesh into the whitelist. Ignores our
// own id and malformed announcements. Returns true if stored or refreshed.
bool absorbPeer(const Fingerprint* fp);

bool  peerKnown(uint16_t nodeId);   // is this peer in our whitelist
bool  forgetPeer(uint16_t nodeId);  // v7.28.59: drop a peer from the whitelist (eviction, revocation). Returns true if it was there.
uint8_t peerCount();
uint8_t peerList(uint16_t* out, uint8_t maxOut);  // fill out[] with known peer ids, return count

// ---- pairwise token, the actual gate --------------------------------------
// SENDER side: mint the token tag that proves "from us, for dstId", bound to
// our baseline and dst's whitelisted fingerprint and this frame seq. Returns
// false if we have no baseline or dst is not whitelisted. tag16 is 16 bytes.
bool mintTag(uint16_t dstId, uint32_t seq, uint8_t tag16[16]);

// RECIPIENT side: validate a tag addressed to us that claims to be from srcId,
// using srcId's whitelisted fingerprint and OUR own baseline and the seq.
// Returns true only if the recomputed tag matches. False if we have no baseline,
// src is unknown, or the tag does not match (foreign crystal / spoof / blind).
bool validateTag(uint16_t srcId, uint32_t seq, const uint8_t tag16[16]);

// LoRa airtime variants: same key + HMAC, but only the first n bytes (n<=16) go
// on the wire. Sub-GHz uses n=4 (the widened 32-bit MemberPkt token slot). The
// full 16-byte tag is computed internally; truncation only reduces forgery
// resistance to 1 in 2^(8n), which at n=4 is about 1 in 4.3e9 per packet, ample
// for a physical-identity gate on a slow LoRa channel.
bool mintTagN(uint16_t dstId, uint32_t seq, uint8_t* out, uint8_t n);
bool validateTagN(uint16_t srcId, uint32_t seq, const uint8_t* in, uint8_t n);

// Runtime knobs, same meaning as the standalone build.
void setTolN(double n);
void setBaselineSeconds(uint32_t s);   // default 480 (8 minutes)

// v7.13.0: bake progress, for the BASE countdown page on the glass. The learn
// window had no readout at all, so a board mid-bake looked identical to a
// board that had finished. learnRemainSecs() returns 0 once the baseline is
// held (or loaded from NVS, which is instant on a power-cycle).
bool     learning();            // true only while the bake is actually running
uint32_t learnRemainSecs();     // seconds left in the bake, 0 when not learning
uint32_t learnTotalSecs();      // configured bake length (CTOK_LEARN_SECS)
void reset();                          // wipe baseline + whitelist, relearn

} // namespace pairtok
