// Included once, after the legacy GNSS, peer, radio and security definitions.
#ifndef LSM_TELEMETRY_V1
#define LSM_TELEMETRY_V1 1
#endif
struct TelemetryEntry { telemetry::Snapshot value{}; uint32_t received=0; bool used=false,usbPending=false,blePending=false,airPending=false; };
#include "telemetry_export_queue.h"
// Type22 aux D0..D6: snapshot identity, e=seq16,n=frame16,data=boot32.
// Only remote origins are traced; these witnesses do not add radio traffic.
static void telemetryTrace(uint8_t stage,const telemetry::Snapshot& s){
 if(s.node!=(uint8_t)NODE_ID)logRec(LOG_POS,s.node,g_role,stage,(int16_t)s.sequence,(int16_t)s.frame,s.boot);
}
static TelemetryEntry g_telemetry[64];
static uint32_t g_telemetryBoot=0;
static uint16_t g_telemetryFrame=0,g_telemetrySequence=0;
static int32_t g_telemetryLat=0,g_telemetryLon=0;
static bool g_telemetryOrigin=false,g_telemetryUsb=false;
static uint8_t g_telemetryGrantId=0,g_telemetryGrantSeq=0;
static uint8_t g_telemetryFor1=0,g_telemetryBy1=0,g_telemetryFor2=0,g_telemetryBy2=0;
static uint64_t g_telemetryKeeperSent=0;
static uint8_t g_telemetryCursor=0,g_telemetryAirCursor=0;
static NimBLECharacteristic* chTelemetry=nullptr;
static uint32_t g_telemetryAccepted=0,g_telemetryRejected=0,g_telemetryUsbFrames=0;
static uint8_t g_telemetryDataMap[32]{};
static uint8_t g_telemetryDataKeeper=0,g_telemetryDataEpoch=0;
static uint32_t g_telemetryDataAt=0,g_telemetryDataFrameMs=0;
#include "notify_receipt.h"
static std::atomic<TaskHandle_t> g_bleNotifyOwner{nullptr};
// Pointer is used only on the notify caller task; callbacks on other tasks cannot touch its stack.
static telemetryexport::NotifyReceipt* g_bleNotifyReceipt=nullptr;
static NimBLECharacteristic* g_bleNotifyCharacteristic=nullptr;
struct LegacyPeerNotifyStats{uint32_t attempts=0,accepted=0,rejected=0;int lastCode=0;};
static LegacyPeerNotifyStats g_legacyPeerNotifyStats{};
struct BleNotifyStats {uint32_t attempts=0,accepted=0,rejected=0,unconfirmed=0,restarts=0;int lastCode=0;};
static BleNotifyStats g_bleNotifyStats{};
static void telemetryBleNotifyStatus(bool notification,int code){
 if(xTaskGetCurrentTaskHandle()!=g_bleNotifyOwner.load(std::memory_order_acquire))return;
 if(g_bleNotifyReceipt)g_bleNotifyReceipt->note(notification,code);
}
static bool telemetryBleNotifyChecked(const uint8_t* bytes,size_t size){
 telemetryexport::NotifyReceipt receipt{};
 const uint16_t subscribers=chTelemetry->getSubscribedCount();
 g_bleNotifyStats.attempts++;g_bleNotifyReceipt=&receipt;g_bleNotifyCharacteristic=chTelemetry;
 chTelemetry->setValue(bytes,size);chTelemetry->notify();
 g_bleNotifyReceipt=nullptr;g_bleNotifyCharacteristic=nullptr;
 if(receipt.complete(subscribers)){g_bleNotifyStats.accepted++;return true;}
 g_bleNotifyStats.rejected++;g_bleNotifyStats.lastCode=receipt.failureCode();
 if(receipt.callbacks!=subscribers||!subscribers)g_bleNotifyStats.unconfirmed++;
 return false;
}
static bool legacyPeerNotifyChecked(const uint8_t* bytes,size_t size){
 telemetryexport::NotifyReceipt receipt{};const uint16_t subscribers=chPos->getSubscribedCount();
 g_legacyPeerNotifyStats.attempts++;g_bleNotifyReceipt=&receipt;g_bleNotifyCharacteristic=chPos;
 chPos->setValue(bytes,size);chPos->notify();g_bleNotifyReceipt=nullptr;g_bleNotifyCharacteristic=nullptr;
 if(receipt.complete(subscribers)){g_legacyPeerNotifyStats.accepted++;return true;}
 g_legacyPeerNotifyStats.rejected++;g_legacyPeerNotifyStats.lastCode=receipt.failureCode();return false;
}
using TelemetryExportQueue=telemetryexport::Queue<telemetry::Snapshot,64>;
struct TelemetryExportChannel {
 TelemetryExportQueue queue{};telemetry::Snapshot tx{},original{};uint8_t bytes[40]{};
 telemetryexport::Progress progress{};uint32_t received=0,last=0,transportGeneration=0;
 uint32_t shortWrites=0,fragmentAborts=0,lateCompletions=0,retryAfter=0;
 uint8_t message=0,replayCursor=0;bool active=false,remote=false,replay=false,preferOwn=false,shortWitness=false,retryWait=false,notifyErrorWitness=false;
};
static TelemetryExportChannel g_exportUsb{},g_exportBle{};
static telemetryexport::Fair g_exportFair{};
static_assert(sizeof(g_exportUsb)+sizeof(g_exportBle)<=6500,"Bounded remote export RAM budget");
static constexpr size_t TELEMETRY_EXPORT_RAM_BYTES=sizeof(g_exportUsb)+sizeof(g_exportBle)+sizeof(g_exportFair)+sizeof(g_exportSerialMutexStorage)+sizeof(g_telemetryUsbPrefixBusy)+sizeof(g_telemetryReplayRequested)+sizeof(g_exportBleConnected)+sizeof(g_exportBleSubscribed)+sizeof(g_exportBleGeneration)+sizeof(g_exportSerialMutex)+sizeof(g_bleNotifyOwner)+sizeof(g_bleNotifyReceipt)+sizeof(g_bleNotifyStats)+sizeof(g_bleNotifyCharacteristic)+sizeof(g_legacyPeerNotifyStats);
static_assert(TELEMETRY_EXPORT_RAM_BYTES<=7000,"Queues, active buffers and cross-core synchronization RAM bound");
static void telemetryExportSync(){
 static uint32_t seenBleGeneration=0;
 const uint32_t generation=g_exportBleGeneration.load(std::memory_order_acquire);
 const bool ble=g_exportBleConnected.load(std::memory_order_acquire)&&g_exportBleSubscribed.load(std::memory_order_acquire)&&chTelemetry;
 if(generation!=seenBleGeneration){
  if(g_exportBle.active&&g_exportBle.progress.offset)g_exportBle.fragmentAborts++;
  g_exportBle.queue.setEnabled(false);g_exportBle.active=false;g_exportBle.progress.offset=0;
  g_exportBle.replay=false;seenBleGeneration=generation;
 }
 g_exportBle.transportGeneration=generation;
 auto sync=[](TelemetryExportChannel& c,bool enabled,bool usb){
  if(enabled==c.queue.enabled)return;
  const bool keep=usb&&c.active&&c.progress.offset!=0;
  c.queue.setEnabled(enabled,keep&&c.remote);
  if(!enabled&&!keep){if(c.active&&c.progress.offset)c.fragmentAborts++;c.active=false;c.progress.offset=0;}
  c.replay=enabled;c.replayCursor=0;
 };
 sync(g_exportUsb,g_telemetryUsb,true);sync(g_exportBle,ble,false);
}
static void telemetryExportOffer(TelemetryExportChannel& c,const telemetry::Snapshot& s,uint32_t received,bool replay,bool usb){
 auto result=c.queue.offer(s,received,replay);
 if(result.dropped)telemetryTrace(usb?0xD8:0xD9,result.victim.value); // Oldest UNSENT only; active frame protected.
}
static void telemetryExportPrint(){
 auto print=[](const char* name,const TelemetryExportChannel& c){const auto &s=c.queue.stats;
  Serial.printf("EXPORT_QUEUE node=%u channel=%s capacity=64 enabled=%u generation=%lu queued=%u active=%u offered=%lu live=%lu replay=%lu enqueued=%lu duplicate=%lu inactive=%lu completed=%lu overflow=%lu expired=%lu disabled=%lu aborted=%lu highwater=%lu max_residence_ms=%lu short_writes=%lu fragment_aborts=%lu late_completions=%lu conserved=%u\n",
   (unsigned)NODE_ID,name,(unsigned)c.queue.enabled,(unsigned long)c.queue.generation,(unsigned)c.queue.count,(unsigned)c.queue.active,
   (unsigned long)s.offered,(unsigned long)s.live,(unsigned long)s.replay,(unsigned long)s.enqueued,(unsigned long)s.duplicate,(unsigned long)s.inactive,(unsigned long)s.completed,(unsigned long)s.overflow,(unsigned long)s.expired,(unsigned long)s.disabled,(unsigned long)s.aborted,(unsigned long)s.highwater,(unsigned long)s.maxResidence,(unsigned long)c.shortWrites,(unsigned long)c.fragmentAborts,(unsigned long)c.lateCompletions,(unsigned)c.queue.conserved());
 };
 print("USB",g_exportUsb);print("BLE",g_exportBle);
 Serial.printf("BLE_NOTIFY node=%u attempts=%lu stack_accepted=%lu rejected=%lu unconfirmed=%lu restarts=%lu last_code=%d\n",(unsigned)NODE_ID,(unsigned long)g_bleNotifyStats.attempts,(unsigned long)g_bleNotifyStats.accepted,(unsigned long)g_bleNotifyStats.rejected,(unsigned long)g_bleNotifyStats.unconfirmed,(unsigned long)g_bleNotifyStats.restarts,g_bleNotifyStats.lastCode);
 Serial.printf("LEGACY_PEER_NOTIFY node=%u attempts=%lu stack_accepted=%lu rejected=%lu last_code=%d\n",(unsigned)NODE_ID,(unsigned long)g_legacyPeerNotifyStats.attempts,(unsigned long)g_legacyPeerNotifyStats.accepted,(unsigned long)g_legacyPeerNotifyStats.rejected,g_legacyPeerNotifyStats.lastCode);
 Serial.printf("EXPORT_TRANSPORT node=%u ble_generation=%lu usb_prefix_busy=%u ram_bytes=%u ram_bound=7000\n",(unsigned)NODE_ID,(unsigned long)g_exportBleGeneration.load(std::memory_order_acquire),(unsigned)g_telemetryUsbPrefixBusy.load(std::memory_order_acquire),(unsigned)TELEMETRY_EXPORT_RAM_BYTES);
}
static bool telemetryKnown(uint8_t id){
 if(id==(uint8_t)NODE_ID)return true;
 if(ksDenied(id))return false;
 if(id==g_tkId&&g_role!=3&&millis()-g_lastTkHeardMs<5000UL)return true;
 if(g_role==3){int ri=tkRosterFind(id);if(ri<0)return false;
#if defined(CRYSTAL_TOKEN) && CTOK_ENFORCE
 if(g_ctFail[ri])return false;
#endif
 return true;}
 const bool previous=(g_telemetryDataMap[id>>3]>>(id&7))&1U;
 const bool same=g_telemetryDataAt&&g_telemetryDataKeeper==g_tkId&&g_telemetryDataEpoch==g_tkEpoch;
 const uint32_t bound=g_telemetryDataFrameMs+g_frameUs/1000UL+1000UL;
 return telemetry::phaseMember(g_frameType==SF_TYPE_JOIN,g_pubMapValid&&pubIdHas(id),previous,same,millis()-g_telemetryDataAt,bound);
}
static TelemetryEntry* telemetryEntry(uint8_t id,bool create){
 TelemetryEntry* vacant=nullptr;uint32_t now=millis();
 for(auto &e:g_telemetry){if(e.used&&e.value.node==id)return &e;if(!e.used||now-e.received>30000UL)vacant=&e;}
 if(!create||!vacant)return nullptr;*vacant=TelemetryEntry{};vacant->used=true;return vacant;
}
static void telemetryReplay(){
 telemetryExportSync();g_exportUsb.replay=g_exportUsb.queue.enabled;g_exportBle.replay=g_exportBle.queue.enabled;
 g_exportUsb.replayCursor=g_exportBle.replayCursor=0;
 for(auto &e:g_telemetry)if(e.used&&e.value.node==(uint8_t)NODE_ID){e.usbPending=true;e.blePending=true;}
}
static bool telemetryStore(const telemetry::Snapshot& s,bool direct){
 if(!telemetry::valid(s)||!telemetryKnown(s.node)){g_telemetryRejected++;return false;}
 auto *e=telemetryEntry(s.node,true);if(!e){g_telemetryRejected++;return false;}
 const bool old=e->received!=0&&millis()-e->received<=30000UL;
 if(!telemetry::acceptable(s,old?&e->value:nullptr,direct)){g_telemetryRejected++;return false;}
 bool originChanged=!old||s.boot!=e->value.boot||s.frame!=e->value.frame;
 e->value=s;e->received=millis();e->used=true;e->usbPending=s.node==(uint8_t)NODE_ID;e->blePending=s.node==(uint8_t)NODE_ID;e->airPending=true;g_telemetryAccepted++;
 if(s.node!=(uint8_t)NODE_ID){
  telemetryExportSync();telemetryExportOffer(g_exportUsb,s,e->received,false,true);telemetryExportOffer(g_exportBle,s,e->received,false,false);
 }
 telemetryTrace(0xD0,s);
 // Legacy seed replay is a compatibility service. It never re-centres an origin.
 if(originChanged&&(s.flags&telemetry::ORIGIN)){
  int32_t dm=s.altitudeCm/10;int16_t legacyAlt=(s.flags&telemetry::ALTITUDE)&&dm>=INT16_MIN&&dm<=INT16_MAX?(int16_t)dm:0;
  queueSeedBle(s.node,s.originLatMicro,s.originLonMicro,legacyAlt);
 }
 return true;
}
static telemetry::Snapshot telemetryOwn(){
 telemetry::Snapshot s{};if(!g_telemetryBoot){g_telemetryBoot=esp_random();if(!g_telemetryBoot)g_telemetryBoot=1;}
 s.node=(uint8_t)NODE_ID;s.boot=g_telemetryBoot;s.sequence=++g_telemetrySequence;
 const bool origin=originSet&&g_haveRealFix;
 int32_t la=origin?(int32_t)llround(lat0*1000000.0):0,lo=origin?(int32_t)llround(lon0*1000000.0):0;
 if(origin&&(!g_telemetryOrigin||la!=g_telemetryLat||lo!=g_telemetryLon)){
  if(++g_telemetryFrame==0){g_telemetryBoot=esp_random();if(!g_telemetryBoot)g_telemetryBoot=1;s.boot=g_telemetryBoot;g_telemetryFrame=1;}
  g_telemetryLat=la;g_telemetryLon=lo;g_telemetryOrigin=true;
 }
 s.frame=g_telemetryFrame;s.originLatMicro=la;s.originLonMicro=lo;
 if(origin)s.flags|=telemetry::ORIGIN;
 uint32_t age=65535UL;
 bool fix=g_haveRealFix&&g_satsNow>=MIN_SATS_TX&&gps.location.isValid()&&gps.location.age()<=5000UL;
 if(fix&&origin&&g_posValid&&g_posConf>0&&g_fusE>=INT16_MIN&&g_fusE<=INT16_MAX&&g_fusN>=INT16_MIN&&g_fusN<=INT16_MAX){
  s.flags|=telemetry::POSITION;s.eastCm=(int16_t)lround(g_fusE);s.northCm=(int16_t)lround(g_fusN);age=gps.location.age();
 }
 // Keep full signed centimetres; legacy altitudeCmNow() clips at +/-327 metres.
 // The datum is explicitly receiver/unverified, never silently WGS84 or AGL.
 if(fix&&gps.altitude.isValid()&&gps.altitude.age()<=5000UL){
  double cm=gps.altitude.meters()*100.0;
  if(isfinite(cm)&&cm>=INT32_MIN&&cm<=INT32_MAX){s.altitudeCm=(int32_t)llround(cm);s.flags|=telemetry::ALTITUDE;s.datum=telemetry::RECEIVER_UNVERIFIED;uint32_t aa=gps.altitude.age();age=age==65535UL?aa:(age>aa?age:aa);}
 }
 s.confidence=(uint8_t)(g_posConf>63?63:g_posConf);s.floor=FLOOR_LEVEL; // no FLOOR-valid flag: fixed config is not a floor measurement
 if(g_posState==3)s.flags|=telemetry::HELD;
 s.ageMs=(uint16_t)(age>=65535UL?65535UL:age);telemetry::seal(s);return s;
}
static void telemetryRefresh(){auto s=telemetryOwn();telemetryStore(s,true);}
static bool telemetryTxOwn(){
#if LSM_TELEMETRY_V1
 // Position uses existing member opportunities; never adds airtime to a slot.
 // Preserve ordinary control/attestation reports at least every two frames on
 // a slow PHY, or at least every fourth schedule sequence on a fast PHY.
 // Position takes other grants; the radio/frame budget remains authoritative.
 uint32_t &lastControl=g_telemetryControlMs;uint8_t &lastControlSeq=g_telemetryControlSeq;
 const uint32_t now=millis(),frameMs=g_frameUs/1000UL;
 const uint32_t controlPeriod=frameMs>1500UL?2UL*frameMs:3000UL;
 const uint8_t controlFrames=(uint8_t)(g_curSchedSeq-lastControlSeq);
 // Never leave more than three intervening schedule sequences without the
 // ordinary attested control report: successor lease evidence also uses that
 // bounded advance. Otherwise use EVERY available opportunity for position.
 if(!lastControl||controlFrames>=4U||now-lastControl>=controlPeriod){lastControl=now;lastControlSeq=g_curSchedSeq;return false;}
 telemetryRefresh();auto* e=telemetryEntry((uint8_t)NODE_ID,false);if(!e)return false;
 auto s=telemetry::aged(e->value,millis()-e->received);

 const uint64_t txCallUs=(uint64_t)esp_timer_get_time();
 const uint32_t dOff=(uint32_t)(txCallUs-g_frameAnchorUs)+g_txLatUs;
 femTx();int16_t st=LSM_TX((uint8_t*)&s,sizeof(s));
 if(ownedWasSkipped()){rxArmAfterTx();return true;}
 const uint64_t txRetUs=(uint64_t)esp_timer_get_time();
 if(st==RADIOLIB_ERR_NONE){txLatSample(txCallUs,txDoneInstant(txCallUs,txRetUs),g_airWitnessUs?g_airWitnessUs:g_memberAirUsLive);txDoneWitness();}
 rxArmAfterTx();g_seq++;logSlotTrim(dOff);

 logRec(LOG_TX,NODE_ID,g_role,0xB4,s.eastCm,s.northCm,(uint32_t)s.sequence|((uint32_t)(st==RADIOLIB_ERR_NONE)<<31));return true;
#else
 return false;
#endif
}
static bool telemetryReceive(const uint8_t* raw,int len){
 if(len!=(int)sizeof(telemetry::Snapshot)||raw[0]!=telemetry::MAGIC||raw[2]!=telemetry::KIND)return false;
 telemetry::Snapshot wire;memcpy(&wire,raw,sizeof(wire));
 // Validate BEFORE aging/resealing: never repair an invalid incoming CRC.
 if(!telemetry::valid(wire)){g_telemetryRejected++;return true;}
 const bool direct=wire.node==g_secureRxSender;
 if(!direct&&!telemetry::namedRelay(wire.node,g_secureRxSender,g_telemetryFor1,g_telemetryBy1,g_telemetryFor2,g_telemetryBy2)){g_senderBindReject++;return true;}
 if(direct)telemetryTrace(0xD6,wire); // Authenticated, CRC-valid direct ingress before app/cache policy.
 auto s=telemetry::aged(wire,g_memberAirUsLive/1000UL);
 const bool accepted=telemetryStore(s,direct);
 if(accepted){
  peerTouch(s.node,direct); // Only direct authenticated origin proves member role.
  if(direct){
   if(g_role!=3)volNoteHeard(s.node);
   telemetryRelayQueue(s);
   // Only direct, previously pairwise-proven origins refresh radio membership.
   // Relayed position data never fabricates an end-to-end token proof or a
   // direct-heard bit; ordinary attested control still owns those leases.
   if(g_role==3){int ri=tkRosterFind(s.node);if(ri>=0&&g_ctPassed[ri]&&!g_ctFail[ri]){
    g_lastMemberRxMs=millis();g_lastAirMs[ri]=millis();g_lastAirFr[ri]=g_frame;g_missedAirOpp[ri]=0;
    if(g_slotOf[ri]<V7_SLOTS_MAX){const uint8_t sp=g_slotOf[ri];g_heardAccum[sp>>3]|=(uint8_t)(1u<<(sp&7));}
    g_ctDirectMs[ri]=millis();
   }}
  }
 }
 return true;
}
static void telemetryAdopt(uint8_t grant,uint8_t seq,uint8_t f1,uint8_t b1,uint8_t f2,uint8_t b2){g_telemetryGrantId=grant;g_telemetryGrantSeq=seq;g_telemetryFor1=f1;g_telemetryBy1=b1;g_telemetryFor2=f2;g_telemetryBy2=b2;
 // JOIN slot arrays contain empty admission windows, not a replacement roster.
 // Retain only the immediately preceding authenticated DATA map, with the same
 // keeper/epoch and a bound of one DATA+JOIN interval. Next DATA replaces it.
 if(g_frameType==SF_TYPE_DATA&&g_pubMapValid){memcpy(g_telemetryDataMap,g_pubIdMap,sizeof(g_telemetryDataMap));g_telemetryDataAt=millis();g_telemetryDataFrameMs=g_frameUs/1000UL;g_telemetryDataKeeper=g_tkId;g_telemetryDataEpoch=g_tkEpoch;}
}
static void telemetrySchedule(SchedBeacon& s){
#if LSM_TELEMETRY_V1
 // Reuse the already-derived aggregate tail. No packet, PHY, guard or slot grows.
 // One in eight granted tails publishes keeper data; idle frames may carry it too.
 if(s.aggGrantId==0||(s.seq&7)==0){s.aggGrantId=(uint8_t)NODE_ID;s.aggGrantRecs=2;}
#endif
 telemetryAdopt(s.aggGrantId,s.seq,s.relayForId,s.relayById,s.relayForId2,s.relayById2);
 uint8_t ts=s.grantId?(s.relayById?2:1):0;
 g_aggPosSlotStartUs=g_memberBaseUs+(uint32_t)s.nSlots*g_slotUsLive+g_relayReplySlotUs+(uint32_t)ts*g_tokSlotUsLive;
}
static bool telemetryAggregateTx(uint32_t offUs,bool keeper=false){
#if LSM_TELEMETRY_V1
 if(g_telemetryGrantId!=(uint8_t)NODE_ID)return false;
 if(offUs<g_aggPosSlotStartUs||offUs>=g_aggPosSlotStartUs+AGG_POS_SLOT_US)return false;
 if(keeper){if(g_telemetryKeeperSent==g_frameAnchorUs)return false;}
 else {static bool turn=false;turn=!turn;if(!turn)return false;}
 uint8_t raw[telemetry::AGG_BYTES]{};raw[0]='Q';raw[1]=telemetry::VERSION;raw[2]=(uint8_t)NODE_ID;raw[3]=g_telemetryGrantSeq;
 uint8_t count=0;size_t at=6;
 // Keep the transmitting keeper's own measurement in the cache, even without BLE.
 // Read age clock AFTER refresh: a millisecond tick during refresh must not
 // underflow the unsigned age and suppress the keeper snapshot as expired.
 if(keeper)telemetryRefresh();
 const uint32_t now=millis();
 const uint8_t begin=g_telemetryAirCursor;const uint8_t limit=keeper?2:(g_aggPosGrantRecs<2?g_aggPosGrantRecs:2);
 uint8_t picked[2]={0,0};
 // Fresh, changed positions go first. A second pass carries changed status;
 // unchanged cached snapshots no longer consume repeated aggregate airtime.
 for(unsigned pass=0;pass<2&&count<limit;pass++)for(unsigned n=0;n<64&&count<limit;n++){
  const uint8_t index=(uint8_t)((begin+n)%64);auto &e=g_telemetry[index];
  if(!e.used||!e.airPending||now-e.received>30000UL||!telemetryKnown(e.value.node))continue;
  if(!keeper&&!volMapGet(g_volOrphanMap,e.value.node))continue;
  bool chosen=false;for(uint8_t j=0;j<count;j++)if(picked[j]==index)chosen=true;if(chosen)continue;
  auto s=telemetry::aged(e.value,now-e.received);
  const bool fresh=(s.flags&telemetry::POSITION)!=0;
  if((pass==0)!=fresh)continue;
  memcpy(raw+at,&s,sizeof(s));at+=sizeof(s);picked[count]=index;count++;
  g_telemetryAirCursor=(uint8_t)((index+1)%64);
 }
 if(!count)return false;raw[4]=count;raw[at]=telemetry::crc8(raw,at);at++;
 uint32_t air=lsmLoraAirUs((uint32_t)at+MESH_SEC_OVERHEAD,LSM_ACTIVE_SF,LSM_ACTIVE_BW,(uint8_t)(LORA_CR-4));
 uint32_t actual=(uint32_t)((uint64_t)esp_timer_get_time()-g_frameAnchorUs);
 if(actual+air+SLOT_GUARD_US>g_aggPosSlotStartUs+AGG_POS_SLOT_US)return false;
 femTx();int16_t st=LSM_TX(raw,at);rxArmAfterTx();
 if(st==RADIOLIB_ERR_NONE)for(uint8_t j=0;j<count;j++)g_telemetry[picked[j]].airPending=false;
 if(keeper)g_telemetryKeeperSent=g_frameAnchorUs;else{g_aggPosLastTxAnchor=g_frameAnchorUs;g_aggPosGrantMe=false;}
 logRec(LOG_TX,NODE_ID,g_role,0xB5,count,(int16_t)at,(uint32_t)g_telemetryGrantSeq|((uint32_t)(st==RADIOLIB_ERR_NONE)<<31));
#ifndef LSM_LISTEN_ONLY
 if(st==RADIOLIB_ERR_NONE)for(uint8_t i=0;i<raw[4];i++){
  telemetry::Snapshot sent;memcpy(&sent,raw+6+(size_t)i*sizeof(sent),sizeof(sent));
  // Unlike remote-only telemetryTrace, D7 includes this transmitter's own origin.
  logRec(LOG_POS,sent.node,g_role,0xD7,(int16_t)sent.sequence,(int16_t)sent.frame,sent.boot);
 }
#endif // Passive LSM_TX success shim is not an actual radio-driver success.
 return true;
#else
 return false;
#endif
}
static bool telemetryReceiveAggregate(const uint8_t* raw,int len){
 if(len<7||raw[0]!='Q')return false;
 uint8_t count=raw[4],relay=raw[2];
 if(raw[1]!=telemetry::VERSION||!count||count>telemetry::AGG_MAX||len!=7+(int)count*(int)sizeof(telemetry::Snapshot)||raw[len-1]!=telemetry::crc8(raw,len-1)){g_telemetryRejected++;return true;}
 if(relay!=g_secureRxSender||relay!=g_telemetryGrantId||raw[3]!=g_telemetryGrantSeq||!telemetryKnown(relay)){g_senderBindReject++;return true;}
 for(uint8_t i=0;i<count;i++){telemetry::Snapshot s;memcpy(&s,raw+6+i*sizeof(s),sizeof(s));if(s.node!=(uint8_t)NODE_ID)telemetryStore(s,false);}
 return true;
}
static void telemetryKeeperTail(){if(g_role!=3||!g_frameAnchorUs)return;uint32_t off=(uint32_t)((uint64_t)esp_timer_get_time()-g_frameAnchorUs);telemetryAggregateTx(off,true);}
static bool telemetryExportActivate(TelemetryExportChannel& c,bool usb,uint32_t now){
 if(c.active)return true;
 if(c.replay){ // Bounded replay work occurs only after the unchanged host eligibility gate.
  auto &e=g_telemetry[c.replayCursor++];
  if(e.used&&e.value.node!=(uint8_t)NODE_ID&&now-e.received<=30000UL)telemetryExportOffer(c,e.value,e.received,true,usb);
  if(c.replayCursor==64)c.replay=false;
  return false;
 }
 auto* own=telemetryEntry((uint8_t)NODE_ID,false);
 const bool ownPending=own&&own->used&&now-own->received<=30000UL&&(usb?own->usbPending:own->blePending);
 c.remote=c.queue.count&&(!ownPending||!c.preferOwn);
 if(c.remote){
  TelemetryExportQueue::Item dropped{};auto result=c.queue.activate(now,30000UL,dropped);
  if(result!=telemetryexport::Activation::READY){
   if(result==telemetryexport::Activation::EXPIRED)telemetryTrace(usb?0xDA:0xDB,dropped.value);
   return false;
  }
  c.original=c.queue.current.value;c.received=c.queue.current.received;
 }else{
  if(!ownPending)return false;c.original=own->value;c.received=own->received;
  // Clear only at activation. A later own refresh sets its newer pending flag independently.
  if(usb)own->usbPending=false;else own->blePending=false;
 }
 c.preferOwn=!c.preferOwn;c.progress.offset=0;c.active=true;c.shortWitness=false;c.retryWait=false;c.notifyErrorWitness=false;c.message++;
 c.tx=telemetry::aged(c.original,now-c.received);
 return true;
}
static void telemetryHostService(){
 static uint32_t refresh=0;
 uint32_t now=millis();if(now-refresh>=500UL){refresh=now;telemetryRefresh();}
 telemetryExportSync();
 // ORIGINAL dump quiet gate only. Prefix-busy suppresses OTHER text, never its own resumption.
 if(g_serQuiet){g_serDropped++;return;}
 // Host work only in an idle tail. Preserve member/keeper critical slot regions.
 if(g_frameAnchorUs&&g_frameUs){uint32_t off=(uint32_t)(((uint64_t)esp_timer_get_time()-g_frameAnchorUs)%g_frameUs);if(g_frameUs>DYN_JOIN_TAIL_US&&off<g_frameUs-DYN_JOIN_TAIL_US)return;}
 if(g_telemetryReplayRequested.exchange(false,std::memory_order_acq_rel))telemetryReplay();
 const bool usb=g_exportUsb.queue.enabled||g_exportUsb.active;
 const bool ble=g_exportBle.queue.enabled;
 if(!usb&&!ble)return;
 const bool useBle=g_exportFair.choose(usb,ble);auto &c=useBle?g_exportBle:g_exportUsb;
 if(!telemetryExportActivate(c,!useBle,now))return;
 // A zero-returning API has emitted no prefix: age may still be refreshed.
 // After the first accepted byte/fragment the exact serialized bytes freeze.
 if(!c.progress.offset)c.tx=telemetry::aged(c.original,now-c.received);
 if(now-c.received>30000UL&&(!c.progress.offset||useBle)){
  telemetryTrace(useBle?0xDB:0xDA,c.tx);if(c.remote)c.queue.expireActive();if(c.progress.offset)c.fragmentAborts++;c.active=false;return;
 }
 if(useBle){
  if(c.retryWait){if((int32_t)(now-c.retryAfter)<0)return;c.retryWait=false;}
  if(now-c.last<1UL)return;c.last=now;
  if(g_exportBleGeneration.load(std::memory_order_acquire)!=c.transportGeneration||!g_exportBleConnected.load(std::memory_order_acquire)||!g_exportBleSubscribed.load(std::memory_order_acquire))return;
  uint8_t b[39];uint16_t available=g_bleMtu>7?g_bleMtu-7:16;uint8_t capacity=(uint8_t)(available>35?35:available);
  uint8_t n=(uint8_t)(35-c.progress.offset);if(n>capacity)n=capacity;
  b[0]=0xA7;b[1]=c.message;b[2]=(uint8_t)c.progress.offset;b[3]=35;memcpy(b+4,((uint8_t*)&c.tx)+c.progress.offset,n);
  const bool stackAccepted=telemetryBleNotifyChecked(b,n+4);
  if(g_exportBleGeneration.load(std::memory_order_acquire)!=c.transportGeneration){
   c.fragmentAborts++;c.queue.setEnabled(false);c.active=false;c.progress.offset=0;c.replay=false;return;
  }
  if(!stackAccepted){
   if(!c.notifyErrorWitness){logRec(LOG_POS,c.tx.node,g_role,0xDC,(int16_t)c.tx.sequence,(int16_t)g_bleNotifyStats.lastCode,c.tx.boot);c.notifyErrorWitness=true;}
   if(c.progress.offset)c.fragmentAborts++;
   // Broadcast may have partially succeeded. Restart the WHOLE message under a new transport ID.
   // Never retry a mid-frame fragment against a recipient that already consumed it.
   c.progress.offset=0;c.message++;c.retryAfter=now+10UL;c.retryWait=true;g_bleNotifyStats.restarts++;return;
  }
  c.progress.advance(n,35);
  if(c.progress.done(35)){
   telemetryTrace(0xD5,c.tx); // Request completed; still not a client acknowledgement.
   logRec(LOG_POS,c.tx.node,g_role,0xDD,(int16_t)c.tx.sequence,(int16_t)c.tx.frame,c.tx.boot); // Host stack accepted every fragment.
   if(c.remote)c.queue.finish(now);c.active=false;
  }
 }else{
  int available=Serial.availableForWrite();if(available<=0)return;
  if(!c.progress.offset&&available<40)return; // Preserve the previous whole-frame start preflight.
  if(!c.progress.offset){c.bytes[0]=0xAA;c.bytes[1]=0x55;c.bytes[2]=5;c.bytes[3]=35;memcpy(c.bytes+4,&c.tx,35);uint8_t ck=0;for(unsigned i=2;i<39;i++)ck^=c.bytes[i];c.bytes[39]=ck;}
  SerialOutputTry output;if(!output.held||g_serQuiet)return;
  g_telemetryUsbPrefixBusy.store(true,std::memory_order_release);
  size_t requested=40-c.progress.offset;if(requested>(size_t)available)requested=(size_t)available;
  size_t written=Serial.write(c.bytes+c.progress.offset,requested);
  if(written<requested){c.shortWrites++;if(!c.shortWitness){telemetryTrace(0xD4,c.tx);c.shortWitness=true;}}
  if(!c.progress.advance(written,40))return; // Contract violation stays busy/fail closed until restart.
  if(!c.progress.offset)g_telemetryUsbPrefixBusy.store(false,std::memory_order_release);
  if(c.progress.done(40)){
   telemetryTrace(0xD3,c.tx);if(c.remote)c.queue.finish(now);if(now-c.received>30000UL)c.lateCompletions++;c.active=false;g_telemetryUsbFrames++;g_telemetryUsbPrefixBusy.store(false,std::memory_order_release);
  }
 }
}

static bool telemetryRelayTransmit(const uint8_t* raw,uint32_t receivedUs){
 telemetry::Snapshot input;memcpy(&input,raw,sizeof(input));if(!telemetry::valid(input))return false;
 const uint32_t actual=(uint32_t)((uint64_t)esp_timer_get_time()-g_frameAnchorUs);
 const uint32_t replyBase=g_memberBaseUs+(uint32_t)g_nSlotsThisFrame*g_slotUsLive;
 if(actual<replyBase||actual+g_txLatUs+g_memberAirUsLive+SLOT_GUARD_US>replyBase+g_relayReplySlotUs)return false;
 auto value=telemetry::aged(input,((uint32_t)esp_timer_get_time()-receivedUs)/1000UL);
 femTx();int16_t st=LSM_TX((uint8_t*)&value,sizeof(value));rxArmAfterTx();
 logRec(LOG_TX,NODE_ID,g_role,0xB8,value.node,(int16_t)value.ageMs,(uint32_t)value.sequence|((uint32_t)(st==RADIOLIB_ERR_NONE)<<31));
 return st==RADIOLIB_ERR_NONE;
}
