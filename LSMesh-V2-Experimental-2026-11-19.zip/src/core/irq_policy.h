#pragma once
namespace irqpolicy {
constexpr bool verified(bool configured,int installResult){return configured&&installResult==0;}
constexpr bool diagnosticAllowed(char c){return c=='I'||c=='u'||c=='Z';}
}
