#pragma once
#include <stdint.h>
namespace ownedslot {
enum Reason:uint8_t { FIT=0, STALE=1, EXPIRED=2, BUDGET=3 };
// Operational predictive allowances, not hard latency bounds.
constexpr uint64_t UNCERTAINTY_US=6000; // operational reserve; V34 observed engage underestimate >4ms
constexpr Reason fits(bool same,uint64_t now,uint64_t end,uint64_t air,
                      uint64_t engage,uint64_t rx,uint64_t uncertainty=UNCERTAINTY_US) {
  return !same ? STALE : now>=end ? EXPIRED :
         air>end-now ? BUDGET :
         engage>end-now-air ? BUDGET :
         rx>end-now-air-engage ? BUDGET :
         uncertainty>end-now-air-engage-rx ? BUDGET : FIT;
}
}
