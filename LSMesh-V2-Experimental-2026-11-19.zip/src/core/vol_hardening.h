// v7.29.9 VOLUNTEER RELAY: Phase 1 HARDENING
// Stuart design, 2026-09-25, bugs fixed 2026-09-26, v7.29.12 missing lookups added
//
// GATE 1: depth test (relayer_depth < source_depth, unchanged from v7.29.8)
// GATE 2: per-neighbor dedup (16 slots, key=(srcId, relayerId, hop), oldest-first eviction)
// GATE 3: claim TTL with AND-guard (wraparound fix: both cooldown AND TTL must pass)
//
// HARDENING 1: claim table cap (8 live claims per node, oldest-first eviction)
// HARDENING 2: re-arm cooldown (4 sequences, atomic death+cooldown, proper eviction)
// HARDENING 3: fleet budget (Phase 3 - deferred with depth map)

#ifndef VOL_HARDENING_H
#define VOL_HARDENING_H

#include <stdint.h>
#include <string.h>

// ============================================================================
// CLAIM STRUCTURE - per-node claim table
// ============================================================================

struct VolClaim {
  uint8_t srcId;            // source node ID (who we're relaying)
  uint8_t relayerId;        // who is relaying (set when claim is born; readonly)
  uint8_t hop;              // hop count at claim time (progress counter)
  int8_t born_seq;          // sequence at birth (for TTL wraparound fix)
};

static_assert(sizeof(VolClaim) == 4, "VolClaim must be 4 bytes");

// ============================================================================
// COOLDOWN TABLE - guards re-arming after a claim dies
// ============================================================================

struct VolCooldown {
  uint8_t srcId;            // source node ID
  uint8_t pad1;
  int8_t expiry_seq;        // sequence at which cooldown expires
  int8_t pad2;
};

static_assert(sizeof(VolCooldown) == 4, "VolCooldown must be 4 bytes");

// ============================================================================
// DEDUP TABLE - per-neighbor (srcId, relayerId, hop) dedup, 16 slots
// Gate 2: kills ping-pong on repeat arrivals
// ============================================================================

struct VolDedupEntry {
  uint8_t srcId;
  uint8_t relayerId;
  uint8_t hop;
  int8_t seq_seen;          // sequence at which this (src, relayer, hop) was seen
};

static_assert(sizeof(VolDedupEntry) == 4, "VolDedupEntry must be 4 bytes");

// ============================================================================
// CLAIM TABLE HARD CAP & EVICTION
// ============================================================================

// Max 8 live claims per node (HARDENING 1)
static constexpr uint8_t VOL_CARRY_N = 8;

// TTL: claim expires after 32 sequences (GATE 3)
static constexpr int8_t VOL_CLAIM_TTL_SEQS = 32;

// Re-arm cooldown: blocked for 4 sequences after a claim dies (HARDENING 2)
static constexpr int8_t VOL_REARM_COOLDOWN_SEQS = 4;

// Dedup table size, 16 slots (GATE 2)
static constexpr uint8_t VOL_DEDUP_N = 16;

// ============================================================================
// ARM, KILL, TTL CHECK FUNCTIONS
// ============================================================================

// Arm a claim at the current sequence
inline void volClaimArm(VolClaim* claim, uint8_t srcId, uint8_t relayerId, 
                         uint8_t hop, int8_t current_seq) {
  claim->srcId = srcId;
  claim->relayerId = relayerId;
  claim->hop = hop;
  claim->born_seq = current_seq;
}

// Kill a claim (mark as dead)
inline void volClaimKill(VolClaim* claim) {
  claim->srcId = 0;  // mark as dead (srcId 0 = invalid)
}

// Check if a claim is alive
inline bool volClaimIsAlive(const VolClaim* claim) {
  return claim->srcId != 0;
}

// Get the age of a claim (wraparound-safe)
inline int8_t volClaimAge(const VolClaim* claim, int8_t current_seq) {
  return (int8_t)(current_seq - claim->born_seq);
}

// Check if a claim has expired by TTL (does not modify, read-only)
inline bool volClaimExpiredByTTL(const VolClaim* claim, int8_t current_seq) {
  if (!volClaimIsAlive(claim)) return true;
  int8_t age = volClaimAge(claim, current_seq);
  return age >= VOL_CLAIM_TTL_SEQS;
}

// ============================================================================
// COOLDOWN HELPERS
// ============================================================================

// Get the age of a cooldown (wraparound-safe)
inline int8_t volCooldownAge(const VolCooldown* cooldown, int8_t current_seq) {
  return (int8_t)(current_seq - cooldown->expiry_seq);
}

// Check if a cooldown is still active (not yet expired)
inline bool volCooldownActive(const VolCooldown* cooldown, int8_t current_seq) {
  if (cooldown->srcId == 0) return false;  // dead entry
  int8_t age = volCooldownAge(cooldown, current_seq);
  return age < 0;  // expiry_seq in the future
}

// ============================================================================
// EVICTION HELPERS - oldest-first by sequence
// ============================================================================

// NOTE: FindOldest implementations use modular age comparison: (now - stored) as int8_t
// This handles int8_t wraparound correctly (128-255 wraps to negative ages)

// Find the oldest-born claim in the table (largest age)
inline uint8_t volClaimFindOldest(const VolClaim* claims, int8_t now) {
  int8_t best = -128;
  uint8_t idx = VOL_CARRY_N;
  for (uint8_t i = 0; i < VOL_CARRY_N; i++) {
    if (!volClaimIsAlive(&claims[i])) continue;
    int8_t age = (int8_t)(now - claims[i].born_seq);
    if (age > best) { best = age; idx = i; }
  }
  return idx;
}

// Find the oldest-expiring cooldown in the table (largest age)
inline uint8_t volCooldownFindOldest(const VolCooldown* cd, int8_t now) {
  int8_t best = -128;
  uint8_t idx = VOL_CARRY_N;
  for (uint8_t i = 0; i < VOL_CARRY_N; i++) {
    if (cd[i].srcId == 0) continue;
    int8_t age = (int8_t)(now - cd[i].expiry_seq);
    if (age > best) { best = age; idx = i; }
  }
  return idx;
}

// Find the oldest-seen entry in the dedup table (largest age)
inline uint8_t volDedupFindOldest(const VolDedupEntry* entries, int8_t now) {
  int8_t best = -128;
  uint8_t idx = VOL_DEDUP_N;
  for (uint8_t i = 0; i < VOL_DEDUP_N; i++) {
    if (entries[i].srcId == 0) continue;
    int8_t age = (int8_t)(now - entries[i].seq_seen);
    if (age > best) { best = age; idx = i; }
  }
  return idx;
}

// Find a free slot in the claim table (srcId == 0)
inline uint8_t volClaimFindFree(const VolClaim* claims) {
  for (uint8_t i = 0; i < VOL_CARRY_N; i++) {
    if (!volClaimIsAlive(&claims[i])) {
      return i;
    }
  }
  return VOL_CARRY_N;
}

// Find a free slot in the cooldown table
inline uint8_t volCooldownFindFree(const VolCooldown* cooldowns) {
  for (uint8_t i = 0; i < VOL_CARRY_N; i++) {
    if (cooldowns[i].srcId == 0) {  // dead
      return i;
    }
  }
  return VOL_CARRY_N;
}

// Find a free slot in the dedup table
inline uint8_t volDedupFindFree(const VolDedupEntry* entries) {
  for (uint8_t i = 0; i < VOL_DEDUP_N; i++) {
    if (entries[i].srcId == 0) {  // dead
      return i;
    }
  }
  return VOL_DEDUP_N;
}

// v7.29.12: lookups by source, and a table-level arm that returns the slot it used.
// The v7.29.9 merge called these from volCarryDecide but they were never written,
// which is why v7.29.11 did not compile.

// Find the live claim for srcId, VOL_CARRY_N if none
inline uint8_t volClaimFindBySource(const VolClaim* claims, uint8_t srcId) {
  if (srcId == 0) return VOL_CARRY_N;
  for (uint8_t i = 0; i < VOL_CARRY_N; i++) {
    if (volClaimIsAlive(&claims[i]) && claims[i].srcId == srcId) return i;
  }
  return VOL_CARRY_N;
}

// Find the cooldown entry for srcId (active or lapsed), VOL_CARRY_N if none
inline uint8_t volCooldownFindBySource(const VolCooldown* cd, uint8_t srcId) {
  if (srcId == 0) return VOL_CARRY_N;
  for (uint8_t i = 0; i < VOL_CARRY_N; i++) {
    if (cd[i].srcId == srcId) return i;
  }
  return VOL_CARRY_N;
}

// Arm srcId into the claim table. Order: refresh the existing claim for srcId,
// else take a free slot, else overwrite the oldest-born claim (the caller records
// the victim's cooldown before calling). Returns the slot armed, VOL_CARRY_N if none.
inline uint8_t volClaimArmTable(VolClaim* claims, uint8_t srcId, uint8_t relayerId,
                                uint8_t hop, int8_t current_seq) {
  if (srcId == 0) return VOL_CARRY_N;
  uint8_t idx = volClaimFindBySource(claims, srcId);
  if (idx >= VOL_CARRY_N) idx = volClaimFindFree(claims);
  if (idx >= VOL_CARRY_N) idx = volClaimFindOldest(claims, current_seq);
  if (idx >= VOL_CARRY_N) return VOL_CARRY_N;
  volClaimArm(&claims[idx], srcId, relayerId, hop, current_seq);
  return idx;
}

// Find a dedup entry by (srcId, relayerId, hop)
inline uint8_t volDedupFind(const VolDedupEntry* entries, uint8_t srcId, 
                             uint8_t relayerId, uint8_t hop) {
  for (uint8_t i = 0; i < VOL_DEDUP_N; i++) {
    if (entries[i].srcId == srcId && entries[i].relayerId == relayerId &&
        entries[i].hop == hop) {
      return i;
    }
  }
  return VOL_DEDUP_N;
}

#endif  // VOL_HARDENING_H
