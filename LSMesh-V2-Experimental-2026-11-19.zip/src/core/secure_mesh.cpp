#include "secure_mesh.h"
#include <Arduino.h>
#include <Preferences.h>
#include <mbedtls/gcm.h>
#include <mbedtls/md.h>
#include <string.h>
#include <limits.h>

namespace securemesh {
static Preferences store;
static uint8_t root[32], selfId;
static uint32_t epoch, rejects, storeMax;
static uint64_t counter;
static bool active=false, opened=false;
// Keep the receiver reboot penalty bounded: a restarted receiver may need to
// wait until a live sender passes this already-reserved range. Throughput is
// supplied by draining several senders per maintenance tail, not by making
// this crash-safe skip range enormous.
static constexpr uint64_t REPLAY_RESERVE_AHEAD = 31;
struct Replay {
  uint32_t epoch; uint64_t count; bool loaded;
  uint32_t savedEpoch; uint64_t savedCount;
  uint32_t pendingEpoch; uint64_t pendingCount; bool pending;
};
// V7.31 removes the old bench-fleet ceiling. Admission remains independently
// restricted by KS_NODE_ALLOW_LIST, so widening replay state does not admit an
// unknown badge; it lets a production allow-list safely address all 64 seats.
static constexpr uint8_t MAX_SECURE_NODE_ID = 64;
static Replay replay[MAX_SECURE_NODE_ID + 1];
static uint32_t lastAuthenticated09Epoch=0;
EpochMetadata epochMetadata(){
  uint8_t saved[12]={}; uint32_t durableEpoch=0;
  const size_t size=opened ? store.getBytesLength("rx9") : 0;
  const bool present=size!=0;
  const bool valid=present && size==12 && store.getBytes("rx9",saved,12)==12;
  if(valid)for(int i=0;i<4;++i)durableEpoch=(durableEpoch<<8)|saved[i];
  return {selfId,epoch,lastAuthenticated09Epoch,replay[9].epoch,replay[9].savedEpoch,
          durableEpoch,replay[9].loaded,present,valid,
          opened ? store.getUInt("epoch",UINT32_MAX) : UINT32_MAX,
          opened && store.getType("epoch")==PT_U32};
}
static uint32_t get32(const uint8_t *p) { uint32_t x=0; for(int i=0;i<4;i++) x=(x<<8)|p[i]; return x; }
static uint64_t get64(const uint8_t *p) { uint64_t x=0; for(int i=0;i<8;i++) x=(x<<8)|p[i]; return x; }
static void put32(uint8_t *p,uint32_t x) { for(int i=3;i>=0;i--) {p[i]=(uint8_t)x; x>>=8;} }
static void put64(uint8_t *p,uint64_t x) { for(int i=7;i>=0;i--) {p[i]=(uint8_t)x; x>>=8;} }
static bool keyFor(uint8_t sender,uint8_t key[32]) {
  const uint8_t label[]={ 'K','S','M','E','S','H',36,sender };
  auto md=mbedtls_md_info_from_type(MBEDTLS_MD_SHA256);
  return md && mbedtls_md_hmac(md,root,sizeof(root),label,sizeof(label),key)==0;
}
bool begin(uint8_t self) {
  active=false; // Every failed initialization remains unable to transmit.
  selfId=self;
  opened=store.begin("ksmesh36",false);
  if(!opened || self<1 || self>MAX_SECURE_NODE_ID || store.getBytesLength("key")!=32) return false;
  if(store.getBytes("key",root,32)!=32) return false;
  if(store.getType("epoch")!=PT_U32) return false;
  uint32_t old=store.getUInt("epoch",UINT32_MAX);
  if(old==0 || old==UINT32_MAX) return false;
  epoch=old+1;
  // Reserve a new boot epoch durably BEFORE any transmission. Never wrap.
  if(store.putUInt("epoch",epoch)!=sizeof(epoch)) return false;
  if(store.getType("epoch")!=PT_U32 || store.getUInt("epoch",0)!=epoch) return false;
  counter=0; active=true; return true;
}
bool ready(){return active;}
bool provision(const uint8_t key[32]) {
  // Existing keys, including malformed typed entries, are never overwritten.
  if(!opened || active || !key || store.getType("key")!=PT_INVALID) return false;
  uint8_t any=0; for(int i=0;i<32;i++) any|=key[i];
  if(!any) return false;
  uint32_t next=1;
  const PreferenceType type=store.getType("epoch");
  if(type!=PT_INVALID){
    if(type!=PT_U32) return false;
    const uint32_t old=store.getUInt("epoch",UINT32_MAX);
    if(old==0 || old>=UINT32_MAX-1) return false; // Leave room for the required boot.
    next=old+1; // A retry without a key advances rather than resets the epoch.
  }
  if(store.putUInt("epoch",next)!=sizeof(next)) return false;
  if(store.getType("epoch")!=PT_U32 || store.getUInt("epoch",0)!=next) return false;
  // Commit key last: a key is never enrolled without a verified epoch record.
  return store.putBytes("key",key,32)==32;
}
bool seal(const uint8_t *plain,size_t len,uint8_t *wire,size_t &wireLen) {
  if(!active || !plain || !wire || !len || len>MESH_SEC_MAX_PLAIN ||
     wireLen<len+MESH_SEC_OVERHEAD || counter==UINT64_MAX) return false;
  wire[0]='S'; wire[1]='M'; wire[2]=36; wire[3]=selfId;
  put32(wire+4,epoch); put64(wire+8,++counter);
  uint8_t key[32]; if(!keyFor(selfId,key)) return false;
  mbedtls_gcm_context ctx; mbedtls_gcm_init(&ctx);
  int rc=mbedtls_gcm_setkey(&ctx,MBEDTLS_CIPHER_ID_AES,key,256);
  if(!rc) rc=mbedtls_gcm_crypt_and_tag(&ctx,MBEDTLS_GCM_ENCRYPT,len,
    wire+4,12,wire,16,plain,wire+16,16,wire+16+len);
  mbedtls_gcm_free(&ctx); memset(key,0,sizeof(key));
  if(rc) return false;
  wireLen=len+MESH_SEC_OVERHEAD; return true;
}
bool open(const uint8_t *wire,size_t len,uint8_t *plain,size_t &plainLen,uint8_t &sender) {
  sender=0;
  if(!active || !wire || !plain || len<=MESH_SEC_OVERHEAD || len>255 ||
     len-MESH_SEC_OVERHEAD>plainLen || wire[0]!='S' || wire[1]!='M' || wire[2]!=36 ||
     wire[3]<1 || wire[3]>MAX_SECURE_NODE_ID || wire[3]==selfId) {++rejects; return false;}
  const uint8_t id=wire[3]; const uint32_t ep=get32(wire+4); const uint64_t seq=get64(wire+8);
  if(!ep || !seq) {++rejects; return false;}
  uint8_t key[32]; if(!keyFor(id,key)) {++rejects; return false;}
  mbedtls_gcm_context ctx; mbedtls_gcm_init(&ctx);
  int rc=mbedtls_gcm_setkey(&ctx,MBEDTLS_CIPHER_ID_AES,key,256);
  const size_t n=len-MESH_SEC_OVERHEAD;
  if(!rc) rc=mbedtls_gcm_auth_decrypt(&ctx,n,wire+4,12,wire,16,wire+16+n,16,wire+16,plain);
  mbedtls_gcm_free(&ctx); memset(key,0,sizeof(key));
  if(rc) {memset(plain,0,n); ++rejects; return false;}
  if(id==9)lastAuthenticated09Epoch=ep; // only after successful GCM authentication
  Replay &r=replay[id]; char name[8]; snprintf(name,sizeof(name),"rx%u",id);
  if(!r.loaded) {
    uint8_t old[12]={}; const size_t size=store.getBytesLength(name);
    if(size && (size!=12 || store.getBytes(name,old,12)!=12)) {memset(plain,0,n); ++rejects; return false;}
    r.epoch=get32(old); r.count=get64(old+4); r.loaded=true;
    r.savedEpoch=r.epoch; r.savedCount=r.count;
  }
  // Strict monotonic receive policy. Reordered older physical transmissions
  // are discarded; relays seal fresh hop envelopes with their own counters.
  if(ep<r.epoch || (ep==r.epoch && seq<=r.count)) {memset(plain,0,n); ++rejects; return false;}
  // Reserve future counters durably BEFORE delivering any in that range.
  // No flash write in the receive path. The first out-of-range packet is
  // deliberately dropped until service() commits its reservation in idle time.
  if(ep!=r.savedEpoch || seq>r.savedCount) {
    if(!r.pending || ep>r.pendingEpoch || (ep==r.pendingEpoch && seq>r.pendingCount)) {
      r.pendingEpoch=ep;
      r.pendingCount=seq>UINT64_MAX-REPLAY_RESERVE_AHEAD
        ? UINT64_MAX : seq+REPLAY_RESERVE_AHEAD;
      r.pending=true;
    }
    memset(plain,0,n); ++rejects; return false;
  }
  r.epoch=ep; r.count=seq;
  // Experimental: ask the existing quiet-tail writer to extend coverage
  // while this authenticated packet is still inside its committed range.
  // The extension stays at most 31 counters ahead of this accepted packet.
  if(r.savedCount!=UINT64_MAX && r.savedCount-seq<=8) {
    const uint64_t next=seq>UINT64_MAX-REPLAY_RESERVE_AHEAD
      ? UINT64_MAX : seq+REPLAY_RESERVE_AHEAD;
    if(!r.pending || ep>r.pendingEpoch ||
       (ep==r.pendingEpoch && next>r.pendingCount)) {
      r.pendingEpoch=ep; r.pendingCount=next; r.pending=true;
    }
  }
  plainLen=n; sender=id; return true;
}
static bool persistPending(uint8_t id) {
  if(!active || id<1 || id>MAX_SECURE_NODE_ID) return false;
  Replay &r=replay[id];
  if(!r.pending) return false;
    uint8_t next[12]; put32(next,r.pendingEpoch); put64(next+4,r.pendingCount);
    char name[8]; snprintf(name,sizeof(name),"rx%u",id);
    const uint32_t start=micros();
    const bool saved=store.putBytes(name,next,12)==12;
    const uint32_t elapsed=micros()-start; if(elapsed>storeMax) storeMax=elapsed;
    if(saved) {
      r.savedEpoch=r.pendingEpoch; r.savedCount=r.pendingCount;
      if(r.epoch<r.savedEpoch) {r.epoch=r.savedEpoch; r.count=0;}
      r.pending=false;
    }
  return saved;
}
bool serviceSender(uint8_t sender) {
  return persistPending(sender);
}
void service() {
  if(!active) return;
  static uint8_t cursor=1;
  for(unsigned k=0;k<MAX_SECURE_NODE_ID;k++) {
    const uint8_t id=cursor; cursor=cursor==MAX_SECURE_NODE_ID ? 1 : cursor+1;
    if(persistPending(id)) return; // At most one durable write per call.
  }
}
uint32_t rejected(){return rejects;}
uint32_t maxStoreUs(){return storeMax;}
}
