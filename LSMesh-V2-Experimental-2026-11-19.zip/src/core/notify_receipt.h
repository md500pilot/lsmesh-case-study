#pragma once
#include <stdint.h>
namespace telemetryexport {
// A synchronous host-stack result, never an over-the-air/client acknowledgement.
struct NotifyReceipt {
 uint16_t callbacks=0,accepted=0;int lastError=0;
 constexpr void note(bool notification,int code){
  ++callbacks;
  if(notification&&code==0)++accepted;
  else lastError=code?code:-9002;
 }
 constexpr bool complete(uint16_t expected)const{
  return expected>0&&callbacks==expected&&accepted==expected&&lastError==0;
 }
 constexpr int failureCode()const{return lastError?lastError:-9001;}
};
}
