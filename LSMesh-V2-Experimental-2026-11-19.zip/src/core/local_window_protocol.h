#pragma once

#include <stddef.h>
#include <stdint.h>

// V7.31 experimental protocol definitions. These types are deliberately
// dormant until LSM_LOCAL_AGGREGATE_WINDOWS is enabled. The proven V7.30
// field path remains byte-for-byte unchanged while the new parser, authority
// and scheduling rules are validated.
namespace lsm731 {

static constexpr uint8_t PROTOCOL_VERSION = 1;
static constexpr uint8_t MAX_NODE_ID = 64;
static constexpr uint8_t MAX_DEPTH = 7;
static constexpr uint8_t MAX_CHANNEL = 7;
static constexpr uint8_t MAX_SIBLING_SLOT = 31;
static constexpr uint8_t MAX_PLAN_DELTAS = 16;
static constexpr uint8_t MAX_DIGEST_RECORDS = 16;
static constexpr uint8_t MAX_DIGEST_CHUNKS = 8;
static constexpr uint8_t MAX_LEASE_FRAMES = 8;
static constexpr uint32_t MAX_AUTHORITY_EPOCH_JUMP = 4;

enum class Kind : uint8_t {
  Plan = 0xD1,
  Digest = 0xD2,
  Demand = 0xD3,
  Aggregate = 0xD4,
  Seed = 0xD5,
};

#pragma pack(push, 1)
struct ControlHeader {
  uint8_t kind;
  uint8_t version;
  uint8_t immediateSender;
  uint8_t keeperId;
  uint32_t authorityEpoch;
  uint32_t sequence;
};

struct PlanDelta {
  uint8_t childId;
  uint8_t parentId;
  uint8_t depth;
  uint8_t channel;
  uint8_t siblingSlot;
  uint8_t leaseFrames;
};

struct OfficerDelta {
  uint8_t officerId;
  int16_t eastCm;
  int16_t northCm;
  int16_t altitudeDm;
  int8_t floor;
  uint8_t confidence;
  uint8_t age100ms;
  uint16_t originSequence;
};

struct PlanPacket {
  ControlHeader header;
  uint32_t topologyEpoch;
  uint8_t count;
  uint8_t flags;
  PlanDelta records[MAX_PLAN_DELTAS];
};

struct DigestPacket {
  ControlHeader header;
  uint16_t digestSequence;
  uint8_t chunkIndex;
  uint8_t chunkCount;
  uint8_t recordCount;
  OfficerDelta records[MAX_DIGEST_RECORDS];
};
#pragma pack(pop)

static_assert(sizeof(ControlHeader) == 12, "V7.31 control header layout changed");
static_assert(sizeof(PlanDelta) == 6, "V7.31 plan delta layout changed");
static_assert(sizeof(OfficerDelta) == 12, "V7.31 officer delta layout changed");
static_assert(sizeof(PlanPacket) <= 223, "plan exceeds secure plaintext limit");
static_assert(sizeof(DigestPacket) <= 223, "digest exceeds secure plaintext limit");

inline bool validNode(uint8_t id) { return id >= 1 && id <= MAX_NODE_ID; }

inline bool validHeader(const ControlHeader& h, uint8_t authenticatedSender,
                        uint32_t currentEpoch, uint32_t lastSequence,
                        bool hasKeeperAuthority) {
  if (h.version != PROTOCOL_VERSION || !validNode(h.immediateSender) ||
      !validNode(h.keeperId) || h.immediateSender != authenticatedSender ||
      h.sequence == 0) return false;
  if (h.authorityEpoch < currentEpoch ||
      h.authorityEpoch > currentEpoch + MAX_AUTHORITY_EPOCH_JUMP) return false;
  if (h.authorityEpoch == currentEpoch && h.sequence <= lastSequence) return false;
  const Kind kind = static_cast<Kind>(h.kind);
  if ((kind == Kind::Plan || kind == Kind::Digest) && !hasKeeperAuthority) return false;
  return kind == Kind::Plan || kind == Kind::Digest || kind == Kind::Demand ||
         kind == Kind::Aggregate || kind == Kind::Seed;
}

inline bool validPlanDelta(const PlanDelta& d, uint8_t parentDepth,
                           bool childSeated, bool parentSeated,
                           bool parentInChildAncestry) {
  return validNode(d.childId) && validNode(d.parentId) && d.childId != d.parentId &&
         childSeated && parentSeated && !parentInChildAncestry &&
         d.depth >= 1 && d.depth <= MAX_DEPTH && parentDepth + 1 == d.depth &&
         d.channel <= MAX_CHANNEL && d.siblingSlot <= MAX_SIBLING_SLOT &&
         d.leaseFrames >= 1 && d.leaseFrames <= MAX_LEASE_FRAMES;
}

inline bool validDigestShape(const DigestPacket& p) {
  return p.chunkCount >= 1 && p.chunkCount <= MAX_DIGEST_CHUNKS &&
         p.chunkIndex < p.chunkCount && p.recordCount >= 1 &&
         p.recordCount <= MAX_DIGEST_RECORDS;
}

}  // namespace lsm731

