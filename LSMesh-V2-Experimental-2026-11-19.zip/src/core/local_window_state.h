#pragma once

#include <stdint.h>
#include <string.h>

#include "local_window_protocol.h"

// Small, allocation-free state machines for the V7.31 local-window cut.  They
// are kept separate from the radio scheduler so the two rules that protect
// fleet continuity are explicit and independently testable:
//
//  1. A member keeps a valid parent plan for its bounded lease.  A single lost
//     plan packet cannot orphan it, while an expired plan cannot live forever.
//  2. Keeper roster life advances only on the officer's immutable origin
//     sequence.  Duplicate aggregate copies and relay churn never manufacture
//     liveness for a departed badge.
namespace lsm731 {

inline bool sequence16Newer(uint16_t candidate, uint16_t previous) {
  const uint16_t distance = (uint16_t)(candidate - previous);
  return distance != 0u && distance < 0x8000u;
}

struct ParentLeaseState {
  uint8_t parentId;
  uint8_t depth;
  uint8_t channel;
  uint8_t siblingSlot;
  uint8_t leaseFramesLeft;
  uint32_t topologyEpoch;
  bool valid;

  void clear() { memset(this, 0, sizeof(*this)); }

  bool apply(const PlanDelta& delta, uint8_t selfId, uint8_t parentDepth,
             bool selfSeated, bool parentSeated, bool parentInMyAncestry,
             uint32_t incomingTopologyEpoch) {
    if (delta.childId != selfId || incomingTopologyEpoch < topologyEpoch ||
        !validPlanDelta(delta, parentDepth, selfSeated, parentSeated,
                        parentInMyAncestry)) return false;
    parentId = delta.parentId;
    depth = delta.depth;
    channel = delta.channel;
    siblingSlot = delta.siblingSlot;
    leaseFramesLeft = delta.leaseFrames;
    topologyEpoch = incomingTopologyEpoch;
    valid = true;
    return true;
  }

  // Called once for each authenticated advancing keeper plan.  Returns true
  // only on the edge where orphan search should begin.
  bool advanceWithoutRefresh() {
    if (!valid) return false;
    if (leaseFramesLeft > 0) --leaseFramesLeft;
    if (leaseFramesLeft != 0) return false;
    valid = false;
    parentId = 0;
    return true;
  }
};

struct OriginLifeEntry {
  uint16_t sequence;
  uint32_t lastAdvanceMs;
  bool initialized;
};

class OriginLifeTable {
 public:
  OriginLifeTable() { clear(); }

  void clear() { memset(entries_, 0, sizeof(entries_)); }

  // Returns true only for a first observation or a strictly advancing 16-bit
  // origin sequence.  Relays may repeat the record, but they may never rewrite
  // this sequence; therefore duplicate paths cannot refresh roster life.
  bool observe(uint8_t officerId, uint16_t originSequence, uint32_t nowMs) {
    if (!validNode(officerId)) return false;
    OriginLifeEntry& entry = entries_[officerId];
    if (entry.initialized && !sequence16Newer(originSequence, entry.sequence))
      return false;
    entry.sequence = originSequence;
    entry.lastAdvanceMs = nowMs;
    entry.initialized = true;
    return true;
  }

  bool alive(uint8_t officerId, uint32_t nowMs, uint32_t timeoutMs) const {
    if (!validNode(officerId)) return false;
    const OriginLifeEntry& entry = entries_[officerId];
    return entry.initialized && (uint32_t)(nowMs - entry.lastAdvanceMs) <= timeoutMs;
  }

  const OriginLifeEntry& entry(uint8_t officerId) const {
    static const OriginLifeEntry empty = {0, 0, false};
    return validNode(officerId) ? entries_[officerId] : empty;
  }

 private:
  OriginLifeEntry entries_[MAX_NODE_ID + 1];
};

}  // namespace lsm731
