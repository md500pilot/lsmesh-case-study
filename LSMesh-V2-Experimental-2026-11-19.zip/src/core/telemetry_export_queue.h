#pragma once
#include <stdint.h>
#include <stddef.h>
namespace telemetryexport {
enum class Activation:uint8_t { EMPTY,READY,EXPIRED,GENERATION };
template<class Snapshot,size_t Capacity> struct Queue {
 static_assert(Capacity>0,"Queue must be bounded and nonempty");
 struct Item { uint32_t received=0,generation=0;bool replay=false;Snapshot value{}; };
 struct Stats {uint32_t offered=0,live=0,replay=0,enqueued=0,duplicate=0,inactive=0,overflow=0,expired=0,disabled=0,aborted=0,completed=0,highwater=0,maxResidence=0;};
 struct Offer {bool queued=false,dropped=false;Item victim{};};
 Item pending[Capacity]{},current{};size_t head=0,count=0;bool active=false,enabled=false;uint32_t generation=0;Stats stats{};
 static constexpr bool same(const Snapshot&a,const Snapshot&b){return a.node==b.node&&a.boot==b.boot&&a.sequence==b.sequence&&a.frame==b.frame;}
 constexpr bool contains(const Snapshot&s)const{
  if(active&&same(current.value,s))return true;
  for(size_t i=0;i<count;i++)if(same(pending[(head+i)%Capacity].value,s))return true;
  return false;
 }
 constexpr void setEnabled(bool on,bool preserveActive=false){
  if(on==enabled)return;enabled=on;++generation;
  if(!on){stats.disabled+=(uint32_t)count;head=count=0;if(active&&!preserveActive){active=false;stats.aborted++;}}
 }
 constexpr Offer offer(const Snapshot&s,uint32_t received,bool replay=false){
  Offer result{};stats.offered++;if(replay)stats.replay++;else stats.live++;
  if(!enabled){stats.inactive++;return result;}
  if(contains(s)){stats.duplicate++;return result;}
  if(count==Capacity){result.dropped=true;result.victim=pending[head];head=(head+1)%Capacity;count--;stats.overflow++;}
  pending[(head+count)%Capacity]=Item{received,generation,replay,s};count++;stats.enqueued++;result.queued=true;
  if(count>stats.highwater)stats.highwater=(uint32_t)count;return result;
 }
 constexpr Activation activate(uint32_t now,uint32_t ttl,Item& dropped){
  if(active)return Activation::READY;if(!enabled||!count)return Activation::EMPTY;
  Item item=pending[head];head=(head+1)%Capacity;count--;
  const uint32_t age=now-item.received;
  if(age>stats.maxResidence)stats.maxResidence=age;
  if(age>ttl){stats.expired++;dropped=item;return Activation::EXPIRED;}
  if(item.generation!=generation){stats.aborted++;dropped=item;return Activation::GENERATION;}
  current=item;active=true;return Activation::READY;
 }
 constexpr void finish(uint32_t now){if(!active)return;uint32_t age=now-current.received;if(age>stats.maxResidence)stats.maxResidence=age;active=false;stats.completed++;}
 constexpr void expireActive(){if(active){active=false;stats.expired++;}}
 constexpr bool conserved()const{return stats.offered==stats.enqueued+stats.duplicate+stats.inactive&&stats.live+stats.replay==stats.offered&&stats.enqueued==count+(active?1u:0u)+stats.completed+stats.overflow+stats.expired+stats.disabled+stats.aborted;}
};
struct Progress {size_t offset=0;constexpr bool advance(size_t returned,size_t length){if(returned>length-offset)return false;offset+=returned;return true;}constexpr bool done(size_t length)const{return offset==length;}};
struct Fair {bool nextBle=false;constexpr bool choose(bool usb,bool ble){if(usb&&ble){bool pick=nextBle;nextBle=!nextBle;return pick;}return ble;}};
}
