#include <cassert>
#include <cstdint>
#include <cstdio>
#include <set>
uint8_t g_anchorHops=0,g_schedTiers=2,g_role=1;
bool g_pubMapValid=true,seated=false;
int buffered=0;
std::set<uint8_t> once;
constexpr int RELAY_MAX_HOPS=8,LOG_STATE=4,NODE_ID=1;
bool pubIdHas(uint8_t){return seated;}
bool aggEqOnceHas(uint8_t id){return once.count(id)!=0;}
void aggEqOnceSet(uint8_t id){once.insert(id);}
void aggBufAdd(uint8_t,uint32_t,uint32_t,bool first){assert(!first);buffered++;}
uint32_t g_frame=56;
template<class... T> void logRec(T...){}
#include "baseline.inc"
#include "candidate.inc"
void reset(uint8_t depth,uint8_t tiers){g_anchorHops=depth;g_schedTiers=tiers;g_pubMapValid=true;seated=false;buffered=0;once.clear();}
int main(){
 reset(0,2);assert(!baselineReaggregate(9,123,2));assert(buffered==0);
 reset(0,2);assert(candidateReaggregate(9,123,2));assert(buffered==1);
 reset(1,2);assert(candidateReaggregate(9,123,2));assert(buffered==1);
 assert(!candidateReaggregate(9,123,2));assert(buffered==1);
 reset(0,1);assert(candidateReaggregate(9,123,2));
 reset(0,0);assert(!candidateReaggregate(9,123,2));
 reset(0,2);seated=true;assert(!candidateReaggregate(9,123,2));
 reset(255,2);assert(!candidateReaggregate(9,123,2));
 reset(2,3);assert(!candidateReaggregate(9,123,1));
 reset(0,7);assert(!candidateReaggregate(9,123,7));
 reset(0,7);assert(!candidateReaggregate(9,123,255));
 unsigned cases=0,changed=0;
 for(unsigned depth=0;depth<8;depth++)for(unsigned tiers=0;tiers<8;tiers++)for(unsigned incoming=0;incoming<9;incoming++){
  reset(depth,tiers);bool before=baselineReaggregate(9,123,incoming);
  reset(depth,tiers);bool after=candidateReaggregate(9,123,incoming);cases++;
  if(after){assert(depth+1<=tiers);assert(incoming>=depth+1);assert(incoming+1<8);}
  assert(!(before&&!after));
  if(before!=after)changed++;
 }
 std::printf("PASS: captured depth2/tier2 case fails baseline and passes candidate; one-shot, seated, missing anchor, backward and hop ceiling guards preserved.\n");
 std::printf("PASS: %u topology cases; %u previously blocked uphill/equal-depth cases admitted; no previous valid case removed.\n",cases,changed);
}
