static bool baselineReaggregate(uint8_t sid, uint32_t tok, uint8_t inHops){
  if (g_anchorHops == 255) return false;
  if (!(inHops + 1 < RELAY_MAX_HOPS && inHops + 1 <= g_schedTiers)) return false;   // ceiling, v7.19.0 brick6
  if (g_pubMapValid && pubIdHas(sid)) return false;   // item 6: already seated, discovery is over for this id
  if (inHops > (uint8_t)(g_anchorHops + 1)) { aggBufAdd(sid, tok, g_frame, false); return true; }   // deeper: climb. v7.28.103: secondhand, never latches g_admitId
  if (inHops == (uint8_t)(g_anchorHops + 1)) {                                                // equal: once
    if (aggEqOnceHas(sid)) return false;
    aggEqOnceSet(sid);
    aggBufAdd(sid, tok, g_frame, false);   // v7.28.103: secondhand, never latches g_admitId
    logRec(LOG_STATE, NODE_ID, g_role, 0xAC, (int16_t)sid, (int16_t)inHops, (uint32_t)g_anchorHops);   // v7.28.102: aux 0xAC = equal-depth one-shot taken
    return true;
  }
  return false;   // shallower than us: it is already closer to the keeper than we are
}